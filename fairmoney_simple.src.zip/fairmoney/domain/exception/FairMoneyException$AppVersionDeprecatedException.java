package fairmoney.domain.exception;

import com.fairmoney.domain.exception.FairMoneyException;

public final class AppVersionDeprecatedException extends FairMoneyException {
  public static final AppVersionDeprecatedException f = new AppVersionDeprecatedException();
  
  public AppVersionDeprecatedException() {
    super(null, 1, null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\domain\exception\FairMoneyException$AppVersionDeprecatedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
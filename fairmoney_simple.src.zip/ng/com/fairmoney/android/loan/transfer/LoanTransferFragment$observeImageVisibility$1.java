package ng.com.fairmoney.android.loan.transfer;

import android.widget.ImageView;
import d.o.s;
import f.b.a.c;
import f.b.a.h;

public final class LoanTransferFragment$observeImageVisibility$1<T> implements s<LoanTransferDetails> {
  public final void onChanged(LoanTransferDetails paramLoanTransferDetails) {
    if (paramLoanTransferDetails != null) {
      h h = c.a(LoanTransferFragment.this).a(Integer.valueOf(paramLoanTransferDetails.getIconRes()));
      if (paramLoanTransferDetails.getRoundIcon()) {
        imageView = LoanTransferFragment.access$getRoundLoanTransferImage$p(LoanTransferFragment.this);
      } else {
        imageView = LoanTransferFragment.access$getSquareLoanTransferImage$p(LoanTransferFragment.this);
      } 
      h.a(imageView);
      ImageView imageView = LoanTransferFragment.access$getRoundLoanTransferImage$p(LoanTransferFragment.this);
      boolean bool = paramLoanTransferDetails.getRoundIcon();
      boolean bool1 = false;
      if (bool) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
      imageView = LoanTransferFragment.access$getSquareLoanTransferImage$p(LoanTransferFragment.this);
      byte b = bool1;
      if (paramLoanTransferDetails.getRoundIcon())
        b = 8; 
      imageView.setVisibility(b);
      LoanTransferFragment.access$getTvLoanTransferText$p(LoanTransferFragment.this).setText(LoanTransferFragment.this.getString(paramLoanTransferDetails.getTextRes()));
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\transfer\LoanTransferFragment$observeImageVisibility$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import android.view.MenuItem;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NavigationListener implements BottomNavigationView.d {
  public boolean onNavigationItemSelected(MenuItem paramMenuItem) {
    switch (paramMenuItem.getItemId()) {
      default:
        return false;
      case 2131296849:
        HomeActivity.this.displayReferralFragment();
        return true;
      case 2131296792:
        HomeActivity.this.displayBillsFragment();
        return true;
      case 2131296789:
        HomeActivity.this.displayPayFragment();
        return true;
      case 2131296304:
        break;
    } 
    HomeActivity.this.displayAccountFragment();
    return true;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\HomeActivity$NavigationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
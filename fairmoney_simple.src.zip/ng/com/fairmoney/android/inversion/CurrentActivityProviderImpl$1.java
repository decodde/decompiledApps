package ng.com.fairmoney.android.inversion;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import j.q.d.k;

public final class null implements Application.ActivityLifecycleCallbacks {
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    k.b(paramActivity, "activity");
    CurrentActivityProviderImpl.access$setCurrentActivity$p(CurrentActivityProviderImpl.this, paramActivity);
  }
  
  public void onActivityDestroyed(Activity paramActivity) {
    k.b(paramActivity, "activity");
    if (paramActivity == CurrentActivityProviderImpl.access$getCurrentActivity$p(CurrentActivityProviderImpl.this))
      CurrentActivityProviderImpl.access$setCurrentActivity$p(CurrentActivityProviderImpl.this, null); 
  }
  
  public void onActivityPaused(Activity paramActivity) {
    k.b(paramActivity, "activity");
  }
  
  public void onActivityResumed(Activity paramActivity) {
    k.b(paramActivity, "activity");
    CurrentActivityProviderImpl.access$setCurrentActivity$p(CurrentActivityProviderImpl.this, paramActivity);
  }
  
  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {
    k.b(paramActivity, "activity");
    k.b(paramBundle, "outState");
  }
  
  public void onActivityStarted(Activity paramActivity) {
    k.b(paramActivity, "activity");
    CurrentActivityProviderImpl.access$setCurrentActivity$p(CurrentActivityProviderImpl.this, paramActivity);
  }
  
  public void onActivityStopped(Activity paramActivity) {
    k.b(paramActivity, "activity");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\CurrentActivityProviderImpl$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
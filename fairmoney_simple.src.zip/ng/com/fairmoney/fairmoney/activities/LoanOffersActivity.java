package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.android.volley.VolleyError;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.a.b.k;
import f.c.a.a;
import f.d.b.i.c;
import f.d.c.b;
import j.k;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import l.a.a.a.a.i;
import l.a.a.a.a.j;
import l.a.a.a.a.k;
import l.a.a.a.a.l;
import l.a.a.a.a.m;
import l.a.a.a.a.n;
import l.a.a.a.a.o;
import l.a.a.a.a.p;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.loan.offers.LoanOffersViewModel;
import ng.com.fairmoney.fairmoney.activities.form.FormBankActivity;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.models.OfferRefusalReason;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.BackendApi;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.utils.AmountFormatter;
import ng.com.fairmoney.fairmoney.utils.Authentication;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.views.StyledSpinner;
import org.json.JSONObject;

public class LoanOffersActivity extends LoanOfferActivity {
  public StyledSpinner amountSpinner;
  
  public TextWatcher amountTextWatcher;
  
  public Button btTakeLoan;
  
  @Inject
  public y.b factory;
  
  public FrameLayout flLoanOfferDetails;
  
  public List<c> offers;
  
  public StyledSpinner periodSpinner;
  
  public TextWatcher periodTextWatcher;
  
  public BottomSheetBehavior sheetBehavior;
  
  public TextView tvDeclineLoan;
  
  public LoanOffersViewModel viewModel;
  
  private void animateBottomSheetView() {
    if (this.sheetBehavior.f() == 3) {
      this.sheetBehavior.e(4);
    } else if (this.sheetBehavior.f() == 4) {
      this.sheetBehavior.e(3);
    } 
  }
  
  private void createAndAddTextChangedListeners() {
    TextWatcher textWatcher = new TextWatcher() {
        public void afterTextChanged(Editable param1Editable) {
          LoanOffersActivity.this.hideOfferDetails();
          LoanOffersActivity.this.resetMaturitySpinner();
          if (param1Editable.length() != 0)
            LoanOffersActivity.this.setupMaturitySpinnerForAmount(param1Editable.toString()); 
        }
        
        public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        
        public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
      };
    this.amountTextWatcher = textWatcher;
    this.amountSpinner.addTextChangedListener(textWatcher);
    textWatcher = new TextWatcher() {
        public void afterTextChanged(Editable param1Editable) {
          if (param1Editable.length() != 0) {
            LoanOffersActivity loanOffersActivity = LoanOffersActivity.this;
            c c = loanOffersActivity.getOffer(loanOffersActivity.amountSpinner.getText().toString(), LoanOffersActivity.this.periodSpinner.getText().toString());
            if (c != null) {
              LoanOffersActivity.this.displayOfferDetails(c);
            } else {
              LoanOffersActivity.this.hideOfferDetails();
            } 
          } else {
            LoanOffersActivity.this.hideOfferDetails();
          } 
        }
        
        public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        
        public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
      };
    this.periodTextWatcher = textWatcher;
    this.periodSpinner.addTextChangedListener(textWatcher);
  }
  
  private void displayOfferDetails(c paramc) {
    displayLoanOfferDetails(paramc);
    this.flLoanOfferDetails.setVisibility(0);
    this.btTakeLoan.setVisibility(0);
    this.tvDeclineLoan.setVisibility(0);
  }
  
  private List<String> getMaturitiesForAmount(String paramString) {
    ArrayList<String> arrayList = new ArrayList();
    for (c c : this.offers) {
      if (AmountFormatter.format(c.c(), c.a()).contentEquals(paramString) && !arrayList.contains(this.viewModel.getFormattedMaturity(c)))
        arrayList.add(this.viewModel.getFormattedMaturity(c)); 
    } 
    return arrayList;
  }
  
  private c getOffer(String paramString1, String paramString2) {
    for (c c : this.offers) {
      if (AmountFormatter.format(c.c(), c.a()).contentEquals(paramString1) && this.viewModel.getFormattedMaturity(c).contentEquals(paramString2))
        return c; 
    } 
    return null;
  }
  
  private void getUserBvn() {
    RetrofitSession.getInstance((Context)this).getUserManager().getUserBvn(Authentication.getUserId((Context)this), new APIResponse<BankDetails>() {
          public void failure(int param1Int, String param1String) {
            LoanOffersActivity.this.showNewToastMessage(param1String, 0);
            LoanOffersActivity.this.enableAnswers(true);
          }
          
          public void success(BankDetails param1BankDetails) {
            Intent intent = new Intent(LoanOffersActivity.this.getApplicationContext(), FormBankActivity.class);
            intent.putExtra("EXTRA_BVN", param1BankDetails.getBvn());
            LoanOffersActivity.this.startActivity(intent);
            LoanOffersActivity.this.finish();
          }
        });
  }
  
  private void getViews() {
    this.amountSpinner = (StyledSpinner)findViewById(2131296939);
    this.periodSpinner = (StyledSpinner)findViewById(2131296940);
    this.flLoanOfferDetails = (FrameLayout)findViewById(2131296578);
    this.tvDeclineLoan = (TextView)findViewById(2131297169);
    this.btTakeLoan = (Button)findViewById(2131296390);
  }
  
  private void hideOfferDetails() {
    this.flLoanOfferDetails.setVisibility(8);
    this.btTakeLoan.setVisibility(8);
    this.tvDeclineLoan.setVisibility(8);
  }
  
  private void initView() {
    getViews();
    resetAmountSpinner();
    resetMaturitySpinner();
    this.btTakeLoan.setOnClickListener(new TakeLoanClickListener());
    this.tvDeclineLoan.setOnClickListener((View.OnClickListener)new m(this));
  }
  
  private void observeCheckBvn() {
    this.viewModel.getCheckBvn().a((l)this, (s)new p(this));
  }
  
  private void observeLoanOffers() {
    this.viewModel.getLoanOffersState().a((l)this, (s)new l(this));
  }
  
  private String readSelectedRefusalReason() {
    switch (((RadioGroup)findViewById(2131296851)).getCheckedRadioButtonId()) {
      default:
        a.a("No reason selected for refusal reason");
        return "";
      case 2131296778:
        return "other_reason";
      case 2131296569:
        return "fees_too_high";
      case 2131296508:
        return "duration_too_short";
      case 2131296334:
        break;
    } 
    return "amount_too_low";
  }
  
  private String readWrittenRefusalReason() {
    return ((EditText)findViewById(2131296850)).getText().toString();
  }
  
  private void resetAmountSpinner() {
    ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367049, new ArrayList());
    this.amountSpinner.setAdapter((ListAdapter)arrayAdapter);
  }
  
  private void resetMaturitySpinner() {
    ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367049, new ArrayList());
    this.periodSpinner.setAdapter((ListAdapter)arrayAdapter);
    this.periodSpinner.setText(getString(2131820763));
  }
  
  private void selectLoanOffer(c paramc) {
    RetrofitSession.getInstance((Context)this).getLoanManager().selectLoanOffer(paramc, new APIResponse<Object>() {
          public void failure(int param1Int, String param1String) {
            LoanOffersActivity.this.showNewToastMessage(param1String, 0);
            LoanOffersActivity.this.enableAnswers(true);
          }
          
          public void success(Object param1Object) {
            LoanOffersActivity.this.viewModel.onLoanOfferSelected();
          }
        });
  }
  
  private void sendDeclinedFeedback() {
    ((Button)findViewById(2131296909)).setOnClickListener((View.OnClickListener)new i(this));
  }
  
  private void setupAmountSpinner() {
    ArrayList<String> arrayList = new ArrayList();
    for (c c : this.offers) {
      if (!arrayList.contains(AmountFormatter.format(c.c(), c.a())))
        arrayList.add(AmountFormatter.format(c.c(), c.a())); 
    } 
    ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367049, arrayList);
    this.amountSpinner.setAdapter((ListAdapter)arrayAdapter);
  }
  
  private void setupMaturitySpinnerForAmount(String paramString) {
    ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367049, getMaturitiesForAmount(paramString));
    this.periodSpinner.setAdapter((ListAdapter)arrayAdapter);
  }
  
  public void enableAnswers(boolean paramBoolean) {
    this.tvDeclineLoan.setEnabled(paramBoolean);
    this.btTakeLoan.setEnabled(paramBoolean);
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, HomeActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.viewModel = (LoanOffersViewModel)z.a((d)this, this.factory).a(LoanOffersViewModel.class);
    observeCheckBvn();
    observeLoanOffers();
    setTitle(2131820904);
    initView();
    Tracking.sendUniqueEvent((Context)this, new Event("form", "LoanOffers"));
    Intent intent = getIntent();
    if (intent != null && intent.hasExtra("newLoanOffers"))
      this.offers = (List<c>)intent.getSerializableExtra("newLoanOffers"); 
    if (this.offers == null) {
      this.viewModel.getLoanOffers();
    } else {
      setupAmountSpinner();
    } 
  }
  
  public void onOfferDeclinedResponse() {
    cancelDialog();
    BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.b(findViewById(2131296709));
    this.sheetBehavior = bottomSheetBehavior;
    bottomSheetBehavior.a(new DeclinedBottomSheetBehavior());
    animateBottomSheetView();
    LinearLayout linearLayout = (LinearLayout)findViewById(2131296710);
    TextView textView = (TextView)findViewById(2131297188);
    ((RadioButton)findViewById(2131296334)).setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new n(textView));
    ((RadioButton)findViewById(2131296778)).setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new o(linearLayout));
    sendDeclinedFeedback();
  }
  
  public void onPause() {
    this.amountSpinner.removeTextChangedListener(this.amountTextWatcher);
    this.periodSpinner.removeTextChangedListener(this.periodTextWatcher);
    super.onPause();
  }
  
  public void onResume() {
    super.onResume();
    createAndAddTextChangedListeners();
  }
  
  public int provideContentViewId() {
    return 2131492907;
  }
  
  public class DeclinedBottomSheetBehavior extends BottomSheetBehavior.e {
    public DeclinedBottomSheetBehavior() {}
    
    public void onSlide(View param1View, float param1Float) {}
    
    public void onStateChanged(View param1View, int param1Int) {
      if (param1Int == 4) {
        LoanOffersActivity.this.startActivity(new Intent((Context)LoanOffersActivity.this, HomeActivity.class));
        LoanOffersActivity.this.finish();
      } 
    }
  }
  
  public class TakeLoanClickListener implements View.OnClickListener {
    public TakeLoanClickListener() {}
    
    private boolean checkSpinnerIsSelected(StyledSpinner param1StyledSpinner, int param1Int) {
      if (param1StyledSpinner.getText().toString().isEmpty() || param1StyledSpinner.getText().toString().contentEquals(LoanOffersActivity.this.getString(param1Int))) {
        param1StyledSpinner.setTextColor(-65536);
        param1StyledSpinner.setText(LoanOffersActivity.this.getString(param1Int));
        return false;
      } 
      return true;
    }
    
    public void onClick(View param1View) {
      if (checkSpinnerIsSelected(LoanOffersActivity.this.amountSpinner, 2131820901) && checkSpinnerIsSelected(LoanOffersActivity.this.periodSpinner, 2131820914)) {
        LoanOffersActivity loanOffersActivity = LoanOffersActivity.this;
        c c = loanOffersActivity.getOffer(loanOffersActivity.amountSpinner.getText().toString(), LoanOffersActivity.this.periodSpinner.getText().toString());
        if (c != null) {
          LoanOffersActivity.this.btTakeLoan.setEnabled(false);
          LoanOffersActivity.this.tvDeclineLoan.setEnabled(false);
          LoanOffersActivity.this.selectLoanOffer(c);
        } 
      } 
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOffersActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
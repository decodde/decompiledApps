package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class CardViewHolder extends RecyclerView.d0 {
  public CardView cvCard;
  
  public ImageView ivCardMenu;
  
  public ImageView ivCardType;
  
  public RadioButton rbCardPick;
  
  public TextView tvCardExpiredCard;
  
  public TextView tvCardLast4;
  
  public TextView tvCardMainCard;
  
  public TextView tvCardPending;
  
  public CardViewHolder(View paramView) {
    super(paramView);
    this.ivCardType = (ImageView)paramView.findViewById(2131296624);
    this.tvCardLast4 = (TextView)paramView.findViewById(2131297093);
    this.tvCardMainCard = (TextView)paramView.findViewById(2131297091);
    this.ivCardMenu = (ImageView)paramView.findViewById(2131296623);
    this.tvCardExpiredCard = (TextView)paramView.findViewById(2131297092);
    this.tvCardPending = (TextView)paramView.findViewById(2131297099);
    this.rbCardPick = (RadioButton)paramView.findViewById(2131296830);
    this.cvCard = (CardView)paramView.findViewById(2131296461);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CardAdapter$CardViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
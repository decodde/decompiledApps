package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.view.View;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    RejectedActivity.this.startActivity(new Intent((Context)RejectedActivity.this, HomeActivity.class));
    RejectedActivity.this.finish();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\RejectedActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
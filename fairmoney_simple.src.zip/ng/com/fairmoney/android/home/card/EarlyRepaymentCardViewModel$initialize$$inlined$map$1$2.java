package ng.com.fairmoney.android.home.card;

import f.d.b.k.b;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.b;
import j.q.d.k;
import k.a.h2.b;
import kotlin.NoWhenBranchMatchedException;

public final class null implements b<b> {
  public null(EarlyRepaymentCardViewModel$initialize$$inlined$map$1 paramEarlyRepaymentCardViewModel$initialize$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    paramObject = paramObject;
    if (k.a(paramObject, b.b.h)) {
      paramObject = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₦500,000", 6, b.a(5), "wahala", false);
    } else if (k.a(paramObject, b.a.h)) {
      paramObject = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₹50,000", 6, null, "hassle", true);
    } else {
      if (k.a(paramObject, b.c.h))
        throw new IllegalArgumentException(); 
      throw new NoWhenBranchMatchedException();
    } 
    paramObject = b1.emit(paramObject, paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardViewModel$initialize$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
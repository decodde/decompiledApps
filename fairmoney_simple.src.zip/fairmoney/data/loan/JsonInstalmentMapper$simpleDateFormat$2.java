package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonInstalmentMapper;
import j.q.c.a;
import j.q.d.l;
import java.text.SimpleDateFormat;
import java.util.Locale;

public final class null extends l implements a<SimpleDateFormat> {
  public static final null INSTANCE = (null)new Object();
  
  public null() {
    super(0);
  }
  
  public final SimpleDateFormat invoke() {
    return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonInstalmentMapper$simpleDateFormat$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
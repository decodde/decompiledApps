package ng.com.fairmoney.android.payment.history;

import f.d.b.j.a;
import java.util.List;

public final class Success extends PaymentHistoryViewModel.BillState {
  public final List<a> bills;
  
  public Success(List<a> paramList) {
    super(null);
    this.bills = paramList;
  }
  
  public final List<a> getBills() {
    return this.bills;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel$BillState$Success.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
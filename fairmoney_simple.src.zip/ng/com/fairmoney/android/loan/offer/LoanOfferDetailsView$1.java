package ng.com.fairmoney.android.loan.offer;

import d.o.s;

public final class null<T> implements s<LoanOfferDetailsViewModel.LoanOfferDetailsDataState> {
  public final void onChanged(LoanOfferDetailsViewModel.LoanOfferDetailsDataState paramLoanOfferDetailsDataState) {
    if (paramLoanOfferDetailsDataState instanceof LoanOfferDetailsViewModel.LoanOfferDetailsDataState.DisbursementFees) {
      LoanOfferDetailsView.access$updateView(LoanOfferDetailsView.this, (LoanOfferDetailsViewModel.LoanOfferDetailsDataState.DisbursementFees)paramLoanOfferDetailsDataState);
    } else if (paramLoanOfferDetailsDataState instanceof LoanOfferDetailsViewModel.LoanOfferDetailsDataState.Empty) {
      LoanOfferDetailsView.access$hideView(LoanOfferDetailsView.this);
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsView$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
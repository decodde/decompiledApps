package ng.com.fairmoney.android.loan.form.personal;

public final class Hyperverge extends FormPersonalViewModel.FormPersonalState {
  public static final Hyperverge INSTANCE = new Hyperverge();
  
  public Hyperverge() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$FormPersonalState$Hyperverge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
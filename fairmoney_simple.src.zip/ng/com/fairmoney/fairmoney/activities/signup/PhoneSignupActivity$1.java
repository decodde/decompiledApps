package ng.com.fairmoney.fairmoney.activities.signup;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;

public class null implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    Button button = PhoneSignupActivity.access$100(PhoneSignupActivity.this);
    PhoneInputView phoneInputView = PhoneSignupActivity.access$000(PhoneSignupActivity.this);
    boolean bool = false;
    if (phoneInputView.getPhoneNumber(false) != null)
      bool = true; 
    button.setEnabled(bool);
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.inversion;

import android.content.Context;
import f.d.a.l;
import j.q.d.k;
import ng.com.fairmoney.fairmoney.utils.Authentication;

public final class TokenProviderImpl implements l {
  public final Context context;
  
  public TokenProviderImpl(Context paramContext) {
    this.context = paramContext;
  }
  
  public String getToken() {
    String str = Authentication.getAuthToken(this.context);
    k.a(str, "Authentication.getAuthToken(context)");
    return str;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\TokenProviderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
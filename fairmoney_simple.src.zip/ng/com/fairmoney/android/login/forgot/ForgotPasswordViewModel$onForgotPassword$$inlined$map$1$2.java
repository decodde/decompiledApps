package ng.com.fairmoney.android.login.forgot;

import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.b;

public final class null implements b<String> {
  public null(ForgotPasswordViewModel$onForgotPassword$$inlined$map$1 paramForgotPasswordViewModel$onForgotPassword$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    paramObject = paramObject;
    paramObject = b1.emit(new ForgotPasswordViewModel.ForgotPasswordState.Success(ForgotPasswordViewModel$onForgotPassword$$inlined$map$1.this.$phoneNumber$inlined, (String)paramObject), paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordViewModel$onForgotPassword$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
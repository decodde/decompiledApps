package ng.com.fairmoney.fairmoney.activities.login;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;
import d.b.k.c;
import d.l.a.d;
import f.b.a.c;
import f.d.b.k.f;
import java.io.Serializable;
import java.util.Calendar;
import l.a.a.a.a.t.e;
import l.a.a.a.a.t.f;
import l.a.a.a.a.t.g;
import l.a.a.a.a.t.h;
import l.a.a.a.a.t.i;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.forgotpassword.ForgotPasswordActivity;
import ng.com.fairmoney.fairmoney.activities.signup.PhoneSignupEnterOtpActivity;
import ng.com.fairmoney.fairmoney.models.PhoneAuthentication;
import ng.com.fairmoney.fairmoney.models.Session;
import ng.com.fairmoney.fairmoney.models.UssdCode;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.network.model.GenericApiResponse;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.utils.Utils;

public class PhoneLoginActivity extends LoginActivity {
  public static final String SHARED_PREFERENCES_NAME = "CurrentUser";
  
  public Button btPhoneLogin;
  
  public EditText etPassword;
  
  public boolean isRedirectedLogin = false;
  
  public f phoneNumber;
  
  public TextInputLayout tilPassword;
  
  private void displayUnknownAccountPopUp() {
    if (this.isActivityActive) {
      c.a a = new c.a((Context)this);
      a.b("Ok", (DialogInterface.OnClickListener)e.f);
      a.b(2131821221);
      a.a().show();
    } 
  }
  
  private void getIntentExtras() {
    Intent intent = getIntent();
    if (intent != null)
      this.isRedirectedLogin = intent.getBooleanExtra("EXTRA_PHONE_VERIFICATION", false); 
  }
  
  private PhoneAuthentication getPhoneAuthentication() {
    PhoneAuthentication phoneAuthentication = new PhoneAuthentication();
    phoneAuthentication.setPhone(this.phoneNumber.toString());
    phoneAuthentication.setPassword(this.etPassword.getText().toString());
    phoneAuthentication.setAndroidAppInstanceGuid(Utils.getAndroidAppInstanceGuid((Context)this));
    return phoneAuthentication;
  }
  
  private void initHeader() {
    ImageView imageView = (ImageView)findViewById(2131296648);
    TextView textView = (TextView)findViewById(2131297177);
    SharedPreferences sharedPreferences = getSharedPreferences("CurrentUser", 0);
    if (this.isRedirectedLogin) {
      textView.setText(2131821163);
      imageView.setVisibility(8);
      return;
    } 
    String str = sharedPreferences.getString("et_form_firstname", null);
    if (str == null) {
      textView.setText(2131821243);
      imageView.setVisibility(8);
    } else {
      textView.setText(getString(2131821244, new Object[] { str }));
      str = sharedPreferences.getString("profile_picture", null);
      if (str != null)
        c.a((d)this).a(str).a(imageView).a(getResources().getDrawable(2131231056)); 
    } 
  }
  
  private void initLoginButton() {
    Button button = (Button)findViewById(2131296403);
    this.btPhoneLogin = button;
    button.setOnClickListener((View.OnClickListener)new g(this));
  }
  
  private void initPhoneInputView() {
    this.pivLogin.addTextChangedListener(new PhoneTextWatcher(this.etPassword));
    this.pivLogin.setOnEditorActionListener((TextView.OnEditorActionListener)new i(this));
  }
  
  private void initView() {
    this.pivLogin = (PhoneInputView)getSupportFragmentManager().a(2131296799);
    this.tilPassword = (TextInputLayout)findViewById(2131297019);
    ((TextView)findViewById(2131297119)).setOnClickListener((View.OnClickListener)new f(this));
    this.etPassword = (EditText)findViewById(2131296549);
    initPhoneInputView();
    this.etPassword.addTextChangedListener(new PasswordTextWatcher(this.tilPassword, this.pivLogin));
    this.etPassword.setImeOptions(6);
    this.etPassword.setOnEditorActionListener((TextView.OnEditorActionListener)new h(this));
  }
  
  private void manageSuccessfulLogin(Session paramSession) {
    String str = paramSession.getStatus();
    logLoginResult("Phone", true);
    Tracking.setUserIdentifier(paramSession.getAuthenticationToken(), paramSession.getApplicationId());
    getSharedPreferences("CurrentUser", 0).edit().putString("AuthToken", paramSession.getAuthenticationToken()).putLong("LastLogin", Calendar.getInstance().getTimeInMillis()).putString("ApplicationId", paramSession.getApplicationId()).putString("et_form_email", paramSession.getUserEmail()).apply();
    Tracking.sendUniqueEvent((Context)this, new Event("application", "phoneLogin"));
    goToNextScreen(str);
  }
  
  private void phoneLogin() {
    final PhoneAuthentication phoneAuthentication = getPhoneAuthentication();
    RetrofitSession.getInstance((Context)this).getUserLoginManager().phoneLogin(phoneAuthentication, new GenericApiResponse<Session, UssdCode>() {
          public void failure(int param1Int, String param1String, UssdCode param1UssdCode) {
            PhoneLoginActivity.this.logLoginResult("Phone", false);
            if (param1Int == 17) {
              PhoneLoginActivity.this.displayUnknownAccountPopUp();
            } else if (param1Int == 401) {
              PhoneLoginActivity.this.etPassword.setText(2131820763);
              PhoneLoginActivity.this.showNewToastMessage(param1String, 1);
            } else {
              PhoneLoginActivity phoneLoginActivity;
              if (param1Int == 12 || param1Int == 18) {
                phoneLoginActivity = PhoneLoginActivity.this;
                phoneLoginActivity.savePhoneNumber(phoneLoginActivity.phoneNumber);
                PhoneLoginActivity.this.verifyPhoneNumber(phoneAuthentication, param1Int, param1UssdCode);
              } else {
                PhoneLoginActivity.this.showNewToastMessage((String)phoneLoginActivity, 1);
              } 
            } 
            PhoneLoginActivity.this.makeButtonEnabled(true);
          }
          
          public void success(Session param1Session) {
            PhoneLoginActivity phoneLoginActivity = PhoneLoginActivity.this;
            phoneLoginActivity.savePhoneNumber(phoneLoginActivity.phoneNumber);
            PhoneLoginActivity.this.manageSuccessfulLogin(param1Session);
          }
        });
  }
  
  private void verifyPhoneNumber(PhoneAuthentication paramPhoneAuthentication, int paramInt, UssdCode paramUssdCode) {
    Intent intent = new Intent((Context)this, PhoneSignupEnterOtpActivity.class);
    intent.putExtra("EXTRA_PHONE_NUMBER", (Serializable)this.phoneNumber);
    intent.putExtra("EXTRA_PASSWORD", paramPhoneAuthentication.getPassword());
    boolean bool = true;
    intent.putExtra("EXTRA_PHONE_VERIFICATION", true);
    intent.putExtra("EXTRA_CASE_CODE", paramInt);
    if (paramInt != 18)
      bool = false; 
    intent.putExtra("EXTRA_CAN_SKIP_PHONE_VERIFICATION", bool);
    if (paramUssdCode != null) {
      String str = paramUssdCode.getUssdCode();
    } else {
      paramPhoneAuthentication = null;
    } 
    intent.putExtra("EXTRA_USSD_CODE", (String)paramPhoneAuthentication);
    startActivity(intent);
    finish();
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {
    int i;
    this.btPhoneLogin.setEnabled(paramBoolean);
    Button button = this.btPhoneLogin;
    if (paramBoolean) {
      i = 2131820683;
    } else {
      i = 2131820897;
    } 
    button.setText(i);
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, WelcomeActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.isAuthMandatory = false;
    getIntentExtras();
    initHeader();
    initView();
    initLoginButton();
    getPhoneNumber();
  }
  
  public int provideContentViewId() {
    return 2131492912;
  }
  
  public class PasswordTextWatcher implements TextWatcher {
    public PhoneInputView pivLogin;
    
    public TextInputLayout tilPassword;
    
    public PasswordTextWatcher(TextInputLayout param1TextInputLayout, PhoneInputView param1PhoneInputView) {
      this.tilPassword = param1TextInputLayout;
      this.pivLogin = param1PhoneInputView;
    }
    
    public void afterTextChanged(Editable param1Editable) {
      if (param1Editable.length() == 4) {
        this.tilPassword.setError(null);
        if (this.pivLogin.getPhoneNumber(false) != null)
          PhoneLoginActivity.this.btPhoneLogin.setEnabled(true); 
      } else {
        PhoneLoginActivity.this.btPhoneLogin.setEnabled(false);
      } 
    }
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
  }
  
  public class PhoneTextWatcher implements TextWatcher {
    public EditText etPassword;
    
    public PhoneTextWatcher(EditText param1EditText) {
      this.etPassword = param1EditText;
    }
    
    public void afterTextChanged(Editable param1Editable) {
      if (this.etPassword.length() == 4) {
        Button button = PhoneLoginActivity.this.btPhoneLogin;
        PhoneInputView phoneInputView = PhoneLoginActivity.this.pivLogin;
        boolean bool = false;
        if (phoneInputView.getPhoneNumber(false) != null)
          bool = true; 
        button.setEnabled(bool);
      } 
    }
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\PhoneLoginActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
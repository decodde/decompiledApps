package ng.com.fairmoney.android.loan.offer;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class LoanOfferDetailsView_MembersInjector implements a<LoanOfferDetailsView> {
  public final Provider<y.b> factoryProvider;
  
  public LoanOfferDetailsView_MembersInjector(Provider<y.b> paramProvider) {
    this.factoryProvider = paramProvider;
  }
  
  public static a<LoanOfferDetailsView> create(Provider<y.b> paramProvider) {
    return new LoanOfferDetailsView_MembersInjector(paramProvider);
  }
  
  public static void injectFactory(LoanOfferDetailsView paramLoanOfferDetailsView, y.b paramb) {
    paramLoanOfferDetailsView.factory = paramb;
  }
  
  public void injectMembers(LoanOfferDetailsView paramLoanOfferDetailsView) {
    injectFactory(paramLoanOfferDetailsView, (y.b)this.factoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsView_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
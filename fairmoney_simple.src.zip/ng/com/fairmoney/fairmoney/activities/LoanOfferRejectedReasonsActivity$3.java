package ng.com.fairmoney.fairmoney.activities;

import android.text.Html;
import d.o.s;
import ng.com.fairmoney.fairmoney.models.RejectionMessage;

public class null implements s<RejectionMessage> {
  public void onChanged(RejectionMessage paramRejectionMessage) {
    if (paramRejectionMessage != null) {
      LoanOfferRejectedReasonsActivity.access$300(LoanOfferRejectedReasonsActivity.this).setText((CharSequence)Html.fromHtml(paramRejectionMessage.getMessage()));
      LoanOfferRejectedReasonsActivity.access$400(LoanOfferRejectedReasonsActivity.this).setVisibility(8);
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOfferRejectedReasonsActivity$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
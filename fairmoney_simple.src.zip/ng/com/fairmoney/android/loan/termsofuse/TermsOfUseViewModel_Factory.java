package ng.com.fairmoney.android.loan.termsofuse;

import f.d.b.i.e;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class TermsOfUseViewModel_Factory implements d<TermsOfUseViewModel> {
  public final Provider<e> loanUseCaseProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public TermsOfUseViewModel_Factory(Provider<h> paramProvider, Provider<e> paramProvider1) {
    this.userUseCaseProvider = paramProvider;
    this.loanUseCaseProvider = paramProvider1;
  }
  
  public static TermsOfUseViewModel_Factory create(Provider<h> paramProvider, Provider<e> paramProvider1) {
    return new TermsOfUseViewModel_Factory(paramProvider, paramProvider1);
  }
  
  public static TermsOfUseViewModel newInstance(h paramh, e parame) {
    return new TermsOfUseViewModel(paramh, parame);
  }
  
  public TermsOfUseViewModel get() {
    return newInstance((h)this.userUseCaseProvider.get(), (e)this.loanUseCaseProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.forgotpassword;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import f.d.b.k.f;
import java.io.Serializable;
import l.a.a.a.a.r.e;
import l.a.a.a.a.r.f;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.login.PasswordActivity;
import ng.com.fairmoney.fairmoney.models.PhoneAuthentication;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class ForgotPasswordConfirmPasswordActivity extends PasswordActivity {
  public Button btNext;
  
  public String firstPassword;
  
  public f phoneNumber;
  
  public String token;
  
  private void goToPreviousActivity() {
    Intent intent = new Intent((Context)this, ForgotPasswordSelectPasswordActivity.class);
    intent.putExtra("EXTRA_TOKEN", this.token);
    intent.putExtra("EXTRA_PHONE_NUMBER", (Serializable)this.phoneNumber);
    startActivity(intent);
    finish();
  }
  
  private void initBackArrow() {
    ((ImageView)findViewById(2131296631)).setOnClickListener((View.OnClickListener)new e(this));
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {
    this.btNext.setEnabled(paramBoolean);
  }
  
  public void makePasswordAction() {
    PhoneAuthentication phoneAuthentication = new PhoneAuthentication();
    phoneAuthentication.setNewPassword(this.firstPassword);
    phoneAuthentication.setPhone(this.phoneNumber.toString());
    RetrofitSession.getInstance((Context)this).getUserLoginManager().forgotPasswordUpdatePassword(this.token, phoneAuthentication, new APIResponse<Object>() {
          public void failure(int param1Int, String param1String) {
            ForgotPasswordConfirmPasswordActivity.this.showNewToastMessage(param1String, 0);
            ForgotPasswordConfirmPasswordActivity.this.makeButtonEnabled(true);
          }
          
          public void success(Object param1Object) {
            param1Object = new Event("application", "phoneLogin");
            Tracking.sendUniqueEvent((Context)ForgotPasswordConfirmPasswordActivity.this, (Event)param1Object);
            ForgotPasswordConfirmPasswordActivity.this.goToNextScreen(null);
          }
        });
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    goToPreviousActivity();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((BaseActivity)this).isAuthMandatory = false;
    initBackArrow();
    initPasswords();
    if (getIntent() != null) {
      this.token = getIntent().getStringExtra("EXTRA_TOKEN");
      this.phoneNumber = (f)getIntent().getSerializableExtra("EXTRA_PHONE_NUMBER");
      this.firstPassword = getIntent().getStringExtra("password");
    } 
    Button button = (Button)findViewById(2131296385);
    this.btNext = button;
    button.setOnClickListener((View.OnClickListener)new f(this));
  }
  
  public int provideContentViewId() {
    return 2131492895;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\forgotpassword\ForgotPasswordConfirmPasswordActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
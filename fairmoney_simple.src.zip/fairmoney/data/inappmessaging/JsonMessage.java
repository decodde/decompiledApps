package fairmoney.data.inappmessaging;

import j.q.d.k;

public final class JsonMessage {
  public final String id;
  
  public final String message;
  
  public final String title;
  
  public final String url;
  
  public JsonMessage(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.id = paramString1;
    this.title = paramString2;
    this.message = paramString3;
    this.url = paramString4;
  }
  
  public final String component1() {
    return this.id;
  }
  
  public final String component2() {
    return this.title;
  }
  
  public final String component3() {
    return this.message;
  }
  
  public final String component4() {
    return this.url;
  }
  
  public final com.fairmoney.data.inappmessaging.JsonMessage copy(String paramString1, String paramString2, String paramString3, String paramString4) {
    k.b(paramString1, "id");
    k.b(paramString2, "title");
    k.b(paramString3, "message");
    return new com.fairmoney.data.inappmessaging.JsonMessage(paramString1, paramString2, paramString3, paramString4);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.inappmessaging.JsonMessage) {
        paramObject = paramObject;
        if (k.a(this.id, ((com.fairmoney.data.inappmessaging.JsonMessage)paramObject).id) && k.a(this.title, ((com.fairmoney.data.inappmessaging.JsonMessage)paramObject).title) && k.a(this.message, ((com.fairmoney.data.inappmessaging.JsonMessage)paramObject).message) && k.a(this.url, ((com.fairmoney.data.inappmessaging.JsonMessage)paramObject).url))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getId() {
    return this.id;
  }
  
  public final String getMessage() {
    return this.message;
  }
  
  public final String getTitle() {
    return this.title;
  }
  
  public final String getUrl() {
    return this.url;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    String str = this.id;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    str = this.title;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    str = this.message;
    if (str != null) {
      b3 = str.hashCode();
    } else {
      b3 = 0;
    } 
    str = this.url;
    if (str != null)
      i = str.hashCode(); 
    return ((b1 * 31 + b2) * 31 + b3) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonMessage(id=");
    stringBuilder.append(this.id);
    stringBuilder.append(", title=");
    stringBuilder.append(this.title);
    stringBuilder.append(", message=");
    stringBuilder.append(this.message);
    stringBuilder.append(", url=");
    stringBuilder.append(this.url);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\inappmessaging\JsonMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
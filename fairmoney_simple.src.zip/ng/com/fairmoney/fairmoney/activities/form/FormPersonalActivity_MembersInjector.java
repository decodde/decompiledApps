package ng.com.fairmoney.fairmoney.activities.form;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class FormPersonalActivity_MembersInjector implements a<FormPersonalActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public FormPersonalActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<FormPersonalActivity> create(Provider<y.b> paramProvider) {
    return new FormPersonalActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(FormPersonalActivity paramFormPersonalActivity, y.b paramb) {
    paramFormPersonalActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(FormPersonalActivity paramFormPersonalActivity) {
    injectViewModelFactory(paramFormPersonalActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormPersonalActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.payment.history;

public final class Loading extends PaymentHistoryViewModel.BillState {
  public final boolean isLoading;
  
  public Loading(boolean paramBoolean) {
    super(null);
    this.isLoading = paramBoolean;
  }
  
  public final boolean isLoading() {
    return this.isLoading;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel$BillState$Loading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
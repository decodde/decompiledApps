package ng.com.fairmoney.fairmoney.activities;

public final class Loading extends DataUploadViewModel.LoanOffersState {
  public final boolean isLoading;
  
  public Loading(boolean paramBoolean) {
    super(null);
    this.isLoading = paramBoolean;
  }
  
  public final boolean isLoading() {
    return this.isLoading;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadViewModel$LoanOffersState$Loading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
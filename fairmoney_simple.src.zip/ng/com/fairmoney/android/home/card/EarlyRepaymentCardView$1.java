package ng.com.fairmoney.android.home.card;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import d.i.f.a;
import d.o.s;
import j.q.d.k;

public final class null<T> implements s<EarlyRepaymentCardViewModel.EarlyRepaymentSate> {
  public null(Context paramContext) {}
  
  public final void onChanged(EarlyRepaymentCardViewModel.EarlyRepaymentSate paramEarlyRepaymentSate) {
    View view = EarlyRepaymentCardView.this.findViewById(2131296333);
    k.a(view, "findViewById<TextView>(R.id.amount_and_duration)");
    ((TextView)view).setText(this.$context.getString(2131820855, new Object[] { paramEarlyRepaymentSate.getAmount(), Integer.valueOf(paramEarlyRepaymentSate.getDuration()) }));
    if (paramEarlyRepaymentSate.getDiscount() != null) {
      view = EarlyRepaymentCardView.this.findViewById(2131296493);
      k.a(view, "findViewById<TextView>(R.id.discount)");
      ((TextView)view).setText(this.$context.getString(2131820742, new Object[] { paramEarlyRepaymentSate.getDiscount() }));
    } else {
      view = EarlyRepaymentCardView.this.findViewById(2131296494);
      k.a(view, "findViewById<View>(R.id.discount_container)");
      view.setVisibility(8);
    } 
    view = EarlyRepaymentCardView.this.findViewById(2131296846);
    k.a(view, "findViewById<TextView>(R.id.reapplication)");
    ((TextView)view).setText(this.$context.getString(2131820880, new Object[] { paramEarlyRepaymentSate.getIssueWording() }));
    if (paramEarlyRepaymentSate.getNeutralCurrency())
      ((ImageView)EarlyRepaymentCardView.this.findViewById(2131296649)).setImageDrawable(a.c(this.$context, 2131231037)); 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardView$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
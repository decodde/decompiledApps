package ng.com.fairmoney.android.loan.form.personal;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.q;
import j.q.d.k;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel$goToNextActivity$2", f = "FormPersonalViewModel.kt", l = {96}, m = "invokeSuspend")
public final class FormPersonalViewModel$goToNextActivity$2 extends k implements q<b<? super FormPersonalViewModel.FormPersonalState>, Throwable, d<? super k>, Object> {
  public Object L$0;
  
  public Object L$1;
  
  public int label;
  
  public b p$;
  
  public Throwable p$0;
  
  public FormPersonalViewModel$goToNextActivity$2(d paramd) {
    super(3, paramd);
  }
  
  public final d<k> create(b<? super FormPersonalViewModel.FormPersonalState> paramb, Throwable paramThrowable, d<? super k> paramd) {
    k.b(paramb, "$this$create");
    k.b(paramThrowable, "it");
    k.b(paramd, "continuation");
    FormPersonalViewModel$goToNextActivity$2 formPersonalViewModel$goToNextActivity$2 = new FormPersonalViewModel$goToNextActivity$2(paramd);
    formPersonalViewModel$goToNextActivity$2.p$ = paramb;
    formPersonalViewModel$goToNextActivity$2.p$0 = paramThrowable;
    return (d<k>)formPersonalViewModel$goToNextActivity$2;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2, Object paramObject3) {
    return ((FormPersonalViewModel$goToNextActivity$2)create((b<? super FormPersonalViewModel.FormPersonalState>)paramObject1, (Throwable)paramObject2, (d<? super k>)paramObject3)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    Object object = c.a();
    int i = this.label;
    if (i != 0) {
      if (i == 1) {
        object = this.L$1;
        object = this.L$0;
        g.a(paramObject);
      } else {
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
    } else {
      g.a(paramObject);
      paramObject = this.p$;
      Throwable throwable = this.p$0;
      FormPersonalViewModel.FormPersonalState.Error error = new FormPersonalViewModel.FormPersonalState.Error(throwable);
      this.L$0 = paramObject;
      this.L$1 = throwable;
      this.label = 1;
      if (paramObject.emit(error, (d)this) == object)
        return object; 
    } 
    return k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$goToNextActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
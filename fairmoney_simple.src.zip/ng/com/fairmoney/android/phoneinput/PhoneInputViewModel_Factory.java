package ng.com.fairmoney.android.phoneinput;

import f.d.b.b;
import f.d.b.d.a;
import f.d.b.k.c;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class PhoneInputViewModel_Factory implements d<PhoneInputViewModel> {
  public final Provider<a> countryUseCaseProvider;
  
  public final Provider<c> indicatorMapperProvider;
  
  public final Provider<b> phoneNumberValidatorProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public PhoneInputViewModel_Factory(Provider<b> paramProvider, Provider<a> paramProvider1, Provider<h> paramProvider2, Provider<c> paramProvider3) {
    this.phoneNumberValidatorProvider = paramProvider;
    this.countryUseCaseProvider = paramProvider1;
    this.userUseCaseProvider = paramProvider2;
    this.indicatorMapperProvider = paramProvider3;
  }
  
  public static PhoneInputViewModel_Factory create(Provider<b> paramProvider, Provider<a> paramProvider1, Provider<h> paramProvider2, Provider<c> paramProvider3) {
    return new PhoneInputViewModel_Factory(paramProvider, paramProvider1, paramProvider2, paramProvider3);
  }
  
  public static PhoneInputViewModel newInstance(b paramb, a parama, h paramh, c paramc) {
    return new PhoneInputViewModel(paramb, parama, paramh, paramc);
  }
  
  public PhoneInputViewModel get() {
    return newInstance((b)this.phoneNumberValidatorProvider.get(), (a)this.countryUseCaseProvider.get(), (h)this.userUseCaseProvider.get(), (c)this.indicatorMapperProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
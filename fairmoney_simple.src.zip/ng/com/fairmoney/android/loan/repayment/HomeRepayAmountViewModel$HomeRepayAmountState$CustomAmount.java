package ng.com.fairmoney.android.loan.repayment;

public final class CustomAmount extends HomeRepayAmountViewModel.HomeRepayAmountState {
  public CustomAmount(int paramInt) {
    super(paramInt, null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$HomeRepayAmountState$CustomAmount.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
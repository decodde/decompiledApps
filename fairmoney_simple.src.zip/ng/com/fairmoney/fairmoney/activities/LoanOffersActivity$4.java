package ng.com.fairmoney.fairmoney.activities;

import android.content.Intent;
import ng.com.fairmoney.fairmoney.activities.form.FormBankActivity;
import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<BankDetails> {
  public void failure(int paramInt, String paramString) {
    LoanOffersActivity.this.showNewToastMessage(paramString, 0);
    LoanOffersActivity.this.enableAnswers(true);
  }
  
  public void success(BankDetails paramBankDetails) {
    Intent intent = new Intent(LoanOffersActivity.this.getApplicationContext(), FormBankActivity.class);
    intent.putExtra("EXTRA_BVN", paramBankDetails.getBvn());
    LoanOffersActivity.this.startActivity(intent);
    LoanOffersActivity.this.finish();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOffersActivity$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import d.l.a.o;
import ng.com.fairmoney.fairmoney.fragments.form.FormMBSStep1Fragment;

public class FormFinancialMBSActivity extends FormActivity {
  public void goToPreviousActivity() {
    if (getSupportFragmentManager().b() > 0) {
      getSupportFragmentManager().f();
    } else {
      startActivity(new Intent(getApplicationContext(), FormPersonalActivity.class));
      finish();
    } 
  }
  
  public void onBackPressed() {
    goToPreviousActivity();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    fillFormWithPreviousResponses();
    initBackButton(2131296632);
    o o = getSupportFragmentManager().a();
    o.a(2131296579, (Fragment)new FormMBSStep1Fragment());
    o.a();
  }
  
  public int provideContentViewId() {
    return 2131492902;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormFinancialMBSActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
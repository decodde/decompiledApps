package ng.com.fairmoney.android.loan.termsofuse;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;

@f(c = "ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel$initialize$2", f = "TermsOfUseViewModel.kt", l = {}, m = "invokeSuspend")
public final class TermsOfUseViewModel$initialize$2 extends k implements p<TermsOfUseViewModel.TermsOfUse, d<? super k>, Object> {
  public int label;
  
  public TermsOfUseViewModel.TermsOfUse p$0;
  
  public TermsOfUseViewModel$initialize$2(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    TermsOfUseViewModel$initialize$2 termsOfUseViewModel$initialize$2 = new TermsOfUseViewModel$initialize$2(paramd);
    termsOfUseViewModel$initialize$2.p$0 = (TermsOfUseViewModel.TermsOfUse)paramObject;
    return (d<k>)termsOfUseViewModel$initialize$2;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((TermsOfUseViewModel$initialize$2)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      TermsOfUseViewModel.access$getMutableTermsOfUse$p(TermsOfUseViewModel.this).b(paramObject);
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$initialize$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
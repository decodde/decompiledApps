package ng.com.fairmoney.fairmoney.activities.forgotpassword;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class ForgotPasswordActivity_MembersInjector implements a<ForgotPasswordActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public ForgotPasswordActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<ForgotPasswordActivity> create(Provider<y.b> paramProvider) {
    return new ForgotPasswordActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(ForgotPasswordActivity paramForgotPasswordActivity, y.b paramb) {
    paramForgotPasswordActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(ForgotPasswordActivity paramForgotPasswordActivity) {
    injectViewModelFactory(paramForgotPasswordActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\forgotpassword\ForgotPasswordActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
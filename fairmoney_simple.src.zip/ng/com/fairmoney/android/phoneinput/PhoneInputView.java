package ng.com.fairmoney.android.phoneinput;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.google.android.material.textfield.TextInputLayout;
import d.i.f.a;
import d.o.l;
import d.o.s;
import d.o.w;
import d.o.y;
import d.o.z;
import f.b.a.c;
import f.b.a.h;
import f.b.a.i;
import f.d.b.k.b;
import f.d.b.k.f;
import f.d.c.b;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.NoWhenBranchMatchedException;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.adapters.CountryFlagAdapter;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.textwatcher.PhoneNumberTextWatcher;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.views.FlagStyledSpinner;

public final class PhoneInputView extends Fragment implements OnCountrySelectedListener {
  public CountryFlagAdapter countryFlagAdapter;
  
  public FlagStyledSpinner countryFlagSpinner;
  
  public PhoneNumberTextWatcher countryTextWatcher;
  
  public ImageView ivArrow;
  
  public ImageView ivFlag;
  
  public PhoneInputViewModel phoneInputViewModel;
  
  public EditText phoneNumberEditText;
  
  public TextView phoneNumberErrorView;
  
  public TextInputLayout phoneNumberTextInputLayout;
  
  public TextInputLayout tilFlag;
  
  @Inject
  public y.b viewModelFactory;
  
  public PhoneInputView() {
    super(2131493057);
  }
  
  private final void addPhoneNumberTextChangedListener() {
    EditText editText = this.phoneNumberEditText;
    if (editText != null) {
      editText.addTextChangedListener(new PhoneInputView$addPhoneNumberTextChangedListener$1());
      return;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  private final void displayArrow(boolean paramBoolean) {
    Context context = getContext();
    if (context != null) {
      int j;
      i i = c.e(context);
      if (paramBoolean) {
        j = 2131230994;
      } else {
        j = 2131230995;
      } 
      h h = i.d(a.c(context, j));
      ImageView imageView = this.ivArrow;
      if (imageView != null) {
        h.a(imageView);
      } else {
        k.d("ivArrow");
        throw null;
      } 
    } 
  }
  
  private final PhoneNumberTextWatcher getCountryTextWatcher(b paramb, Context paramContext) {
    IndianPhoneNumberTextWatcher indianPhoneNumberTextWatcher;
    if (paramb instanceof b.a) {
      EditText editText = this.phoneNumberEditText;
      if (editText != null) {
        indianPhoneNumberTextWatcher = new IndianPhoneNumberTextWatcher(paramContext, editText);
      } else {
        k.d("phoneNumberEditText");
        throw null;
      } 
    } else if (indianPhoneNumberTextWatcher instanceof b.b) {
      EditText editText = this.phoneNumberEditText;
      if (editText != null) {
        NigerianPhoneNumberTextWatcher nigerianPhoneNumberTextWatcher = new NigerianPhoneNumberTextWatcher(paramContext, editText);
      } else {
        k.d("phoneNumberEditText");
        throw null;
      } 
    } else {
      EditText editText = this.phoneNumberEditText;
      if (editText != null)
        return new NigerianPhoneNumberTextWatcher(paramContext, editText); 
      k.d("phoneNumberEditText");
      throw null;
    } 
    return indianPhoneNumberTextWatcher;
  }
  
  private final String getErrorMessage(PhoneInputViewModel.PhoneInputState.Invalid.ErrorType paramErrorType) {
    String str;
    int i = PhoneInputView$WhenMappings.$EnumSwitchMapping$0[paramErrorType.ordinal()];
    if (i != 1) {
      if (i == 2) {
        str = getString(2131821063);
        k.a(str, "getString(R.string.phone_input_no_numbers_error)");
      } else {
        throw new NoWhenBranchMatchedException();
      } 
    } else {
      str = getString(2131821062);
      k.a(str, "getString(R.string.phone_input_no_country_error)");
    } 
    return str;
  }
  
  private final void setErrorMessage(String paramString) {
    TextView textView;
    if (paramString == null) {
      textView = this.phoneNumberErrorView;
      if (textView != null) {
        textView.setVisibility(8);
      } else {
        k.d("phoneNumberErrorView");
        throw null;
      } 
    } else {
      TextView textView1 = this.phoneNumberErrorView;
      if (textView1 != null) {
        textView1.setText((CharSequence)textView);
        textView = this.phoneNumberErrorView;
        if (textView != null) {
          textView.setVisibility(0);
          return;
        } 
        k.d("phoneNumberErrorView");
        throw null;
      } 
      k.d("phoneNumberErrorView");
      throw null;
    } 
  }
  
  private final void subscribeToInputViewModel() {
    y.b b1 = this.viewModelFactory;
    if (b1 != null) {
      w w = z.a(this, b1).a(PhoneInputViewModel.class);
      k.a(w, "ViewModelProviders.of(th…putViewModel::class.java)");
      w = w;
      this.phoneInputViewModel = (PhoneInputViewModel)w;
      if (w != null) {
        w.getPhoneNumberLiveData().a((l)this, new PhoneInputView$subscribeToInputViewModel$1());
        return;
      } 
      k.d("phoneInputViewModel");
      throw null;
    } 
    k.d("viewModelFactory");
    throw null;
  }
  
  public final void addTextChangedListener(TextWatcher paramTextWatcher) {
    k.b(paramTextWatcher, "textWatcher");
    EditText editText = this.phoneNumberEditText;
    if (editText != null) {
      editText.addTextChangedListener(paramTextWatcher);
      return;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  public final f getPhoneNumber(boolean paramBoolean) {
    PhoneInputViewModel phoneInputViewModel = this.phoneInputViewModel;
    if (phoneInputViewModel != null) {
      phoneInputViewModel.validatePhoneNumber(paramBoolean);
      phoneInputViewModel = this.phoneInputViewModel;
      if (phoneInputViewModel != null)
        return phoneInputViewModel.getPhoneNumber(); 
      k.d("phoneInputViewModel");
      throw null;
    } 
    k.d("phoneInputViewModel");
    throw null;
  }
  
  public final y.b getViewModelFactory() {
    y.b b1 = this.viewModelFactory;
    if (b1 != null)
      return b1; 
    k.d("viewModelFactory");
    throw null;
  }
  
  public final void hideFlag() {
    TextInputLayout textInputLayout = this.tilFlag;
    if (textInputLayout != null) {
      textInputLayout.setVisibility(8);
      return;
    } 
    k.d("tilFlag");
    throw null;
  }
  
  public void onCountrySelected(b paramb, String paramString, int paramInt) {
    k.b(paramb, "country");
    EditText editText = this.phoneNumberEditText;
    if (editText != null) {
      editText.removeTextChangedListener((TextWatcher)this.countryTextWatcher);
      PhoneInputViewModel phoneInputViewModel = this.phoneInputViewModel;
      if (phoneInputViewModel != null) {
        phoneInputViewModel.setSelectedIndicator(paramString);
        Context context = getContext();
        if (context != null) {
          h h = c.e(context).d(a.c(context, paramInt));
          ImageView imageView = this.ivFlag;
          if (imageView != null) {
            h.a(imageView);
            k.a(context, "it");
            this.countryTextWatcher = getCountryTextWatcher(paramb, context);
          } else {
            k.d("ivFlag");
            throw null;
          } 
        } 
        FlagStyledSpinner flagStyledSpinner = this.countryFlagSpinner;
        if (flagStyledSpinner != null) {
          flagStyledSpinner.dismissDropDown();
          EditText editText1 = this.phoneNumberEditText;
          if (editText1 != null) {
            editText1.addTextChangedListener((TextWatcher)this.countryTextWatcher);
            PhoneNumberTextWatcher phoneNumberTextWatcher = this.countryTextWatcher;
            if (phoneNumberTextWatcher != null) {
              EditText editText2 = this.phoneNumberEditText;
              if (editText2 != null) {
                Editable editable = editText2.getText();
                k.a(editable, "phoneNumberEditText.text");
                phoneNumberTextWatcher.formatPhoneNumber(editable, true);
                return;
              } 
              k.d("phoneNumberEditText");
              throw null;
            } 
            k.a();
            throw null;
          } 
          k.d("phoneNumberEditText");
          throw null;
        } 
        k.d("countryFlagSpinner");
        throw null;
      } 
      k.d("phoneInputViewModel");
      throw null;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {
    k.b(paramView, "view");
    super.onViewCreated(paramView, paramBundle);
    Context context = paramView.getContext();
    k.a(context, "view.context");
    context = context.getApplicationContext();
    if (context != null) {
      ViewModelComponentKt.create((b)context).inject(this);
      View view = paramView.findViewById(2131296929);
      k.a(view, "view.findViewById(R.id.sp_country_flag)");
      this.countryFlagSpinner = (FlagStyledSpinner)view;
      view = paramView.findViewById(2131297192);
      k.a(view, "view.findViewById(R.id.tv_phone_error)");
      this.phoneNumberErrorView = (TextView)view;
      view = paramView.findViewById(2131296630);
      k.a(view, "view.findViewById(R.id.iv_flag)");
      this.ivFlag = (ImageView)view;
      view = paramView.findViewById(2131296613);
      k.a(view, "view.findViewById(R.id.iv_arrow)");
      this.ivArrow = (ImageView)view;
      displayArrow(false);
      subscribeToInputViewModel();
      FlagStyledSpinner flagStyledSpinner = this.countryFlagSpinner;
      if (flagStyledSpinner != null) {
        flagStyledSpinner.setOnFocusChangeListener(new PhoneInputView$onViewCreated$1());
        Context context1 = paramView.getContext();
        k.a(context1, "view.context");
        PhoneInputViewModel phoneInputViewModel = this.phoneInputViewModel;
        if (phoneInputViewModel != null) {
          CountryFlagAdapter countryFlagAdapter = new CountryFlagAdapter(context1, 2131493001, 2131297105, phoneInputViewModel.getCountries());
          this.countryFlagAdapter = countryFlagAdapter;
          if (countryFlagAdapter != null) {
            countryFlagAdapter.setOnCountrySelectedListener(this);
            FlagStyledSpinner flagStyledSpinner1 = this.countryFlagSpinner;
            if (flagStyledSpinner1 != null) {
              countryFlagAdapter = this.countryFlagAdapter;
              if (countryFlagAdapter != null) {
                flagStyledSpinner1.setAdapter((ListAdapter)countryFlagAdapter);
                View view1 = paramView.findViewById(2131296992);
                k.a(view1, "view.findViewById(R.id.til_country_flag)");
                this.tilFlag = (TextInputLayout)view1;
                view1 = paramView.findViewById(2131297025);
                k.a(view1, "view.findViewById(R.id.til_phone_number)");
                this.phoneNumberTextInputLayout = (TextInputLayout)view1;
                paramView = paramView.findViewById(2131296564);
                k.a(paramView, "view.findViewById(R.id.et_phone_number)");
                this.phoneNumberEditText = (EditText)paramView;
                addPhoneNumberTextChangedListener();
                return;
              } 
              k.d("countryFlagAdapter");
              throw null;
            } 
            k.d("countryFlagSpinner");
            throw null;
          } 
          k.d("countryFlagAdapter");
          throw null;
        } 
        k.d("phoneInputViewModel");
        throw null;
      } 
      k.d("countryFlagSpinner");
      throw null;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  public final void selectCountry(b paramb) {
    k.b(paramb, "country");
    CountryFlagAdapter countryFlagAdapter = this.countryFlagAdapter;
    if (countryFlagAdapter != null) {
      countryFlagAdapter.selectCountry(paramb);
      return;
    } 
    k.d("countryFlagAdapter");
    throw null;
  }
  
  public final void selectCountry(String paramString) {
    CountryFlagAdapter countryFlagAdapter = this.countryFlagAdapter;
    if (countryFlagAdapter != null) {
      PhoneInputViewModel phoneInputViewModel = this.phoneInputViewModel;
      if (phoneInputViewModel != null) {
        countryFlagAdapter.selectCountry(phoneInputViewModel.getPhoneCountry(paramString));
        return;
      } 
      k.d("phoneInputViewModel");
      throw null;
    } 
    k.d("countryFlagAdapter");
    throw null;
  }
  
  public final void setFocusTracking(String paramString) {
    k.b(paramString, "key");
    EditText editText = this.phoneNumberEditText;
    if (editText != null) {
      editText.setOnFocusChangeListener(new PhoneInputView$setFocusTracking$1(paramString));
      return;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  public final void setImeOptions(int paramInt) {
    EditText editText = this.phoneNumberEditText;
    if (editText != null) {
      editText.setImeOptions(paramInt);
      return;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  public final void setNumbers(String paramString) {
    k.b(paramString, "numbers");
    EditText editText = this.phoneNumberEditText;
    if (editText != null) {
      editText.setText(paramString);
      return;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  public final void setOnEditorActionListener(TextView.OnEditorActionListener paramOnEditorActionListener) {
    k.b(paramOnEditorActionListener, "onEditorActionListener");
    EditText editText = this.phoneNumberEditText;
    if (editText != null) {
      editText.setOnEditorActionListener(paramOnEditorActionListener);
      return;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  public final void setPhoneNumber(f paramf) {
    EditText editText = this.phoneNumberEditText;
    CharSequence charSequence = null;
    if (editText != null) {
      CharSequence charSequence1;
      if (paramf != null) {
        charSequence1 = paramf.b();
      } else {
        charSequence1 = null;
      } 
      editText.setText(charSequence1);
      CountryFlagAdapter countryFlagAdapter = this.countryFlagAdapter;
      if (countryFlagAdapter != null) {
        charSequence1 = charSequence;
        if (paramf != null)
          charSequence1 = paramf.a(); 
        countryFlagAdapter.selectCountry((String)charSequence1);
        return;
      } 
      k.d("countryFlagAdapter");
      throw null;
    } 
    k.d("phoneNumberEditText");
    throw null;
  }
  
  public final void setViewModelFactory(y.b paramb) {
    k.b(paramb, "<set-?>");
    this.viewModelFactory = paramb;
  }
  
  public static final class PhoneInputView$addPhoneNumberTextChangedListener$1 implements TextWatcher {
    public void afterTextChanged(Editable param1Editable) {
      PhoneInputView.access$getPhoneInputViewModel$p(PhoneInputView.this).setPhoneNumbers(String.valueOf(param1Editable));
    }
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
  }
  
  public static final class PhoneInputView$onViewCreated$1 implements View.OnFocusChangeListener {
    public final void onFocusChange(View param1View, boolean param1Boolean) {
      PhoneInputView.this.displayArrow(param1Boolean);
    }
  }
  
  public static final class PhoneInputView$setFocusTracking$1 implements View.OnFocusChangeListener {
    public PhoneInputView$setFocusTracking$1(String param1String) {}
    
    public final void onFocusChange(View param1View, boolean param1Boolean) {
      ApplicationFormEvent.FormEventType formEventType;
      Event event = new Event(this.$key, "form_input_focus_changed", 0, 4, null);
      if (param1Boolean) {
        formEventType = ApplicationFormEvent.FormEventType.GET_FOCUS;
      } else {
        formEventType = ApplicationFormEvent.FormEventType.RELEASE_FOCUS;
      } 
      ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)PhoneInputView.this.getActivity(), formEventType, null, this.$key));
      Tracking.sendFormInputFocusChanged((Context)PhoneInputView.this.getActivity(), event, param1Boolean);
    }
  }
  
  public static final class PhoneInputView$subscribeToInputViewModel$1<T> implements s<PhoneInputViewModel.PhoneInputState> {
    public final void onChanged(PhoneInputViewModel.PhoneInputState param1PhoneInputState) {
      if (param1PhoneInputState instanceof PhoneInputViewModel.PhoneInputState.Valid) {
        PhoneInputView.this.setErrorMessage(null);
      } else if (param1PhoneInputState instanceof PhoneInputViewModel.PhoneInputState.Invalid) {
        PhoneInputView phoneInputView = PhoneInputView.this;
        phoneInputView.setErrorMessage(phoneInputView.getErrorMessage(((PhoneInputViewModel.PhoneInputState.Invalid)param1PhoneInputState).getErrorType()));
      } 
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
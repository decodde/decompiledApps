package ng.com.fairmoney.android.phoneinput;

import g.a;
import javax.inject.Provider;

public final class IndianPhoneNumberTextWatcher_MembersInjector implements a<IndianPhoneNumberTextWatcher> {
  public final Provider<IndianPhoneNumberViewModel> viewModelProvider;
  
  public IndianPhoneNumberTextWatcher_MembersInjector(Provider<IndianPhoneNumberViewModel> paramProvider) {
    this.viewModelProvider = paramProvider;
  }
  
  public static a<IndianPhoneNumberTextWatcher> create(Provider<IndianPhoneNumberViewModel> paramProvider) {
    return new IndianPhoneNumberTextWatcher_MembersInjector(paramProvider);
  }
  
  public static void injectViewModel(IndianPhoneNumberTextWatcher paramIndianPhoneNumberTextWatcher, IndianPhoneNumberViewModel paramIndianPhoneNumberViewModel) {
    paramIndianPhoneNumberTextWatcher.viewModel = paramIndianPhoneNumberViewModel;
  }
  
  public void injectMembers(IndianPhoneNumberTextWatcher paramIndianPhoneNumberTextWatcher) {
    injectViewModel(paramIndianPhoneNumberTextWatcher, (IndianPhoneNumberViewModel)this.viewModelProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\IndianPhoneNumberTextWatcher_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
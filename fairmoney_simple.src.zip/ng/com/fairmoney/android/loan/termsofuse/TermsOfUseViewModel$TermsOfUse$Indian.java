package ng.com.fairmoney.android.loan.termsofuse;

import j.i;

public final class Indian extends TermsOfUseViewModel.TermsOfUse {
  public Indian(String paramString1, String paramString2) {
    super("₹50,000 rupees", false, false, i.a(str, stringBuilder2.toString()), i.a("1%", "15%"), i.a("1%", "10%"), "https://www.fairmoney.in/terms-and-conditions", paramString2, "https://www.fairmoney.in/privacy-policy", true, true, null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$TermsOfUse$Indian.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
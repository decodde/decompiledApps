package ng.com.fairmoney.android.inversion;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import f.c.a.a;
import f.d.b.c;
import f.d.b.j.b;
import f.d.b.j.d;
import j.q.d.k;
import java.io.Serializable;
import java.net.URL;
import javax.inject.Inject;
import ng.com.fairmoney.android.loan.bankdetails.BankDetailsActivity;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferActivity;
import ng.com.fairmoney.fairmoney.activities.HomeActivity;
import ng.com.fairmoney.fairmoney.activities.UpdateAppActivity;
import ng.com.fairmoney.fairmoney.activities.WalkthroughActivity;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormFinancialKycActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormFinancialMBSActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormPersonalActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormWorkActivity;

public final class RouterImpl implements c {
  public final Context context;
  
  public final CurrentActivityProvider currentActivityProvider;
  
  @Inject
  public RouterImpl(Context paramContext, CurrentActivityProvider paramCurrentActivityProvider) {
    this.context = paramContext;
    this.currentActivityProvider = paramCurrentActivityProvider;
  }
  
  public void toBankDetails() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, BankDetailsActivity.class));
      activity.finish();
    } 
  }
  
  public void toBrowser(URL paramURL) {
    k.b(paramURL, "url");
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null)
      try {
        Intent intent = new Intent();
        this("android.intent.action.VIEW");
        intent.setData(Uri.parse(paramURL.toString()));
        activity.startActivity(intent);
      } catch (ActivityNotFoundException activityNotFoundException) {
        a.a((Throwable)activityNotFoundException);
      }  
  }
  
  public void toBvnKyc() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, FormFinancialKycActivity.class));
      activity.finish();
    } 
  }
  
  public void toFinalLoanOffer() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, FinalLoanOfferActivity.class));
      activity.finish();
    } 
  }
  
  public void toFinancialMbs() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, FormFinancialMBSActivity.class));
      activity.finish();
    } 
  }
  
  public void toHome() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      Intent intent = new Intent((Context)activity, HomeActivity.class);
      intent.addFlags(32768);
      intent.addFlags(268435456);
      activity.startActivity(intent);
      activity.finish();
    } 
  }
  
  public void toHypervergeKyc() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null)
      try {
        Intent intent = new Intent();
        this((Context)activity, Class.forName("com.fairmoney.kyc.KycActivity"));
        activity.startActivity(intent);
      } catch (ClassNotFoundException classNotFoundException) {
        a.a(classNotFoundException);
      }  
  }
  
  public void toPayment(b paramb) {
    k.b(paramb, "inboundPaymentParams");
    d d = paramb.b();
    if (RouterImpl$WhenMappings.$EnumSwitchMapping$0[d.ordinal()] == 1)
      try {
        Class.forName("com.fairmoney.payment.CashFreeActivity");
        Activity activity = this.currentActivityProvider.getCurrentActivity();
        if (activity != null) {
          Intent intent = new Intent();
          this();
          intent.setClassName("ng.com.fairmoney.fairmoney", "com.fairmoney.payment.CashFreeActivity");
          intent.putExtra("extra_inbound_payment_params", (Serializable)paramb);
          activity.startActivity(intent);
        } 
      } catch (ClassNotFoundException classNotFoundException) {
        a.a(new Exception("Payment Activity not found for CashFree provider"));
      }  
  }
  
  public void toPersonalForm() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, FormPersonalActivity.class));
      activity.finish();
    } 
  }
  
  public void toUpdate() {
    Intent intent = new Intent(this.context.getApplicationContext(), UpdateAppActivity.class);
    intent.setFlags(268468224);
    this.context.getApplicationContext().startActivity(intent);
  }
  
  public void toWalkThrough() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, WalkthroughActivity.class));
      activity.finish();
    } 
  }
  
  public void toWelcome() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, WelcomeActivity.class));
      activity.finish();
    } 
  }
  
  public void toWorkForm() {
    Activity activity = this.currentActivityProvider.getCurrentActivity();
    if (activity != null) {
      activity.startActivity(new Intent((Context)activity, FormWorkActivity.class));
      activity.finish();
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\RouterImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
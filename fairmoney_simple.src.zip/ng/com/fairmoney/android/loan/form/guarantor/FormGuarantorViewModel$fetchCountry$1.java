package ng.com.fairmoney.android.loan.form.guarantor;

import f.d.b.k.b;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;

@f(c = "ng.com.fairmoney.android.loan.form.guarantor.FormGuarantorViewModel$fetchCountry$1", f = "FormGuarantorViewModel.kt", l = {}, m = "invokeSuspend")
public final class FormGuarantorViewModel$fetchCountry$1 extends k implements p<b, d<? super k>, Object> {
  public int label;
  
  public b p$0;
  
  public FormGuarantorViewModel$fetchCountry$1(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    FormGuarantorViewModel$fetchCountry$1 formGuarantorViewModel$fetchCountry$1 = new FormGuarantorViewModel$fetchCountry$1(paramd);
    formGuarantorViewModel$fetchCountry$1.p$0 = (b)paramObject;
    return (d<k>)formGuarantorViewModel$fetchCountry$1;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((FormGuarantorViewModel$fetchCountry$1)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      FormGuarantorViewModel.access$getMutableCountry$p(FormGuarantorViewModel.this).b(paramObject);
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\guarantor\FormGuarantorViewModel$fetchCountry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
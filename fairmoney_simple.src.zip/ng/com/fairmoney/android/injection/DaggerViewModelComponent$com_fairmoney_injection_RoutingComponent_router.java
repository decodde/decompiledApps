package ng.com.fairmoney.android.injection;

import f.d.b.c;
import f.d.c.k;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_RoutingComponent_router implements Provider<c> {
  public final k routingComponent;
  
  public com_fairmoney_injection_RoutingComponent_router(k paramk) {
    this.routingComponent = paramk;
  }
  
  public c get() {
    c c = this.routingComponent.a();
    g.a(c, "Cannot return null from a non-@Nullable component method");
    return c;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_RoutingComponent_router.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.fragment.app.Fragment;
import d.l.a.o;
import f.c.a.a;
import f.d.b.k.f;
import java.io.Serializable;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.fragments.form.VerifyBvnPhoneOtpFragment;
import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class VerifyBvnPhoneOtpActivity extends BaseActivity {
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (getIntent() != null) {
      BankDetails bankDetails = (BankDetails)getIntent().getParcelableExtra("EXTRA_BANK_DETAILS");
      f f = (f)getIntent().getSerializableExtra("EXTRA_PHONE_NUMBER");
      boolean bool = getIntent().getBooleanExtra("EXTRA_CAN_BVN_BE_UPDATED", false);
      paramBundle = new Bundle();
      paramBundle.putParcelable("EXTRA_BANK_DETAILS", (Parcelable)bankDetails);
      paramBundle.putSerializable("EXTRA_PHONE_NUMBER", (Serializable)f);
      paramBundle.putBoolean("EXTRA_CAN_BVN_BE_UPDATED", bool);
      VerifyBvnPhoneOtpFragment verifyBvnPhoneOtpFragment = new VerifyBvnPhoneOtpFragment();
      verifyBvnPhoneOtpFragment.setArguments(paramBundle);
      o o = getSupportFragmentManager().a();
      o.a(2131296583, (Fragment)verifyBvnPhoneOtpFragment);
      o.a();
    } else {
      a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)this, "Null intent in VerifyBvnPhoneOtpActivity")));
    } 
  }
  
  public int provideContentViewId() {
    return 2131492920;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\VerifyBvnPhoneOtpActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
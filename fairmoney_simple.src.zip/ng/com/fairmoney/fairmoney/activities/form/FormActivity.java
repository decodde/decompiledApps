package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import com.google.gson.JsonObject;
import d.b.k.d;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.form.utils.FormUtils;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public abstract class FormActivity extends BaseActivity {
  public Button loadingButton;
  
  public Button nextButton;
  
  public SharedPreferences preferences;
  
  private JsonObject serializeAndStoreAnswers() {
    return FormUtils.serializeAndStoreAnswers((d)this, this.preferences.edit(), getFormParameters());
  }
  
  public boolean checkAnswersValidity() {
    return FormUtils.checkAnswersValidity((d)this, getFormParameters());
  }
  
  public void disableNextButton() {
    this.loadingButton.setVisibility(0);
    this.nextButton.setVisibility(8);
  }
  
  public void enableNextButton() {
    this.loadingButton.setVisibility(8);
    this.nextButton.setVisibility(0);
  }
  
  public void fillFormWithPreviousResponses() {
    FormUtils.fillFormWithPreviousResponses((d)this, this.preferences, getFormParameters());
  }
  
  public List<Map<String, String>> getFormParameters() {
    return new ArrayList<Map<String, String>>();
  }
  
  public void goToNextActivity() {
    startActivity(new Intent(getApplicationContext(), WelcomeActivity.class));
    finish();
  }
  
  public void goToPreviousActivity() {
    startActivity(new Intent(getApplicationContext(), WelcomeActivity.class));
    finish();
  }
  
  public void initBackButton(int paramInt) {
    ((ImageView)findViewById(paramInt)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)FormActivity.this, ApplicationFormEvent.FormEventType.BACK_ARROW_CLICK_EVENT, null, null.class.getSimpleName()));
            FormActivity.this.goToPreviousActivity();
          }
        });
  }
  
  public void nextPage(View paramView) {
    if (!FormUtils.checkAnswersValidity((d)this, getFormParameters()))
      return; 
    JsonObject jsonObject = serializeAndStoreAnswers();
    disableNextButton();
    RetrofitSession.getInstance((Context)this).getLoanAppplicationManager().sendFormAnswers(jsonObject, new APIResponse<Object>() {
          public void failure(int param1Int, String param1String) {
            FormActivity.this.onFormCallFailure(param1String);
          }
          
          public void success(Object param1Object) {
            FormActivity.this.enableNextButton();
            FormActivity.this.cancelToast();
            FormActivity.this.goToNextActivity();
          }
        });
  }
  
  public void onBackPressed() {
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.BACK_BUTTON_CLICK_EVENT, null, getClass().getSimpleName()));
    goToPreviousActivity();
  }
  
  public void onClickOnNextButton(View paramView) {
    reportClickOnNextButton();
    nextPage(paramView);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.LIFECYCLE_EVENT, ApplicationFormEvent.LifecycleEvent.ON_CREATE.getName(), getClass().getSimpleName()));
    this.preferences = getSharedPreferences("CurrentUser", 0);
    this.nextButton = (Button)findViewById(2131296760);
    this.loadingButton = (Button)findViewById(2131296717);
  }
  
  public void onDestroy() {
    super.onDestroy();
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.LIFECYCLE_EVENT, ApplicationFormEvent.LifecycleEvent.ON_DESTROY.getName(), getClass().getSimpleName()));
  }
  
  public void onFormCallFailure(String paramString) {
    enableNextButton();
    showNewToastMessage(paramString, 1);
  }
  
  public void onPause() {
    super.onPause();
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.LIFECYCLE_EVENT, ApplicationFormEvent.LifecycleEvent.ON_PAUSE.getName(), getClass().getSimpleName()));
  }
  
  public void onResume() {
    super.onResume();
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.LIFECYCLE_EVENT, ApplicationFormEvent.LifecycleEvent.ON_RESUME.getName(), getClass().getSimpleName()));
  }
  
  public void onStart() {
    super.onStart();
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.LIFECYCLE_EVENT, ApplicationFormEvent.LifecycleEvent.ON_START.getName(), getClass().getSimpleName()));
  }
  
  public void onStop() {
    super.onStop();
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.LIFECYCLE_EVENT, ApplicationFormEvent.LifecycleEvent.ON_STOP.getName(), getClass().getSimpleName()));
  }
  
  public void reportClickOnNextButton() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getLocalClassName());
    stringBuilder.append(" - NEXT");
    Tracking.sendUniqueClickEvent((Context)this, stringBuilder.toString());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
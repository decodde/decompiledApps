package fairmoney.data.kyc;

import j.q.d.k;

public final class JsonPan {
  public final String pan;
  
  public JsonPan(String paramString) {
    this.pan = paramString;
  }
  
  public final String component1() {
    return this.pan;
  }
  
  public final com.fairmoney.data.kyc.JsonPan copy(String paramString) {
    k.b(paramString, "pan");
    return new com.fairmoney.data.kyc.JsonPan(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.kyc.JsonPan) {
        paramObject = paramObject;
        if (k.a(this.pan, ((com.fairmoney.data.kyc.JsonPan)paramObject).pan))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getPan() {
    return this.pan;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.pan;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonPan(pan=");
    stringBuilder.append(this.pan);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonPan.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.bankdetails;

import j.q.d.g;

public abstract class BankDetailsStateError {
  public BankDetailsStateError() {}
  
  public static final class BankAccountError extends BankDetailsStateError {
    public static final BankAccountError INSTANCE = new BankAccountError();
    
    public BankAccountError() {
      super(null);
    }
  }
  
  public static final class IfscError extends BankDetailsStateError {
    public static final IfscError INSTANCE = new IfscError();
    
    public IfscError() {
      super(null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$BankDetailsStateError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
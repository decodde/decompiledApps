package ng.com.fairmoney.android.phoneinput;

import f.d.b.k.b;
import j.q.d.k;
import kotlin.NoWhenBranchMatchedException;

public final class CountryMapper {
  public final int getFlagResource(b paramb) {
    k.b(paramb, "country");
    if (k.a(paramb, b.b.h)) {
      int i = 2131231004;
    } else if (k.a(paramb, b.a.h)) {
      int i = 2131231003;
    } else {
      if (k.a(paramb, b.c.h))
        return 2131231121; 
      throw new NoWhenBranchMatchedException();
    } 
    return SYNTHETIC_LOCAL_VARIABLE_2;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\CountryMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
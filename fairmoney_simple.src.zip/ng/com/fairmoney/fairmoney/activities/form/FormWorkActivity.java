package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;
import d.b.k.d;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.d.b.k.b;
import f.d.c.b;
import f.h.b.a.b;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import l.a.a.a.a.s.f;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.loan.form.work.view.FormWorkViewModel;
import ng.com.fairmoney.fairmoney.activities.form.utils.FormUtils;
import ng.com.fairmoney.fairmoney.textwatcher.AmountTextChangedListener;
import ng.com.fairmoney.fairmoney.utils.Utils;
import ng.com.fairmoney.fairmoney.views.RelativeRadioGroup;
import ng.com.fairmoney.fairmoney.views.StyledSpinner;

public class FormWorkActivity extends FormActivity {
  public static final String ARRAY = "array";
  
  public EditText etFormSalaryPayday;
  
  public FormWorkViewModel formWorkViewModel;
  
  public LinearLayout llEmployed;
  
  public LinearLayout llSelfEmployed;
  
  public StyledSpinner professionalCategorySpinner;
  
  public StyledSpinner professionalSubcategorySpinner;
  
  public TextInputLayout tilFormSalaryPayday;
  
  public TextInputLayout tilProfessionalCategory;
  
  public TextInputLayout tilProfessionalSubcategory;
  
  @Inject
  public y.b viewModelFactory;
  
  private boolean checkPayDayValidity() {
    if (this.etFormSalaryPayday.getText().length() != 0) {
      int i = Integer.valueOf(this.etFormSalaryPayday.getText().toString()).intValue();
      if (i >= 1 && i <= 31) {
        this.tilFormSalaryPayday.setError(null);
        return true;
      } 
    } 
    this.tilFormSalaryPayday.setError(getString(2131820873));
    return false;
  }
  
  private String getCompanyRegisteredAnswer() {
    RelativeRadioGroup relativeRadioGroup = (RelativeRadioGroup)findViewById(2131296853);
    try {
      return getResources().getResourceEntryName(relativeRadioGroup.getCheckedRadioButtonId());
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      return null;
    } 
  }
  
  private void initEmployerAgeSpinner() {
    ((StyledSpinner)findViewById(2131296935)).setAdapter((ListAdapter)ArrayAdapter.createFromResource((Context)this, getResources().getIdentifier("employerAge", "array", getPackageName()), 17367049));
  }
  
  private void initProfessionalStatusSpinner() {
    StyledSpinner styledSpinner = (StyledSpinner)findViewById(2131296937);
    this.professionalCategorySpinner = (StyledSpinner)findViewById(2131296936);
    this.professionalSubcategorySpinner = (StyledSpinner)findViewById(2131296938);
    styledSpinner.setAdapter((ListAdapter)new ArrayAdapter((Context)this, 17367049, 0, this.formWorkViewModel.getProfessionalStatus()));
    styledSpinner.addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            String str = param1Editable.toString();
            if (FormWorkActivity.this.isSalaryEarner(str)) {
              FormWorkActivity.this.llEmployed.setVisibility(0);
              FormWorkActivity.this.llSelfEmployed.setVisibility(8);
              FormWorkActivity.this.tilProfessionalCategory.setVisibility(0);
              FormWorkActivity.this.tilProfessionalSubcategory.setVisibility(0);
              FormWorkActivity.this.updateProfessionalCategoryDropdown(str);
            } else if (FormWorkActivity.this.isSelfEmployed(str)) {
              FormWorkActivity.this.llSelfEmployed.setVisibility(0);
              FormWorkActivity.this.llEmployed.setVisibility(8);
              FormWorkActivity.this.tilProfessionalCategory.setVisibility(0);
              FormWorkActivity.this.tilProfessionalSubcategory.setVisibility(0);
              FormWorkActivity.this.updateProfessionalCategoryDropdown(str);
            } else {
              FormWorkActivity.this.llEmployed.setVisibility(8);
              FormWorkActivity.this.llSelfEmployed.setVisibility(8);
              FormWorkActivity.this.tilProfessionalCategory.setVisibility(8);
              FormWorkActivity.this.tilProfessionalSubcategory.setVisibility(8);
            } 
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
    this.professionalCategorySpinner.addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            FormWorkActivity.this.updateProfessionalSubcategoryDropdown(param1Editable.toString());
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
  }
  
  private void initRadioButtons() {
    final TextInputLayout tilCacNumber = (TextInputLayout)findViewById(2131296998);
    final TextView tvCacNumberExplanations = (TextView)findViewById(2131297121);
    ((RelativeRadioGroup)findViewById(2131296853)).setOnCheckedChangeListener(new RelativeRadioGroup.OnCheckedChangeListener() {
          public void onCheckedChanged(RelativeRadioGroup param1RelativeRadioGroup, int param1Int) {
            if (param1Int == 2131296833) {
              tilCacNumber.setVisibility(0);
              tvCacNumberExplanations.setVisibility(0);
            } else {
              tilCacNumber.setVisibility(8);
              tvCacNumberExplanations.setVisibility(8);
            } 
          }
        });
  }
  
  private boolean isSalaryEarner(String paramString) {
    return (paramString.equals(getString(2131821086)) || paramString.equals(getString(2131821107)));
  }
  
  private boolean isSelfEmployed(String paramString) {
    return paramString.equals(getString(2131821151));
  }
  
  private Integer resourceIdentifier(String paramString) {
    String str2 = paramString.replace(",", "_").replace(" ", "_").replace("/", "_");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(b.LOWER_UNDERSCORE.to(b.LOWER_CAMEL, str2));
    stringBuilder.append("Subcategory");
    String str1 = stringBuilder.toString();
    int i = getResources().getIdentifier(str1, "array", getPackageName());
    int j = i;
    if (i == 0)
      j = getResources().getIdentifier("empty", "array", getPackageName()); 
    return Integer.valueOf(j);
  }
  
  private void updateProfessionalCategoryDropdown(String paramString) {
    ArrayAdapter arrayAdapter;
    this.professionalCategorySpinner.setText("");
    if (isSalaryEarner(paramString)) {
      arrayAdapter = ArrayAdapter.createFromResource((Context)this, getResources().getIdentifier("salaryEarnerCategory", "array", getPackageName()), 17367049);
      this.professionalCategorySpinner.setAdapter((ListAdapter)arrayAdapter);
    } else if (isSelfEmployed((String)arrayAdapter)) {
      arrayAdapter = ArrayAdapter.createFromResource((Context)this, getResources().getIdentifier("selfEmployedCategory", "array", getPackageName()), 17367049);
      this.professionalCategorySpinner.setAdapter((ListAdapter)arrayAdapter);
    } 
  }
  
  private void updateProfessionalSubcategoryDropdown(String paramString) {
    this.professionalSubcategorySpinner.setText("");
    ArrayAdapter arrayAdapter = ArrayAdapter.createFromResource((Context)this, resourceIdentifier(paramString).intValue(), 17367049);
    this.professionalSubcategorySpinner.setAdapter((ListAdapter)arrayAdapter);
  }
  
  public List<Map<String, String>> getFormParameters() {
    List<Map<String, String>> list = Utils.getActivityConfigValue((Context)this, 2131755015);
    ((Map<String, String>)list.get(5)).put("selected_view_value", getCompanyRegisteredAnswer());
    return list;
  }
  
  public void goToNextActivity() {
    startActivity(new Intent(getApplicationContext(), FormGuarantorActivity.class));
    finish();
  }
  
  public void goToPreviousActivity() {
    startActivity(new Intent(getApplicationContext(), FormPersonalActivity.class));
    finish();
  }
  
  public void onClickOnNextButton(View paramView) {
    FormUtils.checkAnswersValidity((d)this, getFormParameters());
    if (this.tilFormSalaryPayday.isShown() && !checkPayDayValidity())
      return; 
    super.onClickOnNextButton(paramView);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplication()).inject(this);
    this.formWorkViewModel = (FormWorkViewModel)z.a((d)this, this.viewModelFactory).a(FormWorkViewModel.class);
    this.llEmployed = (LinearLayout)findViewById(2131296696);
    this.llSelfEmployed = (LinearLayout)findViewById(2131296697);
    this.tilProfessionalCategory = (TextInputLayout)findViewById(2131297017);
    this.tilProfessionalSubcategory = (TextInputLayout)findViewById(2131297018);
    this.etFormSalaryPayday = (EditText)findViewById(2131296548);
    this.tilFormSalaryPayday = (TextInputLayout)findViewById(2131297015);
    EditText editText1 = (EditText)findViewById(2131296545);
    EditText editText2 = (EditText)findViewById(2131296544);
    this.formWorkViewModel.getCountry().a((l)this, (s)new f(this));
    this.formWorkViewModel.fetchCountry();
    editText1.addTextChangedListener((TextWatcher)new AmountTextChangedListener((Context)this, editText1));
    editText2.addTextChangedListener((TextWatcher)new AmountTextChangedListener((Context)this, editText2));
    initRadioButtons();
    initProfessionalStatusSpinner();
    initEmployerAgeSpinner();
    fillFormWithPreviousResponses();
    initBackButton(2131296635);
  }
  
  public int provideContentViewId() {
    return 2131492905;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormWorkActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
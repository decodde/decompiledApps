package ng.com.fairmoney.android.loan.termsofuse;

import f.d.b.k.b;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.k;
import java.net.URL;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import kotlin.NoWhenBranchMatchedException;

@f(c = "ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel$initialize$1", f = "TermsOfUseViewModel.kt", l = {}, m = "invokeSuspend")
public final class TermsOfUseViewModel$initialize$1 extends k implements p<b, d<? super a<? extends TermsOfUseViewModel.TermsOfUse>>, Object> {
  public int label;
  
  public b p$0;
  
  public TermsOfUseViewModel$initialize$1(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    TermsOfUseViewModel$initialize$1 termsOfUseViewModel$initialize$1 = new TermsOfUseViewModel$initialize$1(paramd);
    termsOfUseViewModel$initialize$1.p$0 = (b)paramObject;
    return (d<k>)termsOfUseViewModel$initialize$1;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((TermsOfUseViewModel$initialize$1)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      if (k.a(paramObject, b.b.h)) {
        paramObject = c.a(new TermsOfUseViewModel.TermsOfUse.Nigerian(paramObject.b()));
      } else {
        if (k.a(paramObject, b.a.h))
          return new TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1(c.a(TermsOfUseViewModel.access$getLoanUseCase$p(TermsOfUseViewModel.this).a(), new q<b<? super URL>, Throwable, d<? super k>, Object>(null) {
                  public Object L$0;
                  
                  public Object L$1;
                  
                  public int label;
                  
                  public b p$;
                  
                  public Throwable p$0;
                  
                  public final d<k> create(b<? super URL> param1b, Throwable param1Throwable, d<? super k> param1d) {
                    k.b(param1b, "$this$create");
                    k.b(param1Throwable, "it");
                    k.b(param1d, "continuation");
                    q<b<? super URL>, Throwable, d<? super k>, Object> q1 = new q<b<? super URL>, Throwable, d<? super k>, Object>(param1d);
                    q1.p$ = param1b;
                    q1.p$0 = param1Throwable;
                    return (d)q1;
                  }
                  
                  public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                    return ((null)create((b<? super URL>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
                  }
                  
                  public final Object invokeSuspend(Object param1Object) {
                    Object object = c.a();
                    int i = this.label;
                    if (i != 0) {
                      if (i == 1) {
                        object = this.L$1;
                        object = this.L$0;
                        g.a(param1Object);
                      } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                      } 
                    } else {
                      g.a(param1Object);
                      b b1 = this.p$;
                      param1Object = this.p$0;
                      URL uRL = new URL("https://app.fairmoney.com.ng/in/loan_agreement");
                      this.L$0 = b1;
                      this.L$1 = param1Object;
                      this.label = 1;
                      if (b1.emit(uRL, (d)this) == object)
                        return object; 
                    } 
                    return k.a;
                  }
                }), (b)paramObject); 
        if (k.a(paramObject, b.c.h))
          throw new IllegalArgumentException("Terms of use must have known country"); 
        throw new NoWhenBranchMatchedException();
      } 
      return paramObject;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
  
  public static final class TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 implements a<TermsOfUseViewModel.TermsOfUse.Indian> {
    public TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1(a param1a, b param1b) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<URL>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              URL uRL = (URL)param1Object;
              param1Object = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(", <a href=\"");
              stringBuilder.append(uRL);
              stringBuilder.append("\">loan agreement</a> ");
              param1Object = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)param1Object, stringBuilder.toString()), param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<URL> {
    public null(TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 param1TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      URL uRL = (URL)param1Object;
      param1Object = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(", <a href=\"");
      stringBuilder.append(uRL);
      stringBuilder.append("\">loan agreement</a> ");
      param1Object = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)param1Object, stringBuilder.toString()), param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$initialize$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
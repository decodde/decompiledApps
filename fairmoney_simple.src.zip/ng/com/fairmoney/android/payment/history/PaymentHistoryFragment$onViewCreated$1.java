package ng.com.fairmoney.android.payment.history;

import android.view.View;
import d.l.a.d;
import ng.com.fairmoney.fairmoney.activities.HomeActivity;

public final class PaymentHistoryFragment$onViewCreated$1 implements View.OnClickListener {
  public final void onClick(View paramView) {
    d d2 = PaymentHistoryFragment.this.getActivity();
    d d1 = d2;
    if (!(d2 instanceof HomeActivity))
      d1 = null; 
    HomeActivity homeActivity = (HomeActivity)d1;
    if (homeActivity != null)
      homeActivity.replaceHistoryFragmentByHomeFragment(); 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryFragment$onViewCreated$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
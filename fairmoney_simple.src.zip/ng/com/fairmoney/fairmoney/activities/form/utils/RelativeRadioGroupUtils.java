package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.content.SharedPreferences;
import android.widget.RadioButton;
import android.widget.TextView;
import java.util.Map;
import ng.com.fairmoney.fairmoney.views.RelativeRadioGroup;

public class RelativeRadioGroupUtils {
  public static String getRelativeRadioGroupAnswer(Activity paramActivity, SharedPreferences.Editor paramEditor, Map<String, String> paramMap, int paramInt) {
    RadioButton radioButton = (RadioButton)paramActivity.findViewById(((RelativeRadioGroup)paramActivity.findViewById(paramInt)).getCheckedRadioButtonId());
    paramEditor.putString(paramMap.get("selected_view_key"), paramMap.get("selected_view_value"));
    return radioButton.getText().toString();
  }
  
  public static boolean isRelativeRadioGroupChecked(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    TextView textView = (TextView)paramActivity.findViewById(paramActivity.getResources().getIdentifier(paramMap.get("error_view_id"), "id", paramActivity.getPackageName()));
    if (((RelativeRadioGroup)paramActivity.findViewById(paramInt)).getCheckedRadioButtonId() == -1) {
      RadioGroupUtils.displayRadioGroupError(textView);
      return false;
    } 
    textView.setVisibility(8);
    return true;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\RelativeRadioGroupUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.login.forgot;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.k.f;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class ForgotPasswordViewModel extends w {
  public final LiveData<ForgotPasswordState> forgotPassword;
  
  public final r<ForgotPasswordState> mutableForgotPassword;
  
  public final LiveData<f> phoneNumber;
  
  public final r<f> phoneNumberLiveData;
  
  public final h userUseCase;
  
  @Inject
  public ForgotPasswordViewModel(h paramh) {
    this.userUseCase = paramh;
    r<ForgotPasswordState> r1 = new r();
    this.mutableForgotPassword = r1;
    this.forgotPassword = (LiveData<ForgotPasswordState>)r1;
    r1 = new r();
    this.phoneNumberLiveData = (r)r1;
    this.phoneNumber = (LiveData)r1;
  }
  
  public final LiveData<ForgotPasswordState> getForgotPassword() {
    return this.forgotPassword;
  }
  
  public final LiveData<f> getPhoneNumber() {
    return this.phoneNumber;
  }
  
  public final void initialize() {
    c.a(c.a(this.userUseCase.b(), new ForgotPasswordViewModel$initialize$1(null)), x.a(this));
  }
  
  public final void onForgotPassword(f paramf) {
    k.b(paramf, "phoneNumber");
    c.a(c.a(c.b(c.b(c.a(new ForgotPasswordViewModel$onForgotPassword$$inlined$map$1(this.userUseCase.a(paramf), paramf), new ForgotPasswordViewModel$onForgotPassword$2(null)), new ForgotPasswordViewModel$onForgotPassword$3(null)), new ForgotPasswordViewModel$onForgotPassword$4(null)), new ForgotPasswordViewModel$onForgotPassword$5(null)), x.a(this));
  }
  
  public static abstract class ForgotPasswordState {
    public ForgotPasswordState() {}
    
    public static final class Error extends ForgotPasswordState {
      public final Throwable throwable;
      
      public Error(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Loading extends ForgotPasswordState {
      public final boolean isLoading;
      
      public Loading(boolean param2Boolean) {
        super(null);
        this.isLoading = param2Boolean;
      }
      
      public final boolean isLoading() {
        return this.isLoading;
      }
    }
    
    public static final class Success extends ForgotPasswordState {
      public final f phoneNumber;
      
      public final String ussdCode;
      
      public Success(f param2f, String param2String) {
        super(null);
        this.phoneNumber = param2f;
        this.ussdCode = param2String;
      }
      
      public final f getPhoneNumber() {
        return this.phoneNumber;
      }
      
      public final String getUssdCode() {
        return this.ussdCode;
      }
    }
  }
  
  public static final class Error extends ForgotPasswordState {
    public final Throwable throwable;
    
    public Error(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Loading extends ForgotPasswordState {
    public final boolean isLoading;
    
    public Loading(boolean param1Boolean) {
      super(null);
      this.isLoading = param1Boolean;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
  }
  
  public static final class Success extends ForgotPasswordState {
    public final f phoneNumber;
    
    public final String ussdCode;
    
    public Success(f param1f, String param1String) {
      super(null);
      this.phoneNumber = param1f;
      this.ussdCode = param1String;
    }
    
    public final f getPhoneNumber() {
      return this.phoneNumber;
    }
    
    public final String getUssdCode() {
      return this.ussdCode;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel$initialize$1", f = "ForgotPasswordViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordViewModel$initialize$1 extends k implements p<f, d<? super k>, Object> {
    public int label;
    
    public f p$0;
    
    public ForgotPasswordViewModel$initialize$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      ForgotPasswordViewModel$initialize$1 forgotPasswordViewModel$initialize$1 = new ForgotPasswordViewModel$initialize$1(param1d);
      forgotPasswordViewModel$initialize$1.p$0 = (f)param1Object;
      return (d<k>)forgotPasswordViewModel$initialize$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((ForgotPasswordViewModel$initialize$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        ForgotPasswordViewModel.this.phoneNumberLiveData.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  public static final class ForgotPasswordViewModel$onForgotPassword$$inlined$map$1 implements a<ForgotPasswordState.Success> {
    public ForgotPasswordViewModel$onForgotPassword$$inlined$map$1(a param1a, f param1f) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<String>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              param1Object = b1.emit(new ForgotPasswordViewModel.ForgotPasswordState.Success(ForgotPasswordViewModel$onForgotPassword$$inlined$map$1.this.$phoneNumber$inlined, (String)param1Object), param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<String> {
    public null(ForgotPasswordViewModel$onForgotPassword$$inlined$map$1 param1ForgotPasswordViewModel$onForgotPassword$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      param1Object = b1.emit(new ForgotPasswordViewModel.ForgotPasswordState.Success(ForgotPasswordViewModel$onForgotPassword$$inlined$map$1.this.$phoneNumber$inlined, (String)param1Object), param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel$onForgotPassword$2", f = "ForgotPasswordViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordViewModel$onForgotPassword$2 extends k implements q<b<? super ForgotPasswordState.Success>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public ForgotPasswordViewModel$onForgotPassword$2(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super ForgotPasswordViewModel.ForgotPasswordState.Success> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      ForgotPasswordViewModel$onForgotPassword$2 forgotPasswordViewModel$onForgotPassword$2 = new ForgotPasswordViewModel$onForgotPassword$2(param1d);
      forgotPasswordViewModel$onForgotPassword$2.p$ = param1b;
      forgotPasswordViewModel$onForgotPassword$2.p$0 = param1Throwable;
      return (d<k>)forgotPasswordViewModel$onForgotPassword$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((ForgotPasswordViewModel$onForgotPassword$2)create((b<? super ForgotPasswordViewModel.ForgotPasswordState.Success>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        ForgotPasswordViewModel.this.mutableForgotPassword.b(new ForgotPasswordViewModel.ForgotPasswordState.Error((Throwable)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel$onForgotPassword$3", f = "ForgotPasswordViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordViewModel$onForgotPassword$3 extends k implements p<b<? super ForgotPasswordState.Success>, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public ForgotPasswordViewModel$onForgotPassword$3(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      ForgotPasswordViewModel$onForgotPassword$3 forgotPasswordViewModel$onForgotPassword$3 = new ForgotPasswordViewModel$onForgotPassword$3(param1d);
      forgotPasswordViewModel$onForgotPassword$3.p$ = (b)param1Object;
      return (d<k>)forgotPasswordViewModel$onForgotPassword$3;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((ForgotPasswordViewModel$onForgotPassword$3)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        ForgotPasswordViewModel.this.mutableForgotPassword.b(new ForgotPasswordViewModel.ForgotPasswordState.Loading(true));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel$onForgotPassword$4", f = "ForgotPasswordViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordViewModel$onForgotPassword$4 extends k implements q<b<? super ForgotPasswordState.Success>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public ForgotPasswordViewModel$onForgotPassword$4(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super ForgotPasswordViewModel.ForgotPasswordState.Success> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1d, "continuation");
      ForgotPasswordViewModel$onForgotPassword$4 forgotPasswordViewModel$onForgotPassword$4 = new ForgotPasswordViewModel$onForgotPassword$4(param1d);
      forgotPasswordViewModel$onForgotPassword$4.p$ = param1b;
      forgotPasswordViewModel$onForgotPassword$4.p$0 = param1Throwable;
      return (d<k>)forgotPasswordViewModel$onForgotPassword$4;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((ForgotPasswordViewModel$onForgotPassword$4)create((b<? super ForgotPasswordViewModel.ForgotPasswordState.Success>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        ForgotPasswordViewModel.this.mutableForgotPassword.b(new ForgotPasswordViewModel.ForgotPasswordState.Loading(false));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel$onForgotPassword$5", f = "ForgotPasswordViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordViewModel$onForgotPassword$5 extends k implements p<ForgotPasswordState.Success, d<? super k>, Object> {
    public int label;
    
    public ForgotPasswordViewModel.ForgotPasswordState.Success p$0;
    
    public ForgotPasswordViewModel$onForgotPassword$5(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      ForgotPasswordViewModel$onForgotPassword$5 forgotPasswordViewModel$onForgotPassword$5 = new ForgotPasswordViewModel$onForgotPassword$5(param1d);
      forgotPasswordViewModel$onForgotPassword$5.p$0 = (ForgotPasswordViewModel.ForgotPasswordState.Success)param1Object;
      return (d<k>)forgotPasswordViewModel$onForgotPassword$5;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((ForgotPasswordViewModel$onForgotPassword$5)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        ForgotPasswordViewModel.this.mutableForgotPassword.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.home.card;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.k.b;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.b;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import kotlin.NoWhenBranchMatchedException;

public final class EarlyRepaymentCardViewModel extends w {
  public final r<EarlyRepaymentSate> mutableState;
  
  public final LiveData<EarlyRepaymentSate> state;
  
  public final h userUseCase;
  
  @Inject
  public EarlyRepaymentCardViewModel(h paramh) {
    this.userUseCase = paramh;
    r<EarlyRepaymentSate> r1 = new r();
    this.mutableState = r1;
    this.state = (LiveData<EarlyRepaymentSate>)r1;
  }
  
  public final LiveData<EarlyRepaymentSate> getState() {
    return this.state;
  }
  
  public final void initialize() {
    c.a(c.a(new EarlyRepaymentCardViewModel$initialize$$inlined$map$1(this.userUseCase.getCountry()), new EarlyRepaymentCardViewModel$initialize$2(null)), x.a(this));
  }
  
  public static final class EarlyRepaymentSate {
    public final String amount;
    
    public final Integer discount;
    
    public final int duration;
    
    public final String issueWording;
    
    public final boolean neutralCurrency;
    
    public EarlyRepaymentSate(String param1String1, int param1Int, Integer param1Integer, String param1String2, boolean param1Boolean) {
      this.amount = param1String1;
      this.duration = param1Int;
      this.discount = param1Integer;
      this.issueWording = param1String2;
      this.neutralCurrency = param1Boolean;
    }
    
    public final String component1() {
      return this.amount;
    }
    
    public final int component2() {
      return this.duration;
    }
    
    public final Integer component3() {
      return this.discount;
    }
    
    public final String component4() {
      return this.issueWording;
    }
    
    public final boolean component5() {
      return this.neutralCurrency;
    }
    
    public final EarlyRepaymentSate copy(String param1String1, int param1Int, Integer param1Integer, String param1String2, boolean param1Boolean) {
      k.b(param1String1, "amount");
      k.b(param1String2, "issueWording");
      return new EarlyRepaymentSate(param1String1, param1Int, param1Integer, param1String2, param1Boolean);
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object instanceof EarlyRepaymentSate) {
          param1Object = param1Object;
          if (k.a(this.amount, ((EarlyRepaymentSate)param1Object).amount) && this.duration == ((EarlyRepaymentSate)param1Object).duration && k.a(this.discount, ((EarlyRepaymentSate)param1Object).discount) && k.a(this.issueWording, ((EarlyRepaymentSate)param1Object).issueWording) && this.neutralCurrency == ((EarlyRepaymentSate)param1Object).neutralCurrency)
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final String getAmount() {
      return this.amount;
    }
    
    public final Integer getDiscount() {
      return this.discount;
    }
    
    public final int getDuration() {
      return this.duration;
    }
    
    public final String getIssueWording() {
      return this.issueWording;
    }
    
    public final boolean getNeutralCurrency() {
      return this.neutralCurrency;
    }
    
    public int hashCode() {
      byte b1;
      byte b2;
      String str2 = this.amount;
      int i = 0;
      if (str2 != null) {
        b1 = str2.hashCode();
      } else {
        b1 = 0;
      } 
      int j = this.duration;
      Integer integer = this.discount;
      if (integer != null) {
        b2 = integer.hashCode();
      } else {
        b2 = 0;
      } 
      String str1 = this.issueWording;
      if (str1 != null)
        i = str1.hashCode(); 
      boolean bool1 = this.neutralCurrency;
      boolean bool2 = bool1;
      if (bool1)
        bool2 = true; 
      return (((b1 * 31 + j) * 31 + b2) * 31 + i) * 31 + bool2;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("EarlyRepaymentSate(amount=");
      stringBuilder.append(this.amount);
      stringBuilder.append(", duration=");
      stringBuilder.append(this.duration);
      stringBuilder.append(", discount=");
      stringBuilder.append(this.discount);
      stringBuilder.append(", issueWording=");
      stringBuilder.append(this.issueWording);
      stringBuilder.append(", neutralCurrency=");
      stringBuilder.append(this.neutralCurrency);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class EarlyRepaymentCardViewModel$initialize$$inlined$map$1 implements a<EarlyRepaymentSate> {
    public EarlyRepaymentCardViewModel$initialize$$inlined$map$1(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              if (k.a(param1Object, b.b.h)) {
                param1Object = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₦500,000", 6, b.a(5), "wahala", false);
              } else if (k.a(param1Object, b.a.h)) {
                param1Object = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₹50,000", 6, null, "hassle", true);
              } else {
                if (k.a(param1Object, b.c.h))
                  throw new IllegalArgumentException(); 
                throw new NoWhenBranchMatchedException();
              } 
              param1Object = b1.emit(param1Object, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<b> {
    public null(EarlyRepaymentCardViewModel$initialize$$inlined$map$1 param1EarlyRepaymentCardViewModel$initialize$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      if (k.a(param1Object, b.b.h)) {
        param1Object = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₦500,000", 6, b.a(5), "wahala", false);
      } else if (k.a(param1Object, b.a.h)) {
        param1Object = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₹50,000", 6, null, "hassle", true);
      } else {
        if (k.a(param1Object, b.c.h))
          throw new IllegalArgumentException(); 
        throw new NoWhenBranchMatchedException();
      } 
      param1Object = b1.emit(param1Object, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.home.card.EarlyRepaymentCardViewModel$initialize$2", f = "EarlyRepaymentCardViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class EarlyRepaymentCardViewModel$initialize$2 extends k implements p<EarlyRepaymentSate, d<? super k>, Object> {
    public int label;
    
    public EarlyRepaymentCardViewModel.EarlyRepaymentSate p$0;
    
    public EarlyRepaymentCardViewModel$initialize$2(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      EarlyRepaymentCardViewModel$initialize$2 earlyRepaymentCardViewModel$initialize$2 = new EarlyRepaymentCardViewModel$initialize$2(param1d);
      earlyRepaymentCardViewModel$initialize$2.p$0 = (EarlyRepaymentCardViewModel.EarlyRepaymentSate)param1Object;
      return (d<k>)earlyRepaymentCardViewModel$initialize$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((EarlyRepaymentCardViewModel$initialize$2)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        EarlyRepaymentCardViewModel.this.mutableState.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
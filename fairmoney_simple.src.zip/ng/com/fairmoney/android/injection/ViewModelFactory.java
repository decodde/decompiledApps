package ng.com.fairmoney.android.injection;

import d.o.w;
import d.o.y;
import j.q.d.k;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Provider;
import kotlin.TypeCastException;

@ViewModelScope
public final class ViewModelFactory implements y.b {
  public final Map<Class<? extends w>, Provider<w>> viewModels;
  
  @Inject
  public ViewModelFactory(Map<Class<? extends w>, Provider<w>> paramMap) {
    this.viewModels = paramMap;
  }
  
  public <T extends w> T create(Class<T> paramClass) {
    k.b(paramClass, "modelClass");
    Provider provider = this.viewModels.get(paramClass);
    if (provider != null) {
      w w = (w)provider.get();
    } else {
      provider = null;
    } 
    if (provider != null)
      return (T)provider; 
    throw new TypeCastException("null cannot be cast to non-null type T");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\ViewModelFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.kyc;

import com.fairmoney.data.kyc.JsonPan;
import f.d.b.h.e;
import j.q.d.k;

public final class JsonPanMapper {
  public final e transform(JsonPan paramJsonPan) {
    k.b(paramJsonPan, "jsonPan");
    return new e(paramJsonPan.getPan());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonPanMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.user;

import j.q.d.g;
import j.q.d.k;

public final class JsonUssdCode {
  public final String ussdCode;
  
  public JsonUssdCode() {
    this(null, 1, null);
  }
  
  public JsonUssdCode(String paramString) {
    this.ussdCode = paramString;
  }
  
  public final String component1() {
    return this.ussdCode;
  }
  
  public final com.fairmoney.data.user.JsonUssdCode copy(String paramString) {
    return new com.fairmoney.data.user.JsonUssdCode(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.user.JsonUssdCode) {
        paramObject = paramObject;
        if (k.a(this.ussdCode, ((com.fairmoney.data.user.JsonUssdCode)paramObject).ussdCode))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getUssdCode() {
    return this.ussdCode;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.ussdCode;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonUssdCode(ussdCode=");
    stringBuilder.append(this.ussdCode);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\dat\\user\JsonUssdCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
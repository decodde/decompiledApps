package ng.com.fairmoney.android.payment.history;

import f.d.b.j.a;
import j.k;
import j.n.d;
import j.n.i.c;
import java.util.List;
import k.a.h2.b;

public final class null implements b<List<? extends a>> {
  public null(PaymentHistoryViewModel$fetchBills$$inlined$map$1 paramPaymentHistoryViewModel$fetchBills$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    paramObject = paramObject;
    if (paramObject.isEmpty()) {
      paramObject = PaymentHistoryViewModel.BillState.Empty.INSTANCE;
    } else {
      paramObject = new PaymentHistoryViewModel.BillState.Success((List<a>)paramObject);
    } 
    paramObject = b1.emit(paramObject, paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel$fetchBills$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.forgotpassword;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import d.l.a.o;
import f.c.a.a;
import f.d.b.k.f;
import java.io.Serializable;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.fragments.forgotpassword.ForgotPasswordEnterOtpFragment;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class ForgotPasswordEnterOtpActivity extends BaseActivity {
  public f phoneNumber;
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, ForgotPasswordActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.isAuthMandatory = false;
    if (getIntent() != null) {
      this.phoneNumber = (f)getIntent().getSerializableExtra("EXTRA_PHONE_NUMBER");
      Bundle bundle = new Bundle();
      bundle.putBoolean("EXTRA_CAN_SKIP_PHONE_VERIFICATION", false);
      bundle.putSerializable("EXTRA_PHONE_NUMBER", (Serializable)this.phoneNumber);
      bundle.putString("EXTRA_USSD_CODE", getIntent().getStringExtra("EXTRA_USSD_CODE"));
      ForgotPasswordEnterOtpFragment forgotPasswordEnterOtpFragment = new ForgotPasswordEnterOtpFragment();
      forgotPasswordEnterOtpFragment.setArguments(bundle);
      o o = getSupportFragmentManager().a();
      o.a(2131296583, (Fragment)forgotPasswordEnterOtpFragment);
      o.a();
    } else {
      a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)this, "Null intent in ForgotPasswordEnterOtpActivity")));
    } 
  }
  
  public int provideContentViewId() {
    return 2131492897;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\forgotpassword\ForgotPasswordEnterOtpActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<Object> {
  public void failure(int paramInt, String paramString) {
    FormActivity.this.onFormCallFailure(paramString);
  }
  
  public void success(Object paramObject) {
    FormActivity.this.enableNextButton();
    FormActivity.access$000(FormActivity.this);
    FormActivity.this.goToNextActivity();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
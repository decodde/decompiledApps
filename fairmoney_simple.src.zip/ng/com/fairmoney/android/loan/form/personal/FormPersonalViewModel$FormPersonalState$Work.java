package ng.com.fairmoney.android.loan.form.personal;

public final class Work extends FormPersonalViewModel.FormPersonalState {
  public static final Work INSTANCE = new Work();
  
  public Work() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$FormPersonalState$Work.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
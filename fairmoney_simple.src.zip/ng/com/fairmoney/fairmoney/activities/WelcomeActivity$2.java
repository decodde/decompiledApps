package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import ng.com.fairmoney.fairmoney.activities.login.PhoneLoginActivity;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    WelcomeActivity.this.startActivity(new Intent((Context)WelcomeActivity.this, PhoneLoginActivity.class));
    WelcomeActivity.this.finish();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\WelcomeActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
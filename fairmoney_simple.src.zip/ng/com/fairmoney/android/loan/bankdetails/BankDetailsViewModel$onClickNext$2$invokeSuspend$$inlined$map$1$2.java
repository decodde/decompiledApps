package ng.com.fairmoney.android.loan.bankdetails;

import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.b;

public final class null implements b<k> {
  public null(BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1 paramBankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    paramObject = paramObject;
    paramObject = b1.emit(BankDetailsViewModel.BankDetailsState.Success.INSTANCE, paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
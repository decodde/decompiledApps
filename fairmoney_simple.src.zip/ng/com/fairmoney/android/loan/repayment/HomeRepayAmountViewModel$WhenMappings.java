package ng.com.fairmoney.android.loan.repayment;

import f.d.b.j.c;



/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$WhenMappings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
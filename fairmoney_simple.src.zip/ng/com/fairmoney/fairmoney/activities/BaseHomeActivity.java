package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import d.b.k.a;
import d.l.a.d;
import d.l.a.o;
import d.o.y;
import d.o.z;
import f.d.c.b;
import javax.inject.Inject;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.fragments.IOnFragmentBackPressed;
import ng.com.fairmoney.fairmoney.fragments.home.BillPaymentsFragment;
import ng.com.fairmoney.fairmoney.fragments.home.HomeFragment;
import ng.com.fairmoney.fairmoney.fragments.home.ProfileFragment;
import ng.com.fairmoney.fairmoney.fragments.home.ReferralFragment;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.viewmodels.HomeViewModel;

public abstract class BaseHomeActivity extends BaseActivity {
  public static final String MENU_CLICK_TAG = "home_menu_click";
  
  public static final String MENU_ITEM_TAG = "menu_item";
  
  public a actionBar;
  
  public BottomNavigationView bottomNavigationView;
  
  public HomeViewModel homeViewModel;
  
  public boolean isBackArrowVisible = false;
  
  public SharedPreferences preferences;
  
  public int selectedNavigationMenuItem;
  
  @Inject
  public y.b viewModelFactory;
  
  private void backWithInvisibleArrow() {
    if (this.bottomNavigationView.getSelectedItemId() != 2131296789) {
      this.bottomNavigationView.setSelectedItemId(2131296789);
      displayPayFragment();
    } else {
      super.onBackPressed();
    } 
  }
  
  private void backWithVisibleBackArrow(int paramInt) {
    if (paramInt == 1) {
      getSupportFragmentManager().f();
      this.actionBar.d(false);
      this.actionBar.e(false);
      this.isBackArrowVisible = false;
    } else if (paramInt != 0) {
      getSupportFragmentManager().f();
    } else {
      this.actionBar.d(false);
      this.actionBar.e(false);
      this.isBackArrowVisible = false;
      this.bottomNavigationView.setSelectedItemId(2131296789);
    } 
  }
  
  private void displayMenuFragment(Fragment paramFragment, int paramInt, String paramString, boolean paramBoolean) {
    if (this.selectedNavigationMenuItem != paramInt) {
      clearBackstackAndHideBackIcon();
      removePreviousFragmentAndAddFragment(paramFragment);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Menu: ");
      stringBuilder.append(paramString);
      Tracking.sendUniqueClickEvent((Context)this, stringBuilder.toString());
      logClickEvent(paramString);
    } 
    this.selectedNavigationMenuItem = paramInt;
    setToolbarVisibility(paramBoolean);
  }
  
  public void clearBackstackAndHideBackIcon() {
    if (!getSupportFragmentManager().e()) {
      getSupportFragmentManager().a(null, 1);
      this.actionBar.d(false);
      this.actionBar.e(false);
      this.isBackArrowVisible = false;
    } 
  }
  
  public void displayAccountFragment() {
    displayMenuFragment((Fragment)new ProfileFragment(), 2131296304, "Profile", true);
  }
  
  public void displayActionBar(boolean paramBoolean) {
    setToolbarVisibility(true);
    if (paramBoolean) {
      displayBackArrow();
    } else {
      hideBackArrow();
    } 
  }
  
  public void displayBackArrow() {
    if (this.actionBar.k()) {
      this.actionBar.d(true);
      this.actionBar.e(true);
      this.actionBar.b(2131230914);
      this.isBackArrowVisible = true;
    } 
  }
  
  public void displayBillsFragment() {
    displayMenuFragment((Fragment)new BillPaymentsFragment(), 2131296792, "Payment", false);
  }
  
  public void displayPayFragment() {
    displayMenuFragment((Fragment)new HomeFragment(), 2131296789, "Pay now", false);
  }
  
  public void displayReferralFragment() {
    displayMenuFragment((Fragment)new ReferralFragment(), 2131296849, "Refer a friend", true);
  }
  
  public void hideBackArrow() {
    if (!this.actionBar.k()) {
      this.actionBar.d(false);
      this.actionBar.e(false);
      this.isBackArrowVisible = false;
    } 
  }
  
  public boolean isActivityActive() {
    return this.isActivityActive;
  }
  
  public void logClickEvent(String paramString) {
    Bundle bundle = new Bundle();
    bundle.putString("menu_item", paramString);
    FirebaseAnalytics.getInstance((Context)this).a("home_menu_click", bundle);
  }
  
  public void onBackPressed() {
    Fragment fragment = getSupportFragmentManager().a(2131296582);
    if (fragment instanceof IOnFragmentBackPressed) {
      ((IOnFragmentBackPressed)fragment).onBackPressed();
      return;
    } 
    int i = getSupportFragmentManager().b();
    if (this.isBackArrowVisible) {
      backWithVisibleBackArrow(i);
    } else {
      backWithInvisibleArrow();
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplication()).inject(this);
    this.homeViewModel = (HomeViewModel)z.a((d)this, this.viewModelFactory).a(HomeViewModel.class);
  }
  
  public int provideContentViewId() {
    return 2131492906;
  }
  
  public void removePreviousFragmentAndAddFragment(Fragment paramFragment) {
    if (!getSupportFragmentManager().e()) {
      o o = getSupportFragmentManager().a();
      o.a(2131296582, paramFragment);
      o.a();
    } 
  }
  
  public void setBottomNavigationViewVisibility(int paramInt) {
    BottomNavigationView bottomNavigationView = this.bottomNavigationView;
    if (paramInt == 0 && this.homeViewModel.getMenuVisibility()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    bottomNavigationView.setVisibility(paramInt);
  }
  
  public void setToolbarVisibility(boolean paramBoolean) {
    if (paramBoolean) {
      this.actionBar.n();
    } else {
      this.actionBar.i();
      this.isBackArrowVisible = false;
    } 
  }
  
  public void showMessage(String paramString) {
    showNewToastMessage(paramString, 1);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\BaseHomeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
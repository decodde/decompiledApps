package ng.com.fairmoney.android.injection;

import android.app.Application;
import f.d.c.c;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_ContextComponent_application implements Provider<Application> {
  public final c contextComponent;
  
  public com_fairmoney_injection_ContextComponent_application(c paramc) {
    this.contextComponent = paramc;
  }
  
  public Application get() {
    Application application = this.contextComponent.a();
    g.a(application, "Cannot return null from a non-@Nullable component method");
    return application;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_ContextComponent_application.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
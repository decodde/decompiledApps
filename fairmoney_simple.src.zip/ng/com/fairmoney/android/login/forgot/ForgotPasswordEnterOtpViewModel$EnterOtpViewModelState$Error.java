package ng.com.fairmoney.android.login.forgot;

public final class Error extends ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState {
  public final Throwable throwable;
  
  public Error(Throwable paramThrowable) {
    super(null);
    this.throwable = paramThrowable;
  }
  
  public final Throwable getThrowable() {
    return this.throwable;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordEnterOtpViewModel$EnterOtpViewModelState$Error.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.signup;

import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.auth.api.credentials.CredentialPickerConfig;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.gms.common.api.GoogleApiClient;
import d.b.k.c;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.d.b.k.b;
import f.d.b.k.f;
import f.d.c.b;
import f.h.a.a.c.a.a;
import f.h.a.a.e.b;
import java.io.Serializable;
import javax.inject.Inject;
import l.a.a.a.a.u.a;
import l.a.a.a.a.u.b;
import l.a.a.a.a.u.c;
import l.a.a.a.a.u.d;
import l.a.a.a.a.u.e;
import l.a.a.a.a.u.f;
import l.a.a.a.a.u.g;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.login.signup.PhoneSignupViewModel;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.forgotpassword.ForgotPasswordActivity;
import ng.com.fairmoney.fairmoney.activities.login.LoginActivity;
import ng.com.fairmoney.fairmoney.activities.login.PhoneLoginActivity;
import ng.com.fairmoney.fairmoney.models.PhoneAuthentication;
import ng.com.fairmoney.fairmoney.models.UssdCode;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;

public class PhoneSignupActivity extends LoginActivity {
  public static final String EXTRA_CAN_BVN_BE_UPDATED = "EXTRA_CAN_BVN_BE_UPDATED";
  
  public static final String EXTRA_CAN_SKIP_PHONE_VERIFICATION = "EXTRA_CAN_SKIP_PHONE_VERIFICATION";
  
  public static final String EXTRA_CASE_CODE = "EXTRA_CASE_CODE";
  
  public static final String EXTRA_IS_FIRST_PHONE_VERIFICATION = "EXTRA_IS_FIRST_PHONE_VERIFICATION";
  
  public static final String EXTRA_PASSWORD = "EXTRA_PASSWORD";
  
  public static final String EXTRA_PHONE_INDICATOR = "EXTRA_PHONE_INDICATOR";
  
  public static final String EXTRA_PHONE_NUMBER = "EXTRA_PHONE_NUMBER";
  
  public static final String EXTRA_PHONE_VERIFICATION = "EXTRA_PHONE_VERIFICATION";
  
  public static final String EXTRA_USSD_CODE = "EXTRA_USSD_CODE";
  
  public static final int RESOLVE_HINT = 18649;
  
  public Button btNext;
  
  public boolean isPhoneVerification = false;
  
  public TextView tvActionFairmoneyAccount;
  
  @Inject
  public y.b viewModelFactory;
  
  private void displayExistingAccountPopUp() {
    if (((BaseActivity)this).isActivityActive) {
      c.a a = new c.a((Context)this);
      a.b(2131820825, (DialogInterface.OnClickListener)new g(this));
      a.c(2131820934, (DialogInterface.OnClickListener)new c(this));
      a.b(2131820798);
      a.a().show();
    } 
  }
  
  public static void hideKeyboardFrom(Context paramContext, View paramView) {
    InputMethodManager inputMethodManager = (InputMethodManager)paramContext.getSystemService("input_method");
    if (inputMethodManager != null)
      inputMethodManager.hideSoftInputFromWindow(paramView.getWindowToken(), 0); 
  }
  
  private void initBackArrow() {
    ((ImageView)findViewById(2131296654)).setOnClickListener((View.OnClickListener)new a(this));
  }
  
  private void onNextClicked() {
    hideKeyboardFrom((Context)this, this.pivLogin.getView());
    f f = this.pivLogin.getPhoneNumber(true);
    if (f != null) {
      makeButtonEnabled(false);
      PhoneAuthentication phoneAuthentication = new PhoneAuthentication();
      phoneAuthentication.setPhone(f.toString());
      verifyPhoneNumberPhoneSignup(phoneAuthentication, f);
      savePhoneNumber(f);
    } 
  }
  
  private void requestHint() {
    HintRequest.a a = new HintRequest.a();
    CredentialPickerConfig.a a2 = new CredentialPickerConfig.a();
    a2.a(true);
    a.a(a2.a());
    a.a(true);
    HintRequest hintRequest = a.a();
    GoogleApiClient.a a1 = new GoogleApiClient.a((Context)this);
    a1.a(a.e);
    a1.a((d)this, (GoogleApiClient.c)d.a);
    GoogleApiClient googleApiClient = a1.a();
    PendingIntent pendingIntent = a.g.a(googleApiClient, hintRequest);
    try {
      startIntentSenderForResult(pendingIntent.getIntentSender(), 18649, null, 0, 0, 0);
    } catch (android.content.IntentSender.SendIntentException sendIntentException) {
      sendIntentException.printStackTrace();
    } catch (ActivityNotFoundException activityNotFoundException) {}
  }
  
  private void selectCountry() {
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    PhoneSignupViewModel phoneSignupViewModel = (PhoneSignupViewModel)z.a((d)this, this.viewModelFactory).a(PhoneSignupViewModel.class);
    phoneSignupViewModel.getCountryLiveData().a((l)this, (s)new b(this));
    phoneSignupViewModel.getCountry();
  }
  
  private void setupPhoneInputView() {
    this.pivLogin.setImeOptions(6);
    this.pivLogin.setOnEditorActionListener((TextView.OnEditorActionListener)new f(this));
    this.pivLogin.addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            Button button = PhoneSignupActivity.this.btNext;
            PhoneInputView phoneInputView = PhoneSignupActivity.this.pivLogin;
            boolean bool = false;
            if (phoneInputView.getPhoneNumber(false) != null)
              bool = true; 
            button.setEnabled(bool);
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
    getPhoneNumber();
  }
  
  private void verifyPhoneNumberPhoneSignup(PhoneAuthentication paramPhoneAuthentication, final f phoneNumber) {
    RetrofitSession.getInstance((Context)this).getUserLoginManager().verifyPhoneNumber(paramPhoneAuthentication, new APIResponse<UssdCode>() {
          public void failure(int param1Int, String param1String) {
            if (param1Int == 20) {
              PhoneSignupActivity.this.displayExistingAccountPopUp();
              PhoneSignupActivity.this.makeButtonEnabled(true);
              return;
            } 
            PhoneSignupActivity.this.showNewToastMessage(param1String, 0);
            PhoneSignupActivity.this.makeButtonEnabled(true);
          }
          
          public void success(UssdCode param1UssdCode) {
            Intent intent = new Intent((Context)PhoneSignupActivity.this, PhoneSignupEnterOtpActivity.class);
            intent.putExtra("EXTRA_PHONE_NUMBER", (Serializable)phoneNumber);
            intent.putExtra("EXTRA_PHONE_VERIFICATION", PhoneSignupActivity.this.isPhoneVerification);
            intent.putExtra("EXTRA_USSD_CODE", param1UssdCode.getUssdCode());
            PhoneSignupActivity.this.startActivity(intent);
            PhoneSignupActivity.this.finish();
          }
        });
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {
    int i;
    this.btNext.setEnabled(paramBoolean);
    Button button = this.btNext;
    if (paramBoolean) {
      i = 2131821003;
    } else {
      i = 2131820897;
    } 
    button.setText(i);
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 == 18649 && paramInt2 == -1) {
      Credential credential = (Credential)paramIntent.getParcelableExtra("com.google.android.gms.credentials.Credential");
      if (credential != null) {
        this.pivLogin.selectCountry(credential.j());
        this.pivLogin.setNumbers(credential.j().replaceAll(" ", ""));
      } 
    } 
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, WelcomeActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((BaseActivity)this).isAuthMandatory = false;
    this.pivLogin = (PhoneInputView)getSupportFragmentManager().a(2131296799);
    requestHint();
    initBackArrow();
    this.btNext = (Button)findViewById(2131296419);
    this.tvActionFairmoneyAccount = (TextView)findViewById(2131297050);
    Intent intent = getIntent();
    if (intent != null && intent.getBooleanExtra("EXTRA_PHONE_VERIFICATION", false)) {
      this.isPhoneVerification = true;
      TextView textView1 = (TextView)findViewById(2131297054);
      TextView textView2 = (TextView)findViewById(2131297050);
      textView1.setText(getString(2131821234));
      textView2.setText(getString(2131821067));
    } 
    setupPhoneInputView();
    this.btNext.setOnClickListener((View.OnClickListener)new e(this));
    selectCountry();
  }
  
  public int provideContentViewId() {
    return 2131492913;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
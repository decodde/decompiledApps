package ng.com.fairmoney.android.phoneinput;

public final class Valid extends PhoneInputViewModel.PhoneInputState {
  public static final Valid INSTANCE = new Valid();
  
  public Valid() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputViewModel$PhoneInputState$Valid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
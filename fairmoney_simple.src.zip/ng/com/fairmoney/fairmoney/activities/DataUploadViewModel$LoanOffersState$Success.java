package ng.com.fairmoney.fairmoney.activities;

import f.d.b.i.c;
import java.util.List;

public final class Success extends DataUploadViewModel.LoanOffersState {
  public final List<c> loanOffers;
  
  public Success(List<c> paramList) {
    super(null);
    this.loanOffers = paramList;
  }
  
  public final List<c> getLoanOffers() {
    return this.loanOffers;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadViewModel$LoanOffersState$Success.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
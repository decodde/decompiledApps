package ng.com.fairmoney.android.loan.offer;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import f.d.b.i.a;
import f.d.b.i.c;
import j.q.d.g;
import j.q.d.k;
import j.q.d.s;
import java.util.Arrays;
import javax.inject.Inject;
import ng.com.fairmoney.fairmoney.utils.AmountFormatter;

public final class LoanOfferDetailsViewModel extends w implements LoanOfferDetailsInteractor {
  public final LiveData<LoanOfferDetailsDataState> dataState;
  
  public final r<LoanOfferDetailsDataState> mutableDataState;
  
  public final r<LoanOfferDetailsViewState> mutableViewState;
  
  public boolean openState;
  
  public final LiveData<LoanOfferDetailsViewState> viewState;
  
  @Inject
  public LoanOfferDetailsViewModel() {
    r<LoanOfferDetailsViewState> r1 = new r();
    this.mutableViewState = r1;
    this.viewState = (LiveData<LoanOfferDetailsViewState>)r1;
    r1 = new r();
    this.mutableDataState = (r)r1;
    this.dataState = (LiveData)r1;
  }
  
  public final LiveData<LoanOfferDetailsDataState> getDataState() {
    return this.dataState;
  }
  
  public final LiveData<LoanOfferDetailsViewState> getViewState() {
    return this.viewState;
  }
  
  public void initialize(c paramc) {
    LoanOfferDetailsDataState.Empty empty;
    k.b(paramc, "loanOffer");
    this.mutableViewState.b(new LoanOfferDetailsViewState(this.openState));
    r<LoanOfferDetailsDataState> r1 = this.mutableDataState;
    a a = paramc.g();
    if (a != null) {
      String str2 = AmountFormatter.Companion.format(a.b(), paramc.f());
      s s1 = s.a;
      String str3 = String.format("+ %s", Arrays.copyOf(new Object[] { AmountFormatter.Companion.format(a.b(), paramc.j()) }1));
      k.a(str3, "java.lang.String.format(format, *args)");
      s s2 = s.a;
      String str4 = a.d();
      double d1 = a.f();
      double d2 = 100;
      Double.isNaN(d2);
      str4 = String.format("%s (%d%%)", Arrays.copyOf(new Object[] { str4, Integer.valueOf((int)(d1 * d2)) }, 2));
      k.a(str4, "java.lang.String.format(format, *args)");
      s s3 = s.a;
      String str6 = String.format("+ %s", Arrays.copyOf(new Object[] { AmountFormatter.Companion.format(a.b(), a.c() / 100 * 100) }1));
      k.a(str6, "java.lang.String.format(format, *args)");
      String str5 = AmountFormatter.Companion.format(a.b(), paramc.a());
      s s4 = s.a;
      d1 = paramc.k();
      Double.isNaN(d2);
      String str7 = String.format("Interest (%d%%)", Arrays.copyOf(new Object[] { Integer.valueOf((int)(d2 * d1)) }, 1));
      k.a(str7, "java.lang.String.format(format, *args)");
      s s5 = s.a;
      String str1 = String.format("+ %s", Arrays.copyOf(new Object[] { AmountFormatter.Companion.format(a.b(), paramc.b() - paramc.a()) }1));
      k.a(str1, "java.lang.String.format(format, *args)");
      LoanOfferDetailsDataState.DisbursementFees disbursementFees = new LoanOfferDetailsDataState.DisbursementFees(str2, str3, str4, str6, str5, str7, str1, AmountFormatter.Companion.format(paramc.c(), paramc.b()));
    } else {
      empty = LoanOfferDetailsDataState.Empty.INSTANCE;
    } 
    r1.b(empty);
  }
  
  public final void onArrowClicked() {
    int i = this.openState ^ true;
    this.openState = i;
    this.mutableViewState.b(new LoanOfferDetailsViewState(i));
  }
  
  public static abstract class LoanOfferDetailsDataState {
    public LoanOfferDetailsDataState() {}
    
    public static final class DisbursementFees extends LoanOfferDetailsDataState {
      public final String disbursementAmountValue;
      
      public final String interestTitle;
      
      public final String interestValue;
      
      public final String loanAmountValue;
      
      public final String processingFeesValue;
      
      public final String taxTitle;
      
      public final String taxValue;
      
      public final String totalValueToPay;
      
      public DisbursementFees(String param2String1, String param2String2, String param2String3, String param2String4, String param2String5, String param2String6, String param2String7, String param2String8) {
        super(null);
        this.disbursementAmountValue = param2String1;
        this.processingFeesValue = param2String2;
        this.taxTitle = param2String3;
        this.taxValue = param2String4;
        this.loanAmountValue = param2String5;
        this.interestTitle = param2String6;
        this.interestValue = param2String7;
        this.totalValueToPay = param2String8;
      }
      
      public final String component1() {
        return this.disbursementAmountValue;
      }
      
      public final String component2() {
        return this.processingFeesValue;
      }
      
      public final String component3() {
        return this.taxTitle;
      }
      
      public final String component4() {
        return this.taxValue;
      }
      
      public final String component5() {
        return this.loanAmountValue;
      }
      
      public final String component6() {
        return this.interestTitle;
      }
      
      public final String component7() {
        return this.interestValue;
      }
      
      public final String component8() {
        return this.totalValueToPay;
      }
      
      public final DisbursementFees copy(String param2String1, String param2String2, String param2String3, String param2String4, String param2String5, String param2String6, String param2String7, String param2String8) {
        k.b(param2String1, "disbursementAmountValue");
        k.b(param2String2, "processingFeesValue");
        k.b(param2String3, "taxTitle");
        k.b(param2String4, "taxValue");
        k.b(param2String5, "loanAmountValue");
        k.b(param2String6, "interestTitle");
        k.b(param2String7, "interestValue");
        k.b(param2String8, "totalValueToPay");
        return new DisbursementFees(param2String1, param2String2, param2String3, param2String4, param2String5, param2String6, param2String7, param2String8);
      }
      
      public boolean equals(Object param2Object) {
        if (this != param2Object) {
          if (param2Object instanceof DisbursementFees) {
            param2Object = param2Object;
            if (k.a(this.disbursementAmountValue, ((DisbursementFees)param2Object).disbursementAmountValue) && k.a(this.processingFeesValue, ((DisbursementFees)param2Object).processingFeesValue) && k.a(this.taxTitle, ((DisbursementFees)param2Object).taxTitle) && k.a(this.taxValue, ((DisbursementFees)param2Object).taxValue) && k.a(this.loanAmountValue, ((DisbursementFees)param2Object).loanAmountValue) && k.a(this.interestTitle, ((DisbursementFees)param2Object).interestTitle) && k.a(this.interestValue, ((DisbursementFees)param2Object).interestValue) && k.a(this.totalValueToPay, ((DisbursementFees)param2Object).totalValueToPay))
              return true; 
          } 
          return false;
        } 
        return true;
      }
      
      public final String getDisbursementAmountValue() {
        return this.disbursementAmountValue;
      }
      
      public final String getInterestTitle() {
        return this.interestTitle;
      }
      
      public final String getInterestValue() {
        return this.interestValue;
      }
      
      public final String getLoanAmountValue() {
        return this.loanAmountValue;
      }
      
      public final String getProcessingFeesValue() {
        return this.processingFeesValue;
      }
      
      public final String getTaxTitle() {
        return this.taxTitle;
      }
      
      public final String getTaxValue() {
        return this.taxValue;
      }
      
      public final String getTotalValueToPay() {
        return this.totalValueToPay;
      }
      
      public int hashCode() {
        byte b1;
        byte b2;
        byte b3;
        byte b4;
        byte b5;
        byte b6;
        byte b7;
        String str = this.disbursementAmountValue;
        int i = 0;
        if (str != null) {
          b1 = str.hashCode();
        } else {
          b1 = 0;
        } 
        str = this.processingFeesValue;
        if (str != null) {
          b2 = str.hashCode();
        } else {
          b2 = 0;
        } 
        str = this.taxTitle;
        if (str != null) {
          b3 = str.hashCode();
        } else {
          b3 = 0;
        } 
        str = this.taxValue;
        if (str != null) {
          b4 = str.hashCode();
        } else {
          b4 = 0;
        } 
        str = this.loanAmountValue;
        if (str != null) {
          b5 = str.hashCode();
        } else {
          b5 = 0;
        } 
        str = this.interestTitle;
        if (str != null) {
          b6 = str.hashCode();
        } else {
          b6 = 0;
        } 
        str = this.interestValue;
        if (str != null) {
          b7 = str.hashCode();
        } else {
          b7 = 0;
        } 
        str = this.totalValueToPay;
        if (str != null)
          i = str.hashCode(); 
        return ((((((b1 * 31 + b2) * 31 + b3) * 31 + b4) * 31 + b5) * 31 + b6) * 31 + b7) * 31 + i;
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DisbursementFees(disbursementAmountValue=");
        stringBuilder.append(this.disbursementAmountValue);
        stringBuilder.append(", processingFeesValue=");
        stringBuilder.append(this.processingFeesValue);
        stringBuilder.append(", taxTitle=");
        stringBuilder.append(this.taxTitle);
        stringBuilder.append(", taxValue=");
        stringBuilder.append(this.taxValue);
        stringBuilder.append(", loanAmountValue=");
        stringBuilder.append(this.loanAmountValue);
        stringBuilder.append(", interestTitle=");
        stringBuilder.append(this.interestTitle);
        stringBuilder.append(", interestValue=");
        stringBuilder.append(this.interestValue);
        stringBuilder.append(", totalValueToPay=");
        stringBuilder.append(this.totalValueToPay);
        stringBuilder.append(")");
        return stringBuilder.toString();
      }
    }
    
    public static final class Empty extends LoanOfferDetailsDataState {
      public static final Empty INSTANCE = new Empty();
      
      public Empty() {
        super(null);
      }
    }
  }
  
  public static final class DisbursementFees extends LoanOfferDetailsDataState {
    public final String disbursementAmountValue;
    
    public final String interestTitle;
    
    public final String interestValue;
    
    public final String loanAmountValue;
    
    public final String processingFeesValue;
    
    public final String taxTitle;
    
    public final String taxValue;
    
    public final String totalValueToPay;
    
    public DisbursementFees(String param1String1, String param1String2, String param1String3, String param1String4, String param1String5, String param1String6, String param1String7, String param1String8) {
      super(null);
      this.disbursementAmountValue = param1String1;
      this.processingFeesValue = param1String2;
      this.taxTitle = param1String3;
      this.taxValue = param1String4;
      this.loanAmountValue = param1String5;
      this.interestTitle = param1String6;
      this.interestValue = param1String7;
      this.totalValueToPay = param1String8;
    }
    
    public final String component1() {
      return this.disbursementAmountValue;
    }
    
    public final String component2() {
      return this.processingFeesValue;
    }
    
    public final String component3() {
      return this.taxTitle;
    }
    
    public final String component4() {
      return this.taxValue;
    }
    
    public final String component5() {
      return this.loanAmountValue;
    }
    
    public final String component6() {
      return this.interestTitle;
    }
    
    public final String component7() {
      return this.interestValue;
    }
    
    public final String component8() {
      return this.totalValueToPay;
    }
    
    public final DisbursementFees copy(String param1String1, String param1String2, String param1String3, String param1String4, String param1String5, String param1String6, String param1String7, String param1String8) {
      k.b(param1String1, "disbursementAmountValue");
      k.b(param1String2, "processingFeesValue");
      k.b(param1String3, "taxTitle");
      k.b(param1String4, "taxValue");
      k.b(param1String5, "loanAmountValue");
      k.b(param1String6, "interestTitle");
      k.b(param1String7, "interestValue");
      k.b(param1String8, "totalValueToPay");
      return new DisbursementFees(param1String1, param1String2, param1String3, param1String4, param1String5, param1String6, param1String7, param1String8);
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object instanceof DisbursementFees) {
          param1Object = param1Object;
          if (k.a(this.disbursementAmountValue, ((DisbursementFees)param1Object).disbursementAmountValue) && k.a(this.processingFeesValue, ((DisbursementFees)param1Object).processingFeesValue) && k.a(this.taxTitle, ((DisbursementFees)param1Object).taxTitle) && k.a(this.taxValue, ((DisbursementFees)param1Object).taxValue) && k.a(this.loanAmountValue, ((DisbursementFees)param1Object).loanAmountValue) && k.a(this.interestTitle, ((DisbursementFees)param1Object).interestTitle) && k.a(this.interestValue, ((DisbursementFees)param1Object).interestValue) && k.a(this.totalValueToPay, ((DisbursementFees)param1Object).totalValueToPay))
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final String getDisbursementAmountValue() {
      return this.disbursementAmountValue;
    }
    
    public final String getInterestTitle() {
      return this.interestTitle;
    }
    
    public final String getInterestValue() {
      return this.interestValue;
    }
    
    public final String getLoanAmountValue() {
      return this.loanAmountValue;
    }
    
    public final String getProcessingFeesValue() {
      return this.processingFeesValue;
    }
    
    public final String getTaxTitle() {
      return this.taxTitle;
    }
    
    public final String getTaxValue() {
      return this.taxValue;
    }
    
    public final String getTotalValueToPay() {
      return this.totalValueToPay;
    }
    
    public int hashCode() {
      byte b1;
      byte b2;
      byte b3;
      byte b4;
      byte b5;
      byte b6;
      byte b7;
      String str = this.disbursementAmountValue;
      int i = 0;
      if (str != null) {
        b1 = str.hashCode();
      } else {
        b1 = 0;
      } 
      str = this.processingFeesValue;
      if (str != null) {
        b2 = str.hashCode();
      } else {
        b2 = 0;
      } 
      str = this.taxTitle;
      if (str != null) {
        b3 = str.hashCode();
      } else {
        b3 = 0;
      } 
      str = this.taxValue;
      if (str != null) {
        b4 = str.hashCode();
      } else {
        b4 = 0;
      } 
      str = this.loanAmountValue;
      if (str != null) {
        b5 = str.hashCode();
      } else {
        b5 = 0;
      } 
      str = this.interestTitle;
      if (str != null) {
        b6 = str.hashCode();
      } else {
        b6 = 0;
      } 
      str = this.interestValue;
      if (str != null) {
        b7 = str.hashCode();
      } else {
        b7 = 0;
      } 
      str = this.totalValueToPay;
      if (str != null)
        i = str.hashCode(); 
      return ((((((b1 * 31 + b2) * 31 + b3) * 31 + b4) * 31 + b5) * 31 + b6) * 31 + b7) * 31 + i;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("DisbursementFees(disbursementAmountValue=");
      stringBuilder.append(this.disbursementAmountValue);
      stringBuilder.append(", processingFeesValue=");
      stringBuilder.append(this.processingFeesValue);
      stringBuilder.append(", taxTitle=");
      stringBuilder.append(this.taxTitle);
      stringBuilder.append(", taxValue=");
      stringBuilder.append(this.taxValue);
      stringBuilder.append(", loanAmountValue=");
      stringBuilder.append(this.loanAmountValue);
      stringBuilder.append(", interestTitle=");
      stringBuilder.append(this.interestTitle);
      stringBuilder.append(", interestValue=");
      stringBuilder.append(this.interestValue);
      stringBuilder.append(", totalValueToPay=");
      stringBuilder.append(this.totalValueToPay);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class Empty extends LoanOfferDetailsDataState {
    public static final Empty INSTANCE = new Empty();
    
    public Empty() {
      super(null);
    }
  }
  
  public static final class LoanOfferDetailsViewState {
    public final boolean open;
    
    public LoanOfferDetailsViewState(boolean param1Boolean) {
      this.open = param1Boolean;
    }
    
    public final boolean component1() {
      return this.open;
    }
    
    public final LoanOfferDetailsViewState copy(boolean param1Boolean) {
      return new LoanOfferDetailsViewState(param1Boolean);
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object instanceof LoanOfferDetailsViewState) {
          param1Object = param1Object;
          if (this.open == ((LoanOfferDetailsViewState)param1Object).open)
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final boolean getOpen() {
      return this.open;
    }
    
    public int hashCode() {
      boolean bool1 = this.open;
      boolean bool2 = bool1;
      if (bool1)
        bool2 = true; 
      return bool2;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("LoanOfferDetailsViewState(open=");
      stringBuilder.append(this.open);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.offers;

import f.d.b.i.c;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.k;
import java.util.List;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

@f(c = "ng.com.fairmoney.android.loan.offers.LoanOffersViewModel$getLoanOffers$1", f = "LoanOffersViewModel.kt", l = {}, m = "invokeSuspend")
public final class LoanOffersViewModel$getLoanOffers$1 extends k implements p<String, d<? super a<? extends List<? extends c>>>, Object> {
  public int label;
  
  public String p$0;
  
  public LoanOffersViewModel$getLoanOffers$1(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    LoanOffersViewModel$getLoanOffers$1 loanOffersViewModel$getLoanOffers$1 = new LoanOffersViewModel$getLoanOffers$1(paramd);
    loanOffersViewModel$getLoanOffers$1.p$0 = (String)paramObject;
    return (d<k>)loanOffersViewModel$getLoanOffers$1;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((LoanOffersViewModel$getLoanOffers$1)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      return c.a(c.a(LoanOffersViewModel.access$getLoanUseCase$p(LoanOffersViewModel.this).a((String)paramObject), new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(null) {
              public int label;
              
              public b p$;
              
              public Throwable p$0;
              
              public final d<k> create(b<? super List<c>> param1b, Throwable param1Throwable, d<? super k> param1d) {
                k.b(param1b, "$this$create");
                k.b(param1Throwable, "it");
                k.b(param1d, "continuation");
                q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> q1 = new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(LoanOffersViewModel$getLoanOffers$1.this, param1d);
                q1.p$ = param1b;
                q1.p$0 = param1Throwable;
                return (d)q1;
              }
              
              public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                return ((null)create((b<? super List<c>>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
              }
              
              public final Object invokeSuspend(Object param1Object) {
                c.a();
                if (this.label == 0) {
                  g.a(param1Object);
                  param1Object = this.p$0;
                  LoanOffersViewModel.access$getMutableLoanOffersState$p(LoanOffersViewModel.this).b(new LoanOffersViewModel.LoanOffersState.Failure((Throwable)param1Object));
                  return k.a;
                } 
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              }
            }), new p<List<? extends c>, d<? super k>, Object>(null) {
            public int label;
            
            public List p$0;
            
            public final d<k> create(Object param1Object, d<?> param1d) {
              k.b(param1d, "completion");
              p<List<? extends c>, d<? super k>, Object> p1 = new p<List<? extends c>, d<? super k>, Object>(LoanOffersViewModel$getLoanOffers$1.this, param1d);
              p1.p$0 = (List)param1Object;
              return (d)p1;
            }
            
            public final Object invoke(Object param1Object1, Object param1Object2) {
              return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
            }
            
            public final Object invokeSuspend(Object param1Object) {
              c.a();
              if (this.label == 0) {
                g.a(param1Object);
                param1Object = this.p$0;
                LoanOffersViewModel.access$getMutableLoanOffersState$p(LoanOffersViewModel.this).b(new LoanOffersViewModel.LoanOffersState.Success((List<c>)param1Object));
                return k.a;
              } 
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
          });
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offers\LoanOffersViewModel$getLoanOffers$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
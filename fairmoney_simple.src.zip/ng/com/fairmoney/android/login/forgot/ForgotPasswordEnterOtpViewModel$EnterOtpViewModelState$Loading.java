package ng.com.fairmoney.android.login.forgot;

public final class Loading extends ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState {
  public final boolean isLoading;
  
  public Loading(boolean paramBoolean) {
    super(null);
    this.isLoading = paramBoolean;
  }
  
  public final boolean isLoading() {
    return this.isLoading;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordEnterOtpViewModel$EnterOtpViewModelState$Loading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
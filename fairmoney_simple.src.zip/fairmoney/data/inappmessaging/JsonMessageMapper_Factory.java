package fairmoney.data.inappmessaging;

import com.fairmoney.data.inappmessaging.JsonMessageMapper;
import g.b.d;

public final class JsonMessageMapper_Factory implements d<JsonMessageMapper> {
  public static com.fairmoney.data.inappmessaging.JsonMessageMapper_Factory create() {
    return InstanceHolder.access$000();
  }
  
  public static JsonMessageMapper newInstance() {
    return new JsonMessageMapper();
  }
  
  public JsonMessageMapper get() {
    return newInstance();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\inappmessaging\JsonMessageMapper_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
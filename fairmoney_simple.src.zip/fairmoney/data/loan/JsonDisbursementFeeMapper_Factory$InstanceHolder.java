package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonDisbursementFeeMapper_Factory;

public final class InstanceHolder {
  public static final JsonDisbursementFeeMapper_Factory INSTANCE = new JsonDisbursementFeeMapper_Factory();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonDisbursementFeeMapper_Factory$InstanceHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
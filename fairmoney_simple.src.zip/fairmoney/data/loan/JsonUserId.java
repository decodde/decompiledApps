package fairmoney.data.loan;

import j.q.d.k;

public final class JsonUserId {
  public final String userId;
  
  public JsonUserId(String paramString) {
    this.userId = paramString;
  }
  
  public final String component1() {
    return this.userId;
  }
  
  public final com.fairmoney.data.loan.JsonUserId copy(String paramString) {
    k.b(paramString, "userId");
    return new com.fairmoney.data.loan.JsonUserId(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.loan.JsonUserId) {
        paramObject = paramObject;
        if (k.a(this.userId, ((com.fairmoney.data.loan.JsonUserId)paramObject).userId))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getUserId() {
    return this.userId;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.userId;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonUserId(userId=");
    stringBuilder.append(this.userId);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonUserId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
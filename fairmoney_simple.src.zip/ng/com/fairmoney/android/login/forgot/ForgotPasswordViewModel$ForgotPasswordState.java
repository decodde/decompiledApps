package ng.com.fairmoney.android.login.forgot;

import f.d.b.k.f;
import j.q.d.g;

public abstract class ForgotPasswordState {
  public ForgotPasswordState() {}
  
  public static final class Error extends ForgotPasswordState {
    public final Throwable throwable;
    
    public Error(Throwable param2Throwable) {
      super(null);
      this.throwable = param2Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Loading extends ForgotPasswordState {
    public final boolean isLoading;
    
    public Loading(boolean param2Boolean) {
      super(null);
      this.isLoading = param2Boolean;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
  }
  
  public static final class Success extends ForgotPasswordState {
    public final f phoneNumber;
    
    public final String ussdCode;
    
    public Success(f param2f, String param2String) {
      super(null);
      this.phoneNumber = param2f;
      this.ussdCode = param2String;
    }
    
    public final f getPhoneNumber() {
      return this.phoneNumber;
    }
    
    public final String getUssdCode() {
      return this.ussdCode;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordViewModel$ForgotPasswordState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.injection;

import f.d.b.j.f;
import f.d.c.j;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DomainComponent_paymentUseCase implements Provider<f> {
  public final j domainComponent;
  
  public com_fairmoney_injection_DomainComponent_paymentUseCase(j paramj) {
    this.domainComponent = paramj;
  }
  
  public f get() {
    f f = this.domainComponent.c();
    g.a(f, "Cannot return null from a non-@Nullable component method");
    return f;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DomainComponent_paymentUseCase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
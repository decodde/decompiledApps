package ng.com.fairmoney.android.splash;

import j.q.d.g;

public abstract class RouteState {
  public RouteState() {}
  
  public static final class WalkThrough extends RouteState {
    public static final WalkThrough INSTANCE = new WalkThrough();
    
    public WalkThrough() {
      super(null);
    }
  }
  
  public static final class Welcome extends RouteState {
    public static final Welcome INSTANCE = new Welcome();
    
    public Welcome() {
      super(null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\splash\SplashViewModel$RouteState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
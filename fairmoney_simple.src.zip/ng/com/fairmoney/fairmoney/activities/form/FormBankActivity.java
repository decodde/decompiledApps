package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import com.google.android.material.textfield.TextInputLayout;
import d.b.k.c;
import d.l.a.d;
import d.o.y;
import d.o.z;
import f.d.b.k.f;
import f.d.c.b;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferActivity;
import ng.com.fairmoney.fairmoney.activities.LoanOffersActivity;
import ng.com.fairmoney.fairmoney.adapters.BankNamesAdapter;
import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.models.BankListItem;
import ng.com.fairmoney.fairmoney.models.CreditEligibility;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.utils.BankAccountUtils;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.utils.Utils;
import ng.com.fairmoney.fairmoney.viewmodels.FormBankViewModel;
import ng.com.fairmoney.fairmoney.views.StyledSpinner;

public class FormBankActivity extends FormActivity {
  public static final String EXTRA_BANK_DETAILS = "EXTRA_BANK_DETAILS";
  
  public static final String EXTRA_BVN = "EXTRA_BVN";
  
  public StyledSpinner bankSpinner;
  
  public Button btDialBvn;
  
  public Button btNext;
  
  public String bvn;
  
  public c dialog;
  
  public EditText etBankAccountNumber;
  
  public EditText etBvn;
  
  public FormBankViewModel formBankViewModel;
  
  public boolean isShortBanksListDisplayed = false;
  
  public ImageView ivBvnLock;
  
  public LinearLayout llBankFormBvnInfo;
  
  public SharedPreferences preferences;
  
  @Inject
  public y.b viewModelFactory;
  
  private void checkCreditEligibility(final BankDetails bankDetails) {
    RetrofitSession.getInstance((Context)this).getLoanAppplicationManager().checkCreditEligibility(bankDetails, new APIResponse<CreditEligibility>() {
          public void failure(int param1Int, String param1String) {
            FormBankActivity.this.showNewToastMessage(param1String, 1);
            FormBankActivity.this.enableNextButton(true);
          }
          
          public void success(CreditEligibility param1CreditEligibility) {
            if (param1CreditEligibility.isEligible()) {
              if (param1CreditEligibility.isBvnVerificationMandatory()) {
                FormBankActivity.this.goToBvnPhoneCheck(bankDetails, param1CreditEligibility);
              } else {
                FormBankActivity.this.goToFinalLoanOfferActivity();
              } 
            } else {
              FormBankActivity.this.displayDialogWithMessage(param1CreditEligibility.getMessage());
              FormBankActivity.this.enableNextButton(true);
            } 
          }
        });
  }
  
  private void displayDialogWithMessage(String paramString) {
    if (this.isActivityActive) {
      c.a a = new c.a((Context)this, 0);
      a.c(2131820776);
      a.a(paramString);
      a.c(2131821021, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface param1DialogInterface, int param1Int) {
              param1DialogInterface.dismiss();
            }
          });
      this.dialog = a.c();
    } 
  }
  
  private void enableNextButton(boolean paramBoolean) {
    byte b1;
    Button button = this.btNext;
    if (paramBoolean) {
      b1 = 0;
    } else {
      b1 = 8;
    } 
    button.setVisibility(b1);
  }
  
  private BankDetails getAndStoreBankDetails() {
    BankDetails bankDetails = new BankDetails();
    bankDetails.setBvn(this.etBvn.getText().toString());
    bankDetails.setBankAccountNumber(this.etBankAccountNumber.getText().toString());
    bankDetails.setBankName(this.bankSpinner.getText().toString());
    this.preferences.edit().putString("et_bank_details_bvn", bankDetails.getBvn()).putString("sp_bank_details_bank", bankDetails.getBankName()).putString("et_bank_details_account_number", bankDetails.getBankAccountNumber()).apply();
    return bankDetails;
  }
  
  private void goToBvnPhoneCheck(BankDetails paramBankDetails, CreditEligibility paramCreditEligibility) {
    Intent intent = new Intent(getApplicationContext(), VerifyBvnPhoneOtpActivity.class);
    intent.putExtra("EXTRA_BANK_DETAILS", (Parcelable)paramBankDetails);
    intent.putExtra("EXTRA_PHONE_NUMBER", (Serializable)new f("+234", paramCreditEligibility.getBvnPhone()));
    intent.putExtra("EXTRA_CAN_BVN_BE_UPDATED", paramCreditEligibility.canBvnBeUpdated());
    startActivity(intent);
    finish();
  }
  
  private void goToFinalLoanOfferActivity() {
    startActivity(new Intent(getApplicationContext(), FinalLoanOfferActivity.class));
    finish();
  }
  
  private void hideBvnFields() {
    TextInputLayout textInputLayout = (TextInputLayout)findViewById(2131296991);
    this.llBankFormBvnInfo.setVisibility(8);
    textInputLayout.setVisibility(8);
  }
  
  private void initBankNumberWatcher() {
    this.etBankAccountNumber.addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            if (param1Editable.length() == 10) {
              FormBankActivity.this.setupSortedSpinner(param1Editable.toString());
              FormBankActivity.access$102(FormBankActivity.this, true);
            } else if (FormBankActivity.this.isShortBanksListDisplayed) {
              FormBankActivity.this.initBankSpinner();
              FormBankActivity.access$102(FormBankActivity.this, false);
            } 
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
  }
  
  private void initBankSpinner() {
    ArrayAdapter arrayAdapter = ArrayAdapter.createFromResource((Context)this, getResources().getIdentifier("bankName", "array", getPackageName()), 17367049);
    this.bankSpinner.setAdapter((ListAdapter)arrayAdapter);
  }
  
  private void initButtons() {
    this.btDialBvn.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Intent intent = new Intent("android.intent.action.DIAL", Uri.fromParts("tel", FormBankActivity.this.getString(2131820732), null));
            FormBankActivity.this.startActivity(intent);
          }
        });
    this.btNext.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (!FormBankActivity.this.checkAnswersValidity())
              return; 
            FormBankActivity.this.goToNextActivity();
          }
        });
  }
  
  private void initEditTextsFocusChangedListeners() {
    this.etBvn.setOnFocusChangeListener(new View.OnFocusChangeListener() {
          public void onFocusChange(View param1View, boolean param1Boolean) {
            byte b;
            param1View = FormBankActivity.this.findViewById(2131297057);
            if (param1Boolean) {
              b = 0;
            } else {
              b = 8;
            } 
            param1View.setVisibility(b);
          }
        });
    this.etBankAccountNumber.setOnFocusChangeListener(new View.OnFocusChangeListener() {
          public void onFocusChange(View param1View, boolean param1Boolean) {
            byte b;
            param1View = FormBankActivity.this.findViewById(2131297056);
            if (param1Boolean) {
              b = 0;
            } else {
              b = 8;
            } 
            param1View.setVisibility(b);
          }
        });
  }
  
  private void initView() {
    initEditTextsFocusChangedListeners();
    initBankNumberWatcher();
    initBankSpinner();
    initButtons();
    initViewModel();
  }
  
  private void initViewModel() {
    ViewModelComponentKt.create((b)getApplication()).inject(this);
    this.formBankViewModel = (FormBankViewModel)z.a((d)this, this.viewModelFactory).a(FormBankViewModel.class);
  }
  
  private void setBvn(String paramString) {
    if (paramString != null) {
      this.etBvn.setText(paramString);
      this.etBvn.setEnabled(false);
      this.ivBvnLock.setVisibility(0);
      this.ivBvnLock.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
              FormBankActivity formBankActivity = FormBankActivity.this;
              formBankActivity.showNewToastMessage(formBankActivity.getString(2131820628), 1);
            }
          });
      this.llBankFormBvnInfo.setVisibility(8);
    } 
  }
  
  private void setupSortedSpinner(String paramString) {
    final BankNamesAdapter bankNamesAdapter = new BankNamesAdapter((Context)this, BankAccountUtils.getOrderedBanks(paramString));
    this.bankSpinner.setAdapter((ListAdapter)bankNamesAdapter);
    this.bankSpinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
            String str;
            BankListItem bankListItem = (BankListItem)bankNamesAdapter.getItem(param1Int);
            StyledSpinner styledSpinner = FormBankActivity.this.bankSpinner;
            if (bankListItem.isEnabled()) {
              str = bankListItem.getName();
            } else {
              str = "";
            } 
            styledSpinner.setText(str);
          }
        });
  }
  
  public List<Map<String, String>> getFormParameters() {
    return Utils.getActivityConfigValue((Context)this, 2131755009);
  }
  
  public void goToNextActivity() {
    enableNextButton(false);
    checkCreditEligibility(getAndStoreBankDetails());
  }
  
  public void goToPreviousActivity() {
    startActivity(new Intent(getApplicationContext(), LoanOffersActivity.class));
    finish();
  }
  
  public void onClickOnNextButton(View paramView) {
    reportClickOnNextButton();
    nextPage(paramView);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.preferences = getSharedPreferences("CurrentUser", 0);
    this.btNext = (Button)findViewById(2131296373);
    this.bankSpinner = (StyledSpinner)findViewById(2131296928);
    this.etBvn = (EditText)findViewById(2131296523);
    this.etBankAccountNumber = (EditText)findViewById(2131296522);
    this.btDialBvn = (Button)findViewById(2131296372);
    this.ivBvnLock = (ImageView)findViewById(2131296620);
    this.llBankFormBvnInfo = (LinearLayout)findViewById(2131296679);
    initView();
    if (getIntent() != null)
      this.bvn = getIntent().getStringExtra("EXTRA_BVN"); 
    fillFormWithPreviousResponses();
    Tracking.sendUniqueEvent((Context)this, new Event("form", "bankDetails"));
    if (this.formBankViewModel.isFinancialDetailsEnabled()) {
      setBvn(this.bvn);
    } else {
      hideBvnFields();
    } 
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.isActivityActive = false;
    c c1 = this.dialog;
    if (c1 != null && c1.isShowing())
      this.dialog.dismiss(); 
  }
  
  public int provideContentViewId() {
    return 2131492898;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
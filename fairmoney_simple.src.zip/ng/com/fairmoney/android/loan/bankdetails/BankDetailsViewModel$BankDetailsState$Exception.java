package ng.com.fairmoney.android.loan.bankdetails;

import j.q.d.k;

public final class Exception extends BankDetailsViewModel.BankDetailsState {
  public final String message;
  
  public Exception(String paramString) {
    super(null);
    this.message = paramString;
  }
  
  public final String component1() {
    return this.message;
  }
  
  public final Exception copy(String paramString) {
    return new Exception(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof Exception) {
        paramObject = paramObject;
        if (k.a(this.message, ((Exception)paramObject).message))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getMessage() {
    return this.message;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.message;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Exception(message=");
    stringBuilder.append(this.message);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$BankDetailsState$Exception.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
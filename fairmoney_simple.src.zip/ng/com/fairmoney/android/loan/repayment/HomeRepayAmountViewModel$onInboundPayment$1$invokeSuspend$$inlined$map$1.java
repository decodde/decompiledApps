package ng.com.fairmoney.android.loan.repayment;

import f.d.b.j.b;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.a;
import k.a.h2.b;

public final class HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 implements a<HomeRepayAmountViewModel.HomeRepayAmountState.Inbound> {
  public HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1(HomeRepayAmountViewModel$onInboundPayment$1 paramHomeRepayAmountViewModel$onInboundPayment$1) {}
  
  public Object collect(b paramb, d paramd) {
    Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
          public Object emit(Object param1Object, d param1d) {
            b b1 = this.$this_unsafeFlow$inlined;
            param1Object = param1Object;
            param1Object = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(HomeRepayAmountViewModel$onInboundPayment$1.this.$amountInCent, (b)param1Object), param1d);
            return (param1Object == c.a()) ? param1Object : k.a;
          }
        }paramd);
    return (object == c.a()) ? object : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
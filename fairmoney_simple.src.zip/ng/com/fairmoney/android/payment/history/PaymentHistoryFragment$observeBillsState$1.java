package ng.com.fairmoney.android.payment.history;

import android.widget.Button;
import d.o.s;
import f.d.b.j.a;
import j.l.i;
import java.util.ArrayList;
import java.util.List;
import ng.com.fairmoney.fairmoney.adapters.PaymentsHistoryAdapter;
import ng.com.fairmoney.fairmoney.models.Bill;

public final class PaymentHistoryFragment$observeBillsState$1<T> implements s<PaymentHistoryViewModel.BillState> {
  public final void onChanged(PaymentHistoryViewModel.BillState paramBillState) {
    ArrayList<Bill> arrayList;
    if (paramBillState instanceof PaymentHistoryViewModel.BillState.Success) {
      PaymentsHistoryAdapter paymentsHistoryAdapter = PaymentHistoryFragment.access$getAdapter$p(PaymentHistoryFragment.this);
      List<a> list = ((PaymentHistoryViewModel.BillState.Success)paramBillState).getBills();
      arrayList = new ArrayList(i.a(list, 10));
      for (a a : list) {
        Bill bill = new Bill();
        bill.setUserReference(a.a());
        bill.setServiceCategory("Service Category");
        arrayList.add(bill);
      } 
      paymentsHistoryAdapter.setBillList(arrayList);
      PaymentHistoryFragment.access$getViewFlipper$p(PaymentHistoryFragment.this).setDisplayedChild(0);
    } else {
      PaymentHistoryViewModel.BillState.Loading loading;
      if (arrayList instanceof PaymentHistoryViewModel.BillState.Loading) {
        Button button = PaymentHistoryFragment.access$getRetryCta$p(PaymentHistoryFragment.this);
        loading = (PaymentHistoryViewModel.BillState.Loading)arrayList;
        button.setEnabled(loading.isLoading() ^ true);
        PaymentHistoryFragment.access$getPaymentCta$p(PaymentHistoryFragment.this).setEnabled(true ^ loading.isLoading());
        PaymentHistoryFragment.access$getSwipeRefreshLayout$p(PaymentHistoryFragment.this).setRefreshing(loading.isLoading());
      } else if (loading instanceof PaymentHistoryViewModel.BillState.Error) {
        PaymentHistoryFragment.access$getViewFlipper$p(PaymentHistoryFragment.this).setDisplayedChild(2);
      } else if (loading instanceof PaymentHistoryViewModel.BillState.Empty) {
        PaymentHistoryFragment.access$getViewFlipper$p(PaymentHistoryFragment.this).setDisplayedChild(1);
      } 
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryFragment$observeBillsState$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
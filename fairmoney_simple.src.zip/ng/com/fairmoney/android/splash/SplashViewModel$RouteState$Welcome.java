package ng.com.fairmoney.android.splash;

public final class Welcome extends SplashViewModel.RouteState {
  public static final Welcome INSTANCE = new Welcome();
  
  public Welcome() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\splash\SplashViewModel$RouteState$Welcome.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.login;

import f.d.b.f.e;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.b;

public final class null implements b<e> {
  public null(LoginViewModel$fetchInAppMessage$$inlined$map$1 paramLoginViewModel$fetchInAppMessage$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    paramObject = paramObject;
    if (paramObject != null) {
      paramObject = new LoginViewModel.InAppMessageState.Success((e)paramObject);
    } else {
      paramObject = LoginViewModel.InAppMessageState.Empty.INSTANCE;
    } 
    paramObject = b1.emit(paramObject, paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel$fetchInAppMessage$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
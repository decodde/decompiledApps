package ng.com.fairmoney.android.injection;

import f.d.c.c;
import f.d.c.i;
import f.d.c.j;
import f.d.c.k;
import g.b.g;

public final class Factory implements ViewModelComponent.Factory {
  public Factory() {}
  
  public ViewModelComponent create(c paramc, i parami, j paramj, k paramk) {
    g.a(paramc);
    g.a(parami);
    g.a(paramj);
    g.a(paramk);
    return new DaggerViewModelComponent(paramc, parami, paramj, paramk, null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class InstalmentViewHolder extends RecyclerView.d0 {
  public CircleImageView circleImageView;
  
  public InstalmentViewHolder(View paramView) {
    super(paramView);
    this.circleImageView = (CircleImageView)paramView.findViewById(2131296445);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CustomListAdapter$InstalmentViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
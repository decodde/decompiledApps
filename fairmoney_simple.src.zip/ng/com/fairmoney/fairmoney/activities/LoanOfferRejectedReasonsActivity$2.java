package ng.com.fairmoney.fairmoney.activities;

import android.view.View;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    if (LoanOfferRejectedReasonsActivity.access$100(LoanOfferRejectedReasonsActivity.this).getText().toString().isEmpty()) {
      LoanOfferRejectedReasonsActivity.access$100(LoanOfferRejectedReasonsActivity.this).setError(LoanOfferRejectedReasonsActivity.this.getString(2131820818));
      return;
    } 
    LoanOfferRejectedReasonsActivity.access$200(LoanOfferRejectedReasonsActivity.this);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOfferRejectedReasonsActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
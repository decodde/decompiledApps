package ng.com.fairmoney.android.phoneinput;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.widget.EditText;
import f.d.c.b;
import j.e;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.textwatcher.PhoneNumberTextWatcher;

public final class NigerianPhoneNumberTextWatcher implements PhoneNumberTextWatcher {
  public int after;
  
  public final EditText etPhone;
  
  public boolean formatting;
  
  @Inject
  public NigerianPhoneNumberViewModel viewModel;
  
  public NigerianPhoneNumberTextWatcher(Context paramContext, EditText paramEditText) {
    this.etPhone = paramEditText;
    paramContext = paramContext.getApplicationContext();
    if (paramContext != null) {
      ViewModelComponentKt.create((b)paramContext).inject(this);
      paramEditText = this.etPhone;
      NigerianPhoneNumberViewModel nigerianPhoneNumberViewModel = this.viewModel;
      if (nigerianPhoneNumberViewModel != null) {
        paramEditText.setFilters(new InputFilter[] { (InputFilter)new InputFilter.LengthFilter(nigerianPhoneNumberViewModel.getMaxLength()) });
        return;
      } 
      k.d("viewModel");
      throw null;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  private final void transformText(Editable paramEditable) {
    int i = this.etPhone.getSelectionStart();
    NigerianPhoneNumberViewModel nigerianPhoneNumberViewModel = this.viewModel;
    if (nigerianPhoneNumberViewModel != null) {
      EditedPhoneNumber editedPhoneNumber = nigerianPhoneNumberViewModel.transformText(new e(paramEditable.toString(), Integer.valueOf(i)));
      this.etPhone.setFilters(new InputFilter[] { (InputFilter)new InputFilter.LengthFilter(editedPhoneNumber.getMaxLength()) });
      this.etPhone.setText(editedPhoneNumber.getEditedPhone());
      this.etPhone.setSelection(editedPhoneNumber.getCursorPos());
      return;
    } 
    k.d("viewModel");
    throw null;
  }
  
  public void afterTextChanged(Editable paramEditable) {
    k.b(paramEditable, "editable");
    formatPhoneNumber(paramEditable, false);
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    k.b(paramCharSequence, "s");
    this.after = paramInt3;
  }
  
  public void formatPhoneNumber(Editable paramEditable, boolean paramBoolean) {
    k.b(paramEditable, "editable");
    if (!this.formatting) {
      this.formatting = true;
      if (paramBoolean || this.after != 0)
        transformText(paramEditable); 
      this.formatting = false;
    } 
  }
  
  public final NigerianPhoneNumberViewModel getViewModel() {
    NigerianPhoneNumberViewModel nigerianPhoneNumberViewModel = this.viewModel;
    if (nigerianPhoneNumberViewModel != null)
      return nigerianPhoneNumberViewModel; 
    k.d("viewModel");
    throw null;
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    k.b(paramCharSequence, "s");
  }
  
  public final void setViewModel(NigerianPhoneNumberViewModel paramNigerianPhoneNumberViewModel) {
    k.b(paramNigerianPhoneNumberViewModel, "<set-?>");
    this.viewModel = paramNigerianPhoneNumberViewModel;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\NigerianPhoneNumberTextWatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
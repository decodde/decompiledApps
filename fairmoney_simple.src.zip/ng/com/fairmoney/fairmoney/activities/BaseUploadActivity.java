package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.location.Location;
import android.os.Build;
import android.provider.Settings;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import f.c.a.a;
import ng.com.fairmoney.fairmoney.managers.PhoneCharacteristicsManager;
import ng.com.fairmoney.fairmoney.models.AndroidAntennaLocation;
import ng.com.fairmoney.fairmoney.models.AndroidGpsLocation;
import ng.com.fairmoney.fairmoney.models.PhoneCharacteristics;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.network.UploadDataTask;
import ng.com.fairmoney.fairmoney.utils.LocationUtils;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import retrofit2.Call;

public abstract class BaseUploadActivity extends BasePermissionActivity {
  public Call getLoanOffersCall;
  
  public boolean isFirstCallToDataUpload = true;
  
  public Location lastLocation;
  
  public boolean locationSent = false;
  
  public LocationUtils locationUtils;
  
  public boolean phoneCharacteristicsSent = false;
  
  public UploadDataTask uploadDataTask;
  
  private boolean isMockLocation(Location paramLocation) {
    int i;
    if (Build.VERSION.SDK_INT >= 18) {
      boolean bool = paramLocation.isFromMockProvider();
    } else {
      i = Settings.Secure.getString(getContentResolver(), "mock_location").equals("0") ^ true;
    } 
    return i;
  }
  
  private void onSendLocationFailure(Location paramLocation, String paramString, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(" retryCount: ");
    stringBuilder.append(paramInt);
    a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)this, stringBuilder.toString())));
    if (paramInt > 0) {
      sendLocation(paramLocation, paramInt - 1);
    } else {
      showNewToastMessage(paramString, 1);
      if (!this.locationSent)
        displayRetryButtonAndErrorText(paramString); 
    } 
  }
  
  private void onSendLocationSuccess() {
    this.locationSent = true;
    sendPhoneCharacteristicsifNeeded();
  }
  
  private void sendPhoneCharacteristicsFailure(String paramString) {
    a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)this, paramString)));
    showNewToastMessage(paramString, 1);
    displayRetryButtonAndErrorText(paramString);
  }
  
  private void sendPhoneCharacteristicsSuccess() {
    if (this.isFirstCallToDataUpload) {
      this.isFirstCallToDataUpload = false;
      this.phoneCharacteristicsSent = true;
      UploadDataTask uploadDataTask = new UploadDataTask(this);
      this.uploadDataTask = uploadDataTask;
      uploadDataTask.execute((Object[])new Context[] { (Context)this });
    } 
  }
  
  private void sendPhoneCharacteristicsifNeeded() {
    if (!this.phoneCharacteristicsSent)
      sendPhoneCharacteristics(); 
  }
  
  public abstract void displayProgress(int paramInt);
  
  public abstract void displayRetryButtonAndErrorText(String paramString);
  
  public abstract void goToNextActivity();
  
  public void onDestroy() {
    super.onDestroy();
    UploadDataTask uploadDataTask = this.uploadDataTask;
    if (uploadDataTask != null)
      uploadDataTask.cancel(true); 
    LocationUtils locationUtils = this.locationUtils;
    if (locationUtils != null)
      locationUtils.stopLocationUpdates(); 
  }
  
  public void onStart() {
    super.onStart();
    if (this.getLoanOffersCall != null)
      displayRetryButtonAndErrorText(getString(2131820763)); 
  }
  
  public void onStop() {
    super.onStop();
    Call call = this.getLoanOffersCall;
    if (call != null)
      call.cancel(); 
  }
  
  public void sendLocation(final Location location, final int retryCount) {
    this.lastLocation = location;
    if (location != null) {
      AndroidAntennaLocation androidAntennaLocation;
      if (location.getProvider().contentEquals("fused")) {
        AndroidGpsLocation androidGpsLocation = new AndroidGpsLocation(location.getLatitude(), location.getLongitude(), isMockLocation(location));
      } else {
        androidAntennaLocation = new AndroidAntennaLocation(location.getLatitude(), location.getLongitude(), isMockLocation(location));
      } 
      JsonObject jsonObject = (new JsonParser()).parse((new Gson()).toJson(androidAntennaLocation)).getAsJsonObject();
      RetrofitSession.getInstance((Context)this).getLoanAppplicationManager().sendFormAnswers(jsonObject, new APIResponse<Object>() {
            public void failure(int param1Int, String param1String) {
              BaseUploadActivity.this.onSendLocationFailure(location, param1String, retryCount);
            }
            
            public void success(Object param1Object) {
              BaseUploadActivity.this.onSendLocationSuccess();
            }
          });
    } else {
      sendPhoneCharacteristics();
    } 
  }
  
  public void sendPhoneCharacteristics() {
    if (this.phoneCharacteristicsSent)
      return; 
    PhoneCharacteristics phoneCharacteristics = (new PhoneCharacteristicsManager()).getPhoneCharacteristics((Context)this);
    JsonObject jsonObject = (new JsonParser()).parse((new Gson()).toJson(phoneCharacteristics)).getAsJsonObject();
    RetrofitSession.getInstance((Context)this).getLoanAppplicationManager().sendFormAnswers(jsonObject, new APIResponse<Object>() {
          public void failure(int param1Int, String param1String) {
            BaseUploadActivity.this.sendPhoneCharacteristicsFailure(param1String);
          }
          
          public void success(Object param1Object) {
            BaseUploadActivity.this.sendPhoneCharacteristicsSuccess();
          }
        });
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\BaseUploadActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.payment.history;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ViewFlipper;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.w;
import d.o.y;
import d.o.z;
import f.d.b.j.a;
import f.d.c.b;
import j.l.i;
import j.q.d.g;
import j.q.d.k;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.activities.HomeActivity;
import ng.com.fairmoney.fairmoney.adapters.PaymentsHistoryAdapter;
import ng.com.fairmoney.fairmoney.models.Bill;

public final class PaymentHistoryFragment extends Fragment {
  public static final Companion Companion = new Companion(null);
  
  public static final int EMPTY_CHILD = 1;
  
  public static final int ERROR_CHILD = 2;
  
  public static final int SUCCESS_CHILD = 0;
  
  public PaymentsHistoryAdapter adapter;
  
  public Button paymentCta;
  
  public RecyclerView recyclerView;
  
  public Button retryCta;
  
  public SwipeRefreshLayout swipeRefreshLayout;
  
  public ViewFlipper viewFlipper;
  
  public PaymentHistoryViewModel viewModel;
  
  @Inject
  public y.b viewModelFactory;
  
  public PaymentHistoryFragment() {
    super(2131492987);
  }
  
  private final void observeBillsState() {
    PaymentHistoryViewModel paymentHistoryViewModel = this.viewModel;
    if (paymentHistoryViewModel != null) {
      paymentHistoryViewModel.getBills().a((l)this, new PaymentHistoryFragment$observeBillsState$1());
      return;
    } 
    k.d("viewModel");
    throw null;
  }
  
  public final y.b getViewModelFactory() {
    y.b b1 = this.viewModelFactory;
    if (b1 != null)
      return b1; 
    k.d("viewModelFactory");
    throw null;
  }
  
  public void onAttach(Context paramContext) {
    k.b(paramContext, "context");
    super.onAttach(paramContext);
    Context context = paramContext.getApplicationContext();
    if (context != null) {
      ViewModelComponentKt.create((b)context).inject(this);
      y.b b1 = this.viewModelFactory;
      if (b1 != null) {
        w w = z.a(this, b1).a(PaymentHistoryViewModel.class);
        k.a(w, "ViewModelProviders.of(th…oryViewModel::class.java)");
        this.viewModel = (PaymentHistoryViewModel)w;
        this.adapter = new PaymentsHistoryAdapter(paramContext);
        return;
      } 
      k.d("viewModelFactory");
      throw null;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  public void onStart() {
    super.onStart();
    PaymentHistoryViewModel paymentHistoryViewModel = this.viewModel;
    if (paymentHistoryViewModel != null) {
      paymentHistoryViewModel.fetchBills();
      return;
    } 
    k.d("viewModel");
    throw null;
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {
    k.b(paramView, "view");
    super.onViewCreated(paramView, paramBundle);
    View view = paramView.findViewById(2131296965);
    k.a(view, "view.findViewById(R.id.swipe_refresh_layout)");
    this.swipeRefreshLayout = (SwipeRefreshLayout)view;
    view = paramView.findViewById(2131296848);
    k.a(view, "view.findViewById(R.id.recycler)");
    this.recyclerView = (RecyclerView)view;
    view = paramView.findViewById(2131297235);
    k.a(view, "view.findViewById(R.id.view_flipper)");
    this.viewFlipper = (ViewFlipper)view;
    view = paramView.findViewById(2131296790);
    k.a(view, "view.findViewById(R.id.payment_cta)");
    this.paymentCta = (Button)view;
    paramView = paramView.findViewById(2131296791);
    k.a(paramView, "view.findViewById(R.id.payment_retry)");
    this.retryCta = (Button)paramView;
    Button button = this.paymentCta;
    if (button != null) {
      button.setOnClickListener(new PaymentHistoryFragment$onViewCreated$1());
      button = this.retryCta;
      if (button != null) {
        button.setOnClickListener(new PaymentHistoryFragment$onViewCreated$2());
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefreshLayout;
        if (swipeRefreshLayout != null) {
          swipeRefreshLayout.setOnRefreshListener(new PaymentHistoryFragment$onViewCreated$3());
          RecyclerView recyclerView = this.recyclerView;
          if (recyclerView != null) {
            recyclerView.setLayoutManager((RecyclerView.o)new LinearLayoutManager(getContext(), 1, false));
            recyclerView = this.recyclerView;
            if (recyclerView != null) {
              PaymentsHistoryAdapter paymentsHistoryAdapter = this.adapter;
              if (paymentsHistoryAdapter != null) {
                recyclerView.setAdapter((RecyclerView.g)paymentsHistoryAdapter);
                observeBillsState();
                return;
              } 
              k.d("adapter");
              throw null;
            } 
            k.d("recyclerView");
            throw null;
          } 
          k.d("recyclerView");
          throw null;
        } 
        k.d("swipeRefreshLayout");
        throw null;
      } 
      k.d("retryCta");
      throw null;
    } 
    k.d("paymentCta");
    throw null;
  }
  
  public final void setViewModelFactory(y.b paramb) {
    k.b(paramb, "<set-?>");
    this.viewModelFactory = paramb;
  }
  
  public static final class Companion {
    public Companion() {}
  }
  
  public static final class PaymentHistoryFragment$observeBillsState$1<T> implements s<PaymentHistoryViewModel.BillState> {
    public final void onChanged(PaymentHistoryViewModel.BillState param1BillState) {
      ArrayList<Bill> arrayList;
      if (param1BillState instanceof PaymentHistoryViewModel.BillState.Success) {
        PaymentsHistoryAdapter paymentsHistoryAdapter = PaymentHistoryFragment.access$getAdapter$p(PaymentHistoryFragment.this);
        List<a> list = ((PaymentHistoryViewModel.BillState.Success)param1BillState).getBills();
        arrayList = new ArrayList(i.a(list, 10));
        for (a a : list) {
          Bill bill = new Bill();
          bill.setUserReference(a.a());
          bill.setServiceCategory("Service Category");
          arrayList.add(bill);
        } 
        paymentsHistoryAdapter.setBillList(arrayList);
        PaymentHistoryFragment.access$getViewFlipper$p(PaymentHistoryFragment.this).setDisplayedChild(0);
      } else {
        PaymentHistoryViewModel.BillState.Loading loading;
        if (arrayList instanceof PaymentHistoryViewModel.BillState.Loading) {
          Button button = PaymentHistoryFragment.access$getRetryCta$p(PaymentHistoryFragment.this);
          loading = (PaymentHistoryViewModel.BillState.Loading)arrayList;
          button.setEnabled(loading.isLoading() ^ true);
          PaymentHistoryFragment.access$getPaymentCta$p(PaymentHistoryFragment.this).setEnabled(true ^ loading.isLoading());
          PaymentHistoryFragment.access$getSwipeRefreshLayout$p(PaymentHistoryFragment.this).setRefreshing(loading.isLoading());
        } else if (loading instanceof PaymentHistoryViewModel.BillState.Error) {
          PaymentHistoryFragment.access$getViewFlipper$p(PaymentHistoryFragment.this).setDisplayedChild(2);
        } else if (loading instanceof PaymentHistoryViewModel.BillState.Empty) {
          PaymentHistoryFragment.access$getViewFlipper$p(PaymentHistoryFragment.this).setDisplayedChild(1);
        } 
      } 
    }
  }
  
  public static final class PaymentHistoryFragment$onViewCreated$1 implements View.OnClickListener {
    public final void onClick(View param1View) {
      d d2 = PaymentHistoryFragment.this.getActivity();
      d d1 = d2;
      if (!(d2 instanceof HomeActivity))
        d1 = null; 
      HomeActivity homeActivity = (HomeActivity)d1;
      if (homeActivity != null)
        homeActivity.replaceHistoryFragmentByHomeFragment(); 
    }
  }
  
  public static final class PaymentHistoryFragment$onViewCreated$2 implements View.OnClickListener {
    public final void onClick(View param1View) {
      PaymentHistoryFragment.access$getViewModel$p(PaymentHistoryFragment.this).fetchBills();
    }
  }
  
  public static final class PaymentHistoryFragment$onViewCreated$3 implements SwipeRefreshLayout.j {
    public final void onRefresh() {
      PaymentHistoryFragment.access$getViewModel$p(PaymentHistoryFragment.this).fetchBills();
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
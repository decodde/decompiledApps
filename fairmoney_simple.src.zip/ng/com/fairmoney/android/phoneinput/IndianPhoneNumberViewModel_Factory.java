package ng.com.fairmoney.android.phoneinput;

import g.b.d;

public final class IndianPhoneNumberViewModel_Factory implements d<IndianPhoneNumberViewModel> {
  public static IndianPhoneNumberViewModel_Factory create() {
    return InstanceHolder.INSTANCE;
  }
  
  public static IndianPhoneNumberViewModel newInstance() {
    return new IndianPhoneNumberViewModel();
  }
  
  public IndianPhoneNumberViewModel get() {
    return newInstance();
  }
  
  public static final class InstanceHolder {
    public static final IndianPhoneNumberViewModel_Factory INSTANCE = new IndianPhoneNumberViewModel_Factory();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\IndianPhoneNumberViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.kyc;

import com.fairmoney.data.kyc.JsonPanMapper;
import g.b.d;

public final class JsonPanMapper_Factory implements d<JsonPanMapper> {
  public static com.fairmoney.data.kyc.JsonPanMapper_Factory create() {
    return InstanceHolder.access$000();
  }
  
  public static JsonPanMapper newInstance() {
    return new JsonPanMapper();
  }
  
  public JsonPanMapper get() {
    return newInstance();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonPanMapper_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.bankdetails;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$4", f = "BankDetailsViewModel.kt", l = {60}, m = "invokeSuspend")
public final class BankDetailsViewModel$onClickNext$4 extends k implements p<b<? super BankDetailsViewModel.BankDetailsState>, d<? super k>, Object> {
  public Object L$0;
  
  public int label;
  
  public b p$;
  
  public BankDetailsViewModel$onClickNext$4(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    BankDetailsViewModel$onClickNext$4 bankDetailsViewModel$onClickNext$4 = new BankDetailsViewModel$onClickNext$4(paramd);
    bankDetailsViewModel$onClickNext$4.p$ = (b)paramObject;
    return (d<k>)bankDetailsViewModel$onClickNext$4;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((BankDetailsViewModel$onClickNext$4)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    Object object = c.a();
    int i = this.label;
    if (i != 0) {
      if (i == 1) {
        object = this.L$0;
        g.a(paramObject);
      } else {
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
    } else {
      g.a(paramObject);
      b b1 = this.p$;
      paramObject = new BankDetailsViewModel.BankDetailsState.Loading(true);
      this.L$0 = b1;
      this.label = 1;
      if (b1.emit(paramObject, (d)this) == object)
        return object; 
    } 
    return k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$onClickNext$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
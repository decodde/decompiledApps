package ng.com.fairmoney.android.loan.form.work.view;

import android.app.Application;
import g.b.d;
import javax.inject.Provider;

public final class ProfessionalMapper_Factory implements d<ProfessionalMapper> {
  public final Provider<Application> contextProvider;
  
  public ProfessionalMapper_Factory(Provider<Application> paramProvider) {
    this.contextProvider = paramProvider;
  }
  
  public static ProfessionalMapper_Factory create(Provider<Application> paramProvider) {
    return new ProfessionalMapper_Factory(paramProvider);
  }
  
  public static ProfessionalMapper newInstance(Application paramApplication) {
    return new ProfessionalMapper(paramApplication);
  }
  
  public ProfessionalMapper get() {
    return newInstance((Application)this.contextProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\view\ProfessionalMapper_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.form.guarantor;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.k.b;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import javax.inject.Inject;
import k.a.h2.c;

public final class FormGuarantorViewModel extends w {
  public final LiveData<b> country;
  
  public final r<b> mutableCountry;
  
  public final h userUseCase;
  
  @Inject
  public FormGuarantorViewModel(h paramh) {
    this.userUseCase = paramh;
    r<b> r1 = new r();
    this.mutableCountry = r1;
    this.country = (LiveData<b>)r1;
  }
  
  public final void fetchCountry() {
    c.a(c.a(this.userUseCase.getCountry(), new FormGuarantorViewModel$fetchCountry$1(null)), x.a(this));
  }
  
  public final LiveData<b> getCountry() {
    return this.country;
  }
  
  @f(c = "ng.com.fairmoney.android.loan.form.guarantor.FormGuarantorViewModel$fetchCountry$1", f = "FormGuarantorViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class FormGuarantorViewModel$fetchCountry$1 extends k implements p<b, d<? super k>, Object> {
    public int label;
    
    public b p$0;
    
    public FormGuarantorViewModel$fetchCountry$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      FormGuarantorViewModel$fetchCountry$1 formGuarantorViewModel$fetchCountry$1 = new FormGuarantorViewModel$fetchCountry$1(param1d);
      formGuarantorViewModel$fetchCountry$1.p$0 = (b)param1Object;
      return (d<k>)formGuarantorViewModel$fetchCountry$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((FormGuarantorViewModel$fetchCountry$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        FormGuarantorViewModel.this.mutableCountry.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\guarantor\FormGuarantorViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import f.d.b.i.c;
import j.q.d.g;

public abstract class SelectedLoanOfferState {
  public SelectedLoanOfferState() {}
  
  public static final class Failure extends SelectedLoanOfferState {
    public final Throwable throwable;
    
    public Failure(Throwable param2Throwable) {
      super(null);
      this.throwable = param2Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Success extends SelectedLoanOfferState {
    public final c loanOffer;
    
    public Success(c param2c) {
      super(null);
      this.loanOffer = param2c;
    }
    
    public final c getLoanOffer() {
      return this.loanOffer;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\FinalLoanOfferViewModel$SelectedLoanOfferState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
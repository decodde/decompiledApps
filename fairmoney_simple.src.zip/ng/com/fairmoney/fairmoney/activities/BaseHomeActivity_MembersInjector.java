package ng.com.fairmoney.fairmoney.activities;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class BaseHomeActivity_MembersInjector implements a<BaseHomeActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public BaseHomeActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<BaseHomeActivity> create(Provider<y.b> paramProvider) {
    return new BaseHomeActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(BaseHomeActivity paramBaseHomeActivity, y.b paramb) {
    paramBaseHomeActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(BaseHomeActivity paramBaseHomeActivity) {
    injectViewModelFactory(paramBaseHomeActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\BaseHomeActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
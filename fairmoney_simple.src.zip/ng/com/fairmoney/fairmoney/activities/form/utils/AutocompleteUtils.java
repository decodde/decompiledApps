package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ListAdapter;
import com.google.android.material.textfield.TextInputLayout;
import j.q.d.g;
import j.q.d.k;
import j.v.m;
import java.util.Map;

public final class AutocompleteUtils {
  public static final Companion Companion = new Companion(null);
  
  public static final class Companion {
    public Companion() {}
    
    public final boolean isTextValid(Activity param1Activity, Map<String, String> param1Map, int param1Int) {
      k.b(param1Activity, "activity");
      k.b(param1Map, "params");
      AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView)param1Activity.findViewById(param1Int);
      if (param1Map.get("error_view_id") != null) {
        TextInputLayout textInputLayout = (TextInputLayout)param1Activity.findViewById(param1Activity.getResources().getIdentifier(param1Map.get("error_view_id"), "id", param1Activity.getPackageName()));
        k.a(autoCompleteTextView, "autocomplete");
        ListAdapter listAdapter = autoCompleteTextView.getAdapter();
        k.a(listAdapter, "autocomplete.adapter");
        int i = listAdapter.getCount();
        for (param1Int = 0; param1Int < i; param1Int++) {
          if (m.a(autoCompleteTextView.getText().toString(), (String)autoCompleteTextView.getAdapter().getItem(param1Int), true)) {
            FormUtils.hideErrors((EditText)autoCompleteTextView, textInputLayout);
            return true;
          } 
        } 
        FormUtils.setTextError((EditText)autoCompleteTextView, textInputLayout, param1Activity.getString(2131821029, new Object[] { param1Map.get("display_name") }));
      } 
      return false;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\AutocompleteUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.login;

import android.content.Context;
import f.c.a.a;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.models.JsonFeatures;
import ng.com.fairmoney.fairmoney.models.JsonFeaturesMapper;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class null implements APIResponse<JsonFeatures> {
  public void failure(int paramInt, String paramString) {
    LoginActivity.this.showNewToastMessage(paramString, 1);
    a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)LoginActivity.this, paramString, String.valueOf(paramInt))));
    LoginActivity.this.makeButtonEnabled(true);
  }
  
  public void success(JsonFeatures paramJsonFeatures) {
    FairMoney.setFeatures(JsonFeaturesMapper.Companion.transform(paramJsonFeatures));
    LoginActivity.this.loginViewModel.fetchInAppMessage();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
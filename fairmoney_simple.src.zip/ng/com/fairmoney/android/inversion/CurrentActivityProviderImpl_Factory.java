package ng.com.fairmoney.android.inversion;

import android.app.Application;
import g.b.d;
import javax.inject.Provider;

public final class CurrentActivityProviderImpl_Factory implements d<CurrentActivityProviderImpl> {
  public final Provider<Application> applicationProvider;
  
  public CurrentActivityProviderImpl_Factory(Provider<Application> paramProvider) {
    this.applicationProvider = paramProvider;
  }
  
  public static CurrentActivityProviderImpl_Factory create(Provider<Application> paramProvider) {
    return new CurrentActivityProviderImpl_Factory(paramProvider);
  }
  
  public static CurrentActivityProviderImpl newInstance(Application paramApplication) {
    return new CurrentActivityProviderImpl(paramApplication);
  }
  
  public CurrentActivityProviderImpl get() {
    return newInstance((Application)this.applicationProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\CurrentActivityProviderImpl_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
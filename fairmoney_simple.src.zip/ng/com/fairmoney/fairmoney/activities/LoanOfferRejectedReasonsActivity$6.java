package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import com.android.volley.VolleyError;
import f.a.b.k;
import f.c.a.a;
import ng.com.fairmoney.fairmoney.network.BackendApi;

public class null implements k.a {
  public void onErrorResponse(VolleyError paramVolleyError) {
    BackendApi.checkServerError((Context)LoanOfferRejectedReasonsActivity.this, paramVolleyError);
    a.a((Throwable)paramVolleyError);
    LoanOfferRejectedReasonsActivity.access$500(LoanOfferRejectedReasonsActivity.this).setVisibility(8);
    LoanOfferRejectedReasonsActivity.access$600(LoanOfferRejectedReasonsActivity.this).setVisibility(0);
    LoanOfferRejectedReasonsActivity.this.showNewToastMessage("Feedback sent", 0);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOfferRejectedReasonsActivity$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
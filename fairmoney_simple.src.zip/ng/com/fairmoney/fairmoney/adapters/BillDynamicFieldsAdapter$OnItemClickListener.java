package ng.com.fairmoney.fairmoney.adapters;

public interface OnItemClickListener {
  void onClick(String paramString, int paramInt);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BillDynamicFieldsAdapter$OnItemClickListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
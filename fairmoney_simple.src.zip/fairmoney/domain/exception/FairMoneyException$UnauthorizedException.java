package fairmoney.domain.exception;

import com.fairmoney.domain.exception.FairMoneyException;

public final class UnauthorizedException extends FairMoneyException {
  public static final UnauthorizedException f = new UnauthorizedException();
  
  public UnauthorizedException() {
    super(null, 1, null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\domain\exception\FairMoneyException$UnauthorizedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
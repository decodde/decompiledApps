package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class BillCategoryViewHolder extends RecyclerView.d0 {
  public ImageView ivBillCategory;
  
  public TextView tvBillCategory;
  
  public TextView tvBillCategoryDiscount;
  
  public BillCategoryViewHolder(View paramView) {
    super(paramView);
    this.tvBillCategory = (TextView)paramView.findViewById(2131297067);
    this.ivBillCategory = (ImageView)paramView.findViewById(2131296614);
    this.tvBillCategoryDiscount = (TextView)paramView.findViewById(2131297068);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BillCategoryAdapter$BillCategoryViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
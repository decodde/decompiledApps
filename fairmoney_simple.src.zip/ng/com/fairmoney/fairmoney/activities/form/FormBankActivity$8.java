package ng.com.fairmoney.fairmoney.activities.form;

import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.models.CreditEligibility;
import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<CreditEligibility> {
  public void failure(int paramInt, String paramString) {
    FormBankActivity.this.showNewToastMessage(paramString, 1);
    FormBankActivity.access$700(FormBankActivity.this, true);
  }
  
  public void success(CreditEligibility paramCreditEligibility) {
    if (paramCreditEligibility.isEligible()) {
      if (paramCreditEligibility.isBvnVerificationMandatory()) {
        FormBankActivity.access$400(FormBankActivity.this, bankDetails, paramCreditEligibility);
      } else {
        FormBankActivity.access$500(FormBankActivity.this);
      } 
    } else {
      FormBankActivity.access$600(FormBankActivity.this, paramCreditEligibility.getMessage());
      FormBankActivity.access$700(FormBankActivity.this, true);
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity$8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class FormWorkActivity_MembersInjector implements a<FormWorkActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public FormWorkActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<FormWorkActivity> create(Provider<y.b> paramProvider) {
    return new FormWorkActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(FormWorkActivity paramFormWorkActivity, y.b paramb) {
    paramFormWorkActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(FormWorkActivity paramFormWorkActivity) {
    injectViewModelFactory(paramFormWorkActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormWorkActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
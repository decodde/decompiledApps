package ng.com.fairmoney.android.phoneinput;

import d.o.s;

public final class PhoneInputView$subscribeToInputViewModel$1<T> implements s<PhoneInputViewModel.PhoneInputState> {
  public final void onChanged(PhoneInputViewModel.PhoneInputState paramPhoneInputState) {
    if (paramPhoneInputState instanceof PhoneInputViewModel.PhoneInputState.Valid) {
      PhoneInputView.access$setErrorMessage(PhoneInputView.this, null);
    } else if (paramPhoneInputState instanceof PhoneInputViewModel.PhoneInputState.Invalid) {
      PhoneInputView phoneInputView = PhoneInputView.this;
      PhoneInputView.access$setErrorMessage(phoneInputView, PhoneInputView.access$getErrorMessage(phoneInputView, ((PhoneInputViewModel.PhoneInputState.Invalid)paramPhoneInputState).getErrorType()));
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputView$subscribeToInputViewModel$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
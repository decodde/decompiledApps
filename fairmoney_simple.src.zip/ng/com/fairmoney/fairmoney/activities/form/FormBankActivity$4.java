package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    Intent intent = new Intent("android.intent.action.DIAL", Uri.fromParts("tel", FormBankActivity.this.getString(2131820732), null));
    FormBankActivity.this.startActivity(intent);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
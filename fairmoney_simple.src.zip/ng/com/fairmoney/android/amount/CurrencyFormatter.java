package ng.com.fairmoney.android.amount;

import f.d.b.k.b;
import j.q.d.k;
import j.v.d;
import kotlin.TypeCastException;

public final class CurrencyFormatter {
  private final String formatCents(int paramInt, String paramString) {
    int i = paramInt % 100;
    String str = paramString;
    if (i != 0)
      if (paramInt % 10 == 0) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramString);
        stringBuilder1.append('.');
        stringBuilder1.append(i);
        String str1 = stringBuilder1.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(paramString);
        stringBuilder2.append('.');
        stringBuilder2.append(i);
        paramInt = stringBuilder2.toString().length();
        if (str1 != null) {
          str1 = str1.substring(0, paramInt - 1);
          k.a(str1, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        } else {
          throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString);
        stringBuilder.append('.');
        stringBuilder.append(i);
        str = stringBuilder.toString();
      }  
    return str;
  }
  
  private final String formatGroupOfThree(int paramInt) {
    return formatCents(paramInt, (new d("(\\d+?)(?=(\\d{3})+(?!\\d))")).a(String.valueOf(paramInt / 100), "$1,"));
  }
  
  private final String formatIndia(int paramInt) {
    return formatCents(paramInt, (new d("(\\d+?)(?=(\\d{2})+(\\d)(?!\\d))")).a(String.valueOf(paramInt / 100), "$1,"));
  }
  
  private final String getCurrencySymbol(String paramString) {
    String str;
    int i = paramString.hashCode();
    if (i != 72653) {
      if (i != 77237) {
        str = paramString;
      } else {
        str = paramString;
        if (paramString.equals("NGN"))
          str = b.b.h.b(); 
      } 
    } else {
      str = paramString;
      if (paramString.equals("INR"))
        str = b.a.h.b(); 
    } 
    return str;
  }
  
  public final String format(String paramString, int paramInt) {
    k.b(paramString, "currencyCode");
    int i = paramString.hashCode();
    if (i != 72653) {
      if (i == 77237 && paramString.equals("NGN")) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(getCurrencySymbol(paramString));
        stringBuilder1.append(formatGroupOfThree(paramInt));
        return stringBuilder1.toString();
      } 
    } else if (paramString.equals("INR")) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getCurrencySymbol(paramString));
      stringBuilder1.append(formatIndia(paramInt));
      return stringBuilder1.toString();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(' ');
    stringBuilder.append(formatGroupOfThree(paramInt));
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\amount\CurrencyFormatter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.bankdetails;

import j.q.d.g;
import j.q.d.k;
import java.util.List;

public abstract class BankDetailsState {
  public BankDetailsState() {}
  
  public static final class Exception extends BankDetailsState {
    public final String message;
    
    public Exception(String param2String) {
      super(null);
      this.message = param2String;
    }
    
    public final String component1() {
      return this.message;
    }
    
    public final Exception copy(String param2String) {
      return new Exception(param2String);
    }
    
    public boolean equals(Object param2Object) {
      if (this != param2Object) {
        if (param2Object instanceof Exception) {
          param2Object = param2Object;
          if (k.a(this.message, ((Exception)param2Object).message))
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final String getMessage() {
      return this.message;
    }
    
    public int hashCode() {
      boolean bool;
      String str = this.message;
      if (str != null) {
        bool = str.hashCode();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception(message=");
      stringBuilder.append(this.message);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class InputErrors extends BankDetailsState {
    public final List<BankDetailsViewModel.BankDetailsStateError> errors;
    
    public InputErrors(List<? extends BankDetailsViewModel.BankDetailsStateError> param2List) {
      super(null);
      this.errors = (List)param2List;
    }
    
    public final List<BankDetailsViewModel.BankDetailsStateError> component1() {
      return this.errors;
    }
    
    public final InputErrors copy(List<? extends BankDetailsViewModel.BankDetailsStateError> param2List) {
      k.b(param2List, "errors");
      return new InputErrors(param2List);
    }
    
    public boolean equals(Object param2Object) {
      if (this != param2Object) {
        if (param2Object instanceof InputErrors) {
          param2Object = param2Object;
          if (k.a(this.errors, ((InputErrors)param2Object).errors))
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final List<BankDetailsViewModel.BankDetailsStateError> getErrors() {
      return this.errors;
    }
    
    public int hashCode() {
      boolean bool;
      List<BankDetailsViewModel.BankDetailsStateError> list = this.errors;
      if (list != null) {
        bool = list.hashCode();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("InputErrors(errors=");
      stringBuilder.append(this.errors);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class Loading extends BankDetailsState {
    public final boolean isLoading;
    
    public Loading(boolean param2Boolean) {
      super(null);
      this.isLoading = param2Boolean;
    }
    
    public final boolean component1() {
      return this.isLoading;
    }
    
    public final Loading copy(boolean param2Boolean) {
      return new Loading(param2Boolean);
    }
    
    public boolean equals(Object param2Object) {
      if (this != param2Object) {
        if (param2Object instanceof Loading) {
          param2Object = param2Object;
          if (this.isLoading == ((Loading)param2Object).isLoading)
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      boolean bool1 = this.isLoading;
      boolean bool2 = bool1;
      if (bool1)
        bool2 = true; 
      return bool2;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading(isLoading=");
      stringBuilder.append(this.isLoading);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class Success extends BankDetailsState {
    public static final Success INSTANCE = new Success();
    
    public Success() {
      super(null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$BankDetailsState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.injection;

import f.d.b.k.g;
import f.d.c.i;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DataComponent_userRepository implements Provider<g> {
  public final i dataComponent;
  
  public com_fairmoney_injection_DataComponent_userRepository(i parami) {
    this.dataComponent = parami;
  }
  
  public g get() {
    g g = this.dataComponent.b();
    g.a(g, "Cannot return null from a non-@Nullable component method");
    return g;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DataComponent_userRepository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
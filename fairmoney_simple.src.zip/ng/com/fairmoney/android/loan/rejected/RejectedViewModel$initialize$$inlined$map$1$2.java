package ng.com.fairmoney.android.loan.rejected;

import f.d.b.k.b;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.b;
import j.q.d.k;
import k.a.h2.b;

public final class null implements b<b> {
  public null(RejectedViewModel$initialize$$inlined$map$1 paramRejectedViewModel$initialize$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    paramObject = this.$this_unsafeFlow$inlined.emit(b.a(k.a(paramObject, b.b.h)), paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\rejected\RejectedViewModel$initialize$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
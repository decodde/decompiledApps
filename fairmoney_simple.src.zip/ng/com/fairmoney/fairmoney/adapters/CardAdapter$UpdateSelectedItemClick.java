package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;

public class UpdateSelectedItemClick implements View.OnClickListener {
  public CardAdapter.CardViewHolder cardViewHolder;
  
  public UpdateSelectedItemClick(CardAdapter.CardViewHolder paramCardViewHolder) {
    this.cardViewHolder = paramCardViewHolder;
  }
  
  public void onClick(View paramView) {
    CardAdapter.access$702(CardAdapter.this, this.cardViewHolder.getAdapterPosition());
    CardAdapter.this.notifyDataSetChanged();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CardAdapter$UpdateSelectedItemClick.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
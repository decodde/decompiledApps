package ng.com.fairmoney.android.inversion;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import j.q.d.k;
import javax.inject.Inject;

public final class CurrentActivityProviderImpl implements CurrentActivityProvider {
  public Activity currentActivity;
  
  @Inject
  public CurrentActivityProviderImpl(Application paramApplication) {
    paramApplication.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
          public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
            k.b(param1Activity, "activity");
            CurrentActivityProviderImpl.this.currentActivity = param1Activity;
          }
          
          public void onActivityDestroyed(Activity param1Activity) {
            k.b(param1Activity, "activity");
            if (param1Activity == CurrentActivityProviderImpl.this.currentActivity)
              CurrentActivityProviderImpl.this.currentActivity = null; 
          }
          
          public void onActivityPaused(Activity param1Activity) {
            k.b(param1Activity, "activity");
          }
          
          public void onActivityResumed(Activity param1Activity) {
            k.b(param1Activity, "activity");
            CurrentActivityProviderImpl.this.currentActivity = param1Activity;
          }
          
          public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {
            k.b(param1Activity, "activity");
            k.b(param1Bundle, "outState");
          }
          
          public void onActivityStarted(Activity param1Activity) {
            k.b(param1Activity, "activity");
            CurrentActivityProviderImpl.this.currentActivity = param1Activity;
          }
          
          public void onActivityStopped(Activity param1Activity) {
            k.b(param1Activity, "activity");
          }
        });
  }
  
  public Activity getCurrentActivity() {
    return this.currentActivity;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\CurrentActivityProviderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.termsofuse;

import f.d.b.k.b;
import j.k;
import j.n.d;
import j.n.i.c;
import java.net.URL;
import k.a.h2.a;
import k.a.h2.b;

public final class TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 implements a<TermsOfUseViewModel.TermsOfUse.Indian> {
  public TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1(a parama, b paramb) {}
  
  public Object collect(b paramb, d paramd) {
    Object object = this.$this_unsafeTransform$inlined.collect(new b<URL>(this) {
          public Object emit(Object param1Object, d param1d) {
            b b1 = this.$this_unsafeFlow$inlined;
            URL uRL = (URL)param1Object;
            param1Object = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(", <a href=\"");
            stringBuilder.append(uRL);
            stringBuilder.append("\">loan agreement</a> ");
            param1Object = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)param1Object, stringBuilder.toString()), param1d);
            return (param1Object == c.a()) ? param1Object : k.a;
          }
        }paramd);
    return (object == c.a()) ? object : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.offer;

import d.o.s;

public final class null<T> implements s<LoanOfferDetailsViewModel.LoanOfferDetailsViewState> {
  public final void onChanged(LoanOfferDetailsViewModel.LoanOfferDetailsViewState paramLoanOfferDetailsViewState) {
    LoanOfferDetailsView.access$openView(LoanOfferDetailsView.this, paramLoanOfferDetailsViewState.getOpen());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsView$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
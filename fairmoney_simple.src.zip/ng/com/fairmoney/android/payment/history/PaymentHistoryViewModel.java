package ng.com.fairmoney.android.payment.history;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.j.a;
import f.d.b.j.f;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import java.util.List;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class PaymentHistoryViewModel extends w {
  public final LiveData<BillState> bills;
  
  public final r<BillState> mutableBills;
  
  public final f paymentUseCase;
  
  @Inject
  public PaymentHistoryViewModel(f paramf) {
    this.paymentUseCase = paramf;
    r<BillState> r1 = new r();
    this.mutableBills = r1;
    this.bills = (LiveData<BillState>)r1;
  }
  
  public final void fetchBills() {
    c.a(c.a(c.a(c.b(c.b(new PaymentHistoryViewModel$fetchBills$$inlined$map$1(this.paymentUseCase.a()), new PaymentHistoryViewModel$fetchBills$2(null)), new PaymentHistoryViewModel$fetchBills$3(null)), new PaymentHistoryViewModel$fetchBills$4(null)), new PaymentHistoryViewModel$fetchBills$5(null)), x.a(this));
  }
  
  public final LiveData<BillState> getBills() {
    return this.bills;
  }
  
  public static abstract class BillState {
    public BillState() {}
    
    public static final class Empty extends BillState {
      public static final Empty INSTANCE = new Empty();
      
      public Empty() {
        super(null);
      }
    }
    
    public static final class Error extends BillState {
      public final Throwable throwable;
      
      public Error(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Loading extends BillState {
      public final boolean isLoading;
      
      public Loading(boolean param2Boolean) {
        super(null);
        this.isLoading = param2Boolean;
      }
      
      public final boolean isLoading() {
        return this.isLoading;
      }
    }
    
    public static final class Success extends BillState {
      public final List<a> bills;
      
      public Success(List<a> param2List) {
        super(null);
        this.bills = param2List;
      }
      
      public final List<a> getBills() {
        return this.bills;
      }
    }
  }
  
  public static final class Empty extends BillState {
    public static final Empty INSTANCE = new Empty();
    
    public Empty() {
      super(null);
    }
  }
  
  public static final class Error extends BillState {
    public final Throwable throwable;
    
    public Error(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Loading extends BillState {
    public final boolean isLoading;
    
    public Loading(boolean param1Boolean) {
      super(null);
      this.isLoading = param1Boolean;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
  }
  
  public static final class Success extends BillState {
    public final List<a> bills;
    
    public Success(List<a> param1List) {
      super(null);
      this.bills = param1List;
    }
    
    public final List<a> getBills() {
      return this.bills;
    }
  }
  
  public static final class PaymentHistoryViewModel$fetchBills$$inlined$map$1 implements a<BillState> {
    public PaymentHistoryViewModel$fetchBills$$inlined$map$1(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<List<? extends a>>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              if (param1Object.isEmpty()) {
                param1Object = PaymentHistoryViewModel.BillState.Empty.INSTANCE;
              } else {
                param1Object = new PaymentHistoryViewModel.BillState.Success((List<a>)param1Object);
              } 
              param1Object = b1.emit(param1Object, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<List<? extends a>> {
    public null(PaymentHistoryViewModel$fetchBills$$inlined$map$1 param1PaymentHistoryViewModel$fetchBills$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      if (param1Object.isEmpty()) {
        param1Object = PaymentHistoryViewModel.BillState.Empty.INSTANCE;
      } else {
        param1Object = new PaymentHistoryViewModel.BillState.Success((List<a>)param1Object);
      } 
      param1Object = b1.emit(param1Object, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.payment.history.PaymentHistoryViewModel$fetchBills$2", f = "PaymentHistoryViewModel.kt", l = {30}, m = "invokeSuspend")
  public static final class PaymentHistoryViewModel$fetchBills$2 extends k implements p<b<? super BillState>, d<? super k>, Object> {
    public Object L$0;
    
    public int label;
    
    public b p$;
    
    public PaymentHistoryViewModel$fetchBills$2(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      PaymentHistoryViewModel$fetchBills$2 paymentHistoryViewModel$fetchBills$2 = new PaymentHistoryViewModel$fetchBills$2(param1d);
      paymentHistoryViewModel$fetchBills$2.p$ = (b)param1Object;
      return (d<k>)paymentHistoryViewModel$fetchBills$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((PaymentHistoryViewModel$fetchBills$2)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        param1Object = new PaymentHistoryViewModel.BillState.Loading(true);
        this.L$0 = b1;
        this.label = 1;
        if (b1.emit(param1Object, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.payment.history.PaymentHistoryViewModel$fetchBills$3", f = "PaymentHistoryViewModel.kt", l = {31}, m = "invokeSuspend")
  public static final class PaymentHistoryViewModel$fetchBills$3 extends k implements q<b<? super BillState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public PaymentHistoryViewModel$fetchBills$3(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super PaymentHistoryViewModel.BillState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1d, "continuation");
      PaymentHistoryViewModel$fetchBills$3 paymentHistoryViewModel$fetchBills$3 = new PaymentHistoryViewModel$fetchBills$3(param1d);
      paymentHistoryViewModel$fetchBills$3.p$ = param1b;
      paymentHistoryViewModel$fetchBills$3.p$0 = param1Throwable;
      return (d<k>)paymentHistoryViewModel$fetchBills$3;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((PaymentHistoryViewModel$fetchBills$3)create((b<? super PaymentHistoryViewModel.BillState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$;
        Throwable throwable = this.p$0;
        PaymentHistoryViewModel.BillState.Loading loading = new PaymentHistoryViewModel.BillState.Loading(false);
        this.L$0 = param1Object;
        this.L$1 = throwable;
        this.label = 1;
        if (param1Object.emit(loading, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.payment.history.PaymentHistoryViewModel$fetchBills$4", f = "PaymentHistoryViewModel.kt", l = {32}, m = "invokeSuspend")
  public static final class PaymentHistoryViewModel$fetchBills$4 extends k implements q<b<? super BillState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public PaymentHistoryViewModel$fetchBills$4(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super PaymentHistoryViewModel.BillState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      PaymentHistoryViewModel$fetchBills$4 paymentHistoryViewModel$fetchBills$4 = new PaymentHistoryViewModel$fetchBills$4(param1d);
      paymentHistoryViewModel$fetchBills$4.p$ = param1b;
      paymentHistoryViewModel$fetchBills$4.p$0 = param1Throwable;
      return (d<k>)paymentHistoryViewModel$fetchBills$4;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((PaymentHistoryViewModel$fetchBills$4)create((b<? super PaymentHistoryViewModel.BillState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$;
        Throwable throwable = this.p$0;
        PaymentHistoryViewModel.BillState.Error error = new PaymentHistoryViewModel.BillState.Error(throwable);
        this.L$0 = param1Object;
        this.L$1 = throwable;
        this.label = 1;
        if (param1Object.emit(error, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.payment.history.PaymentHistoryViewModel$fetchBills$5", f = "PaymentHistoryViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class PaymentHistoryViewModel$fetchBills$5 extends k implements p<BillState, d<? super k>, Object> {
    public int label;
    
    public PaymentHistoryViewModel.BillState p$0;
    
    public PaymentHistoryViewModel$fetchBills$5(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      PaymentHistoryViewModel$fetchBills$5 paymentHistoryViewModel$fetchBills$5 = new PaymentHistoryViewModel$fetchBills$5(param1d);
      paymentHistoryViewModel$fetchBills$5.p$0 = (PaymentHistoryViewModel.BillState)param1Object;
      return (d<k>)paymentHistoryViewModel$fetchBills$5;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((PaymentHistoryViewModel$fetchBills$5)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        PaymentHistoryViewModel.this.mutableBills.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.injection;

import f.d.c.c;
import f.d.c.i;
import f.d.c.j;
import f.d.c.k;
import ng.com.fairmoney.android.home.card.EarlyRepaymentCardView;
import ng.com.fairmoney.android.loan.bankdetails.BankDetailsActivity;
import ng.com.fairmoney.android.loan.offer.LoanOfferDetailsView;
import ng.com.fairmoney.android.loan.transfer.LoanTransferFragment;
import ng.com.fairmoney.android.payment.history.PaymentHistoryFragment;
import ng.com.fairmoney.android.phoneinput.IndianPhoneNumberTextWatcher;
import ng.com.fairmoney.android.phoneinput.NigerianPhoneNumberTextWatcher;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;
import ng.com.fairmoney.fairmoney.activities.BaseHomeActivity;
import ng.com.fairmoney.fairmoney.activities.DataUploadActivity;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferActivity;
import ng.com.fairmoney.fairmoney.activities.LoanOffersActivity;
import ng.com.fairmoney.fairmoney.activities.RejectedActivity;
import ng.com.fairmoney.fairmoney.activities.SplashActivity;
import ng.com.fairmoney.fairmoney.activities.forgotpassword.ForgotPasswordActivity;
import ng.com.fairmoney.fairmoney.activities.forgotpassword.ForgotPasswordConfirmPasswordActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormBankActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormFinancialKycActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormGuarantorActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormLoanPurposeActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormPersonalActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormWorkActivity;
import ng.com.fairmoney.fairmoney.activities.form.PermissionsActivity;
import ng.com.fairmoney.fairmoney.activities.login.LoginActivity;
import ng.com.fairmoney.fairmoney.activities.signup.PhoneSignupActivity;
import ng.com.fairmoney.fairmoney.fragments.VerifyOtpBaseFragment;
import ng.com.fairmoney.fairmoney.fragments.forgotpassword.ForgotPasswordEnterOtpFragment;
import ng.com.fairmoney.fairmoney.fragments.form.BvnVerificationFragment;
import ng.com.fairmoney.fairmoney.fragments.home.BankAndCardsFragment;
import ng.com.fairmoney.fairmoney.fragments.home.BillChoosePaymentMethodFragment;
import ng.com.fairmoney.fairmoney.fragments.home.BillOtherCardPaymentFragment;
import ng.com.fairmoney.fairmoney.fragments.home.CardConnectionFragment;
import ng.com.fairmoney.fairmoney.fragments.home.HomeCardRepaymentFragment;
import ng.com.fairmoney.fairmoney.fragments.home.HomeRepayAmountFragment;
import ng.com.fairmoney.fairmoney.fragments.home.HomeRepaymentMethodFragment;
import ng.com.fairmoney.fairmoney.fragments.loanoffer.LoanOfferDetailsFragment;

@ViewModelScope
public interface ViewModelComponent {
  void inject(EarlyRepaymentCardView paramEarlyRepaymentCardView);
  
  void inject(BankDetailsActivity paramBankDetailsActivity);
  
  void inject(LoanOfferDetailsView paramLoanOfferDetailsView);
  
  void inject(LoanTransferFragment paramLoanTransferFragment);
  
  void inject(PaymentHistoryFragment paramPaymentHistoryFragment);
  
  void inject(IndianPhoneNumberTextWatcher paramIndianPhoneNumberTextWatcher);
  
  void inject(NigerianPhoneNumberTextWatcher paramNigerianPhoneNumberTextWatcher);
  
  void inject(PhoneInputView paramPhoneInputView);
  
  void inject(BaseHomeActivity paramBaseHomeActivity);
  
  void inject(DataUploadActivity paramDataUploadActivity);
  
  void inject(FinalLoanOfferActivity paramFinalLoanOfferActivity);
  
  void inject(LoanOffersActivity paramLoanOffersActivity);
  
  void inject(RejectedActivity paramRejectedActivity);
  
  void inject(SplashActivity paramSplashActivity);
  
  void inject(ForgotPasswordActivity paramForgotPasswordActivity);
  
  void inject(ForgotPasswordConfirmPasswordActivity paramForgotPasswordConfirmPasswordActivity);
  
  void inject(FormBankActivity paramFormBankActivity);
  
  void inject(FormFinancialKycActivity paramFormFinancialKycActivity);
  
  void inject(FormGuarantorActivity paramFormGuarantorActivity);
  
  void inject(FormLoanPurposeActivity paramFormLoanPurposeActivity);
  
  void inject(FormPersonalActivity paramFormPersonalActivity);
  
  void inject(FormWorkActivity paramFormWorkActivity);
  
  void inject(PermissionsActivity paramPermissionsActivity);
  
  void inject(LoginActivity paramLoginActivity);
  
  void inject(PhoneSignupActivity paramPhoneSignupActivity);
  
  void inject(VerifyOtpBaseFragment paramVerifyOtpBaseFragment);
  
  void inject(ForgotPasswordEnterOtpFragment paramForgotPasswordEnterOtpFragment);
  
  void inject(BvnVerificationFragment paramBvnVerificationFragment);
  
  void inject(BankAndCardsFragment paramBankAndCardsFragment);
  
  void inject(BillChoosePaymentMethodFragment paramBillChoosePaymentMethodFragment);
  
  void inject(BillOtherCardPaymentFragment paramBillOtherCardPaymentFragment);
  
  void inject(CardConnectionFragment paramCardConnectionFragment);
  
  void inject(HomeCardRepaymentFragment paramHomeCardRepaymentFragment);
  
  void inject(HomeRepayAmountFragment paramHomeRepayAmountFragment);
  
  void inject(HomeRepaymentMethodFragment paramHomeRepaymentMethodFragment);
  
  void inject(LoanOfferDetailsFragment paramLoanOfferDetailsFragment);
  
  public static interface Factory {
    ViewModelComponent create(c param1c, i param1i, j param1j, k param1k);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\ViewModelComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
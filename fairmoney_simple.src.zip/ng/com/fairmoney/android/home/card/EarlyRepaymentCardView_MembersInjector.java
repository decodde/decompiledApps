package ng.com.fairmoney.android.home.card;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class EarlyRepaymentCardView_MembersInjector implements a<EarlyRepaymentCardView> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public EarlyRepaymentCardView_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<EarlyRepaymentCardView> create(Provider<y.b> paramProvider) {
    return new EarlyRepaymentCardView_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(EarlyRepaymentCardView paramEarlyRepaymentCardView, y.b paramb) {
    paramEarlyRepaymentCardView.viewModelFactory = paramb;
  }
  
  public void injectMembers(EarlyRepaymentCardView paramEarlyRepaymentCardView) {
    injectViewModelFactory(paramEarlyRepaymentCardView, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardView_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.view.View;
import com.android.volley.VolleyError;
import f.a.b.k;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.models.OfferRefusalReason;
import ng.com.fairmoney.fairmoney.network.BackendApi;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import org.json.JSONObject;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    Tracking.sendUniqueClickEvent((Context)OfferDeclinedActivity.this, "SEND_FEEDBACK");
    OfferDeclinedActivity.access$000(OfferDeclinedActivity.this);
    OfferDeclinedActivity.access$100(OfferDeclinedActivity.this);
    k.b<JSONObject> b = new k.b<JSONObject>() {
        public void onResponse(JSONObject param2JSONObject) {
          OfferDeclinedActivity.access$200(OfferDeclinedActivity.this);
        }
      };
    k.a a = new k.a() {
        public void onErrorResponse(VolleyError param2VolleyError) {
          BackendApi.checkServerError((Context)OfferDeclinedActivity.this, param2VolleyError);
          String str = BackendApi.getErrorMessageAccordingTo((Context)OfferDeclinedActivity.this, param2VolleyError);
          OfferDeclinedActivity.this.showNewToastMessage(str, 1);
        }
      };
    FairMoney.getBackendApi((Context)OfferDeclinedActivity.this).sendOfferRefusalReason(b, a, new OfferRefusalReason(OfferDeclinedActivity.access$300(OfferDeclinedActivity.this), OfferDeclinedActivity.access$400(OfferDeclinedActivity.this)));
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\OfferDeclinedActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
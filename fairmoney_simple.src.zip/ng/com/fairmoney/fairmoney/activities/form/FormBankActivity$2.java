package ng.com.fairmoney.fairmoney.activities.form;

import android.view.View;
import android.widget.AdapterView;
import ng.com.fairmoney.fairmoney.adapters.BankNamesAdapter;
import ng.com.fairmoney.fairmoney.models.BankListItem;
import ng.com.fairmoney.fairmoney.views.StyledSpinner;

public class null implements AdapterView.OnItemClickListener {
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    String str;
    BankListItem bankListItem = (BankListItem)bankNamesAdapter.getItem(paramInt);
    StyledSpinner styledSpinner = FormBankActivity.access$300(FormBankActivity.this);
    if (bankListItem.isEnabled()) {
      str = bankListItem.getName();
    } else {
      str = "";
    } 
    styledSpinner.setText(str);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
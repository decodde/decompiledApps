package ng.com.fairmoney.fairmoney.activities.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import f.d.b.k.f;
import l.a.a.a.a.t.j;
import l.a.a.a.a.t.k;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.signup.PhoneSignupEnterOtpActivity;
import ng.com.fairmoney.fairmoney.models.PhoneAuthentication;
import ng.com.fairmoney.fairmoney.models.Session;
import ng.com.fairmoney.fairmoney.models.UssdCode;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.network.model.GenericApiResponse;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.utils.Utils;

public class VerifyPasswordActivity extends PasswordActivity {
  public static final String LOG_TAG = "Phone";
  
  public Button btConfirm;
  
  public String password;
  
  public f phoneNumber;
  
  private void goToPreviousActivity() {
    startActivity(new Intent((Context)this, WelcomeActivity.class));
    finish();
  }
  
  private void initBackArrow() {
    ((ImageView)findViewById(2131296654)).setOnClickListener((View.OnClickListener)new j(this));
  }
  
  private void onConfirmClicked() {
    TextView textView = (TextView)findViewById(2131297100);
    String str = getPassword();
    if (str.length() != 4) {
      textView.setText(2131820770);
      textView.setVisibility(0);
      return;
    } 
    this.password = str;
    textView.setVisibility(8);
    makeButtonEnabled(false);
    makePasswordAction();
  }
  
  private void onLoginSuccess(Session paramSession) {
    logLoginResult("Phone", true);
    Tracking.setUserIdentifier(paramSession.getAuthenticationToken(), paramSession.getApplicationId());
    getSharedPreferences("CurrentUser", 0).edit().putString("AuthToken", paramSession.getAuthenticationToken()).putString("ApplicationId", paramSession.getApplicationId()).putString("et_form_email", paramSession.getUserEmail()).apply();
    Tracking.sendUniqueEvent((Context)this, new Event("application", "phoneLogin"));
    goToNextScreen(paramSession.getStatus());
  }
  
  private void phoneLogin(final PhoneAuthentication phoneAuthentication) {
    RetrofitSession.getInstance((Context)this).getUserLoginManager().phoneLogin(phoneAuthentication, new GenericApiResponse<Session, UssdCode>() {
          public void failure(int param1Int, String param1String, UssdCode param1UssdCode) {
            VerifyPasswordActivity.this.logLoginResult("Phone", false);
            if (param1Int == 12 || param1Int == 18) {
              VerifyPasswordActivity.this.verifyPhoneNumber(phoneAuthentication.getPhone(), param1Int, param1UssdCode);
              return;
            } 
            VerifyPasswordActivity.this.showNewToastMessage(param1String, 0);
            VerifyPasswordActivity.this.makeButtonEnabled(true);
          }
          
          public void success(Session param1Session) {
            VerifyPasswordActivity.this.onLoginSuccess(param1Session);
          }
        });
  }
  
  private void putIntentExtras(Intent paramIntent, String paramString, int paramInt, UssdCode paramUssdCode) {
    paramIntent.putExtra("EXTRA_PHONE_NUMBER", paramString);
    boolean bool = true;
    paramIntent.putExtra("EXTRA_PHONE_VERIFICATION", true);
    paramIntent.putExtra("EXTRA_IS_FIRST_PHONE_VERIFICATION", false);
    paramIntent.putExtra("EXTRA_CASE_CODE", paramInt);
    if (paramInt != 18)
      bool = false; 
    paramIntent.putExtra("EXTRA_CAN_SKIP_PHONE_VERIFICATION", bool);
    paramIntent.putExtra("EXTRA_PASSWORD", this.password);
    if (paramUssdCode != null) {
      paramString = paramUssdCode.getUssdCode();
    } else {
      paramString = null;
    } 
    paramIntent.putExtra("EXTRA_USSD_CODE", paramString);
  }
  
  private void verifyPhoneNumber(String paramString, int paramInt, UssdCode paramUssdCode) {
    Intent intent = new Intent((Context)this, PhoneSignupEnterOtpActivity.class);
    putIntentExtras(intent, paramString, paramInt, paramUssdCode);
    startActivity(intent);
    finish();
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {
    this.btConfirm.setEnabled(paramBoolean);
  }
  
  public void makePasswordAction() {
    PhoneAuthentication phoneAuthentication = new PhoneAuthentication();
    phoneAuthentication.setPassword(this.password);
    phoneAuthentication.setPhone(this.phoneNumber.toString());
    phoneAuthentication.setAndroidAppInstanceGuid(Utils.getAndroidAppInstanceGuid((Context)this));
    phoneLogin(phoneAuthentication);
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    goToPreviousActivity();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.isAuthMandatory = false;
    initBackArrow();
    initPasswords();
    if (getIntent() != null)
      this.phoneNumber = (f)getIntent().getSerializableExtra("EXTRA_PHONE_NUMBER"); 
    Button button = (Button)findViewById(2131296418);
    this.btConfirm = button;
    button.setOnClickListener((View.OnClickListener)new k(this));
  }
  
  public int provideContentViewId() {
    return 2131492921;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\VerifyPasswordActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
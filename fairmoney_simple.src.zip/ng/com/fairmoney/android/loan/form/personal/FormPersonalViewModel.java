package ng.com.fairmoney.android.loan.form.personal;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.c;
import f.d.b.e.a.a;
import f.d.b.g.a;
import f.d.b.h.b;
import f.d.b.h.c;
import f.d.b.k.a;
import f.d.b.k.b;
import f.d.b.k.g;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import java.util.List;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class FormPersonalViewModel extends w {
  public final LiveData<b> country;
  
  public final a features;
  
  public final a formPersonalRepository;
  
  public final LiveData<FormPersonalState> formPersonalState;
  
  public final c kycUseCase;
  
  public final r<b> mutableCountry;
  
  public final r<FormPersonalState> mutableFormPersonalState;
  
  public final c router;
  
  public final g userRepository;
  
  public final h userUseCase;
  
  @Inject
  public FormPersonalViewModel(a parama, h paramh, c paramc, c paramc1, g paramg, a parama1) {
    this.formPersonalRepository = parama;
    this.userUseCase = paramh;
    this.kycUseCase = paramc;
    this.router = paramc1;
    this.userRepository = paramg;
    this.features = parama1;
    r<b> r1 = new r();
    this.mutableCountry = r1;
    this.country = (LiveData<b>)r1;
    r1 = new r();
    this.mutableFormPersonalState = (r)r1;
    this.formPersonalState = (LiveData)r1;
  }
  
  public final void fetchCountry() {
    c.a(c.a(this.userUseCase.getCountry(), new FormPersonalViewModel$fetchCountry$1(null)), x.a(this));
  }
  
  public final List<String> getCities() {
    return this.formPersonalRepository.b(this.userRepository.d());
  }
  
  public final LiveData<b> getCountry() {
    return this.country;
  }
  
  public final LiveData<FormPersonalState> getFormPersonalState() {
    return this.formPersonalState;
  }
  
  public final List<String> getStates() {
    return this.formPersonalRepository.a(this.userRepository.d());
  }
  
  public final void goToNextActivity() {
    c.a(c.a(c.b(c.b(c.a(c.a(this.userUseCase.getCountry(), 0, new FormPersonalViewModel$goToNextActivity$1(null), 1, null), new FormPersonalViewModel$goToNextActivity$2(null)), new FormPersonalViewModel$goToNextActivity$3(null)), new FormPersonalViewModel$goToNextActivity$4(null)), new FormPersonalViewModel$goToNextActivity$5(null)), x.a(this));
  }
  
  public final boolean isKycBvnEnabled() {
    return this.features.e();
  }
  
  public final boolean isMbsEnabled() {
    return this.features.f();
  }
  
  public static abstract class FormPersonalState {
    public FormPersonalState() {}
    
    public static final class Bvn extends FormPersonalState {
      public static final Bvn INSTANCE = new Bvn();
      
      public Bvn() {
        super(null);
      }
    }
    
    public static final class Error extends FormPersonalState {
      public final Throwable throwable;
      
      public Error(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Hyperverge extends FormPersonalState {
      public static final Hyperverge INSTANCE = new Hyperverge();
      
      public Hyperverge() {
        super(null);
      }
    }
    
    public static final class Loading extends FormPersonalState {
      public final boolean loading;
      
      public Loading(boolean param2Boolean) {
        super(null);
        this.loading = param2Boolean;
      }
      
      public final boolean getLoading() {
        return this.loading;
      }
    }
    
    public static final class Mbs extends FormPersonalState {
      public static final Mbs INSTANCE = new Mbs();
      
      public Mbs() {
        super(null);
      }
    }
    
    public static final class Work extends FormPersonalState {
      public static final Work INSTANCE = new Work();
      
      public Work() {
        super(null);
      }
    }
  }
  
  public static final class Bvn extends FormPersonalState {
    public static final Bvn INSTANCE = new Bvn();
    
    public Bvn() {
      super(null);
    }
  }
  
  public static final class Error extends FormPersonalState {
    public final Throwable throwable;
    
    public Error(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Hyperverge extends FormPersonalState {
    public static final Hyperverge INSTANCE = new Hyperverge();
    
    public Hyperverge() {
      super(null);
    }
  }
  
  public static final class Loading extends FormPersonalState {
    public final boolean loading;
    
    public Loading(boolean param1Boolean) {
      super(null);
      this.loading = param1Boolean;
    }
    
    public final boolean getLoading() {
      return this.loading;
    }
  }
  
  public static final class Mbs extends FormPersonalState {
    public static final Mbs INSTANCE = new Mbs();
    
    public Mbs() {
      super(null);
    }
  }
  
  public static final class Work extends FormPersonalState {
    public static final Work INSTANCE = new Work();
    
    public Work() {
      super(null);
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel$fetchCountry$1", f = "FormPersonalViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class FormPersonalViewModel$fetchCountry$1 extends k implements p<b, d<? super k>, Object> {
    public int label;
    
    public b p$0;
    
    public FormPersonalViewModel$fetchCountry$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      FormPersonalViewModel$fetchCountry$1 formPersonalViewModel$fetchCountry$1 = new FormPersonalViewModel$fetchCountry$1(param1d);
      formPersonalViewModel$fetchCountry$1.p$0 = (b)param1Object;
      return (d<k>)formPersonalViewModel$fetchCountry$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((FormPersonalViewModel$fetchCountry$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        FormPersonalViewModel.this.mutableCountry.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel$goToNextActivity$1", f = "FormPersonalViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class FormPersonalViewModel$goToNextActivity$1 extends k implements p<b, d<? super a<? extends FormPersonalState>>, Object> {
    public int label;
    
    public b p$0;
    
    public FormPersonalViewModel$goToNextActivity$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      FormPersonalViewModel$goToNextActivity$1 formPersonalViewModel$goToNextActivity$1 = new FormPersonalViewModel$goToNextActivity$1(param1d);
      formPersonalViewModel$goToNextActivity$1.p$0 = (b)param1Object;
      return (d<k>)formPersonalViewModel$goToNextActivity$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((FormPersonalViewModel$goToNextActivity$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        if (param1Object instanceof b.b) {
          if (FormPersonalViewModel.this.isKycBvnEnabled()) {
            param1Object = new FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1(FormPersonalViewModel.this.userUseCase.c());
          } else if (FormPersonalViewModel.this.isMbsEnabled()) {
            param1Object = c.a(FormPersonalViewModel.FormPersonalState.Mbs.INSTANCE);
          } else {
            param1Object = c.a(FormPersonalViewModel.FormPersonalState.Work.INSTANCE);
          } 
        } else if (param1Object instanceof b.a) {
          param1Object = new FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2(FormPersonalViewModel.this.kycUseCase.a());
        } else {
          param1Object = c.a(FormPersonalViewModel.FormPersonalState.Work.INSTANCE);
        } 
        return param1Object;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    public static final class FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1 implements a<FormPersonalViewModel.FormPersonalState> {
      public FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1(a param1a) {}
      
      public Object collect(b param1b, d param1d) {
        Object object = this.$this_unsafeTransform$inlined.collect(new b<a>(this) {
              public Object emit(Object param1Object, d param1d) {
                b b1 = this.$this_unsafeFlow$inlined;
                if (((a)param1Object).a() == null) {
                  param1Object = FormPersonalViewModel.FormPersonalState.Bvn.INSTANCE;
                } else {
                  param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
                } 
                param1Object = b1.emit(param1Object, param1d);
                return (param1Object == c.a()) ? param1Object : k.a;
              }
            }param1d);
        return (object == c.a()) ? object : k.a;
      }
    }
    
    public static final class null implements b<a> {
      public null(FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1 param1FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1) {}
      
      public Object emit(Object param1Object, d param1d) {
        b b1 = this.$this_unsafeFlow$inlined;
        if (((a)param1Object).a() == null) {
          param1Object = FormPersonalViewModel.FormPersonalState.Bvn.INSTANCE;
        } else {
          param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
        } 
        param1Object = b1.emit(param1Object, param1d);
        return (param1Object == c.a()) ? param1Object : k.a;
      }
    }
    
    public static final class FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2 implements a<FormPersonalViewModel.FormPersonalState> {
      public FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2(a param1a) {}
      
      public Object collect(b param1b, d param1d) {
        Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
              public Object emit(Object param1Object, d param1d) {
                b b1 = this.$this_unsafeFlow$inlined;
                if (((b)param1Object).a()) {
                  param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
                } else {
                  param1Object = FormPersonalViewModel.FormPersonalState.Hyperverge.INSTANCE;
                } 
                param1Object = b1.emit(param1Object, param1d);
                return (param1Object == c.a()) ? param1Object : k.a;
              }
            }param1d);
        return (object == c.a()) ? object : k.a;
      }
    }
    
    public static final class null implements b<b> {
      public null(FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2 param1FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2) {}
      
      public Object emit(Object param1Object, d param1d) {
        b b1 = this.$this_unsafeFlow$inlined;
        if (((b)param1Object).a()) {
          param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
        } else {
          param1Object = FormPersonalViewModel.FormPersonalState.Hyperverge.INSTANCE;
        } 
        param1Object = b1.emit(param1Object, param1d);
        return (param1Object == c.a()) ? param1Object : k.a;
      }
    }
  }
  
  public static final class FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1 implements a<FormPersonalState> {
    public FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<a>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              if (((a)param1Object).a() == null) {
                param1Object = FormPersonalViewModel.FormPersonalState.Bvn.INSTANCE;
              } else {
                param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
              } 
              param1Object = b1.emit(param1Object, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<a> {
    public null(FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1 param1FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      if (((a)param1Object).a() == null) {
        param1Object = FormPersonalViewModel.FormPersonalState.Bvn.INSTANCE;
      } else {
        param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
      } 
      param1Object = b1.emit(param1Object, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  public static final class FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2 implements a<FormPersonalState> {
    public FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              if (((b)param1Object).a()) {
                param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
              } else {
                param1Object = FormPersonalViewModel.FormPersonalState.Hyperverge.INSTANCE;
              } 
              param1Object = b1.emit(param1Object, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<b> {
    public null(FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2 param1FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      if (((b)param1Object).a()) {
        param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
      } else {
        param1Object = FormPersonalViewModel.FormPersonalState.Hyperverge.INSTANCE;
      } 
      param1Object = b1.emit(param1Object, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel$goToNextActivity$2", f = "FormPersonalViewModel.kt", l = {96}, m = "invokeSuspend")
  public static final class FormPersonalViewModel$goToNextActivity$2 extends k implements q<b<? super FormPersonalState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public FormPersonalViewModel$goToNextActivity$2(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super FormPersonalViewModel.FormPersonalState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      FormPersonalViewModel$goToNextActivity$2 formPersonalViewModel$goToNextActivity$2 = new FormPersonalViewModel$goToNextActivity$2(param1d);
      formPersonalViewModel$goToNextActivity$2.p$ = param1b;
      formPersonalViewModel$goToNextActivity$2.p$0 = param1Throwable;
      return (d<k>)formPersonalViewModel$goToNextActivity$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((FormPersonalViewModel$goToNextActivity$2)create((b<? super FormPersonalViewModel.FormPersonalState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$;
        Throwable throwable = this.p$0;
        FormPersonalViewModel.FormPersonalState.Error error = new FormPersonalViewModel.FormPersonalState.Error(throwable);
        this.L$0 = param1Object;
        this.L$1 = throwable;
        this.label = 1;
        if (param1Object.emit(error, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel$goToNextActivity$3", f = "FormPersonalViewModel.kt", l = {99}, m = "invokeSuspend")
  public static final class FormPersonalViewModel$goToNextActivity$3 extends k implements p<b<? super FormPersonalState>, d<? super k>, Object> {
    public Object L$0;
    
    public int label;
    
    public b p$;
    
    public FormPersonalViewModel$goToNextActivity$3(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      FormPersonalViewModel$goToNextActivity$3 formPersonalViewModel$goToNextActivity$3 = new FormPersonalViewModel$goToNextActivity$3(param1d);
      formPersonalViewModel$goToNextActivity$3.p$ = (b)param1Object;
      return (d<k>)formPersonalViewModel$goToNextActivity$3;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((FormPersonalViewModel$goToNextActivity$3)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        param1Object = new FormPersonalViewModel.FormPersonalState.Loading(true);
        this.L$0 = b1;
        this.label = 1;
        if (b1.emit(param1Object, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel$goToNextActivity$4", f = "FormPersonalViewModel.kt", l = {102}, m = "invokeSuspend")
  public static final class FormPersonalViewModel$goToNextActivity$4 extends k implements q<b<? super FormPersonalState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public FormPersonalViewModel$goToNextActivity$4(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super FormPersonalViewModel.FormPersonalState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1d, "continuation");
      FormPersonalViewModel$goToNextActivity$4 formPersonalViewModel$goToNextActivity$4 = new FormPersonalViewModel$goToNextActivity$4(param1d);
      formPersonalViewModel$goToNextActivity$4.p$ = param1b;
      formPersonalViewModel$goToNextActivity$4.p$0 = param1Throwable;
      return (d<k>)formPersonalViewModel$goToNextActivity$4;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((FormPersonalViewModel$goToNextActivity$4)create((b<? super FormPersonalViewModel.FormPersonalState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$;
        Throwable throwable = this.p$0;
        FormPersonalViewModel.FormPersonalState.Loading loading = new FormPersonalViewModel.FormPersonalState.Loading(false);
        this.L$0 = param1Object;
        this.L$1 = throwable;
        this.label = 1;
        if (param1Object.emit(loading, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel$goToNextActivity$5", f = "FormPersonalViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class FormPersonalViewModel$goToNextActivity$5 extends k implements p<FormPersonalState, d<? super k>, Object> {
    public int label;
    
    public FormPersonalViewModel.FormPersonalState p$0;
    
    public FormPersonalViewModel$goToNextActivity$5(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      FormPersonalViewModel$goToNextActivity$5 formPersonalViewModel$goToNextActivity$5 = new FormPersonalViewModel$goToNextActivity$5(param1d);
      formPersonalViewModel$goToNextActivity$5.p$0 = (FormPersonalViewModel.FormPersonalState)param1Object;
      return (d<k>)formPersonalViewModel$goToNextActivity$5;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((FormPersonalViewModel$goToNextActivity$5)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        if (param1Object instanceof FormPersonalViewModel.FormPersonalState.Work) {
          FormPersonalViewModel.this.router.toWorkForm();
        } else if (param1Object instanceof FormPersonalViewModel.FormPersonalState.Hyperverge) {
          FormPersonalViewModel.this.router.toHypervergeKyc();
        } else if (param1Object instanceof FormPersonalViewModel.FormPersonalState.Mbs) {
          FormPersonalViewModel.this.router.toFinancialMbs();
        } else if (param1Object instanceof FormPersonalViewModel.FormPersonalState.Bvn) {
          FormPersonalViewModel.this.router.toBvnKyc();
        } else {
          FormPersonalViewModel.this.mutableFormPersonalState.b(param1Object);
        } 
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
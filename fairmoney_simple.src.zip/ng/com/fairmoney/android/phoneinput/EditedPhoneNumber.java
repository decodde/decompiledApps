package ng.com.fairmoney.android.phoneinput;

import j.q.d.k;

public final class EditedPhoneNumber {
  public final int cursorPos;
  
  public final String editedPhone;
  
  public final int maxLength;
  
  public EditedPhoneNumber(String paramString, int paramInt1, int paramInt2) {
    this.editedPhone = paramString;
    this.cursorPos = paramInt1;
    this.maxLength = paramInt2;
  }
  
  public final String component1() {
    return this.editedPhone;
  }
  
  public final int component2() {
    return this.cursorPos;
  }
  
  public final int component3() {
    return this.maxLength;
  }
  
  public final EditedPhoneNumber copy(String paramString, int paramInt1, int paramInt2) {
    k.b(paramString, "editedPhone");
    return new EditedPhoneNumber(paramString, paramInt1, paramInt2);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof EditedPhoneNumber) {
        paramObject = paramObject;
        if (k.a(this.editedPhone, ((EditedPhoneNumber)paramObject).editedPhone) && this.cursorPos == ((EditedPhoneNumber)paramObject).cursorPos && this.maxLength == ((EditedPhoneNumber)paramObject).maxLength)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final int getCursorPos() {
    return this.cursorPos;
  }
  
  public final String getEditedPhone() {
    return this.editedPhone;
  }
  
  public final int getMaxLength() {
    return this.maxLength;
  }
  
  public int hashCode() {
    byte b;
    String str = this.editedPhone;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    return (b * 31 + this.cursorPos) * 31 + this.maxLength;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("EditedPhoneNumber(editedPhone=");
    stringBuilder.append(this.editedPhone);
    stringBuilder.append(", cursorPos=");
    stringBuilder.append(this.cursorPos);
    stringBuilder.append(", maxLength=");
    stringBuilder.append(this.maxLength);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\EditedPhoneNumber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
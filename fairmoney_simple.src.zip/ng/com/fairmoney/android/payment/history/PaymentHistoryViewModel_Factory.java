package ng.com.fairmoney.android.payment.history;

import f.d.b.j.f;
import g.b.d;
import javax.inject.Provider;

public final class PaymentHistoryViewModel_Factory implements d<PaymentHistoryViewModel> {
  public final Provider<f> paymentUseCaseProvider;
  
  public PaymentHistoryViewModel_Factory(Provider<f> paramProvider) {
    this.paymentUseCaseProvider = paramProvider;
  }
  
  public static PaymentHistoryViewModel_Factory create(Provider<f> paramProvider) {
    return new PaymentHistoryViewModel_Factory(paramProvider);
  }
  
  public static PaymentHistoryViewModel newInstance(f paramf) {
    return new PaymentHistoryViewModel(paramf);
  }
  
  public PaymentHistoryViewModel get() {
    return newInstance((f)this.paymentUseCaseProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.payment.history;

import android.view.View;

public final class PaymentHistoryFragment$onViewCreated$2 implements View.OnClickListener {
  public final void onClick(View paramView) {
    PaymentHistoryFragment.access$getViewModel$p(PaymentHistoryFragment.this).fetchBills();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryFragment$onViewCreated$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
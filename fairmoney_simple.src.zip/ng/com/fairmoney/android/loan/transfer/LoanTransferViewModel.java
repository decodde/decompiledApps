package ng.com.fairmoney.android.loan.transfer;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.k.b;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import javax.inject.Inject;
import k.a.h2.c;
import kotlin.NoWhenBranchMatchedException;

public final class LoanTransferViewModel extends w {
  public final LiveData<LoanTransferDetails> loanTransferDetails;
  
  public final r<LoanTransferDetails> mutableLoanTransferDetails;
  
  public final h userUseCase;
  
  @Inject
  public LoanTransferViewModel(h paramh) {
    this.userUseCase = paramh;
    r<LoanTransferDetails> r1 = new r();
    this.mutableLoanTransferDetails = r1;
    this.loanTransferDetails = (LiveData<LoanTransferDetails>)r1;
  }
  
  public final LiveData<LoanTransferDetails> getLoanTransferDetails() {
    return this.loanTransferDetails;
  }
  
  public final void initialize() {
    c.a(c.a(this.userUseCase.getCountry(), new LoanTransferViewModel$initialize$1(null)), x.a(this));
  }
  
  @f(c = "ng.com.fairmoney.android.loan.transfer.LoanTransferViewModel$initialize$1", f = "LoanTransferViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class LoanTransferViewModel$initialize$1 extends k implements p<b, d<? super k>, Object> {
    public int label;
    
    public b p$0;
    
    public LoanTransferViewModel$initialize$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      LoanTransferViewModel$initialize$1 loanTransferViewModel$initialize$1 = new LoanTransferViewModel$initialize$1(param1d);
      loanTransferViewModel$initialize$1.p$0 = (b)param1Object;
      return (d<k>)loanTransferViewModel$initialize$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LoanTransferViewModel$initialize$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        r r = LoanTransferViewModel.this.mutableLoanTransferDetails;
        if (param1Object instanceof b.b) {
          param1Object = new LoanTransferDetails(2131231025, 2131820927, true);
        } else if (k.a(param1Object, b.a.h)) {
          param1Object = new LoanTransferDetails(2131231024, 2131820926, false);
        } else {
          if (k.a(param1Object, b.c.h)) {
            param1Object = null;
            r.b(param1Object);
            return k.a;
          } 
          throw new NoWhenBranchMatchedException();
        } 
        r.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\transfer\LoanTransferViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
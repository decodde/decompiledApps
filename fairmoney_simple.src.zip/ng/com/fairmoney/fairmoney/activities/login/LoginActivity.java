package ng.com.fairmoney.fairmoney.activities.login;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import com.google.firebase.analytics.FirebaseAnalytics;
import d.b.k.c;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.c.a.a;
import f.d.a.t.e;
import f.d.b.f.e;
import f.d.b.k.f;
import f.d.c.b;
import java.net.URI;
import javax.inject.Inject;
import l.a.a.a.a.t.a;
import l.a.a.a.a.t.b;
import l.a.a.a.a.t.c;
import l.a.a.a.a.t.d;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;
import ng.com.fairmoney.android.user.data.UserLegacyImpl;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.HomeActivity;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.database.CardRoomDatabase;
import ng.com.fairmoney.fairmoney.models.FirebaseToken;
import ng.com.fairmoney.fairmoney.models.JsonFeatures;
import ng.com.fairmoney.fairmoney.models.JsonFeaturesMapper;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.repositories.CardRepositoryImpl;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.viewmodels.BillViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.CardViewModel;
import ng.com.fairmoney.fairmoney.views.PopUpMessageDialog;

public abstract class LoginActivity extends BaseActivity {
  public static final String EXTRA_LOAN_REPAID = "ng.com.fairmoney.EXTRA_LOAN_REPAID";
  
  public c alertDialog;
  
  public LoginViewModel loginViewModel;
  
  public PhoneInputView pivLogin;
  
  public String status;
  
  @Inject
  public y.b viewModelFactory;
  
  private void displayInAppMessage(e parame) {
    PopUpMessageDialog popUpMessageDialog = (new PopUpMessageDialog((Context)this)).init();
    popUpMessageDialog.setTitle(parame.c()).setMessage(parame.a()).setPositiveButton(2131821078, (View.OnClickListener)new c(this));
    if (parame.d() != null)
      popUpMessageDialog.setNegativeButton(2131821077, (View.OnClickListener)new d(this, popUpMessageDialog, parame)); 
    popUpMessageDialog.show();
  }
  
  private void goToHomeScreen() {
    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
    String str = this.status;
    if (str != null)
      intent.putExtra("ng.com.fairmoney.EXTRA_LOAN_REPAID", str.contentEquals("loan_repaid")); 
    startActivity(intent);
    finish();
  }
  
  private void observeInAppMessage() {
    this.loginViewModel.getInAppMessage().a((l)this, (s)new a(this));
  }
  
  private void openWebPage(URI paramURI) {
    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(paramURI.toString()));
    try {
      startActivity(intent);
    } catch (ActivityNotFoundException activityNotFoundException) {}
  }
  
  private void uploadFirebaseToken(final int retryCount) {
    FirebaseToken firebaseToken = FirebaseToken.getStoredToken((Context)this);
    if (firebaseToken != null)
      RetrofitSession.getInstance((Context)this).getUserManager().saveFirebaseToken(firebaseToken, new APIResponse<Void>() {
            public void failure(int param1Int, String param1String) {
              a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)LoginActivity.this, param1String, String.valueOf(param1Int))));
              param1Int = retryCount;
              if (param1Int > 0)
                LoginActivity.this.uploadFirebaseToken(param1Int - 1); 
            }
            
            public void success(Void param1Void) {}
          }); 
  }
  
  public void getFeatures() {
    CardViewModel cardViewModel = (CardViewModel)z.a((d)this, this.viewModelFactory).a(CardViewModel.class);
    cardViewModel.setRepository(new CardRepositoryImpl(CardRoomDatabase.getDatabase((Context)getApplication()).getCardDao(), (e)new UserLegacyImpl((Context)this)));
    cardViewModel.deleteAll();
    ((BillViewModel)z.a((d)this).a(BillViewModel.class)).deleteAll();
    RetrofitSession.getInstance((Context)this).getAppUtilsManager().getFeatures(new APIResponse<JsonFeatures>() {
          public void failure(int param1Int, String param1String) {
            LoginActivity.this.showNewToastMessage(param1String, 1);
            a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)LoginActivity.this, param1String, String.valueOf(param1Int))));
            LoginActivity.this.makeButtonEnabled(true);
          }
          
          public void success(JsonFeatures param1JsonFeatures) {
            FairMoney.setFeatures(JsonFeaturesMapper.Companion.transform(param1JsonFeatures));
            LoginActivity.this.loginViewModel.fetchInAppMessage();
          }
        });
  }
  
  public void getPhoneNumber() {
    this.loginViewModel.getPhoneNumber().a((l)this, (s)new b(this));
    this.loginViewModel.fetchPhoneNumber();
  }
  
  public void goToNextScreen(String paramString) {
    this.status = paramString;
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    getFeatures();
    uploadFirebaseToken(3);
  }
  
  public void logLoginResult(String paramString, boolean paramBoolean) {
    Bundle bundle = new Bundle();
    bundle.putString("method", paramString);
    bundle.putBoolean("success", paramBoolean);
    FirebaseAnalytics.getInstance((Context)this).a("login", bundle);
  }
  
  public void logSignupResult(String paramString, boolean paramBoolean) {
    Bundle bundle = new Bundle();
    bundle.putString("method", paramString);
    bundle.putBoolean("success", paramBoolean);
    FirebaseAnalytics.getInstance((Context)this).a("sign_up", bundle);
  }
  
  public abstract void makeButtonEnabled(boolean paramBoolean);
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplication()).inject(this);
    this.loginViewModel = (LoginViewModel)z.a((d)this, this.viewModelFactory).a(LoginViewModel.class);
    observeInAppMessage();
  }
  
  public void onDestroy() {
    super.onDestroy();
    c c1 = this.alertDialog;
    if (c1 != null)
      c1.dismiss(); 
    this.alertDialog = null;
  }
  
  public void savePhoneNumber(f paramf) {
    this.loginViewModel.savePhoneNumber(paramf);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
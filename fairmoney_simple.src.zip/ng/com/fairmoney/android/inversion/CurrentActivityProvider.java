package ng.com.fairmoney.android.inversion;

import android.app.Activity;

public interface CurrentActivityProvider {
  Activity getCurrentActivity();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\CurrentActivityProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.phoneinput;

public enum ErrorType {
  NO_COUNTRY, NO_NUMBERS;
  
  static {
    ErrorType errorType1 = new ErrorType("NO_COUNTRY", 0);
    NO_COUNTRY = errorType1;
    ErrorType errorType2 = new ErrorType("NO_NUMBERS", 1);
    NO_NUMBERS = errorType2;
    $VALUES = new ErrorType[] { errorType1, errorType2 };
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputViewModel$PhoneInputState$Invalid$ErrorType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.phoneinput;

import g.a;
import javax.inject.Provider;

public final class NigerianPhoneNumberTextWatcher_MembersInjector implements a<NigerianPhoneNumberTextWatcher> {
  public final Provider<NigerianPhoneNumberViewModel> viewModelProvider;
  
  public NigerianPhoneNumberTextWatcher_MembersInjector(Provider<NigerianPhoneNumberViewModel> paramProvider) {
    this.viewModelProvider = paramProvider;
  }
  
  public static a<NigerianPhoneNumberTextWatcher> create(Provider<NigerianPhoneNumberViewModel> paramProvider) {
    return new NigerianPhoneNumberTextWatcher_MembersInjector(paramProvider);
  }
  
  public static void injectViewModel(NigerianPhoneNumberTextWatcher paramNigerianPhoneNumberTextWatcher, NigerianPhoneNumberViewModel paramNigerianPhoneNumberViewModel) {
    paramNigerianPhoneNumberTextWatcher.viewModel = paramNigerianPhoneNumberViewModel;
  }
  
  public void injectMembers(NigerianPhoneNumberTextWatcher paramNigerianPhoneNumberTextWatcher) {
    injectViewModel(paramNigerianPhoneNumberTextWatcher, (NigerianPhoneNumberViewModel)this.viewModelProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\NigerianPhoneNumberTextWatcher_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.injection;

import d.o.w;
import d.o.y;
import ng.com.fairmoney.android.home.card.EarlyRepaymentCardViewModel;
import ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel;
import ng.com.fairmoney.android.loan.form.guarantor.FormGuarantorViewModel;
import ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel;
import ng.com.fairmoney.android.loan.form.work.view.FormWorkViewModel;
import ng.com.fairmoney.android.loan.offer.LoanOfferDetailsViewModel;
import ng.com.fairmoney.android.loan.offers.LoanOffersViewModel;
import ng.com.fairmoney.android.loan.rejected.RejectedViewModel;
import ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel;
import ng.com.fairmoney.android.loan.repayment.methods.RepaymentMethodsViewModel;
import ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel;
import ng.com.fairmoney.android.loan.transfer.LoanTransferViewModel;
import ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel;
import ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel;
import ng.com.fairmoney.android.login.signup.PhoneSignupViewModel;
import ng.com.fairmoney.android.otp.VerifyOtpViewModel;
import ng.com.fairmoney.android.payment.history.PaymentHistoryViewModel;
import ng.com.fairmoney.android.phoneinput.PhoneInputViewModel;
import ng.com.fairmoney.android.splash.SplashViewModel;
import ng.com.fairmoney.fairmoney.activities.DataUploadViewModel;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferViewModel;
import ng.com.fairmoney.fairmoney.activities.login.LoginViewModel;
import ng.com.fairmoney.fairmoney.fragments.loanoffer.LoanOfferDetailsFragmentViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.BvnVerificationViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.CardViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.FormBankViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.FormFinancialKycViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.FormLoanPurposeViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.HomeViewModel;

public abstract class ViewModelModule {
  @ViewModelKey(BankDetailsViewModel.class)
  @ViewModelScope
  public abstract w bindBankDetailsViewModel$app_prodRelease(BankDetailsViewModel paramBankDetailsViewModel);
  
  @ViewModelKey(BvnVerificationViewModel.class)
  @ViewModelScope
  public abstract w bindBvnVerificationViewModel$app_prodRelease(BvnVerificationViewModel paramBvnVerificationViewModel);
  
  @ViewModelKey(CardViewModel.class)
  @ViewModelScope
  public abstract w bindCardViewModel$app_prodRelease(CardViewModel paramCardViewModel);
  
  @ViewModelKey(DataUploadViewModel.class)
  @ViewModelScope
  public abstract w bindDataUploadViewModel$app_prodRelease(DataUploadViewModel paramDataUploadViewModel);
  
  @ViewModelKey(EarlyRepaymentCardViewModel.class)
  @ViewModelScope
  public abstract w bindEarlyRepaymentCardViewModel$app_prodRelease(EarlyRepaymentCardViewModel paramEarlyRepaymentCardViewModel);
  
  @ViewModelKey(FinalLoanOfferViewModel.class)
  @ViewModelScope
  public abstract w bindFinalLoanOfferViewModel$app_prodRelease(FinalLoanOfferViewModel paramFinalLoanOfferViewModel);
  
  @ViewModelKey(ForgotPasswordEnterOtpViewModel.class)
  @ViewModelScope
  public abstract w bindForgotPasswordEnterOtpViewModel$app_prodRelease(ForgotPasswordEnterOtpViewModel paramForgotPasswordEnterOtpViewModel);
  
  @ViewModelKey(ForgotPasswordViewModel.class)
  @ViewModelScope
  public abstract w bindForgotPasswordViewModel$app_prodRelease(ForgotPasswordViewModel paramForgotPasswordViewModel);
  
  @ViewModelKey(FormBankViewModel.class)
  @ViewModelScope
  public abstract w bindFormBankViewModel$app_prodRelease(FormBankViewModel paramFormBankViewModel);
  
  @ViewModelKey(FormFinancialKycViewModel.class)
  @ViewModelScope
  public abstract w bindFormFinancialKYCViewModel$app_prodRelease(FormFinancialKycViewModel paramFormFinancialKycViewModel);
  
  @ViewModelKey(FormGuarantorViewModel.class)
  @ViewModelScope
  public abstract w bindFormGuarantorViewModel$app_prodRelease(FormGuarantorViewModel paramFormGuarantorViewModel);
  
  @ViewModelKey(FormLoanPurposeViewModel.class)
  @ViewModelScope
  public abstract w bindFormLoanPurposeViewModel$app_prodRelease(FormLoanPurposeViewModel paramFormLoanPurposeViewModel);
  
  @ViewModelKey(FormPersonalViewModel.class)
  @ViewModelScope
  public abstract w bindFormViewModel$app_prodRelease(FormPersonalViewModel paramFormPersonalViewModel);
  
  @ViewModelKey(FormWorkViewModel.class)
  @ViewModelScope
  public abstract w bindFormWorkViewModel$app_prodRelease(FormWorkViewModel paramFormWorkViewModel);
  
  @ViewModelKey(HomeRepayAmountViewModel.class)
  @ViewModelScope
  public abstract w bindHomeRepayAmountViewModel$app_prodRelease(HomeRepayAmountViewModel paramHomeRepayAmountViewModel);
  
  @ViewModelKey(HomeViewModel.class)
  @ViewModelScope
  public abstract w bindHomeViewModel$app_prodRelease(HomeViewModel paramHomeViewModel);
  
  @ViewModelKey(LoanOfferDetailsFragmentViewModel.class)
  @ViewModelScope
  public abstract w bindLoanOfferDetailsFragmentViewModel$app_prodRelease(LoanOfferDetailsFragmentViewModel paramLoanOfferDetailsFragmentViewModel);
  
  @ViewModelKey(LoanOfferDetailsViewModel.class)
  @ViewModelScope
  public abstract w bindLoanOfferDetailsViewModel$app_prodRelease(LoanOfferDetailsViewModel paramLoanOfferDetailsViewModel);
  
  @ViewModelKey(LoanOffersViewModel.class)
  @ViewModelScope
  public abstract w bindLoanOffersViewModel$app_prodRelease(LoanOffersViewModel paramLoanOffersViewModel);
  
  @ViewModelKey(LoanTransferViewModel.class)
  @ViewModelScope
  public abstract w bindLoanTransferViewModel$app_prodRelease(LoanTransferViewModel paramLoanTransferViewModel);
  
  @ViewModelKey(LoginViewModel.class)
  @ViewModelScope
  public abstract w bindLoginViewModel$app_prodRelease(LoginViewModel paramLoginViewModel);
  
  @ViewModelKey(PaymentHistoryViewModel.class)
  @ViewModelScope
  public abstract w bindPaymentHistoryViewModel$app_prodRelease(PaymentHistoryViewModel paramPaymentHistoryViewModel);
  
  @ViewModelKey(PhoneInputViewModel.class)
  @ViewModelScope
  public abstract w bindPhoneInputViewModel$app_prodRelease(PhoneInputViewModel paramPhoneInputViewModel);
  
  @ViewModelKey(PhoneSignupViewModel.class)
  @ViewModelScope
  public abstract w bindPhoneSignupViewModel$app_prodRelease(PhoneSignupViewModel paramPhoneSignupViewModel);
  
  @ViewModelKey(RejectedViewModel.class)
  @ViewModelScope
  public abstract w bindRejectedViewModel$app_prodRelease(RejectedViewModel paramRejectedViewModel);
  
  @ViewModelKey(RepaymentMethodsViewModel.class)
  @ViewModelScope
  public abstract w bindRepaymentMethodsViewModel$app_prodRelease(RepaymentMethodsViewModel paramRepaymentMethodsViewModel);
  
  @ViewModelKey(SplashViewModel.class)
  @ViewModelScope
  public abstract w bindSplashViewModel$app_prodRelease(SplashViewModel paramSplashViewModel);
  
  @ViewModelKey(TermsOfUseViewModel.class)
  @ViewModelScope
  public abstract w bindTermsOfUseViewModel$app_prodRelease(TermsOfUseViewModel paramTermsOfUseViewModel);
  
  @ViewModelKey(VerifyOtpViewModel.class)
  @ViewModelScope
  public abstract w bindVerifyOtpViewModel$app_prodRelease(VerifyOtpViewModel paramVerifyOtpViewModel);
  
  @ViewModelScope
  public abstract y.b bindViewModelFactory$app_prodRelease(ViewModelFactory paramViewModelFactory);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\ViewModelModule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonDisbursementFee;
import com.fairmoney.data.loan.JsonDisbursementFeeMapper;
import com.fairmoney.data.loan.JsonInstalment;
import com.fairmoney.data.loan.JsonInstalmentMapper;
import com.fairmoney.data.loan.JsonLoanOffer;
import f.d.b.i.a;
import f.d.b.i.b;
import f.d.b.i.c;
import j.l.i;
import j.q.d.k;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

public final class JsonLoanOfferMapper {
  public final JsonDisbursementFeeMapper jsonDisbursementFeesMapper;
  
  public final JsonInstalmentMapper jsonInstalmentMapper;
  
  @Inject
  public JsonLoanOfferMapper(JsonInstalmentMapper paramJsonInstalmentMapper, JsonDisbursementFeeMapper paramJsonDisbursementFeeMapper) {
    this.jsonInstalmentMapper = paramJsonInstalmentMapper;
    this.jsonDisbursementFeesMapper = paramJsonDisbursementFeeMapper;
  }
  
  public final c transform(JsonLoanOffer paramJsonLoanOffer) {
    k.b(paramJsonLoanOffer, "jsonLoanOffer");
    String str1 = paramJsonLoanOffer.getId();
    int i = paramJsonLoanOffer.getAmountOffered();
    int j = paramJsonLoanOffer.getDisbursementAmount();
    String str2 = paramJsonLoanOffer.getCurrencyCode();
    JsonDisbursementFee jsonDisbursementFee = paramJsonLoanOffer.getDisbursementFees();
    if (jsonDisbursementFee != null) {
      a a = this.jsonDisbursementFeesMapper.transform(jsonDisbursementFee);
    } else {
      jsonDisbursementFee = null;
    } 
    int k = paramJsonLoanOffer.getDaysLoanMaturity();
    double d = paramJsonLoanOffer.getTotalInterestRate();
    List list = paramJsonLoanOffer.getInstalments();
    ArrayList<b> arrayList = new ArrayList(i.a(list, 10));
    for (JsonInstalment jsonInstalment : list)
      arrayList.add(this.jsonInstalmentMapper.transform(jsonInstalment)); 
    return new c(str1, j, k, i, d, str2, arrayList, (a)jsonDisbursementFee);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonLoanOfferMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
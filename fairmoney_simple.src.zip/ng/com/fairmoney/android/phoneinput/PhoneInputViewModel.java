package ng.com.fairmoney.android.phoneinput;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.b;
import f.d.b.d.a;
import f.d.b.k.b;
import f.d.b.k.c;
import f.d.b.k.f;
import f.d.b.k.h;
import j.k;
import j.n.d;
import j.n.i.c;
import j.q.d.g;
import j.q.d.k;
import java.util.List;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import ng.com.fairmoney.fairmoney.utils.PhoneUtils;

public final class PhoneInputViewModel extends w {
  public final a countryUseCase;
  
  public final r<PhoneInputState> errorLiveData;
  
  public final c indicatorMapper;
  
  public f inputPhoneNumber;
  
  public final LiveData<PhoneInputState> phoneNumberLiveData;
  
  public final b phoneNumberValidator;
  
  public String phoneNumbers;
  
  public String selectedIndicator;
  
  @Inject
  public PhoneInputViewModel(b paramb, a parama, h paramh, c paramc) {
    this.phoneNumberValidator = paramb;
    this.countryUseCase = parama;
    this.indicatorMapper = paramc;
    r<PhoneInputState> r1 = new r();
    this.errorLiveData = r1;
    this.phoneNumberLiveData = (LiveData<PhoneInputState>)r1;
    c.a(new PhoneInputViewModel$$special$$inlined$map$1(this), x.a(this));
  }
  
  public final List<b> getCountries() {
    return this.countryUseCase.a();
  }
  
  public final f getInputPhoneNumber() {
    return this.inputPhoneNumber;
  }
  
  public final b getPhoneCountry(String paramString) {
    return this.indicatorMapper.a(paramString);
  }
  
  public final f getPhoneNumber() {
    return this.inputPhoneNumber;
  }
  
  public final LiveData<PhoneInputState> getPhoneNumberLiveData() {
    return this.phoneNumberLiveData;
  }
  
  public final String getPhoneNumbers() {
    return this.phoneNumbers;
  }
  
  public final String getSelectedIndicator() {
    return this.selectedIndicator;
  }
  
  public final void setInputPhoneNumber(f paramf) {
    this.inputPhoneNumber = paramf;
  }
  
  public final void setPhoneNumbers(String paramString) {
    this.phoneNumbers = paramString;
  }
  
  public final void setSelectedIndicator(String paramString) {
    this.selectedIndicator = paramString;
  }
  
  public final boolean validatePhoneNumber(boolean paramBoolean) {
    String str1 = this.selectedIndicator;
    if (str1 == null) {
      if (paramBoolean)
        this.errorLiveData.b(new PhoneInputState.Invalid(PhoneInputState.Invalid.ErrorType.NO_COUNTRY)); 
      return false;
    } 
    String str2 = this.phoneNumbers;
    if (str2 == null) {
      if (paramBoolean)
        this.errorLiveData.b(new PhoneInputState.Invalid(PhoneInputState.Invalid.ErrorType.NO_NUMBERS)); 
      return false;
    } 
    b b1 = this.phoneNumberValidator;
    if (str1 != null) {
      if (str2 != null) {
        if (!b1.a(str1, str2)) {
          if (paramBoolean)
            this.errorLiveData.b(new PhoneInputState.Invalid(PhoneInputState.Invalid.ErrorType.NO_NUMBERS)); 
          this.inputPhoneNumber = null;
          return false;
        } 
        String str = this.selectedIndicator;
        if (str != null) {
          str2 = this.phoneNumbers;
          if (str2 != null) {
            str2 = PhoneUtils.cleanPhoneNumber(str2);
            k.a(str2, "PhoneUtils.cleanPhoneNumber(phoneNumbers!!)");
            this.inputPhoneNumber = new f(str, str2);
            this.errorLiveData.b(PhoneInputState.Valid.INSTANCE);
            return true;
          } 
          k.a();
          throw null;
        } 
        k.a();
        throw null;
      } 
      k.a();
      throw null;
    } 
    k.a();
    throw null;
  }
  
  public static final class PhoneInputViewModel$$special$$inlined$map$1 implements a<k> {
    public PhoneInputViewModel$$special$$inlined$map$1(PhoneInputViewModel param1PhoneInputViewModel) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<f>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              PhoneInputViewModel.this.errorLiveData.b(new PhoneInputViewModel.PhoneInputState.InitValue((f)param1Object));
              param1Object = b1.emit(k.a, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<f> {
    public null(PhoneInputViewModel$$special$$inlined$map$1 param1PhoneInputViewModel$$special$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      PhoneInputViewModel.this.errorLiveData.b(new PhoneInputViewModel.PhoneInputState.InitValue((f)param1Object));
      param1Object = b1.emit(k.a, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  public static abstract class PhoneInputState {
    public PhoneInputState() {}
    
    public static final class InitValue extends PhoneInputState {
      public final f phoneNumber;
      
      public InitValue(f param2f) {
        super(null);
        this.phoneNumber = param2f;
      }
      
      public final f getPhoneNumber() {
        return this.phoneNumber;
      }
    }
    
    public static final class Invalid extends PhoneInputState {
      public final ErrorType errorType;
      
      public Invalid(ErrorType param2ErrorType) {
        super(null);
        this.errorType = param2ErrorType;
      }
      
      public final ErrorType getErrorType() {
        return this.errorType;
      }
      
      public enum ErrorType {
        NO_COUNTRY, NO_NUMBERS;
        
        static {
          ErrorType errorType1 = new ErrorType("NO_COUNTRY", 0);
          NO_COUNTRY = errorType1;
          ErrorType errorType2 = new ErrorType("NO_NUMBERS", 1);
          NO_NUMBERS = errorType2;
          $VALUES = new ErrorType[] { errorType1, errorType2 };
        }
      }
    }
    
    public enum ErrorType {
      NO_COUNTRY, NO_NUMBERS;
      
      static {
        ErrorType errorType1 = new ErrorType("NO_COUNTRY", 0);
        NO_COUNTRY = errorType1;
        ErrorType errorType2 = new ErrorType("NO_NUMBERS", 1);
        NO_NUMBERS = errorType2;
        $VALUES = new ErrorType[] { errorType1, errorType2 };
      }
    }
    
    public static final class Valid extends PhoneInputState {
      public static final Valid INSTANCE = new Valid();
      
      public Valid() {
        super(null);
      }
    }
  }
  
  public static final class InitValue extends PhoneInputState {
    public final f phoneNumber;
    
    public InitValue(f param1f) {
      super(null);
      this.phoneNumber = param1f;
    }
    
    public final f getPhoneNumber() {
      return this.phoneNumber;
    }
  }
  
  public static final class Invalid extends PhoneInputState {
    public final ErrorType errorType;
    
    public Invalid(ErrorType param1ErrorType) {
      super(null);
      this.errorType = param1ErrorType;
    }
    
    public final ErrorType getErrorType() {
      return this.errorType;
    }
    
    public enum ErrorType {
      NO_COUNTRY, NO_NUMBERS;
      
      static {
        ErrorType errorType1 = new ErrorType("NO_COUNTRY", 0);
        NO_COUNTRY = errorType1;
        ErrorType errorType2 = new ErrorType("NO_NUMBERS", 1);
        NO_NUMBERS = errorType2;
        $VALUES = new ErrorType[] { errorType1, errorType2 };
      }
    }
  }
  
  public enum ErrorType {
    NO_COUNTRY, NO_NUMBERS;
    
    static {
      ErrorType errorType1 = new ErrorType("NO_COUNTRY", 0);
      NO_COUNTRY = errorType1;
      ErrorType errorType2 = new ErrorType("NO_NUMBERS", 1);
      NO_NUMBERS = errorType2;
      $VALUES = new ErrorType[] { errorType1, errorType2 };
    }
  }
  
  public static final class Valid extends PhoneInputState {
    public static final Valid INSTANCE = new Valid();
    
    public Valid() {
      super(null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.EditText;
import com.google.android.material.textfield.TextInputLayout;
import f.c.a.a;
import java.util.Map;
import l.a.a.a.a.s.i.a;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;
import ng.com.fairmoney.fairmoney.utils.DateUtils;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.PhoneUtils;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class EditTextUtils {
  public static final String MINIMUM = "minimum";
  
  public static void addFocusChangedListenerToEditText(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    ((EditText)paramActivity.findViewById(paramInt)).setOnFocusChangeListener((View.OnFocusChangeListener)new a(paramMap, paramActivity));
  }
  
  public static void fillEditText(Activity paramActivity, Map<String, String> paramMap, SharedPreferences paramSharedPreferences, int paramInt) {
    ((EditText)paramActivity.findViewById(paramInt)).setText(paramSharedPreferences.getString(paramMap.get("id"), ""));
  }
  
  public static String getEditTextValue(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    EditText editText = (EditText)paramActivity.findViewById(paramInt);
    String str3 = paramMap.get("id");
    if (str3 == null)
      return ""; 
    String str4 = editText.getText().toString();
    String str1 = str4;
    if (paramMap.get("minimum") != null)
      str1 = str4.replaceAll(",", ""); 
    String str2 = str1;
    if (str3.contentEquals("phone"))
      str2 = PhoneUtils.transformPhoneNumber(str1); 
    return str2;
  }
  
  public static boolean isTextValid(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    TextInputLayout textInputLayout;
    EditText editText = (EditText)paramActivity.findViewById(paramInt);
    if (paramMap.get("error_view_id") != null) {
      textInputLayout = (TextInputLayout)paramActivity.findViewById(paramActivity.getResources().getIdentifier(paramMap.get("error_view_id"), "id", paramActivity.getPackageName()));
    } else {
      textInputLayout = null;
    } 
    if (editText.getText().toString().trim().equals("") && paramMap.get("optional") == null) {
      FormUtils.setTextError(editText, textInputLayout, paramActivity.getString(2131821029, new Object[] { paramMap.get("display_name") }));
      return false;
    } 
    if (paramMap.get("minimum") != null && !editText.getText().toString().trim().equals(""))
      try {
        String str1 = paramMap.get("minimum");
        String str2 = editText.getText().toString().replaceAll(",", "");
        if (str1 == null || Long.parseLong(str2) < Long.parseLong(str1)) {
          FormUtils.setTextError(editText, textInputLayout, paramActivity.getString(2131820953, new Object[] { paramMap.get("minimum") }));
          return false;
        } 
      } catch (NumberFormatException numberFormatException) {
        FormUtils.setTextError(editText, textInputLayout, paramActivity.getString(2131820872));
        return false;
      }  
    String str = (String)numberFormatException.get("id");
    if (str == null)
      return false; 
    if (str.contains("email") && !FormUtils.isValidEmailAddress(editText.getText().toString())) {
      FormUtils.setTextError(editText, textInputLayout, paramActivity.getString(2131820759));
      return false;
    } 
    if (str.contains("phone") && !PhoneUtils.isValidPhone(editText.getText().toString())) {
      FormUtils.setTextError(editText, textInputLayout, paramActivity.getString(2131821069));
      return false;
    } 
    if (str.contains("birthdate")) {
      if (!DateUtils.checkIs18YearsOld(DateUtils.fromFormCalendar(editText.getText().toString()))) {
        FormUtils.setTextError(editText, textInputLayout, paramActivity.getString(2131820952));
        return false;
      } 
      paramInt = DateUtils.fromFormCalendar(editText.getText().toString()).get(1);
      if (paramInt < 1900 || paramInt > 2100) {
        FormUtils.setTextError(editText, textInputLayout, paramActivity.getString(2131820720));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Year validation error in form: ");
        stringBuilder.append(paramInt);
        a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)paramActivity, stringBuilder.toString())));
        return false;
      } 
    } 
    FormUtils.hideErrors(editText, textInputLayout);
    return true;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\EditTextUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
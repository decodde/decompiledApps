package fairmoney.data.payment;

import j.q.d.k;

public final class JsonBill {
  public final String userReference;
  
  public JsonBill(String paramString) {
    this.userReference = paramString;
  }
  
  public final String component1() {
    return this.userReference;
  }
  
  public final com.fairmoney.data.payment.JsonBill copy(String paramString) {
    k.b(paramString, "userReference");
    return new com.fairmoney.data.payment.JsonBill(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.payment.JsonBill) {
        paramObject = paramObject;
        if (k.a(this.userReference, ((com.fairmoney.data.payment.JsonBill)paramObject).userReference))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getUserReference() {
    return this.userReference;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.userReference;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonBill(userReference=");
    stringBuilder.append(this.userReference);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\payment\JsonBill.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
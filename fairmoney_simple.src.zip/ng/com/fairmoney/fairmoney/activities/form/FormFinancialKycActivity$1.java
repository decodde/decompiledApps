package ng.com.fairmoney.fairmoney.activities.form;

import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<BankDetails> {
  public void failure(int paramInt, String paramString) {
    FormFinancialKycActivity.this.onFormCallFailure(paramString);
  }
  
  public void success(BankDetails paramBankDetails) {
    if (paramBankDetails.isBvnVerificationMandatory()) {
      FormFinancialKycActivity.access$000(FormFinancialKycActivity.this, paramBankDetails);
    } else {
      FormFinancialKycActivity.this.goToNextActivity();
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormFinancialKycActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
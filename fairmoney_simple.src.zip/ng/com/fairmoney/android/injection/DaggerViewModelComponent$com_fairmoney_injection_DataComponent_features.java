package ng.com.fairmoney.android.injection;

import f.d.b.g.a;
import f.d.c.i;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DataComponent_features implements Provider<a> {
  public final i dataComponent;
  
  public com_fairmoney_injection_DataComponent_features(i parami) {
    this.dataComponent = parami;
  }
  
  public a get() {
    a a = this.dataComponent.g();
    g.a(a, "Cannot return null from a non-@Nullable component method");
    return a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DataComponent_features.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
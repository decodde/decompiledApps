package fairmoney.data.inappmessaging;

import com.fairmoney.data.inappmessaging.JsonMessage;
import f.d.b.f.e;
import j.q.d.k;
import java.net.URI;

public final class JsonMessageMapper {
  public final e transform(JsonMessage paramJsonMessage) {
    k.b(paramJsonMessage, "jsonMessage");
    String str1 = paramJsonMessage.getId();
    String str2 = paramJsonMessage.getTitle();
    String str3 = paramJsonMessage.getMessage();
    try {
      URI uRI = URI.create(paramJsonMessage.getUrl());
    } catch (Exception exception) {
      exception = null;
    } 
    return new e(str1, str2, str3, (URI)exception);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\inappmessaging\JsonMessageMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.offer;

public final class LoanOfferDetailsViewState {
  public final boolean open;
  
  public LoanOfferDetailsViewState(boolean paramBoolean) {
    this.open = paramBoolean;
  }
  
  public final boolean component1() {
    return this.open;
  }
  
  public final LoanOfferDetailsViewState copy(boolean paramBoolean) {
    return new LoanOfferDetailsViewState(paramBoolean);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof LoanOfferDetailsViewState) {
        paramObject = paramObject;
        if (this.open == ((LoanOfferDetailsViewState)paramObject).open)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final boolean getOpen() {
    return this.open;
  }
  
  public int hashCode() {
    boolean bool1 = this.open;
    boolean bool2 = bool1;
    if (bool1)
      bool2 = true; 
    return bool2;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LoanOfferDetailsViewState(open=");
    stringBuilder.append(this.open);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsViewModel$LoanOfferDetailsViewState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import android.text.Editable;
import android.text.TextWatcher;

public class null implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    if (paramEditable.length() == 10) {
      FormBankActivity.access$000(FormBankActivity.this, paramEditable.toString());
      FormBankActivity.access$102(FormBankActivity.this, true);
    } else if (FormBankActivity.access$100(FormBankActivity.this)) {
      FormBankActivity.access$200(FormBankActivity.this);
      FormBankActivity.access$102(FormBankActivity.this, false);
    } 
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
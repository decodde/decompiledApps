package fairmoney.data.payment;

import com.fairmoney.data.payment.JsonParam;
import j.q.d.k;
import java.util.List;

public final class JsonInboundPaymentParams {
  public final List<JsonParam> params;
  
  public final String provider;
  
  public final String token;
  
  public JsonInboundPaymentParams(String paramString1, String paramString2, List<JsonParam> paramList) {
    this.provider = paramString1;
    this.token = paramString2;
    this.params = paramList;
  }
  
  public final String component1() {
    return this.provider;
  }
  
  public final String component2() {
    return this.token;
  }
  
  public final List<JsonParam> component3() {
    return this.params;
  }
  
  public final com.fairmoney.data.payment.JsonInboundPaymentParams copy(String paramString1, String paramString2, List<JsonParam> paramList) {
    k.b(paramString1, "provider");
    k.b(paramString2, "token");
    k.b(paramList, "params");
    return new com.fairmoney.data.payment.JsonInboundPaymentParams(paramString1, paramString2, paramList);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.payment.JsonInboundPaymentParams) {
        paramObject = paramObject;
        if (k.a(this.provider, ((com.fairmoney.data.payment.JsonInboundPaymentParams)paramObject).provider) && k.a(this.token, ((com.fairmoney.data.payment.JsonInboundPaymentParams)paramObject).token) && k.a(this.params, ((com.fairmoney.data.payment.JsonInboundPaymentParams)paramObject).params))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final List<JsonParam> getParams() {
    return this.params;
  }
  
  public final String getProvider() {
    return this.provider;
  }
  
  public final String getToken() {
    return this.token;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    String str = this.provider;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    str = this.token;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    List<JsonParam> list = this.params;
    if (list != null)
      i = list.hashCode(); 
    return (b1 * 31 + b2) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonInboundPaymentParams(provider=");
    stringBuilder.append(this.provider);
    stringBuilder.append(", token=");
    stringBuilder.append(this.token);
    stringBuilder.append(", params=");
    stringBuilder.append(this.params);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\payment\JsonInboundPaymentParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
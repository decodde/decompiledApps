package ng.com.fairmoney.android.loan.form.work.view;

import f.d.b.i.h;
import j.q.d.k;

public final class ProfessionalStatus {
  public final String description;
  
  public final int position;
  
  public final h professionalStatus;
  
  public ProfessionalStatus(h paramh, String paramString, int paramInt) {
    this.professionalStatus = paramh;
    this.description = paramString;
    this.position = paramInt;
  }
  
  public final h component1() {
    return this.professionalStatus;
  }
  
  public final String component2() {
    return this.description;
  }
  
  public final int component3() {
    return this.position;
  }
  
  public final ProfessionalStatus copy(h paramh, String paramString, int paramInt) {
    k.b(paramh, "professionalStatus");
    k.b(paramString, "description");
    return new ProfessionalStatus(paramh, paramString, paramInt);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof ProfessionalStatus) {
        paramObject = paramObject;
        if (k.a(this.professionalStatus, ((ProfessionalStatus)paramObject).professionalStatus) && k.a(this.description, ((ProfessionalStatus)paramObject).description) && this.position == ((ProfessionalStatus)paramObject).position)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getDescription() {
    return this.description;
  }
  
  public final int getPosition() {
    return this.position;
  }
  
  public final h getProfessionalStatus() {
    return this.professionalStatus;
  }
  
  public int hashCode() {
    byte b;
    h h1 = this.professionalStatus;
    int i = 0;
    if (h1 != null) {
      b = h1.hashCode();
    } else {
      b = 0;
    } 
    String str = this.description;
    if (str != null)
      i = str.hashCode(); 
    return (b * 31 + i) * 31 + this.position;
  }
  
  public String toString() {
    return this.description;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\view\ProfessionalStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
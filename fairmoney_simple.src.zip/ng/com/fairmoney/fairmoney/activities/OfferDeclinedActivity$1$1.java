package ng.com.fairmoney.fairmoney.activities;

import f.a.b.k;
import org.json.JSONObject;

public class null implements k.b<JSONObject> {
  public void onResponse(JSONObject paramJSONObject) {
    OfferDeclinedActivity.access$200(this.this$1.this$0);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\OfferDeclinedActivity$1$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.kyc;

import com.fairmoney.data.kyc.JsonKycStatus;
import f.d.b.h.b;
import j.q.d.k;

public final class JsonKycStatusMapper {
  public final b transform(JsonKycStatus paramJsonKycStatus) {
    k.b(paramJsonKycStatus, "jsonKycStatus");
    return new b(paramJsonKycStatus.isClaimed());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonKycStatusMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
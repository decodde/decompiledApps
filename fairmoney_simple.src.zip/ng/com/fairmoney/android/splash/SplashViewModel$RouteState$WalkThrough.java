package ng.com.fairmoney.android.splash;

public final class WalkThrough extends SplashViewModel.RouteState {
  public static final WalkThrough INSTANCE = new WalkThrough();
  
  public WalkThrough() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\splash\SplashViewModel$RouteState$WalkThrough.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
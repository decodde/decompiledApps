package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonDisbursementFee;
import f.d.b.i.a;
import j.q.d.k;

public final class JsonDisbursementFeeMapper {
  public final a transform(JsonDisbursementFee paramJsonDisbursementFee) {
    k.b(paramJsonDisbursementFee, "jsonDisbursementFee");
    return new a(paramJsonDisbursementFee.getName(), paramJsonDisbursementFee.getAmount(), paramJsonDisbursementFee.getTaxAmount(), paramJsonDisbursementFee.getTaxRate(), paramJsonDisbursementFee.getTaxName(), paramJsonDisbursementFee.getCurrencyCode());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonDisbursementFeeMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
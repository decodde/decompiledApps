package ng.com.fairmoney.android.loan.form.work.data;

import f.d.b.i.h;



/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\data\ProfessionalMapper$WhenMappings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
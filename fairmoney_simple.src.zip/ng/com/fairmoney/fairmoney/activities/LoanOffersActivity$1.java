package ng.com.fairmoney.fairmoney.activities;

import android.text.Editable;
import android.text.TextWatcher;

public class null implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    LoanOffersActivity.access$100(LoanOffersActivity.this);
    LoanOffersActivity.access$200(LoanOffersActivity.this);
    if (paramEditable.length() != 0)
      LoanOffersActivity.access$300(LoanOffersActivity.this, paramEditable.toString()); 
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOffersActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
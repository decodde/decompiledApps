package ng.com.fairmoney.android.loan.transfer;

import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class LoanTransferViewModel_Factory implements d<LoanTransferViewModel> {
  public final Provider<h> userUseCaseProvider;
  
  public LoanTransferViewModel_Factory(Provider<h> paramProvider) {
    this.userUseCaseProvider = paramProvider;
  }
  
  public static LoanTransferViewModel_Factory create(Provider<h> paramProvider) {
    return new LoanTransferViewModel_Factory(paramProvider);
  }
  
  public static LoanTransferViewModel newInstance(h paramh) {
    return new LoanTransferViewModel(paramh);
  }
  
  public LoanTransferViewModel get() {
    return newInstance((h)this.userUseCaseProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\transfer\LoanTransferViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
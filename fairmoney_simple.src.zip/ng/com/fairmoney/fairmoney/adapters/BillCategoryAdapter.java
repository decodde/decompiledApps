package ng.com.fairmoney.fairmoney.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import f.b.a.c;
import f.b.a.i;
import java.util.List;
import ng.com.fairmoney.fairmoney.models.BillCategory;

public class BillCategoryAdapter extends RecyclerView.g<RecyclerView.d0> {
  public List<BillCategory> categories;
  
  public Context context;
  
  public BillCategoryAdapter(Context paramContext, List<BillCategory> paramList) {
    this.context = paramContext;
    this.categories = paramList;
  }
  
  public int getItemCount() {
    return this.categories.size();
  }
  
  public void onBindViewHolder(RecyclerView.d0 paramd0, int paramInt) {
    Integer integer;
    BillCategory billCategory = this.categories.get(paramInt);
    BillCategoryViewHolder billCategoryViewHolder = (BillCategoryViewHolder)paramd0;
    paramInt = BillCategory.getIconIfAvailable(billCategory.getDisplayName());
    i i = c.e(this.context);
    if (paramInt == -1) {
      String str = billCategory.getImageUrl();
    } else {
      integer = Integer.valueOf(paramInt);
    } 
    i.a(integer).a(billCategoryViewHolder.ivBillCategory);
    billCategoryViewHolder.tvBillCategory.setText(billCategory.getDisplayName());
    if (billCategory.getDiscountMessage() != null && !billCategory.getDiscountMessage().isEmpty()) {
      billCategoryViewHolder.tvBillCategoryDiscount.setText(billCategory.getDiscountMessage());
      billCategoryViewHolder.tvBillCategoryDiscount.setVisibility(0);
    } else {
      billCategoryViewHolder.tvBillCategoryDiscount.setVisibility(4);
    } 
  }
  
  public RecyclerView.d0 onCreateViewHolder(ViewGroup paramViewGroup, int paramInt) {
    return new BillCategoryViewHolder(LayoutInflater.from(this.context).inflate(2131492999, paramViewGroup, false));
  }
  
  public static class BillCategoryViewHolder extends RecyclerView.d0 {
    public ImageView ivBillCategory;
    
    public TextView tvBillCategory;
    
    public TextView tvBillCategoryDiscount;
    
    public BillCategoryViewHolder(View param1View) {
      super(param1View);
      this.tvBillCategory = (TextView)param1View.findViewById(2131297067);
      this.ivBillCategory = (ImageView)param1View.findViewById(2131296614);
      this.tvBillCategoryDiscount = (TextView)param1View.findViewById(2131297068);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BillCategoryAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
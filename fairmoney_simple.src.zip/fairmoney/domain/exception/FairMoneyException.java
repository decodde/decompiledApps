package fairmoney.domain.exception;

import j.q.d.g;
import java.io.Serializable;

public abstract class FairMoneyException extends Exception implements Serializable {
  public FairMoneyException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\domain\exception\FairMoneyException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import i.a.b.b;
import i.a.b.e;
import org.json.JSONException;
import org.json.JSONObject;

public class null implements b.f {
  public void onInitFinished(JSONObject paramJSONObject, e parame) {
    if (parame == null)
      try {
        String str2 = paramJSONObject.getString("referral_code");
        if (str2 != null && !str2.isEmpty())
          SplashActivity.access$000(SplashActivity.this, str2); 
        String str1 = paramJSONObject.getString("referral_source");
        if (str1 != null && !str1.isEmpty())
          SplashActivity.access$100(SplashActivity.this, str1); 
      } catch (JSONException jSONException) {} 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\SplashActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class FinalLoanOfferActivity_MembersInjector implements a<FinalLoanOfferActivity> {
  public final Provider<y.b> factoryProvider;
  
  public FinalLoanOfferActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.factoryProvider = paramProvider;
  }
  
  public static a<FinalLoanOfferActivity> create(Provider<y.b> paramProvider) {
    return new FinalLoanOfferActivity_MembersInjector(paramProvider);
  }
  
  public static void injectFactory(FinalLoanOfferActivity paramFinalLoanOfferActivity, y.b paramb) {
    paramFinalLoanOfferActivity.factory = paramb;
  }
  
  public void injectMembers(FinalLoanOfferActivity paramFinalLoanOfferActivity) {
    injectFactory(paramFinalLoanOfferActivity, (y.b)this.factoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\FinalLoanOfferActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
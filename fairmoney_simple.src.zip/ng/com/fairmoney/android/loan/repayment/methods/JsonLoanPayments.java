package ng.com.fairmoney.android.loan.repayment.methods;

import com.google.gson.annotations.SerializedName;

public final class JsonLoanPayments {
  @SerializedName("payment_card_enabled")
  public final boolean paymentCardEnabled;
  
  @SerializedName("transfer_enabled")
  public final boolean transferEnabled;
  
  @SerializedName("ussd_enabled")
  public final boolean ussdEnabled;
  
  public JsonLoanPayments(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    this.ussdEnabled = paramBoolean1;
    this.transferEnabled = paramBoolean2;
    this.paymentCardEnabled = paramBoolean3;
  }
  
  public final boolean component1() {
    return this.ussdEnabled;
  }
  
  public final boolean component2() {
    return this.transferEnabled;
  }
  
  public final boolean component3() {
    return this.paymentCardEnabled;
  }
  
  public final JsonLoanPayments copy(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return new JsonLoanPayments(paramBoolean1, paramBoolean2, paramBoolean3);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof JsonLoanPayments) {
        paramObject = paramObject;
        if (this.ussdEnabled == ((JsonLoanPayments)paramObject).ussdEnabled && this.transferEnabled == ((JsonLoanPayments)paramObject).transferEnabled && this.paymentCardEnabled == ((JsonLoanPayments)paramObject).paymentCardEnabled)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final boolean getPaymentCardEnabled() {
    return this.paymentCardEnabled;
  }
  
  public final boolean getTransferEnabled() {
    return this.transferEnabled;
  }
  
  public final boolean getUssdEnabled() {
    return this.ussdEnabled;
  }
  
  public int hashCode() {
    boolean bool1 = this.ussdEnabled;
    boolean bool2 = true;
    boolean bool3 = bool1;
    if (bool1)
      bool3 = true; 
    boolean bool4 = this.transferEnabled;
    bool1 = bool4;
    if (bool4)
      bool1 = true; 
    bool4 = this.paymentCardEnabled;
    if (!bool4)
      bool2 = bool4; 
    return (bool3 * 31 + bool1) * 31 + bool2;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonLoanPayments(ussdEnabled=");
    stringBuilder.append(this.ussdEnabled);
    stringBuilder.append(", transferEnabled=");
    stringBuilder.append(this.transferEnabled);
    stringBuilder.append(", paymentCardEnabled=");
    stringBuilder.append(this.paymentCardEnabled);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\methods\JsonLoanPayments.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
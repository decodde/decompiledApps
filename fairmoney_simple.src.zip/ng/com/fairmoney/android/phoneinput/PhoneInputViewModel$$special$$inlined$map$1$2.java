package ng.com.fairmoney.android.phoneinput;

import f.d.b.k.f;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.b;

public final class null implements b<f> {
  public null(PhoneInputViewModel$$special$$inlined$map$1 paramPhoneInputViewModel$$special$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    paramObject = paramObject;
    PhoneInputViewModel.access$getErrorLiveData$p(this.this$0.this$0).b(new PhoneInputViewModel.PhoneInputState.InitValue((f)paramObject));
    paramObject = b1.emit(k.a, paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputViewModel$$special$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
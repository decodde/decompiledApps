package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import d.b.k.a;

public class LoanRepaidActivity extends BaseActivity {
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setActionBarTitle(getString(2131820597));
    findViewById(2131296393).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            LoanRepaidActivity.this.startActivity(new Intent((Context)LoanRepaidActivity.this, HomeActivity.class));
            LoanRepaidActivity.this.finish();
          }
        });
  }
  
  public int provideContentViewId() {
    return 2131492909;
  }
  
  public void setActionBarTitle(String paramString) {
    a a = getSupportActionBar();
    if (a != null)
      a.a(paramString); 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanRepaidActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
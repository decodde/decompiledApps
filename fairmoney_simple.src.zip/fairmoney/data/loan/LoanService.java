package fairmoney.data.loan;

import com.fairmoney.data.JsonRequest;
import com.fairmoney.data.loan.JsonBankInformation;
import com.fairmoney.data.loan.JsonLoanAgreementUrl;
import com.fairmoney.data.loan.JsonLoanOffer;
import com.fairmoney.data.loan.JsonUserId;
import j.k;
import java.util.List;
import k.a.h2.a;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface LoanService {
  @POST("/v2/android/bank_information")
  a<k> checkBankDetails(@Body JsonRequest<JsonBankInformation> paramJsonRequest);
  
  @POST("/v2/android/loan_agreement_url")
  a<JsonLoanAgreementUrl> getLoanAgreementUrl(@Body JsonRequest<JsonUserId> paramJsonRequest);
  
  @GET("/v2/android/loan_offers")
  a<List<JsonLoanOffer>> getLoanOffers(@Query("application_id") String paramString);
  
  @GET("/v2/android/selected_loan_offer")
  a<JsonLoanOffer> getSelectedLoanOffer(@Query("application_id") String paramString);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\LoanService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
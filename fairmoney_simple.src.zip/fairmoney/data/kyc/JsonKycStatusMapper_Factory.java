package fairmoney.data.kyc;

import com.fairmoney.data.kyc.JsonKycStatusMapper;
import g.b.d;

public final class JsonKycStatusMapper_Factory implements d<JsonKycStatusMapper> {
  public static com.fairmoney.data.kyc.JsonKycStatusMapper_Factory create() {
    return InstanceHolder.access$000();
  }
  
  public static JsonKycStatusMapper newInstance() {
    return new JsonKycStatusMapper();
  }
  
  public JsonKycStatusMapper get() {
    return newInstance();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonKycStatusMapper_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
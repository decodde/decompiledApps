package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.a.a.h.b;
import f.d.b.k.b;
import f.d.c.b;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import l.a.a.a.a.s.c;
import l.a.a.a.a.s.d;
import l.a.a.a.a.s.e;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;
import ng.com.fairmoney.fairmoney.activities.HomeActivity;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;
import ng.com.fairmoney.fairmoney.utils.DateUtils;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.utils.Utils;
import ng.com.fairmoney.fairmoney.views.RelativeRadioGroup;

public class FormPersonalActivity extends FormActivity implements b.c {
  public static final String SELECTED_VIEW_VALUE = "selected_view_value";
  
  public Calendar calendarBirthdate;
  
  public AppCompatAutoCompleteTextView cityAutocomplete;
  
  public EditText etBirthdate;
  
  public FormPersonalViewModel formPersonalViewModel;
  
  public PhoneInputView phoneInputView;
  
  public AppCompatAutoCompleteTextView stateAutocomplete;
  
  @Inject
  public y.b viewModelFactory;
  
  private void getBirthdate() {
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.GET_FOCUS, null, "et_form_birthdate"));
    b b1 = b.b(this, this.calendarBirthdate.get(1), this.calendarBirthdate.get(2), this.calendarBirthdate.get(5));
    b1.show(getFragmentManager(), "datePicker");
    b1.setCancelable(false);
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.RELEASE_FOCUS, null, "et_form_birthdate"));
  }
  
  private String getSelectedEducation() {
    RelativeRadioGroup relativeRadioGroup = (RelativeRadioGroup)findViewById(2131296854);
    try {
      return getResources().getResourceEntryName(relativeRadioGroup.getCheckedRadioButtonId());
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      return null;
    } 
  }
  
  private String getSelectedGender() {
    RelativeRadioGroup relativeRadioGroup = (RelativeRadioGroup)findViewById(2131296855);
    try {
      return getResources().getResourceEntryName(relativeRadioGroup.getCheckedRadioButtonId());
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      return null;
    } 
  }
  
  private String getSelectedMaritalStatus() {
    RelativeRadioGroup relativeRadioGroup = (RelativeRadioGroup)findViewById(2131296856);
    try {
      return getResources().getResourceEntryName(relativeRadioGroup.getCheckedRadioButtonId());
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      return null;
    } 
  }
  
  private void initCitySpinner() {
    List list = this.formPersonalViewModel.getCities();
    if (list.isEmpty()) {
      this.cityAutocomplete.setVisibility(8);
    } else {
      ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367049, list);
      this.cityAutocomplete.setAdapter((ListAdapter)arrayAdapter);
      this.cityAutocomplete.setThreshold(1);
    } 
  }
  
  private void initStateSpinner() {
    List list = this.formPersonalViewModel.getStates();
    if (list.isEmpty()) {
      this.stateAutocomplete.setVisibility(8);
    } else {
      ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367049, list);
      this.stateAutocomplete.setAdapter((ListAdapter)arrayAdapter);
      this.stateAutocomplete.setThreshold(1);
    } 
  }
  
  public List<Map<String, String>> getFormParameters() {
    List<Map<String, String>> list = Utils.getActivityConfigValue((Context)this, 2131755013);
    ((Map<String, String>)list.get(4)).put("selected_view_value", getSelectedGender());
    ((Map<String, String>)list.get(5)).put("selected_view_value", getSelectedMaritalStatus());
    ((Map<String, String>)list.get(6)).put("selected_view_value", getSelectedEducation());
    return list;
  }
  
  public void goToNextActivity() {
    this.formPersonalViewModel.goToNextActivity();
  }
  
  public void goToPreviousActivity() {
    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.START_APPLICATION_EVENT, null, FormPersonalActivity.class.getSimpleName()));
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplication()).inject(this);
    this.formPersonalViewModel = (FormPersonalViewModel)z.a((d)this, this.viewModelFactory).a(FormPersonalViewModel.class);
    fillFormWithPreviousResponses();
    this.calendarBirthdate = Calendar.getInstance();
    this.stateAutocomplete = (AppCompatAutoCompleteTextView)findViewById(2131296932);
    this.cityAutocomplete = (AppCompatAutoCompleteTextView)findViewById(2131296931);
    EditText editText = (EditText)findViewById(2131296532);
    this.etBirthdate = editText;
    editText.setCompoundDrawablesWithIntrinsicBounds(null, null, getResources().getDrawable(2131230977), null);
    this.etBirthdate.setOnClickListener((View.OnClickListener)new d(this));
    if (this.etBirthdate.getText().length() != 0) {
      String[] arrayOfString = this.etBirthdate.getText().toString().trim().split("/");
      this.calendarBirthdate.set(Integer.valueOf(arrayOfString[2]).intValue(), Integer.valueOf(arrayOfString[1]).intValue() - 1, Integer.valueOf(arrayOfString[0]).intValue());
    } 
    initStateSpinner();
    initCitySpinner();
    Tracking.sendUniqueEvent((Context)this, new Event("form", "contact"));
    this.phoneInputView = (PhoneInputView)getSupportFragmentManager().a(2131296804);
    this.formPersonalViewModel.getCountry().a((l)this, (s)new e(this));
    this.formPersonalViewModel.fetchCountry();
    this.phoneInputView.hideFlag();
    this.phoneInputView.setFocusTracking("phone");
    this.formPersonalViewModel.getFormPersonalState().a((l)this, (s)new c(this));
  }
  
  public void onDateSet(b paramb, int paramInt1, int paramInt2, int paramInt3) {
    this.calendarBirthdate.set(paramInt1, paramInt2, paramInt3);
    Calendar.getInstance().set(paramInt1 + 18, paramInt2, paramInt3);
    this.etBirthdate.setText(DateUtils.toFormDate(this.calendarBirthdate.getTime()));
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.RELEASE_FOCUS, null, "et_form_birthdate"));
  }
  
  public int provideContentViewId() {
    return 2131492903;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormPersonalActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
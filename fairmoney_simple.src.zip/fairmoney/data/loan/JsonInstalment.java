package fairmoney.data.loan;

import j.q.d.k;

public final class JsonInstalment {
  public final int amount;
  
  public final String currencyCode;
  
  public final String date;
  
  public JsonInstalment(String paramString1, String paramString2, int paramInt) {
    this.date = paramString1;
    this.currencyCode = paramString2;
    this.amount = paramInt;
  }
  
  public final String component1() {
    return this.date;
  }
  
  public final String component2() {
    return this.currencyCode;
  }
  
  public final int component3() {
    return this.amount;
  }
  
  public final com.fairmoney.data.loan.JsonInstalment copy(String paramString1, String paramString2, int paramInt) {
    k.b(paramString1, "date");
    k.b(paramString2, "currencyCode");
    return new com.fairmoney.data.loan.JsonInstalment(paramString1, paramString2, paramInt);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.loan.JsonInstalment) {
        paramObject = paramObject;
        if (k.a(this.date, ((com.fairmoney.data.loan.JsonInstalment)paramObject).date) && k.a(this.currencyCode, ((com.fairmoney.data.loan.JsonInstalment)paramObject).currencyCode) && this.amount == ((com.fairmoney.data.loan.JsonInstalment)paramObject).amount)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final int getAmount() {
    return this.amount;
  }
  
  public final String getCurrencyCode() {
    return this.currencyCode;
  }
  
  public final String getDate() {
    return this.date;
  }
  
  public int hashCode() {
    byte b;
    String str = this.date;
    int i = 0;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    str = this.currencyCode;
    if (str != null)
      i = str.hashCode(); 
    return (b * 31 + i) * 31 + this.amount;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonInstalment(date=");
    stringBuilder.append(this.date);
    stringBuilder.append(", currencyCode=");
    stringBuilder.append(this.currencyCode);
    stringBuilder.append(", amount=");
    stringBuilder.append(this.amount);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonInstalment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
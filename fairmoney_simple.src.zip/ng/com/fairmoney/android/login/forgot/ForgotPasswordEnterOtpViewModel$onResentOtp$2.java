package ng.com.fairmoney.android.login.forgot;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.q;
import j.q.d.k;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel$onResentOtp$2", f = "ForgotPasswordEnterOtpViewModel.kt", l = {}, m = "invokeSuspend")
public final class ForgotPasswordEnterOtpViewModel$onResentOtp$2 extends k implements q<b<? super ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success>, Throwable, d<? super k>, Object> {
  public int label;
  
  public b p$;
  
  public Throwable p$0;
  
  public ForgotPasswordEnterOtpViewModel$onResentOtp$2(d paramd) {
    super(3, paramd);
  }
  
  public final d<k> create(b<? super ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success> paramb, Throwable paramThrowable, d<? super k> paramd) {
    k.b(paramb, "$this$create");
    k.b(paramThrowable, "it");
    k.b(paramd, "continuation");
    ForgotPasswordEnterOtpViewModel$onResentOtp$2 forgotPasswordEnterOtpViewModel$onResentOtp$2 = new ForgotPasswordEnterOtpViewModel$onResentOtp$2(paramd);
    forgotPasswordEnterOtpViewModel$onResentOtp$2.p$ = paramb;
    forgotPasswordEnterOtpViewModel$onResentOtp$2.p$0 = paramThrowable;
    return (d<k>)forgotPasswordEnterOtpViewModel$onResentOtp$2;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2, Object paramObject3) {
    return ((ForgotPasswordEnterOtpViewModel$onResentOtp$2)create((b<? super ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success>)paramObject1, (Throwable)paramObject2, (d<? super k>)paramObject3)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      ForgotPasswordEnterOtpViewModel.access$getMutableForgotPassword$p(ForgotPasswordEnterOtpViewModel.this).b(new ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Error((Throwable)paramObject));
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordEnterOtpViewModel$onResentOtp$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
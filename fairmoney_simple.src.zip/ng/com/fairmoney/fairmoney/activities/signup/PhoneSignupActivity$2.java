package ng.com.fairmoney.fairmoney.activities.signup;

import android.content.Context;
import android.content.Intent;
import f.d.b.k.f;
import java.io.Serializable;
import ng.com.fairmoney.fairmoney.models.UssdCode;
import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<UssdCode> {
  public void failure(int paramInt, String paramString) {
    if (paramInt == 20) {
      PhoneSignupActivity.access$300(PhoneSignupActivity.this);
      PhoneSignupActivity.this.makeButtonEnabled(true);
      return;
    } 
    PhoneSignupActivity.this.showNewToastMessage(paramString, 0);
    PhoneSignupActivity.this.makeButtonEnabled(true);
  }
  
  public void success(UssdCode paramUssdCode) {
    Intent intent = new Intent((Context)PhoneSignupActivity.this, PhoneSignupEnterOtpActivity.class);
    intent.putExtra("EXTRA_PHONE_NUMBER", (Serializable)phoneNumber);
    intent.putExtra("EXTRA_PHONE_VERIFICATION", PhoneSignupActivity.access$200(PhoneSignupActivity.this));
    intent.putExtra("EXTRA_USSD_CODE", paramUssdCode.getUssdCode());
    PhoneSignupActivity.this.startActivity(intent);
    PhoneSignupActivity.this.finish();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
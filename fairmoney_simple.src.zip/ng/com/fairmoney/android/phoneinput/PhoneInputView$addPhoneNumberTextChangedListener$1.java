package ng.com.fairmoney.android.phoneinput;

import android.text.Editable;
import android.text.TextWatcher;

public final class PhoneInputView$addPhoneNumberTextChangedListener$1 implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    PhoneInputView.access$getPhoneInputViewModel$p(PhoneInputView.this).setPhoneNumbers(String.valueOf(paramEditable));
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputView$addPhoneNumberTextChangedListener$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
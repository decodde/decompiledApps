package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.cardview.widget.CardView;
import com.android.volley.VolleyError;
import com.google.firebase.analytics.FirebaseAnalytics;
import d.b.k.a;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.z;
import f.a.b.k;
import f.c.a.a;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.models.Feedback;
import ng.com.fairmoney.fairmoney.models.RejectionMessage;
import ng.com.fairmoney.fairmoney.network.BackendApi;
import ng.com.fairmoney.fairmoney.network.OnFailureListener;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.viewmodels.RejectionMessageViewModel;
import org.json.JSONObject;

public class LoanOfferRejectedReasonsActivity extends BaseActivity {
  public Button btSendFeedback;
  
  public CardView cvFeedback;
  
  public EditText etFeedback;
  
  public ProgressBar progressBar;
  
  public RejectionMessageViewModel rejectionMessageViewModel;
  
  public TextView tvFeedbackSent;
  
  public TextView tvRejectionMessage;
  
  private void initFeedbackView() {
    this.btSendFeedback = (Button)findViewById(2131296416);
    EditText editText = (EditText)findViewById(2131296528);
    this.etFeedback = editText;
    editText.addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            boolean bool;
            Button button = LoanOfferRejectedReasonsActivity.this.btSendFeedback;
            if (param1Editable.length() != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            button.setEnabled(bool);
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
    this.tvFeedbackSent = (TextView)findViewById(2131297118);
    this.btSendFeedback.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (LoanOfferRejectedReasonsActivity.this.etFeedback.getText().toString().isEmpty()) {
              LoanOfferRejectedReasonsActivity.this.etFeedback.setError(LoanOfferRejectedReasonsActivity.this.getString(2131820818));
              return;
            } 
            LoanOfferRejectedReasonsActivity.this.sendFeedback();
          }
        });
  }
  
  private void initToolbar() {
    a a = getSupportActionBar();
    if (a != null && a.k()) {
      a.c(2131820875);
      a.d(true);
      a.e(true);
      a.b(2131230914);
    } 
  }
  
  private void loadMessageFromApi() {
    this.rejectionMessageViewModel.getRejectionMessage((Context)this, new OnFailureListener() {
          public void onFailure(int param1Int, String param1String) {
            Toast.makeText((Context)LoanOfferRejectedReasonsActivity.this, param1String, 1).show();
            LoanOfferRejectedReasonsActivity.this.progressBar.setVisibility(8);
          }
        }).a((l)this, new s<RejectionMessage>() {
          public void onChanged(RejectionMessage param1RejectionMessage) {
            if (param1RejectionMessage != null) {
              LoanOfferRejectedReasonsActivity.this.tvRejectionMessage.setText((CharSequence)Html.fromHtml(param1RejectionMessage.getMessage()));
              LoanOfferRejectedReasonsActivity.this.progressBar.setVisibility(8);
            } 
          }
        });
  }
  
  private void sendFeedback() {
    FirebaseAnalytics.getInstance((Context)this).a("feedback_sent", null);
    this.btSendFeedback.setEnabled(false);
    Feedback feedback = new Feedback();
    feedback.setRejectedFeedback(this.etFeedback.getText().toString());
    FairMoney.getBackendApi((Context)this).sendRejectedLoanFeedback(new k.b<JSONObject>() {
          public void onResponse(JSONObject param1JSONObject) {
            LoanOfferRejectedReasonsActivity.this.cvFeedback.setVisibility(8);
            LoanOfferRejectedReasonsActivity.this.tvFeedbackSent.setVisibility(0);
            LoanOfferRejectedReasonsActivity.this.showNewToastMessage("Feedback sent", 0);
          }
        }new k.a() {
          public void onErrorResponse(VolleyError param1VolleyError) {
            BackendApi.checkServerError((Context)LoanOfferRejectedReasonsActivity.this, param1VolleyError);
            a.a((Throwable)param1VolleyError);
            LoanOfferRejectedReasonsActivity.this.cvFeedback.setVisibility(8);
            LoanOfferRejectedReasonsActivity.this.tvFeedbackSent.setVisibility(0);
            LoanOfferRejectedReasonsActivity.this.showNewToastMessage("Feedback sent", 0);
          }
        }feedback);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.rejectionMessageViewModel = (RejectionMessageViewModel)z.a((d)this).a(RejectionMessageViewModel.class);
    this.tvRejectionMessage = (TextView)findViewById(2131297170);
    this.cvFeedback = (CardView)findViewById(2131296462);
    this.progressBar = (ProgressBar)findViewById(2131296796);
    initFeedbackView();
    initToolbar();
    loadMessageFromApi();
    Tracking.sendUniqueEvent((Context)this, new Event("form", "loanRejected"));
  }
  
  public boolean onSupportNavigateUp() {
    finish();
    return true;
  }
  
  public int provideContentViewId() {
    return 2131492917;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOfferRejectedReasonsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
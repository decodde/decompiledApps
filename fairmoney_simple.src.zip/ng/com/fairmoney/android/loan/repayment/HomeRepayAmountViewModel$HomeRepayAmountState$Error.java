package ng.com.fairmoney.android.loan.repayment;

public final class Error extends HomeRepayAmountViewModel.HomeRepayAmountState {
  public final Throwable exception;
  
  public Error(int paramInt, Throwable paramThrowable) {
    super(paramInt, null);
    this.exception = paramThrowable;
  }
  
  public final Throwable getException() {
    return this.exception;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$HomeRepayAmountState$Error.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
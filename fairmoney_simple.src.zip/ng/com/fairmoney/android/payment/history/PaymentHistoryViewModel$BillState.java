package ng.com.fairmoney.android.payment.history;

import f.d.b.j.a;
import j.q.d.g;
import java.util.List;

public abstract class BillState {
  public BillState() {}
  
  public static final class Empty extends BillState {
    public static final Empty INSTANCE = new Empty();
    
    public Empty() {
      super(null);
    }
  }
  
  public static final class Error extends BillState {
    public final Throwable throwable;
    
    public Error(Throwable param2Throwable) {
      super(null);
      this.throwable = param2Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Loading extends BillState {
    public final boolean isLoading;
    
    public Loading(boolean param2Boolean) {
      super(null);
      this.isLoading = param2Boolean;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
  }
  
  public static final class Success extends BillState {
    public final List<a> bills;
    
    public Success(List<a> param2List) {
      super(null);
      this.bills = param2List;
    }
    
    public final List<a> getBills() {
      return this.bills;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel$BillState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
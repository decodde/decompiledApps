package ng.com.fairmoney.android.injection;

import f.d.c.b;
import f.d.c.c;
import f.d.c.j;
import j.q.d.k;

public final class ViewModelComponentKt {
  public static final ViewModelComponent create(b paramb) {
    k.b(paramb, "componentProvider");
    ViewModelComponent.Factory factory = DaggerViewModelComponent.factory();
    c c = paramb.getContextComponent();
    j j = paramb.getDomainComponent();
    return factory.create(c, paramb.getDataComponent(), j, paramb.getRoutingComponent());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\ViewModelComponentKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
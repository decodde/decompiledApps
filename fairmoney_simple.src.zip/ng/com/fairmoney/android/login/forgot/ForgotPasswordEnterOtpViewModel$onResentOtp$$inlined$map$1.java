package ng.com.fairmoney.android.login.forgot;

import f.d.b.k.f;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.a;
import k.a.h2.b;

public final class ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1 implements a<ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success> {
  public ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1(a parama, f paramf) {}
  
  public Object collect(b paramb, d paramd) {
    Object object = this.$this_unsafeTransform$inlined.collect(new b<String>(this) {
          public Object emit(Object param1Object, d param1d) {
            b b1 = this.$this_unsafeFlow$inlined;
            param1Object = param1Object;
            param1Object = b1.emit(new ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success(ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1.this.$phoneNumber$inlined, (String)param1Object), param1d);
            return (param1Object == c.a()) ? param1Object : k.a;
          }
        }paramd);
    return (object == c.a()) ? object : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
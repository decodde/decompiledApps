package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.fragment.app.Fragment;
import d.l.a.o;
import f.c.a.a;
import f.d.b.k.f;
import java.io.Serializable;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.fragments.form.BvnVerificationFragment;
import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class BvnVerificationActivity extends BaseActivity {
  public void onBackPressed() {
    startActivity(new Intent((Context)this, FormFinancialKycActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (getIntent() != null) {
      BankDetails bankDetails = (BankDetails)getIntent().getParcelableExtra("EXTRA_BANK_DETAILS");
      Bundle bundle = new Bundle();
      bundle.putParcelable("EXTRA_BANK_DETAILS", (Parcelable)bankDetails);
      bundle.putSerializable("EXTRA_PHONE_NUMBER", (Serializable)new f("+234", bankDetails.getBvnPhone()));
      BvnVerificationFragment bvnVerificationFragment = new BvnVerificationFragment();
      bvnVerificationFragment.setArguments(bundle);
      o o = getSupportFragmentManager().a();
      o.a(2131296583, (Fragment)bvnVerificationFragment);
      o.a();
    } else {
      a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)this, "Null intent in BvnVerificationActivity")));
    } 
  }
  
  public int provideContentViewId() {
    return 2131492920;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\BvnVerificationActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.login;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.k;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

@f(c = "ng.com.fairmoney.fairmoney.activities.login.LoginViewModel$fetchInAppMessage$3", f = "LoginViewModel.kt", l = {39}, m = "invokeSuspend")
public final class LoginViewModel$fetchInAppMessage$3 extends k implements p<LoginViewModel.InAppMessageState, d<? super k>, Object> {
  public Object L$0;
  
  public int label;
  
  public LoginViewModel.InAppMessageState p$0;
  
  public LoginViewModel$fetchInAppMessage$3(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    LoginViewModel$fetchInAppMessage$3 loginViewModel$fetchInAppMessage$3 = new LoginViewModel$fetchInAppMessage$3(paramd);
    loginViewModel$fetchInAppMessage$3.p$0 = (LoginViewModel.InAppMessageState)paramObject;
    return (d<k>)loginViewModel$fetchInAppMessage$3;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((LoginViewModel$fetchInAppMessage$3)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    Object object = c.a();
    int i = this.label;
    if (i != 0) {
      if (i == 1) {
        object = this.L$0;
        g.a(paramObject);
      } else {
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
    } else {
      g.a(paramObject);
      paramObject = this.p$0;
      LoginViewModel.access$getMessageMutableLiveData$p(LoginViewModel.this).b(paramObject);
      if (paramObject instanceof LoginViewModel.InAppMessageState.Success) {
        a a = c.a(LoginViewModel.access$getInAppMessagingUseCase$p(LoginViewModel.this).a(((LoginViewModel.InAppMessageState.Success)paramObject).getInAppMessage().b()), new q<b<? super Boolean>, Throwable, d<? super k>, Object>(null) {
              public int label;
              
              public b p$;
              
              public Throwable p$0;
              
              public final d<k> create(b<? super Boolean> param1b, Throwable param1Throwable, d<? super k> param1d) {
                k.b(param1b, "$this$create");
                k.b(param1Throwable, "it");
                k.b(param1d, "continuation");
                q<b<? super Boolean>, Throwable, d<? super k>, Object> q1 = new q<b<? super Boolean>, Throwable, d<? super k>, Object>(param1d);
                q1.p$ = param1b;
                q1.p$0 = param1Throwable;
                return (d)q1;
              }
              
              public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                return ((null)create((b<? super Boolean>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
              }
              
              public final Object invokeSuspend(Object param1Object) {
                c.a();
                if (this.label == 0) {
                  g.a(param1Object);
                  return k.a;
                } 
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              }
            });
        this.L$0 = paramObject;
        this.label = 1;
        if (c.a(a, (d)this) == object)
          return object; 
      } 
    } 
    return k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel$fetchInAppMessage$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.login;

import j.k;
import j.n.d;
import k.a.h2.b;

public final class LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 implements b<k> {
  public Object emit(Object paramObject, d paramd) {
    paramObject = paramObject;
    return k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
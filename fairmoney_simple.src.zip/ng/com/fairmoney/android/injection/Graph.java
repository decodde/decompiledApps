package ng.com.fairmoney.android.injection;

import android.app.Application;
import android.content.Context;
import f.d.a.i;
import f.d.a.k;
import f.d.a.l;
import f.d.a.m;
import f.d.a.p.i;
import f.d.a.t.e;
import f.d.b.a;
import f.d.b.b;
import f.d.b.c;
import f.d.b.g.a;
import f.d.b.k.c;
import f.d.b.k.e;
import f.d.c.a;
import f.d.c.c;
import f.d.c.d;
import f.d.c.e;
import f.d.c.f;
import f.d.c.g;
import f.d.c.h;
import f.d.c.i;
import f.d.c.j;
import f.d.c.k;
import j.q.d.k;
import ng.com.fairmoney.android.applicationconfiguration.ApplicationConfigurationImpl;
import ng.com.fairmoney.android.inversion.CurrentActivityProvider;
import ng.com.fairmoney.android.inversion.CurrentActivityProviderImpl;
import ng.com.fairmoney.android.inversion.NetworkCountryProviderImpl;
import ng.com.fairmoney.android.inversion.RouterImpl;
import ng.com.fairmoney.android.inversion.StringProviderImpl;
import ng.com.fairmoney.android.inversion.TokenProviderImpl;
import ng.com.fairmoney.android.inversion.VersioningProviderImpl;
import ng.com.fairmoney.android.user.data.UserLegacyImpl;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.fragments.home.summary.dashboard.LocalStorageImpl;

public final class Graph {
  public final a apiComponent;
  
  public final c contextComponent;
  
  public final i dataComponent;
  
  public final j domainComponent;
  
  public final k routingComponent;
  
  public Graph(Application paramApplication) {
    this.contextComponent = e.b().a(paramApplication);
    this.routingComponent = h.b().a((c)new RouterImpl((Context)paramApplication, (CurrentActivityProvider)new CurrentActivityProviderImpl(paramApplication)));
    this.apiComponent = d.f().a(new i((m)new VersioningProviderImpl((Context)paramApplication), (l)new TokenProviderImpl((Context)paramApplication)), this.routingComponent, (k)new StringProviderImpl((Context)paramApplication));
    i.a a1 = f.j();
    UserLegacyImpl userLegacyImpl = new UserLegacyImpl((Context)paramApplication);
    a a2 = FairMoney.getFeatures();
    k.a(a2, "FairMoney.getFeatures()");
    this.dataComponent = a1.a((e)userLegacyImpl, a2, (i)new LocalStorageImpl((Context)paramApplication), new b(new c()), (m)new VersioningProviderImpl((Context)paramApplication), this.apiComponent);
    this.domainComponent = g.h().a(this.dataComponent, (e)new NetworkCountryProviderImpl((Context)paramApplication), (a)new ApplicationConfigurationImpl());
  }
  
  public final c getContextComponent() {
    return this.contextComponent;
  }
  
  public final i getDataComponent() {
    return this.dataComponent;
  }
  
  public final j getDomainComponent() {
    return this.domainComponent;
  }
  
  public final k getRoutingComponent() {
    return this.routingComponent;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\Graph.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
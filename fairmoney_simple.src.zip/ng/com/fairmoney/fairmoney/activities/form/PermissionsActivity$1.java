package ng.com.fairmoney.fairmoney.activities.form;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import d.i.e.a;

public class null implements DialogInterface.OnClickListener {
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    PermissionsActivity.access$000(PermissionsActivity.this);
    if (action.equals("requestPermissions")) {
      a.a((Activity)PermissionsActivity.this, PermissionsActivity.access$100(), 100);
    } else if (action.equals("goToSettings")) {
      Toast.makeText(PermissionsActivity.this.getBaseContext(), PermissionsActivity.this.getString(2131820838), 1).show();
      Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
      intent.setData(Uri.fromParts("package", PermissionsActivity.this.getPackageName(), null));
      PermissionsActivity.this.startActivityForResult(intent, 101);
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\PermissionsActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
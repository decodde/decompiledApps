package ng.com.fairmoney.fairmoney.activities;

import f.c.a.a;
import f.h.a.a.m.c;
import f.h.a.a.m.g;
import f.h.c.h.a;

public class null implements c<a> {
  public void onComplete(g<a> paramg) {
    if (!paramg.e()) {
      a.a(new Exception(paramg.a()));
      return;
    } 
    String str = null;
    if (paramg.b() != null)
      str = ((a)paramg.b()).getToken(); 
    if (str != null)
      SplashActivity.access$300(SplashActivity.this, str); 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\SplashActivity$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
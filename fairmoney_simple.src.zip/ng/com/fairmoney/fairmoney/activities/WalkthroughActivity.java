package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import d.c0.a.a;
import d.l.a.i;
import d.l.a.m;
import ng.com.fairmoney.fairmoney.activities.signup.PhoneSignupActivity;
import ng.com.fairmoney.fairmoney.fragments.walkthrough.WalkthroughStep1Fragment;
import ng.com.fairmoney.fairmoney.fragments.walkthrough.WalkthroughStep2Fragment;
import ng.com.fairmoney.fairmoney.fragments.walkthrough.WalkthroughStep3Fragment;

public class WalkthroughActivity extends BaseActivity {
  private void saveViewDisplayed() {
    getSharedPreferences("CurrentUser", 0).edit().putBoolean("walkthoughDisplayed", true).apply();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.isAuthMandatory = false;
    ((ViewPager)findViewById(2131297239)).setAdapter((a)new WalkThroughViewPagerAdapter(getSupportFragmentManager()));
    ((Button)findViewById(2131296427)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            WalkthroughActivity.this.startActivity(new Intent((Context)WalkthroughActivity.this, PhoneSignupActivity.class));
            WalkthroughActivity.this.finish();
          }
        });
    ((Button)findViewById(2131296428)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            WalkthroughActivity.this.startActivity(new Intent((Context)WalkthroughActivity.this, WelcomeActivity.class));
            WalkthroughActivity.this.finish();
          }
        });
    saveViewDisplayed();
  }
  
  public int provideContentViewId() {
    return 2131492922;
  }
  
  public static class WalkThroughViewPagerAdapter extends m {
    public WalkThroughViewPagerAdapter(i param1i) {
      super(param1i, 1);
    }
    
    public int getCount() {
      return 3;
    }
    
    public Fragment getItem(int param1Int) {
      return (Fragment)((param1Int != 1) ? ((param1Int != 2) ? WalkthroughStep1Fragment.newInstance() : WalkthroughStep3Fragment.newInstance()) : WalkthroughStep2Fragment.newInstance());
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\WalkthroughActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.inversion;

import android.content.Context;
import g.b.d;
import javax.inject.Provider;

public final class VersioningProviderImpl_Factory implements d<VersioningProviderImpl> {
  public final Provider<Context> contextProvider;
  
  public VersioningProviderImpl_Factory(Provider<Context> paramProvider) {
    this.contextProvider = paramProvider;
  }
  
  public static VersioningProviderImpl_Factory create(Provider<Context> paramProvider) {
    return new VersioningProviderImpl_Factory(paramProvider);
  }
  
  public static VersioningProviderImpl newInstance(Context paramContext) {
    return new VersioningProviderImpl(paramContext);
  }
  
  public VersioningProviderImpl get() {
    return newInstance((Context)this.contextProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\VersioningProviderImpl_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
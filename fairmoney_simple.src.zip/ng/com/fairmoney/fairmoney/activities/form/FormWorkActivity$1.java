package ng.com.fairmoney.fairmoney.activities.form;

import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;
import ng.com.fairmoney.fairmoney.views.RelativeRadioGroup;

public class null implements RelativeRadioGroup.OnCheckedChangeListener {
  public void onCheckedChanged(RelativeRadioGroup paramRelativeRadioGroup, int paramInt) {
    if (paramInt == 2131296833) {
      tilCacNumber.setVisibility(0);
      tvCacNumberExplanations.setVisibility(0);
    } else {
      tilCacNumber.setVisibility(8);
      tvCacNumberExplanations.setVisibility(8);
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormWorkActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
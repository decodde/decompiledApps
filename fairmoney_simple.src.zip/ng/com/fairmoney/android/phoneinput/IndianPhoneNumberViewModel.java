package ng.com.fairmoney.android.phoneinput;

import f.d.b.k.b;
import j.e;
import j.i;
import j.q.d.g;
import j.q.d.k;
import j.v.d;
import j.v.m;
import kotlin.TypeCastException;

public final class IndianPhoneNumberViewModel {
  public static final Companion Companion = new Companion(null);
  
  public static int maxLength = 15;
  
  private final int getFirstSeparatorPosition(String paramString) {
    byte b;
    if (m.a(paramString, b.a.h.e(), false, 2, null)) {
      b = 9;
    } else {
      b = 5;
    } 
    return b;
  }
  
  private final e<String, Integer> transformFirstSet(String paramString, int paramInt1, int paramInt2) {
    String str = paramString;
    int i = paramInt1;
    if (paramString.length() > 4) {
      StringBuilder stringBuilder = new StringBuilder();
      if (paramString != null) {
        String str1 = paramString.substring(0, paramInt2);
        k.a(str1, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        stringBuilder.append(str1);
        stringBuilder.append(' ');
        if (paramString != null) {
          paramString = paramString.substring(paramInt2);
          k.a(paramString, "(this as java.lang.String).substring(startIndex)");
          stringBuilder.append(paramString);
          paramString = stringBuilder.toString();
          str = paramString;
          i = paramInt1;
          if (paramInt1 >= paramInt2) {
            i = paramInt1 + 1;
            str = paramString;
          } 
        } else {
          throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        } 
      } else {
        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
      } 
    } 
    return i.a(str, Integer.valueOf(i));
  }
  
  private final e<String, Integer> transformIndicator(String paramString, int paramInt) {
    String str = paramString;
    int i = paramInt;
    if (m.a(paramString, b.a.h.e(), false, 2, null)) {
      StringBuilder stringBuilder = new StringBuilder();
      if (paramString != null) {
        String str1 = paramString.substring(0, 3);
        k.a(str1, "(this as java.lang.Strin…ing(startIndex, endIndex)");
        stringBuilder.append(str1);
        stringBuilder.append(" ");
        if (paramString != null) {
          paramString = paramString.substring(3);
          k.a(paramString, "(this as java.lang.String).substring(startIndex)");
          stringBuilder.append(paramString);
          paramString = stringBuilder.toString();
          str = paramString;
          i = paramInt;
          if (paramInt >= 3) {
            i = paramInt + 1;
            str = paramString;
          } 
        } else {
          throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        } 
      } else {
        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
      } 
    } 
    return i.a(str, Integer.valueOf(i));
  }
  
  public final int getMaxLength(String paramString) {
    k.b(paramString, "phoneNumber");
    String str = b.a.h.e();
    byte b1 = 0;
    boolean bool = m.a(paramString, str, false, 2, null);
    byte b2 = 15;
    if (bool) {
      b1 = b2;
    } else {
      if (paramString.length() == 0)
        b1 = 1; 
      if (b1 != 0) {
        b1 = b2;
      } else {
        b1 = 11;
      } 
    } 
    maxLength = b1;
    return b1;
  }
  
  public final EditedPhoneNumber transformText(e<String, Integer> parame) {
    k.b(parame, "inputPair");
    CharSequence charSequence2 = (CharSequence)parame.c();
    charSequence2 = (new d("[()\\- /.]")).a(charSequence2, "");
    int i = ((Number)parame.d()).intValue();
    int j = i;
    if (i < 0)
      j = 0; 
    CharSequence charSequence1 = charSequence2;
    if (charSequence2.length() > getMaxLength((String)charSequence2) - 1) {
      i = maxLength;
      if (charSequence2 != null) {
        charSequence1 = charSequence2.substring(0, i - 1);
        k.a(charSequence1, "(this as java.lang.Strin…ing(startIndex, endIndex)");
      } else {
        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
      } 
    } 
    i = j;
    if (j > charSequence1.length())
      i = charSequence1.length(); 
    e<String, Integer> e1 = transformIndicator((String)charSequence1, i);
    e<String, Integer> e2 = transformFirstSet((String)e1.c(), ((Number)e1.d()).intValue(), getFirstSeparatorPosition((String)e1.c()));
    e1 = e2;
    if (((Number)e2.d()).intValue() > ((String)e2.c()).length())
      e1 = i.a(e2.c(), Integer.valueOf(((String)e2.c()).length())); 
    return new EditedPhoneNumber((String)e1.c(), ((Number)e1.d()).intValue(), maxLength);
  }
  
  public static final class Companion {
    public Companion() {}
    
    public final int getMaxLength() {
      return IndianPhoneNumberViewModel.maxLength;
    }
    
    public final void setMaxLength(int param1Int) {
      IndianPhoneNumberViewModel.maxLength = param1Int;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\IndianPhoneNumberViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
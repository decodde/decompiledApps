package ng.com.fairmoney.fairmoney.activities.form;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class PermissionsActivity_MembersInjector implements a<PermissionsActivity> {
  public final Provider<y.b> factoryProvider;
  
  public PermissionsActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.factoryProvider = paramProvider;
  }
  
  public static a<PermissionsActivity> create(Provider<y.b> paramProvider) {
    return new PermissionsActivity_MembersInjector(paramProvider);
  }
  
  public static void injectFactory(PermissionsActivity paramPermissionsActivity, y.b paramb) {
    paramPermissionsActivity.factory = paramb;
  }
  
  public void injectMembers(PermissionsActivity paramPermissionsActivity) {
    injectFactory(paramPermissionsActivity, (y.b)this.factoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\PermissionsActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
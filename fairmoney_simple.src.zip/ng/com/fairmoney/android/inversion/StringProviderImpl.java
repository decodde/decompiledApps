package ng.com.fairmoney.android.inversion;

import android.content.Context;
import f.d.a.j;
import f.d.a.k;
import j.e;
import j.i;
import j.l.y;
import j.q.d.k;
import java.util.Map;
import javax.inject.Inject;

public final class StringProviderImpl implements k {
  public final Context context;
  
  public final Map<j, Integer> map;
  
  @Inject
  public StringProviderImpl(Context paramContext) {
    this.context = paramContext;
    this.map = y.a(new e[] { i.a(j.STRING_4xx_ERROR, Integer.valueOf(2131820777)), i.a(j.STRING_403_ERROR, Integer.valueOf(2131821219)), i.a(j.STRING_500_ERROR, Integer.valueOf(2131820779)), i.a(j.STRING_502_ERROR, Integer.valueOf(2131820781)), i.a(j.STRING_SERVER_ERROR, Integer.valueOf(2131821220)) });
  }
  
  public String get(j paramj) {
    k.b(paramj, "stringKey");
    String str = this.context.getString(((Number)y.b(this.map, paramj)).intValue());
    k.a(str, "context.getString(map.getValue(stringKey))");
    return str;
  }
  
  public final Map<j, Integer> getMap() {
    return this.map;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\StringProviderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
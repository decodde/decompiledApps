package ng.com.fairmoney.android.loan.bankdetails;

import android.view.View;

public final class BankDetailsActivity$onCreate$3 implements View.OnClickListener {
  public final void onClick(View paramView) {
    BankDetailsActivity.access$getViewModel$p(BankDetailsActivity.this).onClickFindIfsc();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsActivity$onCreate$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
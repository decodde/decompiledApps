package ng.com.fairmoney.android.loan.bankdetails;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.q;
import j.q.d.k;
import java.util.ArrayList;
import java.util.List;

@f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$1", f = "BankDetailsViewModel.kt", l = {}, m = "invokeSuspend")
public final class BankDetailsViewModel$onClickNext$1 extends k implements q<Boolean, Boolean, d<? super BankDetailsViewModel.BankDetailsState>, Object> {
  public int label;
  
  public boolean p$0;
  
  public boolean p$1;
  
  public BankDetailsViewModel$onClickNext$1(d paramd) {
    super(3, paramd);
  }
  
  public final d<k> create(boolean paramBoolean1, boolean paramBoolean2, d<? super BankDetailsViewModel.BankDetailsState> paramd) {
    k.b(paramd, "continuation");
    BankDetailsViewModel$onClickNext$1 bankDetailsViewModel$onClickNext$1 = new BankDetailsViewModel$onClickNext$1(paramd);
    bankDetailsViewModel$onClickNext$1.p$0 = paramBoolean1;
    bankDetailsViewModel$onClickNext$1.p$1 = paramBoolean2;
    return (d<k>)bankDetailsViewModel$onClickNext$1;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2, Object paramObject3) {
    return ((BankDetailsViewModel$onClickNext$1)create(((Boolean)paramObject1).booleanValue(), ((Boolean)paramObject2).booleanValue(), (d<? super BankDetailsViewModel.BankDetailsState>)paramObject3)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      boolean bool1 = this.p$0;
      boolean bool2 = this.p$1;
      if (bool1 && bool2) {
        paramObject = BankDetailsViewModel.BankDetailsState.Success.INSTANCE;
      } else {
        paramObject = new ArrayList();
        if (!bool1)
          paramObject.add(BankDetailsViewModel.BankDetailsStateError.IfscError.INSTANCE); 
        if (!bool2)
          paramObject.add(BankDetailsViewModel.BankDetailsStateError.BankAccountError.INSTANCE); 
        paramObject = new BankDetailsViewModel.BankDetailsState.InputErrors((List<? extends BankDetailsViewModel.BankDetailsStateError>)paramObject);
      } 
      return paramObject;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$onClickNext$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.adapters;

import android.text.Editable;
import android.text.TextWatcher;

public class null implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield this$0 : Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;
    //   4: invokestatic access$200 : (Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;)Lng/com/fairmoney/fairmoney/fragments/home/BillMakePaymentFragment$OnViewFilledListener;
    //   7: astore_2
    //   8: aload_1
    //   9: invokeinterface length : ()I
    //   14: ifeq -> 38
    //   17: aload_0
    //   18: getfield this$0 : Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;
    //   21: astore_1
    //   22: aload_1
    //   23: aload_1
    //   24: invokestatic access$000 : (Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;)Ljava/util/List;
    //   27: invokestatic access$100 : (Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;Ljava/util/List;)Z
    //   30: ifeq -> 38
    //   33: iconst_1
    //   34: istore_3
    //   35: goto -> 40
    //   38: iconst_0
    //   39: istore_3
    //   40: aload_2
    //   41: iload_3
    //   42: invokeinterface onViewFullyFilled : (Z)V
    //   47: return
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BillDynamicFieldsAdapter$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
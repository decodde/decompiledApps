package ng.com.fairmoney.android.injection;

import f.d.b.f.b;
import f.d.c.j;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DomainComponent_inAppMessagingUseCase implements Provider<b> {
  public final j domainComponent;
  
  public com_fairmoney_injection_DomainComponent_inAppMessagingUseCase(j paramj) {
    this.domainComponent = paramj;
  }
  
  public b get() {
    b b = this.domainComponent.d();
    g.a(b, "Cannot return null from a non-@Nullable component method");
    return b;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DomainComponent_inAppMessagingUseCase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.form.work.view;

import android.app.Application;
import f.d.b.i.h;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.NoWhenBranchMatchedException;

public final class ProfessionalMapper {
  public final Application context;
  
  @Inject
  public ProfessionalMapper(Application paramApplication) {
    this.context = paramApplication;
  }
  
  public final ProfessionalStatus transform(h paramh, int paramInt) {
    k.b(paramh, "professionalStatus");
    switch (ProfessionalMapper$WhenMappings.$EnumSwitchMapping$0[paramh.ordinal()]) {
      default:
        throw new NoWhenBranchMatchedException();
      case 7:
        str = this.context.getString(2131821019);
        k.a(str, "context.getString(R.string.nysc)");
        return new ProfessionalStatus(paramh, str, paramInt);
      case 6:
        str = this.context.getString(2131821133);
        k.a(str, "context.getString(R.string.retired)");
        return new ProfessionalStatus(paramh, str, paramInt);
      case 5:
        str = this.context.getString(2131821218);
        k.a(str, "context.getString(R.string.unemployed)");
        return new ProfessionalStatus(paramh, str, paramInt);
      case 4:
        str = this.context.getString(2131821174);
        k.a(str, "context.getString(R.string.student)");
        return new ProfessionalStatus(paramh, str, paramInt);
      case 3:
        str = this.context.getString(2131821107);
        k.a(str, "context.getString(R.string.public_servant)");
        return new ProfessionalStatus(paramh, str, paramInt);
      case 2:
        str = this.context.getString(2131821086);
        k.a(str, "context.getString(R.string.private_sector)");
        return new ProfessionalStatus(paramh, str, paramInt);
      case 1:
        break;
    } 
    String str = this.context.getString(2131821151);
    k.a(str, "context.getString(R.string.self_employed)");
    return new ProfessionalStatus(paramh, str, paramInt);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\view\ProfessionalMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
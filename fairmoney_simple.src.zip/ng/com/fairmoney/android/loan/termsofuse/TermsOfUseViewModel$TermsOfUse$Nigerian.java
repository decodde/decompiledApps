package ng.com.fairmoney.android.loan.termsofuse;

import j.i;

public final class Nigerian extends TermsOfUseViewModel.TermsOfUse {
  public Nigerian(String paramString) {
    super(str1, true, true, i.a(str2, stringBuilder2.toString()), i.a("10%", "40%"), i.a("1%", "30%"), "https://fairmoney.ng/terms-of-use/", " ", "https://fairmoney.ng/privacy-policy/", false, false, null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$TermsOfUse$Nigerian.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.login.forgot;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.k.f;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class ForgotPasswordEnterOtpViewModel extends w {
  public final LiveData<EnterOtpViewModelState> forgotPassword;
  
  public final r<EnterOtpViewModelState> mutableForgotPassword;
  
  public final h userUseCase;
  
  @Inject
  public ForgotPasswordEnterOtpViewModel(h paramh) {
    this.userUseCase = paramh;
    r<EnterOtpViewModelState> r1 = new r();
    this.mutableForgotPassword = r1;
    this.forgotPassword = (LiveData<EnterOtpViewModelState>)r1;
  }
  
  public final LiveData<EnterOtpViewModelState> getForgotPassword() {
    return this.forgotPassword;
  }
  
  public final void onResentOtp(f paramf) {
    k.b(paramf, "phoneNumber");
    c.a(c.a(c.b(c.b(c.a(new ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1(this.userUseCase.a(paramf), paramf), new ForgotPasswordEnterOtpViewModel$onResentOtp$2(null)), new ForgotPasswordEnterOtpViewModel$onResentOtp$3(null)), new ForgotPasswordEnterOtpViewModel$onResentOtp$4(null)), new ForgotPasswordEnterOtpViewModel$onResentOtp$5(null)), x.a(this));
  }
  
  public static abstract class EnterOtpViewModelState {
    public EnterOtpViewModelState() {}
    
    public static final class Error extends EnterOtpViewModelState {
      public final Throwable throwable;
      
      public Error(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Loading extends EnterOtpViewModelState {
      public final boolean isLoading;
      
      public Loading(boolean param2Boolean) {
        super(null);
        this.isLoading = param2Boolean;
      }
      
      public final boolean isLoading() {
        return this.isLoading;
      }
    }
    
    public static final class Success extends EnterOtpViewModelState {
      public final f phoneNumber;
      
      public final String ussdCode;
      
      public Success(f param2f, String param2String) {
        super(null);
        this.phoneNumber = param2f;
        this.ussdCode = param2String;
      }
      
      public final f getPhoneNumber() {
        return this.phoneNumber;
      }
      
      public final String getUssdCode() {
        return this.ussdCode;
      }
    }
  }
  
  public static final class Error extends EnterOtpViewModelState {
    public final Throwable throwable;
    
    public Error(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Loading extends EnterOtpViewModelState {
    public final boolean isLoading;
    
    public Loading(boolean param1Boolean) {
      super(null);
      this.isLoading = param1Boolean;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
  }
  
  public static final class Success extends EnterOtpViewModelState {
    public final f phoneNumber;
    
    public final String ussdCode;
    
    public Success(f param1f, String param1String) {
      super(null);
      this.phoneNumber = param1f;
      this.ussdCode = param1String;
    }
    
    public final f getPhoneNumber() {
      return this.phoneNumber;
    }
    
    public final String getUssdCode() {
      return this.ussdCode;
    }
  }
  
  public static final class ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1 implements a<EnterOtpViewModelState.Success> {
    public ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1(a param1a, f param1f) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<String>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              param1Object = b1.emit(new ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success(ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1.this.$phoneNumber$inlined, (String)param1Object), param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<String> {
    public null(ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1 param1ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      param1Object = b1.emit(new ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success(ForgotPasswordEnterOtpViewModel$onResentOtp$$inlined$map$1.this.$phoneNumber$inlined, (String)param1Object), param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel$onResentOtp$2", f = "ForgotPasswordEnterOtpViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordEnterOtpViewModel$onResentOtp$2 extends k implements q<b<? super EnterOtpViewModelState.Success>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public ForgotPasswordEnterOtpViewModel$onResentOtp$2(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      ForgotPasswordEnterOtpViewModel$onResentOtp$2 forgotPasswordEnterOtpViewModel$onResentOtp$2 = new ForgotPasswordEnterOtpViewModel$onResentOtp$2(param1d);
      forgotPasswordEnterOtpViewModel$onResentOtp$2.p$ = param1b;
      forgotPasswordEnterOtpViewModel$onResentOtp$2.p$0 = param1Throwable;
      return (d<k>)forgotPasswordEnterOtpViewModel$onResentOtp$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((ForgotPasswordEnterOtpViewModel$onResentOtp$2)create((b<? super ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        ForgotPasswordEnterOtpViewModel.this.mutableForgotPassword.b(new ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Error((Throwable)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel$onResentOtp$3", f = "ForgotPasswordEnterOtpViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordEnterOtpViewModel$onResentOtp$3 extends k implements p<b<? super EnterOtpViewModelState.Success>, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public ForgotPasswordEnterOtpViewModel$onResentOtp$3(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      ForgotPasswordEnterOtpViewModel$onResentOtp$3 forgotPasswordEnterOtpViewModel$onResentOtp$3 = new ForgotPasswordEnterOtpViewModel$onResentOtp$3(param1d);
      forgotPasswordEnterOtpViewModel$onResentOtp$3.p$ = (b)param1Object;
      return (d<k>)forgotPasswordEnterOtpViewModel$onResentOtp$3;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((ForgotPasswordEnterOtpViewModel$onResentOtp$3)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        ForgotPasswordEnterOtpViewModel.this.mutableForgotPassword.b(new ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Loading(true));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel$onResentOtp$4", f = "ForgotPasswordEnterOtpViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordEnterOtpViewModel$onResentOtp$4 extends k implements q<b<? super EnterOtpViewModelState.Success>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public ForgotPasswordEnterOtpViewModel$onResentOtp$4(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1d, "continuation");
      ForgotPasswordEnterOtpViewModel$onResentOtp$4 forgotPasswordEnterOtpViewModel$onResentOtp$4 = new ForgotPasswordEnterOtpViewModel$onResentOtp$4(param1d);
      forgotPasswordEnterOtpViewModel$onResentOtp$4.p$ = param1b;
      forgotPasswordEnterOtpViewModel$onResentOtp$4.p$0 = param1Throwable;
      return (d<k>)forgotPasswordEnterOtpViewModel$onResentOtp$4;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((ForgotPasswordEnterOtpViewModel$onResentOtp$4)create((b<? super ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        ForgotPasswordEnterOtpViewModel.this.mutableForgotPassword.b(new ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Loading(false));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel$onResentOtp$5", f = "ForgotPasswordEnterOtpViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class ForgotPasswordEnterOtpViewModel$onResentOtp$5 extends k implements p<EnterOtpViewModelState.Success, d<? super k>, Object> {
    public int label;
    
    public ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success p$0;
    
    public ForgotPasswordEnterOtpViewModel$onResentOtp$5(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      ForgotPasswordEnterOtpViewModel$onResentOtp$5 forgotPasswordEnterOtpViewModel$onResentOtp$5 = new ForgotPasswordEnterOtpViewModel$onResentOtp$5(param1d);
      forgotPasswordEnterOtpViewModel$onResentOtp$5.p$0 = (ForgotPasswordEnterOtpViewModel.EnterOtpViewModelState.Success)param1Object;
      return (d<k>)forgotPasswordEnterOtpViewModel$onResentOtp$5;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((ForgotPasswordEnterOtpViewModel$onResentOtp$5)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        ForgotPasswordEnterOtpViewModel.this.mutableForgotPassword.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordEnterOtpViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
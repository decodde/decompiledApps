package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import f.c.a.a;
import ng.com.fairmoney.fairmoney.models.LoanAccepted;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class null implements APIResponse<LoanAccepted> {
  public void failure(int paramInt, String paramString) {
    FinalLoanOfferActivity.this.showNewToastMessage(paramString, 1);
    FinalLoanOfferActivity.this.cancelDialog();
    FinalLoanOfferActivity.this.enableAnswers(true);
  }
  
  public void success(LoanAccepted paramLoanAccepted) {
    FinalLoanOfferActivity finalLoanOfferActivity;
    if (paramLoanAccepted.getStatus().contentEquals("card_connection") && paramLoanAccepted.getCardConnectionPaystackAccessCode() == null) {
      a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)FinalLoanOfferActivity.this, "Null access code in acceptLoanOffer")));
      FinalLoanOfferActivity.this.enableAnswers(true);
      finalLoanOfferActivity = FinalLoanOfferActivity.this;
      finalLoanOfferActivity.showNewToastMessage(finalLoanOfferActivity.getString(2131820796), 1);
      return;
    } 
    FinalLoanOfferActivity.this.getSharedPreferences("CurrentUser", 0).edit().putString("cardConnectionAccessCode", finalLoanOfferActivity.getCardConnectionPaystackAccessCode()).putBoolean("needCardConnection", finalLoanOfferActivity.getStatus().contentEquals("card_connection")).apply();
    FinalLoanOfferActivity.this.cancelDialog();
    FinalLoanOfferActivity.access$000(FinalLoanOfferActivity.this, (LoanAccepted)finalLoanOfferActivity);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\FinalLoanOfferActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
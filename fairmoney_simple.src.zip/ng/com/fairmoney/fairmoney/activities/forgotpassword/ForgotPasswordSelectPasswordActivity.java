package ng.com.fairmoney.fairmoney.activities.forgotpassword;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import f.d.b.k.f;
import java.io.Serializable;
import l.a.a.a.a.r.g;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.login.PasswordActivity;

public class ForgotPasswordSelectPasswordActivity extends PasswordActivity {
  public Button btNext;
  
  public f phoneNumber;
  
  public String token;
  
  public void makeButtonEnabled(boolean paramBoolean) {
    this.btNext.setEnabled(paramBoolean);
  }
  
  public void makePasswordAction() {}
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, ForgotPasswordActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((BaseActivity)this).isAuthMandatory = false;
    initPasswords();
    if (getIntent() != null) {
      this.token = getIntent().getStringExtra("EXTRA_TOKEN");
      this.phoneNumber = (f)getIntent().getSerializableExtra("EXTRA_PHONE_NUMBER");
    } 
    Button button = (Button)findViewById(2131296385);
    this.btNext = button;
    button.setOnClickListener((View.OnClickListener)new g(this));
  }
  
  public int provideContentViewId() {
    return 2131492896;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\forgotpassword\ForgotPasswordSelectPasswordActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
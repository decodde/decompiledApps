package ng.com.fairmoney.fairmoney.activities;

import f.d.b.i.e;
import f.d.b.k.g;
import g.b.d;
import javax.inject.Provider;

public final class FinalLoanOfferViewModel_Factory implements d<FinalLoanOfferViewModel> {
  public final Provider<e> loanUseCaseProvider;
  
  public final Provider<g> userRepositoryProvider;
  
  public FinalLoanOfferViewModel_Factory(Provider<e> paramProvider, Provider<g> paramProvider1) {
    this.loanUseCaseProvider = paramProvider;
    this.userRepositoryProvider = paramProvider1;
  }
  
  public static FinalLoanOfferViewModel_Factory create(Provider<e> paramProvider, Provider<g> paramProvider1) {
    return new FinalLoanOfferViewModel_Factory(paramProvider, paramProvider1);
  }
  
  public static FinalLoanOfferViewModel newInstance(e parame, g paramg) {
    return new FinalLoanOfferViewModel(parame, paramg);
  }
  
  public FinalLoanOfferViewModel get() {
    return newInstance((e)this.loanUseCaseProvider.get(), (g)this.userRepositoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\FinalLoanOfferViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
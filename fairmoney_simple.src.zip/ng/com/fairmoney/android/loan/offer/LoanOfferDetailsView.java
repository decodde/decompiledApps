package ng.com.fairmoney.android.loan.offer;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.Group;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.w;
import d.o.y;
import d.o.z;
import f.d.c.b;
import j.q.d.g;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;

public final class LoanOfferDetailsView extends FrameLayout {
  public Group detailsViewGroup;
  
  @Inject
  public y.b factory;
  
  public ImageView ivArrow;
  
  public TextView tvDisbursementAmountTitle;
  
  public TextView tvDisbursementAmountValue;
  
  public TextView tvInterestTitle;
  
  public TextView tvInterestValue;
  
  public TextView tvLoanAmountValue;
  
  public TextView tvMoreDetails;
  
  public TextView tvProcessingFeesValue;
  
  public TextView tvTaxTitle;
  
  public TextView tvTaxValue;
  
  public TextView tvTotalToPayTitle;
  
  public TextView tvTotalToPayValue;
  
  public final LoanOfferDetailsViewModel viewModel;
  
  public LoanOfferDetailsView(Context paramContext) {
    this(paramContext, null, 0, 6, null);
  }
  
  public LoanOfferDetailsView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0, 4, null);
  }
  
  public LoanOfferDetailsView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    LayoutInflater.from(paramContext).inflate(2131493012, (ViewGroup)this, true);
    initView();
    Context context = paramContext.getApplicationContext();
    if (context != null) {
      w w;
      ViewModelComponentKt.create((b)context).inject(this);
      if (paramContext instanceof Fragment) {
        Fragment fragment = (Fragment)paramContext;
        y.b b1 = this.factory;
        if (b1 != null) {
          w = z.a(fragment, b1).a(LoanOfferDetailsViewModel.class);
          k.a(w, "ViewModelProviders.of(co…ilsViewModel::class.java)");
          w = w;
        } else {
          k.d("factory");
          throw null;
        } 
      } else if (paramContext instanceof d) {
        d d = (d)paramContext;
        y.b b1 = this.factory;
        if (b1 != null) {
          w = z.a(d, b1).a(LoanOfferDetailsViewModel.class);
          k.a(w, "ViewModelProviders.of(co…ilsViewModel::class.java)");
          w = w;
        } else {
          k.d("factory");
          throw null;
        } 
      } else {
        throw new IllegalArgumentException("Parent must be Fragment or FragmentActivity");
      } 
      this.viewModel = (LoanOfferDetailsViewModel)w;
      LiveData<LoanOfferDetailsViewModel.LoanOfferDetailsDataState> liveData = w.getDataState();
      l l = (l)paramContext;
      liveData.a(l, new s<LoanOfferDetailsViewModel.LoanOfferDetailsDataState>() {
            public final void onChanged(LoanOfferDetailsViewModel.LoanOfferDetailsDataState param1LoanOfferDetailsDataState) {
              if (param1LoanOfferDetailsDataState instanceof LoanOfferDetailsViewModel.LoanOfferDetailsDataState.DisbursementFees) {
                LoanOfferDetailsView.this.updateView((LoanOfferDetailsViewModel.LoanOfferDetailsDataState.DisbursementFees)param1LoanOfferDetailsDataState);
              } else if (param1LoanOfferDetailsDataState instanceof LoanOfferDetailsViewModel.LoanOfferDetailsDataState.Empty) {
                LoanOfferDetailsView.this.hideView();
              } 
            }
          });
      this.viewModel.getViewState().a(l, new s<LoanOfferDetailsViewModel.LoanOfferDetailsViewState>() {
            public final void onChanged(LoanOfferDetailsViewModel.LoanOfferDetailsViewState param1LoanOfferDetailsViewState) {
              LoanOfferDetailsView.this.openView(param1LoanOfferDetailsViewState.getOpen());
            }
          });
      return;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  private final void hideView() {
    setVisibility(8);
  }
  
  private final void initView() {
    View view = findViewById(2131297110);
    k.a(view, "findViewById(R.id.tv_disbursement_amount_title)");
    this.tvDisbursementAmountTitle = (TextView)view;
    view = findViewById(2131297111);
    k.a(view, "findViewById(R.id.tv_disbursement_amount_value)");
    this.tvDisbursementAmountValue = (TextView)view;
    view = findViewById(2131297194);
    k.a(view, "findViewById(R.id.tv_processing_fees_value)");
    this.tvProcessingFeesValue = (TextView)view;
    view = findViewById(2131297204);
    k.a(view, "findViewById(R.id.tv_tax_title)");
    this.tvTaxTitle = (TextView)view;
    view = findViewById(2131297205);
    k.a(view, "findViewById(R.id.tv_tax_value)");
    this.tvTaxValue = (TextView)view;
    view = findViewById(2131297155);
    k.a(view, "findViewById(R.id.tv_loan_amount_value)");
    this.tvLoanAmountValue = (TextView)view;
    view = findViewById(2131297151);
    k.a(view, "findViewById(R.id.tv_interest_title)");
    this.tvInterestTitle = (TextView)view;
    view = findViewById(2131297152);
    k.a(view, "findViewById(R.id.tv_interest_value)");
    this.tvInterestValue = (TextView)view;
    view = findViewById(2131297209);
    k.a(view, "findViewById(R.id.tv_total_to_pay_value)");
    this.tvTotalToPayValue = (TextView)view;
    view = findViewById(2131296613);
    k.a(view, "findViewById(R.id.iv_arrow)");
    this.ivArrow = (ImageView)view;
    view = findViewById(2131297183);
    k.a(view, "findViewById(R.id.tv_more_details)");
    this.tvMoreDetails = (TextView)view;
    view = findViewById(2131297208);
    k.a(view, "findViewById(R.id.tv_total_to_pay_title)");
    this.tvTotalToPayTitle = (TextView)view;
    view = findViewById(2131296486);
    k.a(view, "findViewById(R.id.details_view_group)");
    this.detailsViewGroup = (Group)view;
    setOnClickListener(new LoanOfferDetailsView$initView$1());
  }
  
  private final void openView(boolean paramBoolean) {
    byte b1;
    if (paramBoolean) {
      b1 = 0;
    } else {
      b1 = 8;
    } 
    Group group = this.detailsViewGroup;
    if (group != null) {
      group.setVisibility(b1);
      ImageView imageView = this.ivArrow;
      if (imageView != null) {
        float f;
        if (paramBoolean) {
          f = 0.0F;
        } else {
          f = -90.0F;
        } 
        imageView.setRotation(f);
        return;
      } 
      k.d("ivArrow");
      throw null;
    } 
    k.d("detailsViewGroup");
    throw null;
  }
  
  private final void updateView(LoanOfferDetailsViewModel.LoanOfferDetailsDataState.DisbursementFees paramDisbursementFees) {
    TextView textView = this.tvDisbursementAmountValue;
    if (textView != null) {
      textView.setText(paramDisbursementFees.getDisbursementAmountValue());
      textView = this.tvProcessingFeesValue;
      if (textView != null) {
        textView.setText(paramDisbursementFees.getProcessingFeesValue());
        textView = this.tvTaxTitle;
        if (textView != null) {
          textView.setText(paramDisbursementFees.getTaxTitle());
          textView = this.tvTaxValue;
          if (textView != null) {
            textView.setText(paramDisbursementFees.getTaxValue());
            textView = this.tvLoanAmountValue;
            if (textView != null) {
              textView.setText(paramDisbursementFees.getLoanAmountValue());
              textView = this.tvInterestValue;
              if (textView != null) {
                textView.setText(paramDisbursementFees.getInterestValue());
                textView = this.tvInterestTitle;
                if (textView != null) {
                  textView.setText(paramDisbursementFees.getInterestTitle());
                  textView = this.tvTotalToPayValue;
                  if (textView != null) {
                    textView.setText(paramDisbursementFees.getTotalValueToPay());
                    setVisibility(0);
                    return;
                  } 
                  k.d("tvTotalToPayValue");
                  throw null;
                } 
                k.d("tvInterestTitle");
                throw null;
              } 
              k.d("tvInterestValue");
              throw null;
            } 
            k.d("tvLoanAmountValue");
            throw null;
          } 
          k.d("tvTaxValue");
          throw null;
        } 
        k.d("tvTaxTitle");
        throw null;
      } 
      k.d("tvProcessingFeesValue");
      throw null;
    } 
    k.d("tvDisbursementAmountValue");
    throw null;
  }
  
  public final y.b getFactory() {
    y.b b1 = this.factory;
    if (b1 != null)
      return b1; 
    k.d("factory");
    throw null;
  }
  
  public final LoanOfferDetailsViewModel getViewModel() {
    return this.viewModel;
  }
  
  public final void setFactory(y.b paramb) {
    k.b(paramb, "<set-?>");
    this.factory = paramb;
  }
  
  public static final class LoanOfferDetailsView$initView$1 implements View.OnClickListener {
    public final void onClick(View param1View) {
      LoanOfferDetailsView.this.getViewModel().onArrowClicked();
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
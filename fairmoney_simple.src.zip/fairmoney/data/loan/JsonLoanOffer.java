package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonDisbursementFee;
import com.fairmoney.data.loan.JsonInstalment;
import j.q.d.k;
import java.util.List;

public final class JsonLoanOffer {
  public final int amountOffered;
  
  public final String currencyCode;
  
  public final int daysLoanMaturity;
  
  public final int disbursementAmount;
  
  public final JsonDisbursementFee disbursementFees;
  
  public final String id;
  
  public final List<JsonInstalment> instalments;
  
  public final double totalInterestRate;
  
  public JsonLoanOffer(String paramString1, int paramInt1, int paramInt2, String paramString2, JsonDisbursementFee paramJsonDisbursementFee, int paramInt3, double paramDouble, List<JsonInstalment> paramList) {
    this.id = paramString1;
    this.amountOffered = paramInt1;
    this.disbursementAmount = paramInt2;
    this.currencyCode = paramString2;
    this.disbursementFees = paramJsonDisbursementFee;
    this.daysLoanMaturity = paramInt3;
    this.totalInterestRate = paramDouble;
    this.instalments = paramList;
  }
  
  public final String component1() {
    return this.id;
  }
  
  public final int component2() {
    return this.amountOffered;
  }
  
  public final int component3() {
    return this.disbursementAmount;
  }
  
  public final String component4() {
    return this.currencyCode;
  }
  
  public final JsonDisbursementFee component5() {
    return this.disbursementFees;
  }
  
  public final int component6() {
    return this.daysLoanMaturity;
  }
  
  public final double component7() {
    return this.totalInterestRate;
  }
  
  public final List<JsonInstalment> component8() {
    return this.instalments;
  }
  
  public final com.fairmoney.data.loan.JsonLoanOffer copy(String paramString1, int paramInt1, int paramInt2, String paramString2, JsonDisbursementFee paramJsonDisbursementFee, int paramInt3, double paramDouble, List<JsonInstalment> paramList) {
    k.b(paramString1, "id");
    k.b(paramString2, "currencyCode");
    k.b(paramList, "instalments");
    return new com.fairmoney.data.loan.JsonLoanOffer(paramString1, paramInt1, paramInt2, paramString2, paramJsonDisbursementFee, paramInt3, paramDouble, paramList);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.loan.JsonLoanOffer) {
        paramObject = paramObject;
        if (k.a(this.id, ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).id) && this.amountOffered == ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).amountOffered && this.disbursementAmount == ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).disbursementAmount && k.a(this.currencyCode, ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).currencyCode) && k.a(this.disbursementFees, ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).disbursementFees) && this.daysLoanMaturity == ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).daysLoanMaturity && Double.compare(this.totalInterestRate, ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).totalInterestRate) == 0 && k.a(this.instalments, ((com.fairmoney.data.loan.JsonLoanOffer)paramObject).instalments))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final int getAmountOffered() {
    return this.amountOffered;
  }
  
  public final String getCurrencyCode() {
    return this.currencyCode;
  }
  
  public final int getDaysLoanMaturity() {
    return this.daysLoanMaturity;
  }
  
  public final int getDisbursementAmount() {
    return this.disbursementAmount;
  }
  
  public final JsonDisbursementFee getDisbursementFees() {
    return this.disbursementFees;
  }
  
  public final String getId() {
    return this.id;
  }
  
  public final List<JsonInstalment> getInstalments() {
    return this.instalments;
  }
  
  public final double getTotalInterestRate() {
    return this.totalInterestRate;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    String str = this.id;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    int j = this.amountOffered;
    int k = this.disbursementAmount;
    str = this.currencyCode;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    JsonDisbursementFee jsonDisbursementFee = this.disbursementFees;
    if (jsonDisbursementFee != null) {
      b3 = jsonDisbursementFee.hashCode();
    } else {
      b3 = 0;
    } 
    int m = this.daysLoanMaturity;
    long l = Double.doubleToLongBits(this.totalInterestRate);
    int n = (int)(l ^ l >>> 32L);
    List<JsonInstalment> list = this.instalments;
    if (list != null)
      i = list.hashCode(); 
    return ((((((b1 * 31 + j) * 31 + k) * 31 + b2) * 31 + b3) * 31 + m) * 31 + n) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonLoanOffer(id=");
    stringBuilder.append(this.id);
    stringBuilder.append(", amountOffered=");
    stringBuilder.append(this.amountOffered);
    stringBuilder.append(", disbursementAmount=");
    stringBuilder.append(this.disbursementAmount);
    stringBuilder.append(", currencyCode=");
    stringBuilder.append(this.currencyCode);
    stringBuilder.append(", disbursementFees=");
    stringBuilder.append(this.disbursementFees);
    stringBuilder.append(", daysLoanMaturity=");
    stringBuilder.append(this.daysLoanMaturity);
    stringBuilder.append(", totalInterestRate=");
    stringBuilder.append(this.totalInterestRate);
    stringBuilder.append(", instalments=");
    stringBuilder.append(this.instalments);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonLoanOffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
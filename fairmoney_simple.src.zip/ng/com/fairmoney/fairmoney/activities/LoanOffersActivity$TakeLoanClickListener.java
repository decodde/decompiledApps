package ng.com.fairmoney.fairmoney.activities;

import android.view.View;
import f.d.b.i.c;
import ng.com.fairmoney.fairmoney.views.StyledSpinner;

public class TakeLoanClickListener implements View.OnClickListener {
  public TakeLoanClickListener() {}
  
  private boolean checkSpinnerIsSelected(StyledSpinner paramStyledSpinner, int paramInt) {
    if (paramStyledSpinner.getText().toString().isEmpty() || paramStyledSpinner.getText().toString().contentEquals(LoanOffersActivity.this.getString(paramInt))) {
      paramStyledSpinner.setTextColor(-65536);
      paramStyledSpinner.setText(LoanOffersActivity.this.getString(paramInt));
      return false;
    } 
    return true;
  }
  
  public void onClick(View paramView) {
    if (checkSpinnerIsSelected(LoanOffersActivity.access$400(LoanOffersActivity.this), 2131820901) && checkSpinnerIsSelected(LoanOffersActivity.access$500(LoanOffersActivity.this), 2131820914)) {
      LoanOffersActivity loanOffersActivity = LoanOffersActivity.this;
      c c = LoanOffersActivity.access$600(loanOffersActivity, LoanOffersActivity.access$400(loanOffersActivity).getText().toString(), LoanOffersActivity.access$500(LoanOffersActivity.this).getText().toString());
      if (c != null) {
        LoanOffersActivity.access$1000(LoanOffersActivity.this).setEnabled(false);
        LoanOffersActivity.access$1100(LoanOffersActivity.this).setEnabled(false);
        LoanOffersActivity.access$1200(LoanOffersActivity.this, c);
      } 
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOffersActivity$TakeLoanClickListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
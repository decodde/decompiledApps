package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonInstalmentMapper_Factory;

public final class InstanceHolder {
  public static final JsonInstalmentMapper_Factory INSTANCE = new JsonInstalmentMapper_Factory();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonInstalmentMapper_Factory$InstanceHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
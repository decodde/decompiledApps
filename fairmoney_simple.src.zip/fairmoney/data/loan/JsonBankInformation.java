package fairmoney.data.loan;

import j.q.d.k;

public final class JsonBankInformation {
  public final String bankAccountNumber;
  
  public final String ifsc;
  
  public JsonBankInformation(String paramString1, String paramString2) {
    this.ifsc = paramString1;
    this.bankAccountNumber = paramString2;
  }
  
  public final String component1() {
    return this.ifsc;
  }
  
  public final String component2() {
    return this.bankAccountNumber;
  }
  
  public final com.fairmoney.data.loan.JsonBankInformation copy(String paramString1, String paramString2) {
    k.b(paramString1, "ifsc");
    k.b(paramString2, "bankAccountNumber");
    return new com.fairmoney.data.loan.JsonBankInformation(paramString1, paramString2);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.loan.JsonBankInformation) {
        paramObject = paramObject;
        if (k.a(this.ifsc, ((com.fairmoney.data.loan.JsonBankInformation)paramObject).ifsc) && k.a(this.bankAccountNumber, ((com.fairmoney.data.loan.JsonBankInformation)paramObject).bankAccountNumber))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getBankAccountNumber() {
    return this.bankAccountNumber;
  }
  
  public final String getIfsc() {
    return this.ifsc;
  }
  
  public int hashCode() {
    byte b;
    String str = this.ifsc;
    int i = 0;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    str = this.bankAccountNumber;
    if (str != null)
      i = str.hashCode(); 
    return b * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonBankInformation(ifsc=");
    stringBuilder.append(this.ifsc);
    stringBuilder.append(", bankAccountNumber=");
    stringBuilder.append(this.bankAccountNumber);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonBankInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
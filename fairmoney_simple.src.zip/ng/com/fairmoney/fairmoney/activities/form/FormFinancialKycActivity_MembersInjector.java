package ng.com.fairmoney.fairmoney.activities.form;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class FormFinancialKycActivity_MembersInjector implements a<FormFinancialKycActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public FormFinancialKycActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<FormFinancialKycActivity> create(Provider<y.b> paramProvider) {
    return new FormFinancialKycActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(FormFinancialKycActivity paramFormFinancialKycActivity, y.b paramb) {
    paramFormFinancialKycActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(FormFinancialKycActivity paramFormFinancialKycActivity) {
    injectViewModelFactory(paramFormFinancialKycActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormFinancialKycActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
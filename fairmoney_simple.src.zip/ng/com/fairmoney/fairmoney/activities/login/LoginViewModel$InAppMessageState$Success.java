package ng.com.fairmoney.fairmoney.activities.login;

import f.d.b.f.e;

public final class Success extends LoginViewModel.InAppMessageState {
  public final e inAppMessage;
  
  public Success(e parame) {
    super(null);
    this.inAppMessage = parame;
  }
  
  public final e getInAppMessage() {
    return this.inAppMessage;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel$InAppMessageState$Success.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.adapters;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import ng.com.fairmoney.fairmoney.fragments.home.BillMakePaymentFragment;
import ng.com.fairmoney.fairmoney.models.Bill;
import ng.com.fairmoney.fairmoney.models.BillChoice;
import ng.com.fairmoney.fairmoney.models.BillWidget;
import ng.com.fairmoney.fairmoney.utils.PhoneUtils;
import ng.com.fairmoney.fairmoney.views.CustomListLayout;
import ng.com.fairmoney.fairmoney.views.CustomPickerLayout;
import ng.com.fairmoney.fairmoney.views.CustomRadioGroupLayout;
import ng.com.fairmoney.fairmoney.views.CustomTextInputLayout;
import ng.com.fairmoney.fairmoney.views.CustomView;

public class BillDynamicFieldsAdapter {
  public BillMakePaymentFragment containerFragment;
  
  public Context context;
  
  public List<CustomView> customViews;
  
  public BillMakePaymentFragment.OnViewFilledListener onViewFilledListener;
  
  public List<BillWidget> widgets;
  
  public BillDynamicFieldsAdapter(Context paramContext, List<BillWidget> paramList) {
    this.context = paramContext;
    this.widgets = paramList;
    this.customViews = new ArrayList<CustomView>();
  }
  
  private void addChildrenToParent(CustomView paramCustomView, BillWidget paramBillWidget, List<View> paramList) {
    if (paramBillWidget.getChildren() != null && !paramBillWidget.getChildren().isEmpty()) {
      Iterator<BillWidget> iterator = paramBillWidget.getChildren().iterator();
      while (iterator.hasNext())
        paramList.addAll(getViewsFromWidget(iterator.next(), paramCustomView)); 
    } 
  }
  
  private boolean checkFieldsFilled(List<CustomView> paramList) {
    for (CustomView customView : paramList) {
      if (customView.getVisibility() == 0 && !customView.isAnswerCorrect(false))
        return false; 
      if (!checkFieldsFilled(customView.getChildren()))
        return false; 
    } 
    return true;
  }
  
  private CustomTextInputLayout getInputViewFromWidget(BillWidget paramBillWidget) {
    CustomTextInputLayout customTextInputLayout = (new CustomTextInputLayout(this.containerFragment, this.context)).init(paramBillWidget.getTitle(), paramBillWidget.getInputValidation(), paramBillWidget.getKey());
    customTextInputLayout.setParentChoiceId(paramBillWidget.getParentChoiceId());
    customTextInputLayout.setServiceName(paramBillWidget.getServiceName());
    customTextInputLayout.getEditText().addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            // Byte code:
            //   0: aload_0
            //   1: getfield this$0 : Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;
            //   4: invokestatic access$200 : (Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;)Lng/com/fairmoney/fairmoney/fragments/home/BillMakePaymentFragment$OnViewFilledListener;
            //   7: astore_2
            //   8: aload_1
            //   9: invokeinterface length : ()I
            //   14: ifeq -> 38
            //   17: aload_0
            //   18: getfield this$0 : Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;
            //   21: astore_1
            //   22: aload_1
            //   23: aload_1
            //   24: invokestatic access$000 : (Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;)Ljava/util/List;
            //   27: invokestatic access$100 : (Lng/com/fairmoney/fairmoney/adapters/BillDynamicFieldsAdapter;Ljava/util/List;)Z
            //   30: ifeq -> 38
            //   33: iconst_1
            //   34: istore_3
            //   35: goto -> 40
            //   38: iconst_0
            //   39: istore_3
            //   40: aload_2
            //   41: iload_3
            //   42: invokeinterface onViewFullyFilled : (Z)V
            //   47: return
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
    return customTextInputLayout;
  }
  
  private CustomListLayout getListLayoutFromWidget(BillWidget paramBillWidget) {
    final CustomListLayout customListLayout = (new CustomListLayout(this.context, paramBillWidget.getInputValidation())).init(paramBillWidget);
    customListLayout.setOnItemClickListener(new OnItemClickListener() {
          public void onClick(String param1String, int param1Int) {
            customListLayout.setChildrenVisibility(0, param1Int);
            BillMakePaymentFragment.OnViewFilledListener onViewFilledListener = BillDynamicFieldsAdapter.this.onViewFilledListener;
            BillDynamicFieldsAdapter billDynamicFieldsAdapter = BillDynamicFieldsAdapter.this;
            onViewFilledListener.onViewFullyFilled(billDynamicFieldsAdapter.checkFieldsFilled(billDynamicFieldsAdapter.customViews));
          }
        });
    customListLayout.setParentChoiceId(paramBillWidget.getParentChoiceId());
    return customListLayout;
  }
  
  private CustomPickerLayout getPickerViewFromWidget(final BillWidget widget) {
    final CustomPickerLayout customPickerLayout = (new CustomPickerLayout(this.context, widget.getInputValidation(), widget.getKey())).init(widget.getTitle(), widget.getChoices());
    customPickerLayout.setParentChoiceId(widget.getParentChoiceId());
    customPickerLayout.getStyledSpinner().setOnItemClickListener(new AdapterView.OnItemClickListener() {
          public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
            customPickerLayout.onSelectedPosition(param1Int, ((BillChoice)widget.getChoices().get(param1Int)).getId());
            BillMakePaymentFragment.OnViewFilledListener onViewFilledListener = BillDynamicFieldsAdapter.this.onViewFilledListener;
            BillDynamicFieldsAdapter billDynamicFieldsAdapter = BillDynamicFieldsAdapter.this;
            onViewFilledListener.onViewFullyFilled(billDynamicFieldsAdapter.checkFieldsFilled(billDynamicFieldsAdapter.customViews));
          }
        });
    return customPickerLayout;
  }
  
  private CustomRadioGroupLayout getRadioGroupViewFromWidget(BillWidget paramBillWidget) {
    final CustomRadioGroupLayout customRadioGroupLayout = (new CustomRadioGroupLayout(this.context, paramBillWidget.getInputValidation(), paramBillWidget.getKey())).init(paramBillWidget.getChoices().get(0), paramBillWidget.getChoices().get(1));
    customRadioGroupLayout.setParentChoiceId(paramBillWidget.getParentChoiceId());
    customRadioGroupLayout.setOnItemClickedListener(new OnItemClickListener() {
          public void onClick(String param1String, int param1Int) {
            customRadioGroupLayout.setChildrenVisibility(0, param1Int);
            BillMakePaymentFragment.OnViewFilledListener onViewFilledListener = BillDynamicFieldsAdapter.this.onViewFilledListener;
            BillDynamicFieldsAdapter billDynamicFieldsAdapter = BillDynamicFieldsAdapter.this;
            onViewFilledListener.onViewFullyFilled(billDynamicFieldsAdapter.checkFieldsFilled(billDynamicFieldsAdapter.customViews));
          }
        });
    return customRadioGroupLayout;
  }
  
  private List<View> getViewsFromWidget(BillWidget paramBillWidget, CustomView paramCustomView) {
    CustomView customView;
    ArrayList<TextView> arrayList = new ArrayList();
    if (paramBillWidget.getType().contentEquals("input")) {
      CustomTextInputLayout customTextInputLayout = getInputViewFromWidget(paramBillWidget);
      if (customTextInputLayout.getTitleView() != null)
        arrayList.add(customTextInputLayout.getTitleView()); 
      arrayList.add(customTextInputLayout.getTextInputLayout());
      customView = (CustomView)customTextInputLayout;
      if (customTextInputLayout.getTextViewAction() != null) {
        arrayList.add(customTextInputLayout.getTextViewAction());
        customView = (CustomView)customTextInputLayout;
      } 
    } else if (paramBillWidget.getType().contentEquals("picker")) {
      customView = (CustomView)getPickerViewFromWidget(paramBillWidget);
      if (customView.getTitleView() != null)
        arrayList.add(customView.getTitleView()); 
      arrayList.add(customView.getPickerLayout());
    } else if (paramBillWidget.getType().contentEquals("radio")) {
      customView = (CustomView)getRadioGroupViewFromWidget(paramBillWidget);
      if (customView.getTitleView() != null)
        arrayList.add(customView.getTitleView()); 
      arrayList.add(customView.getRadioGroup());
    } else if (paramBillWidget.getType().contentEquals("list")) {
      customView = (CustomView)getListLayoutFromWidget(paramBillWidget);
      if (customView.getTitleView() != null)
        arrayList.add(customView.getTitleView()); 
      arrayList.add(customView.getRecyclerView());
    } else {
      customView = null;
    } 
    if (paramCustomView != null) {
      paramCustomView.addChild(customView);
    } else {
      this.customViews.add(customView);
    } 
    addChildrenToParent(customView, paramBillWidget, (List)arrayList);
    return (List)arrayList;
  }
  
  private void updateBillAmount(Bill paramBill, CustomTextInputLayout paramCustomTextInputLayout) {
    int i = Integer.valueOf(paramCustomTextInputLayout.getAnswer()).intValue() * 100;
    paramBill.setUserInputAmount(String.valueOf(i));
    paramBill.setTransactionAmount(String.valueOf(i));
    paramBill.setFlutterwaveServiceId(null);
    if (paramCustomTextInputLayout.getServiceName() != null)
      paramBill.setServiceName(paramCustomTextInputLayout.getServiceName()); 
  }
  
  private void updateBillAnswers(Bill paramBill, CustomView paramCustomView) {
    if (paramCustomView.getKey() == null)
      return; 
    if (paramCustomView.getKey().contentEquals("flutterwave_service_id")) {
      updateBillServiceId(paramBill, paramCustomView);
    } else if (paramCustomView.getKey().contentEquals("user_reference")) {
      updateBillUserReference(paramBill, paramCustomView);
    } else if (paramCustomView.getKey().contentEquals("user_input_amount")) {
      updateBillAmount(paramBill, (CustomTextInputLayout)paramCustomView);
    } 
  }
  
  private void updateBillServiceId(Bill paramBill, CustomView paramCustomView) {
    paramBill.setFlutterwaveServiceId(paramCustomView.getAnswer());
    String str = String.valueOf(paramCustomView.getSelectedChoice().getChoiceAmount());
    paramBill.setUserInputAmount(str);
    paramBill.setTransactionAmount(str);
  }
  
  private void updateBillUserReference(Bill paramBill, CustomView paramCustomView) {
    String str;
    if (paramCustomView.getAnswerTypeValidation().getInputType().contentEquals("phone")) {
      str = PhoneUtils.preparePhoneNumber(paramCustomView.getAnswer());
    } else {
      str = str.getAnswer();
    } 
    paramBill.setUserReference(str);
  }
  
  private boolean verifyAnswers() {
    Iterator<CustomView> iterator = this.customViews.iterator();
    while (iterator.hasNext()) {
      if (!((CustomView)iterator.next()).isAnswerCorrect(true))
        return false; 
    } 
    return true;
  }
  
  public void displayViews(BillMakePaymentFragment paramBillMakePaymentFragment, LinearLayout paramLinearLayout) {
    this.containerFragment = paramBillMakePaymentFragment;
    ArrayList<View> arrayList = new ArrayList();
    Iterator<BillWidget> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      arrayList.addAll(getViewsFromWidget(iterator.next(), null)); 
    iterator = (Iterator)arrayList.iterator();
    while (iterator.hasNext())
      paramLinearLayout.addView((View)iterator.next()); 
  }
  
  public void setOnViewFilledListener(BillMakePaymentFragment.OnViewFilledListener paramOnViewFilledListener) {
    this.onViewFilledListener = paramOnViewFilledListener;
  }
  
  public Bill updateBill(Bill paramBill) {
    if (!verifyAnswers())
      return null; 
    for (CustomView customView : this.customViews) {
      updateBillAnswers(paramBill, customView);
      for (CustomView customView1 : customView.getChildren()) {
        if (customView1.getVisibility() == 0)
          updateBillAnswers(paramBill, customView1); 
      } 
    } 
    return paramBill;
  }
  
  public static interface OnItemClickListener {
    void onClick(String param1String, int param1Int);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BillDynamicFieldsAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import com.android.volley.VolleyError;
import f.a.b.k;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.models.OfferRefusalReason;
import ng.com.fairmoney.fairmoney.network.BackendApi;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import org.json.JSONObject;

public class OfferDeclinedActivity extends BaseActivity {
  public static final String TAG = "OFFER_REFUSED_ACTIVITY";
  
  public SharedPreferences preferences;
  
  public String selectedRefusalReason;
  
  public String writtenRefusalReason;
  
  private void goToWelcomeActivity() {
    logout();
    startActivity(new Intent(getApplicationContext(), WelcomeActivity.class));
    finish();
  }
  
  private void logout() {
    SharedPreferences.Editor editor = this.preferences.edit();
    editor.putString("AuthToken", null);
    editor.apply();
    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
    finish();
  }
  
  private void readSelectedRefusalReason() {
    switch (((RadioGroup)findViewById(2131296851)).getCheckedRadioButtonId()) {
      default:
        this.selectedRefusalReason = "";
        return;
      case 2131296778:
        this.selectedRefusalReason = "other_reason";
        return;
      case 2131296569:
        this.selectedRefusalReason = "fees_too_high";
        return;
      case 2131296508:
        this.selectedRefusalReason = "duration_too_short";
        return;
      case 2131296334:
        break;
    } 
    this.selectedRefusalReason = "amount_too_low";
  }
  
  private void readWrittenRefusalReason() {
    this.writtenRefusalReason = ((EditText)findViewById(2131296850)).getText().toString();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((Button)findViewById(2131296909)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Tracking.sendUniqueClickEvent((Context)OfferDeclinedActivity.this, "SEND_FEEDBACK");
            OfferDeclinedActivity.this.readSelectedRefusalReason();
            OfferDeclinedActivity.this.readWrittenRefusalReason();
            k.b<JSONObject> b = new k.b<JSONObject>() {
                public void onResponse(JSONObject param2JSONObject) {
                  OfferDeclinedActivity.this.goToWelcomeActivity();
                }
              };
            k.a a = new k.a() {
                public void onErrorResponse(VolleyError param2VolleyError) {
                  BackendApi.checkServerError((Context)OfferDeclinedActivity.this, param2VolleyError);
                  String str = BackendApi.getErrorMessageAccordingTo((Context)OfferDeclinedActivity.this, param2VolleyError);
                  OfferDeclinedActivity.this.showNewToastMessage(str, 1);
                }
              };
            FairMoney.getBackendApi((Context)OfferDeclinedActivity.this).sendOfferRefusalReason(b, a, new OfferRefusalReason(OfferDeclinedActivity.this.selectedRefusalReason, OfferDeclinedActivity.this.writtenRefusalReason));
          }
        });
    this.preferences = getSharedPreferences("CurrentUser", 0);
  }
  
  public int provideContentViewId() {
    return 2131492910;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\OfferDeclinedActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
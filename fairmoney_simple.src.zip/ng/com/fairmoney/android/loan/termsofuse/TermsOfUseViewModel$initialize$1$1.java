package ng.com.fairmoney.android.loan.termsofuse;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.q;
import j.q.d.k;
import java.net.URL;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel$initialize$1$1", f = "TermsOfUseViewModel.kt", l = {48}, m = "invokeSuspend")
public final class null extends k implements q<b<? super URL>, Throwable, d<? super k>, Object> {
  public Object L$0;
  
  public Object L$1;
  
  public int label;
  
  public b p$;
  
  public Throwable p$0;
  
  public null(d paramd) {
    super(3, paramd);
  }
  
  public final d<k> create(b<? super URL> paramb, Throwable paramThrowable, d<? super k> paramd) {
    k.b(paramb, "$this$create");
    k.b(paramThrowable, "it");
    k.b(paramd, "continuation");
    Object object = new Object(paramd);
    object.p$ = paramb;
    object.p$0 = paramThrowable;
    return (d<k>)object;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2, Object paramObject3) {
    return ((null)create((b<? super URL>)paramObject1, (Throwable)paramObject2, (d<? super k>)paramObject3)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    Object object = c.a();
    int i = this.label;
    if (i != 0) {
      if (i == 1) {
        object = this.L$1;
        object = this.L$0;
        g.a(paramObject);
      } else {
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
    } else {
      g.a(paramObject);
      b b1 = this.p$;
      paramObject = this.p$0;
      URL uRL = new URL("https://app.fairmoney.com.ng/in/loan_agreement");
      this.L$0 = b1;
      this.L$1 = paramObject;
      this.label = 1;
      if (b1.emit(uRL, (d)this) == object)
        return object; 
    } 
    return k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$initialize$1$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
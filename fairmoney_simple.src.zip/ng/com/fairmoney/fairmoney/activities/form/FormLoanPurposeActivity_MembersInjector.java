package ng.com.fairmoney.fairmoney.activities.form;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class FormLoanPurposeActivity_MembersInjector implements a<FormLoanPurposeActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public FormLoanPurposeActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<FormLoanPurposeActivity> create(Provider<y.b> paramProvider) {
    return new FormLoanPurposeActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(FormLoanPurposeActivity paramFormLoanPurposeActivity, y.b paramb) {
    paramFormLoanPurposeActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(FormLoanPurposeActivity paramFormLoanPurposeActivity) {
    injectViewModelFactory(paramFormLoanPurposeActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormLoanPurposeActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
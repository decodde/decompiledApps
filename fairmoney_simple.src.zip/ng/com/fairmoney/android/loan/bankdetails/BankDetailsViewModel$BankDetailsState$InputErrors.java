package ng.com.fairmoney.android.loan.bankdetails;

import j.q.d.k;
import java.util.List;

public final class InputErrors extends BankDetailsViewModel.BankDetailsState {
  public final List<BankDetailsViewModel.BankDetailsStateError> errors;
  
  public InputErrors(List<? extends BankDetailsViewModel.BankDetailsStateError> paramList) {
    super(null);
    this.errors = (List)paramList;
  }
  
  public final List<BankDetailsViewModel.BankDetailsStateError> component1() {
    return this.errors;
  }
  
  public final InputErrors copy(List<? extends BankDetailsViewModel.BankDetailsStateError> paramList) {
    k.b(paramList, "errors");
    return new InputErrors(paramList);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof InputErrors) {
        paramObject = paramObject;
        if (k.a(this.errors, ((InputErrors)paramObject).errors))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final List<BankDetailsViewModel.BankDetailsStateError> getErrors() {
    return this.errors;
  }
  
  public int hashCode() {
    boolean bool;
    List<BankDetailsViewModel.BankDetailsStateError> list = this.errors;
    if (list != null) {
      bool = list.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("InputErrors(errors=");
    stringBuilder.append(this.errors);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$BankDetailsState$InputErrors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
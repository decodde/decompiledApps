package ng.com.fairmoney.fairmoney.activities.signup;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.login.PasswordActivity;
import ng.com.fairmoney.fairmoney.models.PhoneAuthentication;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class PhoneSignupConfirmPasswordActivity extends PasswordActivity {
  public Button btNext;
  
  public String firstPassword;
  
  public String token;
  
  private void createPhonePassword(PhoneAuthentication paramPhoneAuthentication) {
    RetrofitSession.getInstance((Context)this).getUserLoginManager().createPassword(this.token, paramPhoneAuthentication, new APIResponse<Object>() {
          public void failure(int param1Int, String param1String) {
            PhoneSignupConfirmPasswordActivity.this.logSignupResult("Phone", false);
            PhoneSignupConfirmPasswordActivity.this.showNewToastMessage(param1String, 0);
            PhoneSignupConfirmPasswordActivity.this.makeButtonEnabled(true);
          }
          
          public void success(Object param1Object) {
            PhoneSignupConfirmPasswordActivity.this.logSignupResult("Phone", true);
            PhoneSignupConfirmPasswordActivity.this.logLoginResult("Phone", true);
            param1Object = new Event("application", "phoneLogin");
            Tracking.sendUniqueEvent((Context)PhoneSignupConfirmPasswordActivity.this, (Event)param1Object);
            PhoneSignupConfirmPasswordActivity.this.goToNextScreen(null);
          }
        });
  }
  
  private void goToPreviousActivity() {
    Intent intent = new Intent((Context)this, PhoneSignupSelectPasswordActivity.class);
    intent.putExtra("EXTRA_TOKEN", this.token);
    startActivity(intent);
    finish();
  }
  
  private void initBackArrow() {
    ((ImageView)findViewById(2131296654)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            PhoneSignupConfirmPasswordActivity.this.goToPreviousActivity();
          }
        });
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {
    this.btNext.setEnabled(paramBoolean);
  }
  
  public void makePasswordAction() {
    PhoneAuthentication phoneAuthentication = new PhoneAuthentication();
    phoneAuthentication.setNewPassword(this.firstPassword);
    phoneAuthentication.setPhone(getSharedPreferences("CurrentUser", 0).getString("phone", ""));
    createPhonePassword(phoneAuthentication);
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    goToPreviousActivity();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((BaseActivity)this).isAuthMandatory = false;
    initBackArrow();
    initPasswords();
    Intent intent = getIntent();
    if (intent != null) {
      this.token = intent.getStringExtra("EXTRA_TOKEN");
      this.firstPassword = intent.getStringExtra("password");
    } 
    Button button = (Button)findViewById(2131296420);
    this.btNext = button;
    button.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            PhoneSignupConfirmPasswordActivity phoneSignupConfirmPasswordActivity = PhoneSignupConfirmPasswordActivity.this;
            phoneSignupConfirmPasswordActivity.confirmPassword(phoneSignupConfirmPasswordActivity.firstPassword);
          }
        });
  }
  
  public int provideContentViewId() {
    return 2131492914;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupConfirmPasswordActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.payment;

public final class JsonRepaymentAmount {
  public final long repaymentAmount;
  
  public JsonRepaymentAmount(long paramLong) {
    this.repaymentAmount = paramLong;
  }
  
  public final long component1() {
    return this.repaymentAmount;
  }
  
  public final com.fairmoney.data.payment.JsonRepaymentAmount copy(long paramLong) {
    return new com.fairmoney.data.payment.JsonRepaymentAmount(paramLong);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.payment.JsonRepaymentAmount) {
        paramObject = paramObject;
        if (this.repaymentAmount == ((com.fairmoney.data.payment.JsonRepaymentAmount)paramObject).repaymentAmount)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final long getRepaymentAmount() {
    return this.repaymentAmount;
  }
  
  public int hashCode() {
    long l = this.repaymentAmount;
    return (int)(l ^ l >>> 32L);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonRepaymentAmount(repaymentAmount=");
    stringBuilder.append(this.repaymentAmount);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\payment\JsonRepaymentAmount.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
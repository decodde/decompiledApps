package ng.com.fairmoney.android.inversion;

import android.content.Context;
import g.b.d;
import javax.inject.Provider;

public final class NetworkCountryProviderImpl_Factory implements d<NetworkCountryProviderImpl> {
  public final Provider<Context> contextProvider;
  
  public NetworkCountryProviderImpl_Factory(Provider<Context> paramProvider) {
    this.contextProvider = paramProvider;
  }
  
  public static NetworkCountryProviderImpl_Factory create(Provider<Context> paramProvider) {
    return new NetworkCountryProviderImpl_Factory(paramProvider);
  }
  
  public static NetworkCountryProviderImpl newInstance(Context paramContext) {
    return new NetworkCountryProviderImpl(paramContext);
  }
  
  public NetworkCountryProviderImpl get() {
    return newInstance((Context)this.contextProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\NetworkCountryProviderImpl_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import android.text.Editable;
import android.text.TextWatcher;

public class null implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    FormWorkActivity.access$700(FormWorkActivity.this, paramEditable.toString());
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormWorkActivity$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
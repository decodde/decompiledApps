package ng.com.fairmoney.android.loan.offer;

import android.view.View;

public final class LoanOfferDetailsView$initView$1 implements View.OnClickListener {
  public final void onClick(View paramView) {
    LoanOfferDetailsView.this.getViewModel().onArrowClicked();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsView$initView$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
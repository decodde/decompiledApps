package ng.com.fairmoney.android.loan.termsofuse;

import j.e;
import j.i;
import j.q.d.g;

public abstract class TermsOfUse {
  public final boolean discountVisibility;
  
  public final e<String, String> feesRange;
  
  public final String higherAmounts;
  
  public final boolean isLoanAgreement;
  
  public final boolean lateFeesVisibility;
  
  public final String loanAgreementLink;
  
  public final e<String, String> loanRange;
  
  public final e<String, String> monthlyFeesRange;
  
  public final boolean neutralCurrency;
  
  public final String privacyUrl;
  
  public final String termsOfUseUrl;
  
  public TermsOfUse(String paramString1, boolean paramBoolean1, boolean paramBoolean2, e<String, String> parame1, e<String, String> parame2, e<String, String> parame3, String paramString2, String paramString3, String paramString4, boolean paramBoolean3, boolean paramBoolean4) {
    this.higherAmounts = paramString1;
    this.discountVisibility = paramBoolean1;
    this.lateFeesVisibility = paramBoolean2;
    this.loanRange = parame1;
    this.feesRange = parame2;
    this.monthlyFeesRange = parame3;
    this.termsOfUseUrl = paramString2;
    this.loanAgreementLink = paramString3;
    this.privacyUrl = paramString4;
    this.neutralCurrency = paramBoolean3;
    this.isLoanAgreement = paramBoolean4;
  }
  
  public final boolean getDiscountVisibility() {
    return this.discountVisibility;
  }
  
  public final e<String, String> getFeesRange() {
    return this.feesRange;
  }
  
  public final String getHigherAmounts() {
    return this.higherAmounts;
  }
  
  public final boolean getLateFeesVisibility() {
    return this.lateFeesVisibility;
  }
  
  public final String getLoanAgreementLink() {
    return this.loanAgreementLink;
  }
  
  public final e<String, String> getLoanRange() {
    return this.loanRange;
  }
  
  public final e<String, String> getMonthlyFeesRange() {
    return this.monthlyFeesRange;
  }
  
  public final boolean getNeutralCurrency() {
    return this.neutralCurrency;
  }
  
  public final String getPrivacyUrl() {
    return this.privacyUrl;
  }
  
  public final String getTermsOfUseUrl() {
    return this.termsOfUseUrl;
  }
  
  public final boolean isLoanAgreement() {
    return this.isLoanAgreement;
  }
  
  public static final class Indian extends TermsOfUse {
    public Indian(String param2String1, String param2String2) {
      super("₹50,000 rupees", false, false, i.a(str, stringBuilder2.toString()), i.a("1%", "15%"), i.a("1%", "10%"), "https://www.fairmoney.in/terms-and-conditions", param2String2, "https://www.fairmoney.in/privacy-policy", true, true, null);
    }
  }
  
  public static final class Nigerian extends TermsOfUse {
    public Nigerian(String param2String) {
      super(str1, true, true, i.a(str2, stringBuilder2.toString()), i.a("10%", "40%"), i.a("1%", "30%"), "https://fairmoney.ng/terms-of-use/", " ", "https://fairmoney.ng/privacy-policy/", false, false, null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$TermsOfUse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<Object> {
  public void failure(int paramInt, String paramString) {
    LoanOffersActivity.this.showNewToastMessage(paramString, 0);
    LoanOffersActivity.this.enableAnswers(true);
  }
  
  public void success(Object paramObject) {
    LoanOffersActivity.access$900(LoanOffersActivity.this).onLoanOfferSelected();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOffersActivity$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
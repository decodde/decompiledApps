package ng.com.fairmoney.fairmoney.activities.signup;

import android.view.View;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    PhoneSignupConfirmPasswordActivity.access$200(PhoneSignupConfirmPasswordActivity.this);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupConfirmPasswordActivity$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.bankdetails;

public final class IfscError extends BankDetailsViewModel.BankDetailsStateError {
  public static final IfscError INSTANCE = new IfscError();
  
  public IfscError() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$BankDetailsStateError$IfscError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
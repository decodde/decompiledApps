package ng.com.fairmoney.fairmoney.activities;

import f.d.b.i.c;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.q;
import j.q.d.k;
import java.util.List;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.fairmoney.activities.DataUploadViewModel$initialize$1$1", f = "DataUploadViewModel.kt", l = {}, m = "invokeSuspend")
public final class null extends k implements q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> {
  public int label;
  
  public b p$;
  
  public Throwable p$0;
  
  public null(d paramd) {
    super(3, paramd);
  }
  
  public final d<k> create(b<? super List<c>> paramb, Throwable paramThrowable, d<? super k> paramd) {
    k.b(paramb, "$this$create");
    k.b(paramd, "continuation");
    Object object = new Object(DataUploadViewModel$initialize$1.this, paramd);
    object.p$ = paramb;
    object.p$0 = paramThrowable;
    return (d<k>)object;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2, Object paramObject3) {
    return ((null)create((b<? super List<c>>)paramObject1, (Throwable)paramObject2, (d<? super k>)paramObject3)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      DataUploadViewModel.access$getMutableState$p(this.this$0.this$0).b(new DataUploadViewModel.LoanOffersState.Loading(false));
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadViewModel$initialize$1$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.termsofuse;

import j.k;
import j.n.d;
import j.n.i.c;
import java.net.URL;
import k.a.h2.b;

public final class null implements b<URL> {
  public null(TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 paramTermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    URL uRL = (URL)paramObject;
    paramObject = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(", <a href=\"");
    stringBuilder.append(uRL);
    stringBuilder.append("\">loan agreement</a> ");
    paramObject = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)paramObject, stringBuilder.toString()), paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
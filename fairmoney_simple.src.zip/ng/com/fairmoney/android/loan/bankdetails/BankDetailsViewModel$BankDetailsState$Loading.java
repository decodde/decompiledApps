package ng.com.fairmoney.android.loan.bankdetails;

public final class Loading extends BankDetailsViewModel.BankDetailsState {
  public final boolean isLoading;
  
  public Loading(boolean paramBoolean) {
    super(null);
    this.isLoading = paramBoolean;
  }
  
  public final boolean component1() {
    return this.isLoading;
  }
  
  public final Loading copy(boolean paramBoolean) {
    return new Loading(paramBoolean);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof Loading) {
        paramObject = paramObject;
        if (this.isLoading == ((Loading)paramObject).isLoading)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    boolean bool1 = this.isLoading;
    boolean bool2 = bool1;
    if (bool1)
      bool2 = true; 
    return bool2;
  }
  
  public final boolean isLoading() {
    return this.isLoading;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Loading(isLoading=");
    stringBuilder.append(this.isLoading);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$BankDetailsState$Loading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
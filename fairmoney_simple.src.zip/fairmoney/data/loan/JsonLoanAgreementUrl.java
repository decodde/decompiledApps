package fairmoney.data.loan;

import j.q.d.k;

public final class JsonLoanAgreementUrl {
  public final String loanAgreementUrl;
  
  public JsonLoanAgreementUrl(String paramString) {
    this.loanAgreementUrl = paramString;
  }
  
  public final String component1() {
    return this.loanAgreementUrl;
  }
  
  public final com.fairmoney.data.loan.JsonLoanAgreementUrl copy(String paramString) {
    k.b(paramString, "loanAgreementUrl");
    return new com.fairmoney.data.loan.JsonLoanAgreementUrl(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.loan.JsonLoanAgreementUrl) {
        paramObject = paramObject;
        if (k.a(this.loanAgreementUrl, ((com.fairmoney.data.loan.JsonLoanAgreementUrl)paramObject).loanAgreementUrl))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getLoanAgreementUrl() {
    return this.loanAgreementUrl;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.loanAgreementUrl;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonLoanAgreementUrl(loanAgreementUrl=");
    stringBuilder.append(this.loanAgreementUrl);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonLoanAgreementUrl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.i.c;
import f.d.b.i.e;
import f.d.b.k.g;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import java.util.List;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class DataUploadViewModel extends w {
  public final e loanUseCase;
  
  public final r<LoanOffersState> mutableState;
  
  public final LiveData<LoanOffersState> state;
  
  public final g userRepository;
  
  @Inject
  public DataUploadViewModel(e parame, g paramg) {
    this.loanUseCase = parame;
    this.userRepository = paramg;
    r<LoanOffersState> r1 = new r();
    this.mutableState = r1;
    this.state = (LiveData<LoanOffersState>)r1;
  }
  
  public final LiveData<LoanOffersState> getState() {
    return this.state;
  }
  
  public final void initialize() {
    c.a(c.a(this.userRepository.getApplicationId(), 0, new DataUploadViewModel$initialize$1(null), 1, null), x.a(this));
  }
  
  public static abstract class LoanOffersState {
    public LoanOffersState() {}
    
    public static final class Failure extends LoanOffersState {
      public final Throwable throwable;
      
      public Failure(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Loading extends LoanOffersState {
      public final boolean isLoading;
      
      public Loading(boolean param2Boolean) {
        super(null);
        this.isLoading = param2Boolean;
      }
      
      public final boolean isLoading() {
        return this.isLoading;
      }
    }
    
    public static final class Success extends LoanOffersState {
      public final List<c> loanOffers;
      
      public Success(List<c> param2List) {
        super(null);
        this.loanOffers = param2List;
      }
      
      public final List<c> getLoanOffers() {
        return this.loanOffers;
      }
    }
  }
  
  public static final class Failure extends LoanOffersState {
    public final Throwable throwable;
    
    public Failure(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Loading extends LoanOffersState {
    public final boolean isLoading;
    
    public Loading(boolean param1Boolean) {
      super(null);
      this.isLoading = param1Boolean;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
  }
  
  public static final class Success extends LoanOffersState {
    public final List<c> loanOffers;
    
    public Success(List<c> param1List) {
      super(null);
      this.loanOffers = param1List;
    }
    
    public final List<c> getLoanOffers() {
      return this.loanOffers;
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.DataUploadViewModel$initialize$1", f = "DataUploadViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class DataUploadViewModel$initialize$1 extends k implements p<String, d<? super a<? extends List<? extends c>>>, Object> {
    public int label;
    
    public String p$0;
    
    public DataUploadViewModel$initialize$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      DataUploadViewModel$initialize$1 dataUploadViewModel$initialize$1 = new DataUploadViewModel$initialize$1(param1d);
      dataUploadViewModel$initialize$1.p$0 = (String)param1Object;
      return (d<k>)dataUploadViewModel$initialize$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((DataUploadViewModel$initialize$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        return c.a(c.a(c.b(c.b(DataUploadViewModel.this.loanUseCase.a((String)param1Object), new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(null) {
                    public int label;
                    
                    public b p$;
                    
                    public Throwable p$0;
                    
                    public final d<k> create(b<? super List<c>> param1b, Throwable param1Throwable, d<? super k> param1d) {
                      k.b(param1b, "$this$create");
                      k.b(param1d, "continuation");
                      q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> q1 = new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
                      q1.p$ = param1b;
                      q1.p$0 = param1Throwable;
                      return (d)q1;
                    }
                    
                    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                      return ((null)create((b<? super List<c>>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
                    }
                    
                    public final Object invokeSuspend(Object param1Object) {
                      c.a();
                      if (this.label == 0) {
                        g.a(param1Object);
                        DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Loading(false));
                        return k.a;
                      } 
                      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                  }), new p<b<? super List<? extends c>>, d<? super k>, Object>(null) {
                  public int label;
                  
                  public b p$;
                  
                  public final d<k> create(Object param1Object, d<?> param1d) {
                    k.b(param1d, "completion");
                    p<b<? super List<? extends c>>, d<? super k>, Object> p1 = new p<b<? super List<? extends c>>, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
                    p1.p$ = (b)param1Object;
                    return (d)p1;
                  }
                  
                  public final Object invoke(Object param1Object1, Object param1Object2) {
                    return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
                  }
                  
                  public final Object invokeSuspend(Object param1Object) {
                    c.a();
                    if (this.label == 0) {
                      g.a(param1Object);
                      DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Loading(true));
                      return k.a;
                    } 
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                  }
                }), new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(null) {
                public int label;
                
                public b p$;
                
                public Throwable p$0;
                
                public final d<k> create(b<? super List<c>> param1b, Throwable param1Throwable, d<? super k> param1d) {
                  k.b(param1b, "$this$create");
                  k.b(param1Throwable, "it");
                  k.b(param1d, "continuation");
                  q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> q1 = new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
                  q1.p$ = param1b;
                  q1.p$0 = param1Throwable;
                  return (d)q1;
                }
                
                public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                  return ((null)create((b<? super List<c>>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
                }
                
                public final Object invokeSuspend(Object param1Object) {
                  c.a();
                  if (this.label == 0) {
                    g.a(param1Object);
                    param1Object = this.p$0;
                    DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Failure((Throwable)param1Object));
                    return k.a;
                  } 
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
              }), new p<List<? extends c>, d<? super k>, Object>(null) {
              public int label;
              
              public List p$0;
              
              public final d<k> create(Object param1Object, d<?> param1d) {
                k.b(param1d, "completion");
                p<List<? extends c>, d<? super k>, Object> p1 = new p<List<? extends c>, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
                p1.p$0 = (List)param1Object;
                return (d)p1;
              }
              
              public final Object invoke(Object param1Object1, Object param1Object2) {
                return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
              }
              
              public final Object invokeSuspend(Object param1Object) {
                c.a();
                if (this.label == 0) {
                  g.a(param1Object);
                  param1Object = this.p$0;
                  DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Success((List<c>)param1Object));
                  return k.a;
                } 
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              }
            });
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.DataUploadViewModel$initialize$1$1", f = "DataUploadViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public null(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super List<c>> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1d, "continuation");
      q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> q1 = new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
      q1.p$ = param1b;
      q1.p$0 = param1Throwable;
      return (d)q1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((null)create((b<? super List<c>>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Loading(false));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.DataUploadViewModel$initialize$1$2", f = "DataUploadViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements p<b<? super List<? extends c>>, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public null(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      p<b<? super List<? extends c>>, d<? super k>, Object> p1 = new p<b<? super List<? extends c>>, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
      p1.p$ = (b)param1Object;
      return (d)p1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Loading(true));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.DataUploadViewModel$initialize$1$3", f = "DataUploadViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public null(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super List<c>> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> q1 = new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
      q1.p$ = param1b;
      q1.p$0 = param1Throwable;
      return (d)q1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((null)create((b<? super List<c>>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Failure((Throwable)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.DataUploadViewModel$initialize$1$4", f = "DataUploadViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements p<List<? extends c>, d<? super k>, Object> {
    public int label;
    
    public List p$0;
    
    public null(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      p<List<? extends c>, d<? super k>, Object> p1 = new p<List<? extends c>, d<? super k>, Object>(DataUploadViewModel$initialize$1.this, param1d);
      p1.p$0 = (List)param1Object;
      return (d)p1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        DataUploadViewModel.this.mutableState.b(new DataUploadViewModel.LoanOffersState.Success((List<c>)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
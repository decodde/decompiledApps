package ng.com.fairmoney.android.loan.repayment;

public final class Loading extends HomeRepayAmountViewModel.HomeRepayAmountState {
  public final boolean loading;
  
  public Loading(int paramInt, boolean paramBoolean) {
    super(paramInt, null);
    this.loading = paramBoolean;
  }
  
  public final boolean getLoading() {
    return this.loading;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$HomeRepayAmountState$Loading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
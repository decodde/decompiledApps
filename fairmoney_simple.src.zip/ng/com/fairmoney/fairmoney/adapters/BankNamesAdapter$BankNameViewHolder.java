package ng.com.fairmoney.fairmoney.adapters;

import android.widget.LinearLayout;
import android.widget.TextView;

public class BankNameViewHolder {
  public LinearLayout linearLayout;
  
  public TextView tvName;
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BankNamesAdapter$BankNameViewHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
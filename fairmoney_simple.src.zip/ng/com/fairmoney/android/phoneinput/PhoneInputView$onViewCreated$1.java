package ng.com.fairmoney.android.phoneinput;

import android.view.View;

public final class PhoneInputView$onViewCreated$1 implements View.OnFocusChangeListener {
  public final void onFocusChange(View paramView, boolean paramBoolean) {
    PhoneInputView.access$displayArrow(PhoneInputView.this, paramBoolean);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputView$onViewCreated$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
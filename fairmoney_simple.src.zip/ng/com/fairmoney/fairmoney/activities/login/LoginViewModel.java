package ng.com.fairmoney.fairmoney.activities.login;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.f.b;
import f.d.b.f.e;
import f.d.b.k.f;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.g;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import javax.inject.Inject;
import k.a.d;
import k.a.e0;
import k.a.f0;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import k.a.q0;

public final class LoginViewModel extends w {
  public final LiveData<InAppMessageState> inAppMessage;
  
  public final b inAppMessagingUseCase;
  
  public final r<InAppMessageState> messageMutableLiveData;
  
  public final LiveData<f> phoneNumber;
  
  public final r<f> phoneNumberLiveData;
  
  public final h userUseCase;
  
  @Inject
  public LoginViewModel(b paramb, h paramh) {
    this.inAppMessagingUseCase = paramb;
    this.userUseCase = paramh;
    r<InAppMessageState> r1 = new r();
    this.messageMutableLiveData = r1;
    this.inAppMessage = (LiveData<InAppMessageState>)r1;
    r1 = new r();
    this.phoneNumberLiveData = (r)r1;
    this.phoneNumber = (LiveData)r1;
  }
  
  public final void fetchInAppMessage() {
    c.a(c.a(c.a(new LoginViewModel$fetchInAppMessage$$inlined$map$1(this.inAppMessagingUseCase.getMessage()), new LoginViewModel$fetchInAppMessage$2(null)), new LoginViewModel$fetchInAppMessage$3(null)), x.a(this));
  }
  
  public final void fetchPhoneNumber() {
    c.a(c.a(this.userUseCase.b(), new LoginViewModel$fetchPhoneNumber$1(null)), x.a(this));
  }
  
  public final LiveData<InAppMessageState> getInAppMessage() {
    return this.inAppMessage;
  }
  
  public final LiveData<f> getPhoneNumber() {
    return this.phoneNumber;
  }
  
  public final void savePhoneNumber(f paramf) {
    k.b(paramf, "phoneNumber");
    d.a(f0.a((g)q0.b()), null, null, new LoginViewModel$savePhoneNumber$1(paramf, null), 3, null);
  }
  
  public static abstract class InAppMessageState {
    public InAppMessageState() {}
    
    public static final class Empty extends InAppMessageState {
      public static final Empty INSTANCE = new Empty();
      
      public Empty() {
        super(null);
      }
    }
    
    public static final class Error extends InAppMessageState {
      public final Throwable throwable;
      
      public Error(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Success extends InAppMessageState {
      public final e inAppMessage;
      
      public Success(e param2e) {
        super(null);
        this.inAppMessage = param2e;
      }
      
      public final e getInAppMessage() {
        return this.inAppMessage;
      }
    }
  }
  
  public static final class Empty extends InAppMessageState {
    public static final Empty INSTANCE = new Empty();
    
    public Empty() {
      super(null);
    }
  }
  
  public static final class Error extends InAppMessageState {
    public final Throwable throwable;
    
    public Error(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Success extends InAppMessageState {
    public final e inAppMessage;
    
    public Success(e param1e) {
      super(null);
      this.inAppMessage = param1e;
    }
    
    public final e getInAppMessage() {
      return this.inAppMessage;
    }
  }
  
  public static final class LoginViewModel$fetchInAppMessage$$inlined$map$1 implements a<InAppMessageState> {
    public LoginViewModel$fetchInAppMessage$$inlined$map$1(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<e>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              if (param1Object != null) {
                param1Object = new LoginViewModel.InAppMessageState.Success((e)param1Object);
              } else {
                param1Object = LoginViewModel.InAppMessageState.Empty.INSTANCE;
              } 
              param1Object = b1.emit(param1Object, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<e> {
    public null(LoginViewModel$fetchInAppMessage$$inlined$map$1 param1LoginViewModel$fetchInAppMessage$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      if (param1Object != null) {
        param1Object = new LoginViewModel.InAppMessageState.Success((e)param1Object);
      } else {
        param1Object = LoginViewModel.InAppMessageState.Empty.INSTANCE;
      } 
      param1Object = b1.emit(param1Object, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.login.LoginViewModel$fetchInAppMessage$2", f = "LoginViewModel.kt", l = {33}, m = "invokeSuspend")
  public static final class LoginViewModel$fetchInAppMessage$2 extends k implements q<b<? super InAppMessageState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public LoginViewModel$fetchInAppMessage$2(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super LoginViewModel.InAppMessageState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      LoginViewModel$fetchInAppMessage$2 loginViewModel$fetchInAppMessage$2 = new LoginViewModel$fetchInAppMessage$2(param1d);
      loginViewModel$fetchInAppMessage$2.p$ = param1b;
      loginViewModel$fetchInAppMessage$2.p$0 = param1Throwable;
      return (d<k>)loginViewModel$fetchInAppMessage$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((LoginViewModel$fetchInAppMessage$2)create((b<? super LoginViewModel.InAppMessageState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        Throwable throwable = this.p$0;
        param1Object = new LoginViewModel.InAppMessageState.Error(throwable);
        this.L$0 = b1;
        this.L$1 = throwable;
        this.label = 1;
        if (b1.emit(param1Object, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.login.LoginViewModel$fetchInAppMessage$3", f = "LoginViewModel.kt", l = {39}, m = "invokeSuspend")
  public static final class LoginViewModel$fetchInAppMessage$3 extends k implements p<InAppMessageState, d<? super k>, Object> {
    public Object L$0;
    
    public int label;
    
    public LoginViewModel.InAppMessageState p$0;
    
    public LoginViewModel$fetchInAppMessage$3(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      LoginViewModel$fetchInAppMessage$3 loginViewModel$fetchInAppMessage$3 = new LoginViewModel$fetchInAppMessage$3(param1d);
      loginViewModel$fetchInAppMessage$3.p$0 = (LoginViewModel.InAppMessageState)param1Object;
      return (d<k>)loginViewModel$fetchInAppMessage$3;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LoginViewModel$fetchInAppMessage$3)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$0;
        LoginViewModel.this.messageMutableLiveData.b(param1Object);
        if (param1Object instanceof LoginViewModel.InAppMessageState.Success) {
          a a = c.a(LoginViewModel.this.inAppMessagingUseCase.a(((LoginViewModel.InAppMessageState.Success)param1Object).getInAppMessage().b()), new q<b<? super Boolean>, Throwable, d<? super k>, Object>(null) {
                public int label;
                
                public b p$;
                
                public Throwable p$0;
                
                public final d<k> create(b<? super Boolean> param1b, Throwable param1Throwable, d<? super k> param1d) {
                  k.b(param1b, "$this$create");
                  k.b(param1Throwable, "it");
                  k.b(param1d, "continuation");
                  q<b<? super Boolean>, Throwable, d<? super k>, Object> q1 = new q<b<? super Boolean>, Throwable, d<? super k>, Object>(param1d);
                  q1.p$ = param1b;
                  q1.p$0 = param1Throwable;
                  return (d)q1;
                }
                
                public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                  return ((null)create((b<? super Boolean>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
                }
                
                public final Object invokeSuspend(Object param1Object) {
                  c.a();
                  if (this.label == 0) {
                    g.a(param1Object);
                    return k.a;
                  } 
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
              });
          this.L$0 = param1Object;
          this.label = 1;
          if (c.a(a, (d)this) == object)
            return object; 
        } 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.login.LoginViewModel$fetchInAppMessage$3$1", f = "LoginViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements q<b<? super Boolean>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public null(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super Boolean> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      q<b<? super Boolean>, Throwable, d<? super k>, Object> q1 = new q<b<? super Boolean>, Throwable, d<? super k>, Object>(param1d);
      q1.p$ = param1b;
      q1.p$0 = param1Throwable;
      return (d)q1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((null)create((b<? super Boolean>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.login.LoginViewModel$fetchPhoneNumber$1", f = "LoginViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class LoginViewModel$fetchPhoneNumber$1 extends k implements p<f, d<? super k>, Object> {
    public int label;
    
    public f p$0;
    
    public LoginViewModel$fetchPhoneNumber$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      LoginViewModel$fetchPhoneNumber$1 loginViewModel$fetchPhoneNumber$1 = new LoginViewModel$fetchPhoneNumber$1(param1d);
      loginViewModel$fetchPhoneNumber$1.p$0 = (f)param1Object;
      return (d<k>)loginViewModel$fetchPhoneNumber$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LoginViewModel$fetchPhoneNumber$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        LoginViewModel.this.phoneNumberLiveData.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.login.LoginViewModel$savePhoneNumber$1", f = "LoginViewModel.kt", l = {65}, m = "invokeSuspend")
  public static final class LoginViewModel$savePhoneNumber$1 extends k implements p<e0, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public e0 p$;
    
    public LoginViewModel$savePhoneNumber$1(f param1f, d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      LoginViewModel$savePhoneNumber$1 loginViewModel$savePhoneNumber$1 = new LoginViewModel$savePhoneNumber$1(this.$phoneNumber, param1d);
      loginViewModel$savePhoneNumber$1.p$ = (e0)param1Object;
      return (d<k>)loginViewModel$savePhoneNumber$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LoginViewModel$savePhoneNumber$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$;
        a a = LoginViewModel.this.userUseCase.b(this.$phoneNumber);
        LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 loginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 = new LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1();
        this.L$0 = param1Object;
        this.L$1 = a;
        this.label = 1;
        if (a.collect(loginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
    
    public static final class LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 implements b<k> {
      public Object emit(Object param1Object, d param1d) {
        param1Object = param1Object;
        return k.a;
      }
    }
  }
  
  public static final class LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 implements b<k> {
    public Object emit(Object param1Object, d param1d) {
      param1Object = param1Object;
      return k.a;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
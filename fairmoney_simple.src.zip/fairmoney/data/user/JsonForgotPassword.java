package fairmoney.data.user;

import com.fairmoney.data.JsonAndroid;
import com.fairmoney.data.user.JsonAuthentication;
import j.q.d.k;

public final class JsonForgotPassword {
  public final JsonAndroid android;
  
  public final JsonAuthentication auth;
  
  public JsonForgotPassword(JsonAuthentication paramJsonAuthentication, JsonAndroid paramJsonAndroid) {
    this.auth = paramJsonAuthentication;
    this.android = paramJsonAndroid;
  }
  
  public final JsonAuthentication component1() {
    return this.auth;
  }
  
  public final JsonAndroid component2() {
    return this.android;
  }
  
  public final com.fairmoney.data.user.JsonForgotPassword copy(JsonAuthentication paramJsonAuthentication, JsonAndroid paramJsonAndroid) {
    k.b(paramJsonAuthentication, "auth");
    k.b(paramJsonAndroid, "android");
    return new com.fairmoney.data.user.JsonForgotPassword(paramJsonAuthentication, paramJsonAndroid);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.user.JsonForgotPassword) {
        paramObject = paramObject;
        if (k.a(this.auth, ((com.fairmoney.data.user.JsonForgotPassword)paramObject).auth) && k.a(this.android, ((com.fairmoney.data.user.JsonForgotPassword)paramObject).android))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final JsonAndroid getAndroid() {
    return this.android;
  }
  
  public final JsonAuthentication getAuth() {
    return this.auth;
  }
  
  public int hashCode() {
    byte b;
    JsonAuthentication jsonAuthentication = this.auth;
    int i = 0;
    if (jsonAuthentication != null) {
      b = jsonAuthentication.hashCode();
    } else {
      b = 0;
    } 
    JsonAndroid jsonAndroid = this.android;
    if (jsonAndroid != null)
      i = jsonAndroid.hashCode(); 
    return b * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonForgotPassword(auth=");
    stringBuilder.append(this.auth);
    stringBuilder.append(", android=");
    stringBuilder.append(this.android);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\dat\\user\JsonForgotPassword.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.injection;

import f.d.b.h.c;
import f.d.c.j;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DomainComponent_kycUseCase implements Provider<c> {
  public final j domainComponent;
  
  public com_fairmoney_injection_DomainComponent_kycUseCase(j paramj) {
    this.domainComponent = paramj;
  }
  
  public c get() {
    c c = this.domainComponent.a();
    g.a(c, "Cannot return null from a non-@Nullable component method");
    return c;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DomainComponent_kycUseCase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.repayment;

import f.d.b.j.b;

public final class Inbound extends HomeRepayAmountViewModel.HomeRepayAmountState {
  public final b inboundPaymentParams;
  
  public Inbound(int paramInt, b paramb) {
    super(paramInt, null);
    this.inboundPaymentParams = paramb;
  }
  
  public final b getInboundPaymentParams() {
    return this.inboundPaymentParams;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$HomeRepayAmountState$Inbound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
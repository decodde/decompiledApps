package ng.com.fairmoney.fairmoney.adapters;

import ng.com.fairmoney.fairmoney.models.Card;

public interface CardActionCallback {
  void deleteCard(Card paramCard);
  
  void setDefaultCard(Card paramCard);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CardAdapter$CardActionCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
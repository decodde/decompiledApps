package ng.com.fairmoney.fairmoney.activities.login;

import f.d.b.k.f;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import k.a.e0;
import k.a.h2.a;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.fairmoney.activities.login.LoginViewModel$savePhoneNumber$1", f = "LoginViewModel.kt", l = {65}, m = "invokeSuspend")
public final class LoginViewModel$savePhoneNumber$1 extends k implements p<e0, d<? super k>, Object> {
  public Object L$0;
  
  public Object L$1;
  
  public int label;
  
  public e0 p$;
  
  public LoginViewModel$savePhoneNumber$1(f paramf, d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    LoginViewModel$savePhoneNumber$1 loginViewModel$savePhoneNumber$1 = new LoginViewModel$savePhoneNumber$1(this.$phoneNumber, paramd);
    loginViewModel$savePhoneNumber$1.p$ = (e0)paramObject;
    return (d<k>)loginViewModel$savePhoneNumber$1;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((LoginViewModel$savePhoneNumber$1)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    Object object = c.a();
    int i = this.label;
    if (i != 0) {
      if (i == 1) {
        object = this.L$1;
        object = this.L$0;
        g.a(paramObject);
      } else {
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
    } else {
      g.a(paramObject);
      paramObject = this.p$;
      a a = LoginViewModel.access$getUserUseCase$p(LoginViewModel.this).b(this.$phoneNumber);
      LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 loginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 = new LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1();
      this.L$0 = paramObject;
      this.L$1 = a;
      this.label = 1;
      if (a.collect(loginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1, (d)this) == object)
        return object; 
    } 
    return k.a;
  }
  
  public static final class LoginViewModel$savePhoneNumber$1$invokeSuspend$$inlined$collect$1 implements b<k> {
    public Object emit(Object param1Object, d param1d) {
      param1Object = param1Object;
      return k.a;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel$savePhoneNumber$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.inversion;

import f.d.b.j.d;



/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\RouterImpl$WhenMappings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
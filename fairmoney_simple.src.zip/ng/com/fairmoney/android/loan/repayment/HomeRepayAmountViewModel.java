package ng.com.fairmoney.android.loan.repayment;

import androidx.lifecycle.LiveData;
import d.o.p;
import d.o.w;
import d.o.x;
import f.d.b.c;
import f.d.b.j.b;
import f.d.b.j.c;
import f.d.b.j.f;
import f.d.b.k.b;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import kotlin.NoWhenBranchMatchedException;

public final class HomeRepayAmountViewModel extends w {
  public final p<HomeRepayAmountState> mutableState;
  
  public final f paymentUseCase;
  
  public final c router;
  
  public final LiveData<HomeRepayAmountState> state;
  
  public final h userUseCase;
  
  @Inject
  public HomeRepayAmountViewModel(h paramh, c paramc, f paramf) {
    this.userUseCase = paramh;
    this.router = paramc;
    this.paymentUseCase = paramf;
    p<HomeRepayAmountState> p1 = new p();
    this.mutableState = p1;
    this.state = (LiveData<HomeRepayAmountState>)p1;
  }
  
  private final void onInboundPayment(int paramInt, c paramc) {
    c.a(c.a(c.b(c.b(c.a(c.a(this.userUseCase.getCountry(), 0, new HomeRepayAmountViewModel$onInboundPayment$1(paramc, paramInt, null), 1, null), new HomeRepayAmountViewModel$onInboundPayment$2(paramInt, null)), new HomeRepayAmountViewModel$onInboundPayment$3(paramInt, null)), new HomeRepayAmountViewModel$onInboundPayment$4(paramInt, null)), new HomeRepayAmountViewModel$onInboundPayment$5(null)), x.a(this));
  }
  
  public final LiveData<HomeRepayAmountState> getState() {
    return this.state;
  }
  
  public final void onCustomAmount(int paramInt) {
    onInboundPayment(paramInt, c.CUSTOM_AMOUNT);
  }
  
  public final void onFullRepayment(int paramInt) {
    onInboundPayment(paramInt, c.FULL_LOAN);
  }
  
  public final void onNextInstallment(int paramInt) {
    onInboundPayment(paramInt, c.NEXT_INSTALLMENT);
  }
  
  public static abstract class HomeRepayAmountState {
    public final int amountInCent;
    
    public HomeRepayAmountState(int param1Int) {
      this.amountInCent = param1Int;
    }
    
    public final int getAmountInCent() {
      return this.amountInCent;
    }
    
    public static final class CustomAmount extends HomeRepayAmountState {
      public CustomAmount(int param2Int) {
        super(param2Int, null);
      }
    }
    
    public static final class Error extends HomeRepayAmountState {
      public final Throwable exception;
      
      public Error(int param2Int, Throwable param2Throwable) {
        super(param2Int, null);
        this.exception = param2Throwable;
      }
      
      public final Throwable getException() {
        return this.exception;
      }
    }
    
    public static final class FullRepayment extends HomeRepayAmountState {
      public FullRepayment(int param2Int) {
        super(param2Int, null);
      }
    }
    
    public static final class Inbound extends HomeRepayAmountState {
      public final b inboundPaymentParams;
      
      public Inbound(int param2Int, b param2b) {
        super(param2Int, null);
        this.inboundPaymentParams = param2b;
      }
      
      public final b getInboundPaymentParams() {
        return this.inboundPaymentParams;
      }
    }
    
    public static final class Loading extends HomeRepayAmountState {
      public final boolean loading;
      
      public Loading(int param2Int, boolean param2Boolean) {
        super(param2Int, null);
        this.loading = param2Boolean;
      }
      
      public final boolean getLoading() {
        return this.loading;
      }
    }
    
    public static final class NextInstallment extends HomeRepayAmountState {
      public NextInstallment(int param2Int) {
        super(param2Int, null);
      }
    }
  }
  
  public static final class CustomAmount extends HomeRepayAmountState {
    public CustomAmount(int param1Int) {
      super(param1Int, null);
    }
  }
  
  public static final class Error extends HomeRepayAmountState {
    public final Throwable exception;
    
    public Error(int param1Int, Throwable param1Throwable) {
      super(param1Int, null);
      this.exception = param1Throwable;
    }
    
    public final Throwable getException() {
      return this.exception;
    }
  }
  
  public static final class FullRepayment extends HomeRepayAmountState {
    public FullRepayment(int param1Int) {
      super(param1Int, null);
    }
  }
  
  public static final class Inbound extends HomeRepayAmountState {
    public final b inboundPaymentParams;
    
    public Inbound(int param1Int, b param1b) {
      super(param1Int, null);
      this.inboundPaymentParams = param1b;
    }
    
    public final b getInboundPaymentParams() {
      return this.inboundPaymentParams;
    }
  }
  
  public static final class Loading extends HomeRepayAmountState {
    public final boolean loading;
    
    public Loading(int param1Int, boolean param1Boolean) {
      super(param1Int, null);
      this.loading = param1Boolean;
    }
    
    public final boolean getLoading() {
      return this.loading;
    }
  }
  
  public static final class NextInstallment extends HomeRepayAmountState {
    public NextInstallment(int param1Int) {
      super(param1Int, null);
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel$onInboundPayment$1", f = "HomeRepayAmountViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class HomeRepayAmountViewModel$onInboundPayment$1 extends k implements p<b, d<? super a<? extends HomeRepayAmountState>>, Object> {
    public int label;
    
    public b p$0;
    
    public HomeRepayAmountViewModel$onInboundPayment$1(c param1c, int param1Int, d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      HomeRepayAmountViewModel$onInboundPayment$1 homeRepayAmountViewModel$onInboundPayment$1 = new HomeRepayAmountViewModel$onInboundPayment$1(this.$inboundPaymentType, this.$amountInCent, param1d);
      homeRepayAmountViewModel$onInboundPayment$1.p$0 = (b)param1Object;
      return (d<k>)homeRepayAmountViewModel$onInboundPayment$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((HomeRepayAmountViewModel$onInboundPayment$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        if (k.a(this.p$0, b.b.h)) {
          param1Object = this.$inboundPaymentType;
          int i = HomeRepayAmountViewModel$WhenMappings.$EnumSwitchMapping$0[param1Object.ordinal()];
          if (i != 1) {
            if (i != 2) {
              if (i == 3) {
                param1Object = new HomeRepayAmountViewModel.HomeRepayAmountState.CustomAmount(this.$amountInCent);
              } else {
                throw new NoWhenBranchMatchedException();
              } 
            } else {
              param1Object = new HomeRepayAmountViewModel.HomeRepayAmountState.NextInstallment(this.$amountInCent);
            } 
          } else {
            param1Object = new HomeRepayAmountViewModel.HomeRepayAmountState.FullRepayment(this.$amountInCent);
          } 
          param1Object = c.a(param1Object);
        } else {
          param1Object = new HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1(this);
        } 
        return param1Object;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    public static final class HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 implements a<HomeRepayAmountViewModel.HomeRepayAmountState.Inbound> {
      public HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1(HomeRepayAmountViewModel$onInboundPayment$1 param1HomeRepayAmountViewModel$onInboundPayment$1) {}
      
      public Object collect(b param1b, d param1d) {
        Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
              public Object emit(Object param1Object, d param1d) {
                b b1 = this.$this_unsafeFlow$inlined;
                param1Object = param1Object;
                param1Object = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(HomeRepayAmountViewModel$onInboundPayment$1.this.$amountInCent, (b)param1Object), param1d);
                return (param1Object == c.a()) ? param1Object : k.a;
              }
            }param1d);
        return (object == c.a()) ? object : k.a;
      }
    }
    
    public static final class null implements b<b> {
      public null(HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 param1HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1) {}
      
      public Object emit(Object param1Object, d param1d) {
        b b1 = this.$this_unsafeFlow$inlined;
        param1Object = param1Object;
        param1Object = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(HomeRepayAmountViewModel$onInboundPayment$1.this.$amountInCent, (b)param1Object), param1d);
        return (param1Object == c.a()) ? param1Object : k.a;
      }
    }
  }
  
  public static final class HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 implements a<HomeRepayAmountState.Inbound> {
    public HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1(HomeRepayAmountViewModel$onInboundPayment$1 param1HomeRepayAmountViewModel$onInboundPayment$1) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              param1Object = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(HomeRepayAmountViewModel$onInboundPayment$1.this.$amountInCent, (b)param1Object), param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<b> {
    public null(HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 param1HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      param1Object = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(this.this$0.this$0.$amountInCent, (b)param1Object), param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel$onInboundPayment$2", f = "HomeRepayAmountViewModel.kt", l = {63}, m = "invokeSuspend")
  public static final class HomeRepayAmountViewModel$onInboundPayment$2 extends k implements q<b<? super HomeRepayAmountState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public HomeRepayAmountViewModel$onInboundPayment$2(int param1Int, d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super HomeRepayAmountViewModel.HomeRepayAmountState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      HomeRepayAmountViewModel$onInboundPayment$2 homeRepayAmountViewModel$onInboundPayment$2 = new HomeRepayAmountViewModel$onInboundPayment$2(this.$amountInCent, param1d);
      homeRepayAmountViewModel$onInboundPayment$2.p$ = param1b;
      homeRepayAmountViewModel$onInboundPayment$2.p$0 = param1Throwable;
      return (d<k>)homeRepayAmountViewModel$onInboundPayment$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((HomeRepayAmountViewModel$onInboundPayment$2)create((b<? super HomeRepayAmountViewModel.HomeRepayAmountState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        Throwable throwable = this.p$0;
        param1Object = new HomeRepayAmountViewModel.HomeRepayAmountState.Error(this.$amountInCent, throwable);
        this.L$0 = b1;
        this.L$1 = throwable;
        this.label = 1;
        if (b1.emit(param1Object, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel$onInboundPayment$3", f = "HomeRepayAmountViewModel.kt", l = {64}, m = "invokeSuspend")
  public static final class HomeRepayAmountViewModel$onInboundPayment$3 extends k implements p<b<? super HomeRepayAmountState>, d<? super k>, Object> {
    public Object L$0;
    
    public int label;
    
    public b p$;
    
    public HomeRepayAmountViewModel$onInboundPayment$3(int param1Int, d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      HomeRepayAmountViewModel$onInboundPayment$3 homeRepayAmountViewModel$onInboundPayment$3 = new HomeRepayAmountViewModel$onInboundPayment$3(this.$amountInCent, param1d);
      homeRepayAmountViewModel$onInboundPayment$3.p$ = (b)param1Object;
      return (d<k>)homeRepayAmountViewModel$onInboundPayment$3;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((HomeRepayAmountViewModel$onInboundPayment$3)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        param1Object = new HomeRepayAmountViewModel.HomeRepayAmountState.Loading(this.$amountInCent, true);
        this.L$0 = b1;
        this.label = 1;
        if (b1.emit(param1Object, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel$onInboundPayment$4", f = "HomeRepayAmountViewModel.kt", l = {65}, m = "invokeSuspend")
  public static final class HomeRepayAmountViewModel$onInboundPayment$4 extends k implements q<b<? super HomeRepayAmountState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public HomeRepayAmountViewModel$onInboundPayment$4(int param1Int, d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super HomeRepayAmountViewModel.HomeRepayAmountState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1d, "continuation");
      HomeRepayAmountViewModel$onInboundPayment$4 homeRepayAmountViewModel$onInboundPayment$4 = new HomeRepayAmountViewModel$onInboundPayment$4(this.$amountInCent, param1d);
      homeRepayAmountViewModel$onInboundPayment$4.p$ = param1b;
      homeRepayAmountViewModel$onInboundPayment$4.p$0 = param1Throwable;
      return (d<k>)homeRepayAmountViewModel$onInboundPayment$4;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((HomeRepayAmountViewModel$onInboundPayment$4)create((b<? super HomeRepayAmountViewModel.HomeRepayAmountState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$;
        Throwable throwable = this.p$0;
        HomeRepayAmountViewModel.HomeRepayAmountState.Loading loading = new HomeRepayAmountViewModel.HomeRepayAmountState.Loading(this.$amountInCent, false);
        this.L$0 = param1Object;
        this.L$1 = throwable;
        this.label = 1;
        if (param1Object.emit(loading, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel$onInboundPayment$5", f = "HomeRepayAmountViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class HomeRepayAmountViewModel$onInboundPayment$5 extends k implements p<HomeRepayAmountState, d<? super k>, Object> {
    public int label;
    
    public HomeRepayAmountViewModel.HomeRepayAmountState p$0;
    
    public HomeRepayAmountViewModel$onInboundPayment$5(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      HomeRepayAmountViewModel$onInboundPayment$5 homeRepayAmountViewModel$onInboundPayment$5 = new HomeRepayAmountViewModel$onInboundPayment$5(param1d);
      homeRepayAmountViewModel$onInboundPayment$5.p$0 = (HomeRepayAmountViewModel.HomeRepayAmountState)param1Object;
      return (d<k>)homeRepayAmountViewModel$onInboundPayment$5;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((HomeRepayAmountViewModel$onInboundPayment$5)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        HomeRepayAmountViewModel.this.mutableState.b(param1Object);
        if (param1Object instanceof HomeRepayAmountViewModel.HomeRepayAmountState.Inbound)
          HomeRepayAmountViewModel.this.router.toPayment(((HomeRepayAmountViewModel.HomeRepayAmountState.Inbound)param1Object).getInboundPaymentParams()); 
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
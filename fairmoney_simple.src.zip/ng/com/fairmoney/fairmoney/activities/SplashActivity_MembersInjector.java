package ng.com.fairmoney.fairmoney.activities;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class SplashActivity_MembersInjector implements a<SplashActivity> {
  public final Provider<y.b> factoryProvider;
  
  public SplashActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.factoryProvider = paramProvider;
  }
  
  public static a<SplashActivity> create(Provider<y.b> paramProvider) {
    return new SplashActivity_MembersInjector(paramProvider);
  }
  
  public static void injectFactory(SplashActivity paramSplashActivity, y.b paramb) {
    paramSplashActivity.factory = paramb;
  }
  
  public void injectMembers(SplashActivity paramSplashActivity) {
    injectFactory(paramSplashActivity, (y.b)this.factoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\SplashActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
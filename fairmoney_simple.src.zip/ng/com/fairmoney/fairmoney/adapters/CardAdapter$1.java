package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;
import ng.com.fairmoney.fairmoney.models.Card;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    CardAdapter.access$900(CardAdapter.this, vh, paramView, item);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CardAdapter$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
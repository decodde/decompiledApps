package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;
import f.d.b.k.b;

public final class CountryFlagAdapter$getCustomView$1 implements View.OnClickListener {
  public CountryFlagAdapter$getCustomView$1(b paramb) {}
  
  public final void onClick(View paramView) {
    CountryFlagAdapter.access$getOnCountrySelectedListener$p(CountryFlagAdapter.this).onCountrySelected(this.$country, CountryFlagAdapter.access$getIndicatorMapper$p(CountryFlagAdapter.this).a(this.$country), CountryFlagAdapter.access$getCountryMapper$p(CountryFlagAdapter.this).getFlagResource(this.$country));
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CountryFlagAdapter$getCustomView$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import d.b.k.d;

public abstract class BaseActivity extends d {
  public boolean isActivityActive = false;
  
  public boolean isAuthMandatory = true;
  
  public Toast toast;
  
  public Toolbar toolbar;
  
  private void requestPortraitOrientation() {
    setRequestedOrientation(1);
  }
  
  public void cancelToast() {
    Toast toast = this.toast;
    if (toast != null)
      toast.cancel(); 
  }
  
  public SharedPreferences getSharedPreferences() {
    return getSharedPreferences("CurrentUser", 0);
  }
  
  public void hideKeyboardFrom(View paramView) {
    InputMethodManager inputMethodManager = (InputMethodManager)getSystemService("input_method");
    if (inputMethodManager != null)
      inputMethodManager.hideSoftInputFromWindow(paramView.getWindowToken(), 0); 
  }
  
  public boolean isActivityActive() {
    return this.isActivityActive;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(provideContentViewId());
    Toolbar toolbar = (Toolbar)findViewById(2131297036);
    this.toolbar = toolbar;
    if (toolbar != null)
      setSupportActionBar(toolbar); 
    requestPortraitOrientation();
    this.isActivityActive = true;
  }
  
  public void onPause() {
    super.onPause();
    this.isActivityActive = false;
  }
  
  public void onPostResume() {
    super.onPostResume();
    this.isActivityActive = true;
  }
  
  public void onResume() {
    super.onResume();
    if (this.isAuthMandatory && getSharedPreferences("CurrentUser", 0).getString("AuthToken", "").contentEquals("")) {
      startActivity(new Intent(getApplicationContext(), WelcomeActivity.class));
      finish();
    } 
  }
  
  public abstract int provideContentViewId();
  
  public void showNewToastMessage(String paramString, int paramInt) {
    Toast toast2 = this.toast;
    if (toast2 != null)
      toast2.cancel(); 
    Toast toast1 = Toast.makeText((Context)this, paramString, paramInt);
    this.toast = toast1;
    toast1.show();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\BaseActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
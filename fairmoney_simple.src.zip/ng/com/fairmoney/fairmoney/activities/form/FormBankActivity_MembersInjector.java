package ng.com.fairmoney.fairmoney.activities.form;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class FormBankActivity_MembersInjector implements a<FormBankActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public FormBankActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<FormBankActivity> create(Provider<y.b> paramProvider) {
    return new FormBankActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(FormBankActivity paramFormBankActivity, y.b paramb) {
    paramFormBankActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(FormBankActivity paramFormBankActivity) {
    injectViewModelFactory(paramFormBankActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
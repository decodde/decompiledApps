package ng.com.fairmoney.android.loan.bankdetails;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

@f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$2", f = "BankDetailsViewModel.kt", l = {}, m = "invokeSuspend")
public final class BankDetailsViewModel$onClickNext$2 extends k implements p<BankDetailsViewModel.BankDetailsState, d<? super a<? extends BankDetailsViewModel.BankDetailsState>>, Object> {
  public int label;
  
  public BankDetailsViewModel.BankDetailsState p$0;
  
  public BankDetailsViewModel$onClickNext$2(String paramString1, String paramString2, d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    BankDetailsViewModel$onClickNext$2 bankDetailsViewModel$onClickNext$2 = new BankDetailsViewModel$onClickNext$2(this.$bankAccount, this.$ifsc, paramd);
    bankDetailsViewModel$onClickNext$2.p$0 = (BankDetailsViewModel.BankDetailsState)paramObject;
    return (d<k>)bankDetailsViewModel$onClickNext$2;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((BankDetailsViewModel$onClickNext$2)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      if (k.a(paramObject, BankDetailsViewModel.BankDetailsState.Success.INSTANCE)) {
        paramObject = new BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1(BankDetailsViewModel.access$getLoanUseCase$p(BankDetailsViewModel.this).a(this.$bankAccount, this.$ifsc));
      } else {
        paramObject = c.a(paramObject);
      } 
      return paramObject;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
  
  public static final class BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1 implements a<BankDetailsViewModel.BankDetailsState.Success> {
    public BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<k>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              param1Object = b1.emit(BankDetailsViewModel.BankDetailsState.Success.INSTANCE, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<k> {
    public null(BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1 param1BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      param1Object = b1.emit(BankDetailsViewModel.BankDetailsState.Success.INSTANCE, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$onClickNext$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
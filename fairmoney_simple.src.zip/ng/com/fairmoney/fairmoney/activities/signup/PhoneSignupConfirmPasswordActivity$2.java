package ng.com.fairmoney.fairmoney.activities.signup;

import android.content.Context;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class null implements APIResponse<Object> {
  public void failure(int paramInt, String paramString) {
    PhoneSignupConfirmPasswordActivity.this.logSignupResult("Phone", false);
    PhoneSignupConfirmPasswordActivity.this.showNewToastMessage(paramString, 0);
    PhoneSignupConfirmPasswordActivity.this.makeButtonEnabled(true);
  }
  
  public void success(Object paramObject) {
    PhoneSignupConfirmPasswordActivity.this.logSignupResult("Phone", true);
    PhoneSignupConfirmPasswordActivity.this.logLoginResult("Phone", true);
    paramObject = new Event("application", "phoneLogin");
    Tracking.sendUniqueEvent((Context)PhoneSignupConfirmPasswordActivity.this, (Event)paramObject);
    PhoneSignupConfirmPasswordActivity.this.goToNextScreen(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupConfirmPasswordActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.injection;

import f.d.b.i.e;
import f.d.c.j;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DomainComponent_loanUseCase implements Provider<e> {
  public final j domainComponent;
  
  public com_fairmoney_injection_DomainComponent_loanUseCase(j paramj) {
    this.domainComponent = paramj;
  }
  
  public e get() {
    e e = this.domainComponent.f();
    g.a(e, "Cannot return null from a non-@Nullable component method");
    return e;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DomainComponent_loanUseCase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
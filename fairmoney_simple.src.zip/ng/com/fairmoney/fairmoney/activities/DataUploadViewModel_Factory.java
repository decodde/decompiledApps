package ng.com.fairmoney.fairmoney.activities;

import f.d.b.i.e;
import f.d.b.k.g;
import g.b.d;
import javax.inject.Provider;

public final class DataUploadViewModel_Factory implements d<DataUploadViewModel> {
  public final Provider<e> loanUseCaseProvider;
  
  public final Provider<g> userRepositoryProvider;
  
  public DataUploadViewModel_Factory(Provider<e> paramProvider, Provider<g> paramProvider1) {
    this.loanUseCaseProvider = paramProvider;
    this.userRepositoryProvider = paramProvider1;
  }
  
  public static DataUploadViewModel_Factory create(Provider<e> paramProvider, Provider<g> paramProvider1) {
    return new DataUploadViewModel_Factory(paramProvider, paramProvider1);
  }
  
  public static DataUploadViewModel newInstance(e parame, g paramg) {
    return new DataUploadViewModel(parame, paramg);
  }
  
  public DataUploadViewModel get() {
    return newInstance((e)this.loanUseCaseProvider.get(), (g)this.userRepositoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
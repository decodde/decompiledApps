package ng.com.fairmoney.fairmoney.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.c.a.a;
import f.d.b.i.c;
import f.d.c.b;
import javax.inject.Inject;
import l.a.a.a.a.c;
import l.a.a.a.a.d;
import l.a.a.a.a.e;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.models.LoanAccepted;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class FinalLoanOfferActivity extends LoanOfferActivity {
  public Button btAcceptLoan;
  
  @Inject
  public y.b factory;
  
  public c loanOffer;
  
  public TextView tvDeclineLoan;
  
  public FinalLoanOfferViewModel viewModel;
  
  private void displayLoanOffer() {
    displayLoanOfferDetails(this.loanOffer);
    enableAnswers(true);
  }
  
  private void goToHomeActivity(LoanAccepted paramLoanAccepted) {
    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
    intent.putExtra("accessCode", (Parcelable)paramLoanAccepted);
    startActivity(intent);
    cancelDialog();
    finish();
  }
  
  private void initView() {
    this.btAcceptLoan = (Button)findViewById(2131296370);
    TextView textView = (TextView)findViewById(2131296382);
    this.tvDeclineLoan = textView;
    textView.setOnClickListener((View.OnClickListener)new d(this));
    this.btAcceptLoan.setOnClickListener((View.OnClickListener)new c(this));
  }
  
  private void observeFinalLoanOffer() {
    this.viewModel.getState().a((l)this, (s)new e(this));
  }
  
  public void acceptLoanOffer() {
    enableAnswers(false);
    this.progressDialog = ProgressDialog.show((Context)this, getString(2131821087), getString(2131820573));
    Tracking.sendUniqueClickEvent((Context)this, "ACCEPT");
    RetrofitSession.getInstance((Context)this).getLoanManager().acceptLoanOffer(new APIResponse<LoanAccepted>() {
          public void failure(int param1Int, String param1String) {
            FinalLoanOfferActivity.this.showNewToastMessage(param1String, 1);
            FinalLoanOfferActivity.this.cancelDialog();
            FinalLoanOfferActivity.this.enableAnswers(true);
          }
          
          public void success(LoanAccepted param1LoanAccepted) {
            FinalLoanOfferActivity finalLoanOfferActivity;
            if (param1LoanAccepted.getStatus().contentEquals("card_connection") && param1LoanAccepted.getCardConnectionPaystackAccessCode() == null) {
              a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)FinalLoanOfferActivity.this, "Null access code in acceptLoanOffer")));
              FinalLoanOfferActivity.this.enableAnswers(true);
              finalLoanOfferActivity = FinalLoanOfferActivity.this;
              finalLoanOfferActivity.showNewToastMessage(finalLoanOfferActivity.getString(2131820796), 1);
              return;
            } 
            FinalLoanOfferActivity.this.getSharedPreferences("CurrentUser", 0).edit().putString("cardConnectionAccessCode", finalLoanOfferActivity.getCardConnectionPaystackAccessCode()).putBoolean("needCardConnection", finalLoanOfferActivity.getStatus().contentEquals("card_connection")).apply();
            FinalLoanOfferActivity.this.cancelDialog();
            FinalLoanOfferActivity.this.goToHomeActivity((LoanAccepted)finalLoanOfferActivity);
          }
        });
  }
  
  public void enableAnswers(boolean paramBoolean) {
    this.btAcceptLoan.setEnabled(paramBoolean);
    this.tvDeclineLoan.setEnabled(paramBoolean);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    initView();
    FairMoney.incrementIdlingResource();
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.viewModel = (FinalLoanOfferViewModel)z.a((d)this, this.factory).a(FinalLoanOfferViewModel.class);
    observeFinalLoanOffer();
    this.viewModel.initialize();
  }
  
  public void onOfferDeclinedResponse() {
    startActivity(new Intent(getApplicationContext(), OfferDeclinedActivity.class));
    cancelDialog();
    finish();
  }
  
  public int provideContentViewId() {
    return 2131492893;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\FinalLoanOfferActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.home.card;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;

@f(c = "ng.com.fairmoney.android.home.card.EarlyRepaymentCardViewModel$initialize$2", f = "EarlyRepaymentCardViewModel.kt", l = {}, m = "invokeSuspend")
public final class EarlyRepaymentCardViewModel$initialize$2 extends k implements p<EarlyRepaymentCardViewModel.EarlyRepaymentSate, d<? super k>, Object> {
  public int label;
  
  public EarlyRepaymentCardViewModel.EarlyRepaymentSate p$0;
  
  public EarlyRepaymentCardViewModel$initialize$2(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    EarlyRepaymentCardViewModel$initialize$2 earlyRepaymentCardViewModel$initialize$2 = new EarlyRepaymentCardViewModel$initialize$2(paramd);
    earlyRepaymentCardViewModel$initialize$2.p$0 = (EarlyRepaymentCardViewModel.EarlyRepaymentSate)paramObject;
    return (d<k>)earlyRepaymentCardViewModel$initialize$2;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((EarlyRepaymentCardViewModel$initialize$2)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      EarlyRepaymentCardViewModel.access$getMutableState$p(EarlyRepaymentCardViewModel.this).b(paramObject);
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardViewModel$initialize$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
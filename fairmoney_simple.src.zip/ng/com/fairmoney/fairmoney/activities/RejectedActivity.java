package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.d.c.b;
import javax.inject.Inject;
import l.a.a.a.a.q;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.loan.rejected.RejectedViewModel;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class RejectedActivity extends BaseActivity {
  @Inject
  public y.b factory;
  
  public RejectedViewModel viewModel;
  
  private void observeImageVisibility() {
    this.viewModel.getImageVisibility().a((l)this, (s)new q(this));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.viewModel = (RejectedViewModel)z.a((d)this, this.factory).a(RejectedViewModel.class);
    observeImageVisibility();
    ((Button)findViewById(2131296391)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            RejectedActivity.this.startActivity(new Intent((Context)RejectedActivity.this, HomeActivity.class));
            RejectedActivity.this.finish();
          }
        });
    ((Button)findViewById(2131296392)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            RejectedActivity.this.startActivity(new Intent((Context)RejectedActivity.this, LoanOfferRejectedReasonsActivity.class));
          }
        });
    Tracking.sendUniqueEvent((Context)this, new Event("form", "noLoanOffer"));
    this.viewModel.initialize();
  }
  
  public int provideContentViewId() {
    return 2131492908;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\RejectedActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
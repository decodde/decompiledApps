package ng.com.fairmoney.android.phoneinput;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.widget.EditText;
import f.d.c.b;
import j.e;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.textwatcher.PhoneNumberTextWatcher;

public final class IndianPhoneNumberTextWatcher implements PhoneNumberTextWatcher {
  public int after;
  
  public final EditText etPhone;
  
  public boolean formatting;
  
  @Inject
  public IndianPhoneNumberViewModel viewModel;
  
  public IndianPhoneNumberTextWatcher(Context paramContext, EditText paramEditText) {
    this.etPhone = paramEditText;
    paramContext = paramContext.getApplicationContext();
    if (paramContext != null) {
      ViewModelComponentKt.create((b)paramContext).inject(this);
      this.etPhone.setFilters(new InputFilter[] { (InputFilter)new InputFilter.LengthFilter(IndianPhoneNumberViewModel.Companion.getMaxLength()) });
      return;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  private final void transformText(Editable paramEditable) {
    int i = this.etPhone.getSelectionStart();
    IndianPhoneNumberViewModel indianPhoneNumberViewModel = this.viewModel;
    if (indianPhoneNumberViewModel != null) {
      EditedPhoneNumber editedPhoneNumber = indianPhoneNumberViewModel.transformText(new e(paramEditable.toString(), Integer.valueOf(i)));
      this.etPhone.setFilters(new InputFilter[] { (InputFilter)new InputFilter.LengthFilter(editedPhoneNumber.getMaxLength()) });
      this.etPhone.setText(editedPhoneNumber.getEditedPhone());
      this.etPhone.setSelection(editedPhoneNumber.getCursorPos());
      return;
    } 
    k.d("viewModel");
    throw null;
  }
  
  public void afterTextChanged(Editable paramEditable) {
    k.b(paramEditable, "editable");
    formatPhoneNumber(paramEditable, false);
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    this.after = paramInt3;
  }
  
  public void formatPhoneNumber(Editable paramEditable, boolean paramBoolean) {
    k.b(paramEditable, "editable");
    if (!this.formatting) {
      this.formatting = true;
      if (paramBoolean || this.after != 0)
        transformText(paramEditable); 
      this.formatting = false;
    } 
  }
  
  public final IndianPhoneNumberViewModel getViewModel() {
    IndianPhoneNumberViewModel indianPhoneNumberViewModel = this.viewModel;
    if (indianPhoneNumberViewModel != null)
      return indianPhoneNumberViewModel; 
    k.d("viewModel");
    throw null;
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public final void setViewModel(IndianPhoneNumberViewModel paramIndianPhoneNumberViewModel) {
    k.b(paramIndianPhoneNumberViewModel, "<set-?>");
    this.viewModel = paramIndianPhoneNumberViewModel;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\IndianPhoneNumberTextWatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
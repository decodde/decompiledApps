package ng.com.fairmoney.fairmoney.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;
import ng.com.fairmoney.fairmoney.models.BankListItem;

public class BankNamesAdapter extends BaseAdapter implements Filterable {
  public Context context;
  
  public List<BankListItem> list;
  
  public BankNamesAdapter(Context paramContext, List<BankListItem> paramList) {
    this.context = paramContext;
    this.list = paramList;
  }
  
  public int getCount() {
    return this.list.size();
  }
  
  public Filter getFilter() {
    return new Filter() {
        public Filter.FilterResults performFiltering(CharSequence param1CharSequence) {
          return null;
        }
        
        public void publishResults(CharSequence param1CharSequence, Filter.FilterResults param1FilterResults) {}
      };
  }
  
  public Object getItem(int paramInt) {
    return this.list.get(paramInt);
  }
  
  public long getItemId(int paramInt) {
    return 0L;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    BankNameViewHolder bankNameViewHolder1;
    BankNameViewHolder bankNameViewHolder2;
    LayoutInflater layoutInflater = (LayoutInflater)this.context.getSystemService("layout_inflater");
    BankNameViewHolder bankNameViewHolder3 = new BankNameViewHolder();
    if (paramView == null) {
      View view = layoutInflater.inflate(2131492924, paramViewGroup, false);
      bankNameViewHolder3.linearLayout = (LinearLayout)view.findViewById(2131296680);
      bankNameViewHolder3.tvName = (TextView)view.findViewById(2131297058);
      view.setTag(bankNameViewHolder3);
      bankNameViewHolder1 = bankNameViewHolder3;
    } else {
      bankNameViewHolder3 = (BankNameViewHolder)bankNameViewHolder1.getTag();
      bankNameViewHolder2 = bankNameViewHolder1;
      bankNameViewHolder1 = bankNameViewHolder3;
    } 
    bankNameViewHolder1.tvName.setText(((BankListItem)this.list.get(paramInt)).getName());
    if (((BankListItem)this.list.get(paramInt)).isEnabled()) {
      bankNameViewHolder1.linearLayout.setBackgroundColor(bankNameViewHolder2.getResources().getColor(2131099916));
      bankNameViewHolder1.tvName.setTextColor(this.context.getResources().getColor(2131099680));
      bankNameViewHolder1.tvName.setTypeface(null, 0);
    } else {
      bankNameViewHolder1.linearLayout.setBackgroundColor(bankNameViewHolder2.getResources().getColor(2131099876));
      bankNameViewHolder1.tvName.setTextColor(this.context.getResources().getColor(2131099914));
      bankNameViewHolder1.tvName.setTypeface(null, 2);
    } 
    return (View)bankNameViewHolder2;
  }
  
  public static class BankNameViewHolder {
    public LinearLayout linearLayout;
    
    public TextView tvName;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BankNamesAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
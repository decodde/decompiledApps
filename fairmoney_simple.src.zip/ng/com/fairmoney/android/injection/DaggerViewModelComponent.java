package ng.com.fairmoney.android.injection;

import android.app.Application;
import d.o.w;
import d.o.y;
import f.d.b.b;
import f.d.b.c;
import f.d.b.d.a;
import f.d.b.e.a.a;
import f.d.b.f.b;
import f.d.b.g.a;
import f.d.b.h.c;
import f.d.b.i.e;
import f.d.b.j.f;
import f.d.b.k.d;
import f.d.b.k.g;
import f.d.b.k.h;
import f.d.c.c;
import f.d.c.i;
import f.d.c.j;
import f.d.c.k;
import g.b.c;
import g.b.f;
import g.b.g;
import java.util.Map;
import javax.inject.Provider;
import ng.com.fairmoney.android.home.card.EarlyRepaymentCardView;
import ng.com.fairmoney.android.home.card.EarlyRepaymentCardViewModel;
import ng.com.fairmoney.android.home.card.EarlyRepaymentCardViewModel_Factory;
import ng.com.fairmoney.android.home.card.EarlyRepaymentCardView_MembersInjector;
import ng.com.fairmoney.android.loan.bankdetails.BankDetailsActivity;
import ng.com.fairmoney.android.loan.bankdetails.BankDetailsActivity_MembersInjector;
import ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel;
import ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel_Factory;
import ng.com.fairmoney.android.loan.form.guarantor.FormGuarantorViewModel;
import ng.com.fairmoney.android.loan.form.guarantor.FormGuarantorViewModel_Factory;
import ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel;
import ng.com.fairmoney.android.loan.form.personal.FormPersonalViewModel_Factory;
import ng.com.fairmoney.android.loan.form.work.view.FormWorkViewModel;
import ng.com.fairmoney.android.loan.form.work.view.FormWorkViewModel_Factory;
import ng.com.fairmoney.android.loan.form.work.view.ProfessionalMapper;
import ng.com.fairmoney.android.loan.form.work.view.ProfessionalMapper_Factory;
import ng.com.fairmoney.android.loan.offer.LoanOfferDetailsView;
import ng.com.fairmoney.android.loan.offer.LoanOfferDetailsViewModel;
import ng.com.fairmoney.android.loan.offer.LoanOfferDetailsViewModel_Factory;
import ng.com.fairmoney.android.loan.offer.LoanOfferDetailsView_MembersInjector;
import ng.com.fairmoney.android.loan.offers.LoanOffersViewModel;
import ng.com.fairmoney.android.loan.offers.LoanOffersViewModel_Factory;
import ng.com.fairmoney.android.loan.rejected.RejectedViewModel;
import ng.com.fairmoney.android.loan.rejected.RejectedViewModel_Factory;
import ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel;
import ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel_Factory;
import ng.com.fairmoney.android.loan.repayment.methods.RepaymentMethodsViewModel;
import ng.com.fairmoney.android.loan.repayment.methods.RepaymentMethodsViewModel_Factory;
import ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel;
import ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel_Factory;
import ng.com.fairmoney.android.loan.transfer.LoanTransferFragment;
import ng.com.fairmoney.android.loan.transfer.LoanTransferFragment_MembersInjector;
import ng.com.fairmoney.android.loan.transfer.LoanTransferViewModel;
import ng.com.fairmoney.android.loan.transfer.LoanTransferViewModel_Factory;
import ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel;
import ng.com.fairmoney.android.login.forgot.ForgotPasswordEnterOtpViewModel_Factory;
import ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel;
import ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel_Factory;
import ng.com.fairmoney.android.login.signup.PhoneSignupViewModel;
import ng.com.fairmoney.android.login.signup.PhoneSignupViewModel_Factory;
import ng.com.fairmoney.android.otp.VerifyOtpViewModel;
import ng.com.fairmoney.android.otp.VerifyOtpViewModel_Factory;
import ng.com.fairmoney.android.payment.history.PaymentHistoryFragment;
import ng.com.fairmoney.android.payment.history.PaymentHistoryFragment_MembersInjector;
import ng.com.fairmoney.android.payment.history.PaymentHistoryViewModel;
import ng.com.fairmoney.android.payment.history.PaymentHistoryViewModel_Factory;
import ng.com.fairmoney.android.phoneinput.IndianPhoneNumberTextWatcher;
import ng.com.fairmoney.android.phoneinput.IndianPhoneNumberTextWatcher_MembersInjector;
import ng.com.fairmoney.android.phoneinput.IndianPhoneNumberViewModel;
import ng.com.fairmoney.android.phoneinput.NigerianPhoneNumberTextWatcher;
import ng.com.fairmoney.android.phoneinput.NigerianPhoneNumberTextWatcher_MembersInjector;
import ng.com.fairmoney.android.phoneinput.NigerianPhoneNumberViewModel;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;
import ng.com.fairmoney.android.phoneinput.PhoneInputViewModel;
import ng.com.fairmoney.android.phoneinput.PhoneInputViewModel_Factory;
import ng.com.fairmoney.android.phoneinput.PhoneInputView_MembersInjector;
import ng.com.fairmoney.android.splash.SplashViewModel;
import ng.com.fairmoney.android.splash.SplashViewModel_Factory;
import ng.com.fairmoney.fairmoney.activities.BaseHomeActivity;
import ng.com.fairmoney.fairmoney.activities.BaseHomeActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.DataUploadActivity;
import ng.com.fairmoney.fairmoney.activities.DataUploadActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.DataUploadViewModel;
import ng.com.fairmoney.fairmoney.activities.DataUploadViewModel_Factory;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferActivity;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferViewModel;
import ng.com.fairmoney.fairmoney.activities.FinalLoanOfferViewModel_Factory;
import ng.com.fairmoney.fairmoney.activities.LoanOffersActivity;
import ng.com.fairmoney.fairmoney.activities.LoanOffersActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.RejectedActivity;
import ng.com.fairmoney.fairmoney.activities.RejectedActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.SplashActivity;
import ng.com.fairmoney.fairmoney.activities.SplashActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.forgotpassword.ForgotPasswordActivity;
import ng.com.fairmoney.fairmoney.activities.forgotpassword.ForgotPasswordActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.forgotpassword.ForgotPasswordConfirmPasswordActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormBankActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormBankActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.form.FormFinancialKycActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormFinancialKycActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.form.FormGuarantorActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormGuarantorActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.form.FormLoanPurposeActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormLoanPurposeActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.form.FormPersonalActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormPersonalActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.form.FormWorkActivity;
import ng.com.fairmoney.fairmoney.activities.form.FormWorkActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.form.PermissionsActivity;
import ng.com.fairmoney.fairmoney.activities.form.PermissionsActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.login.LoginActivity;
import ng.com.fairmoney.fairmoney.activities.login.LoginActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.activities.login.LoginViewModel;
import ng.com.fairmoney.fairmoney.activities.login.LoginViewModel_Factory;
import ng.com.fairmoney.fairmoney.activities.signup.PhoneSignupActivity;
import ng.com.fairmoney.fairmoney.activities.signup.PhoneSignupActivity_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.VerifyOtpBaseFragment;
import ng.com.fairmoney.fairmoney.fragments.VerifyOtpBaseFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.forgotpassword.ForgotPasswordEnterOtpFragment;
import ng.com.fairmoney.fairmoney.fragments.forgotpassword.ForgotPasswordEnterOtpFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.form.BvnVerificationFragment;
import ng.com.fairmoney.fairmoney.fragments.form.BvnVerificationFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.home.BankAndCardsFragment;
import ng.com.fairmoney.fairmoney.fragments.home.BankAndCardsFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.home.BillChoosePaymentMethodFragment;
import ng.com.fairmoney.fairmoney.fragments.home.BillChoosePaymentMethodFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.home.BillOtherCardPaymentFragment;
import ng.com.fairmoney.fairmoney.fragments.home.CardConnectionFragment;
import ng.com.fairmoney.fairmoney.fragments.home.CardConnectionFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.home.HomeCardRepaymentFragment;
import ng.com.fairmoney.fairmoney.fragments.home.HomeCardRepaymentFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.home.HomeRepayAmountFragment;
import ng.com.fairmoney.fairmoney.fragments.home.HomeRepayAmountFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.home.HomeRepaymentMethodFragment;
import ng.com.fairmoney.fairmoney.fragments.home.HomeRepaymentMethodFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.fragments.loanoffer.LoanOfferDetailsFragment;
import ng.com.fairmoney.fairmoney.fragments.loanoffer.LoanOfferDetailsFragmentViewModel;
import ng.com.fairmoney.fairmoney.fragments.loanoffer.LoanOfferDetailsFragmentViewModel_Factory;
import ng.com.fairmoney.fairmoney.fragments.loanoffer.LoanOfferDetailsFragment_MembersInjector;
import ng.com.fairmoney.fairmoney.utils.IndianPhoneNumberFormatter_Factory;
import ng.com.fairmoney.fairmoney.utils.NigerianPhoneNumberFormatter_Factory;
import ng.com.fairmoney.fairmoney.utils.PhoneNumberFormatter;
import ng.com.fairmoney.fairmoney.utils.PhoneNumberFormatter_Factory;
import ng.com.fairmoney.fairmoney.viewmodels.BvnVerificationViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.BvnVerificationViewModel_Factory;
import ng.com.fairmoney.fairmoney.viewmodels.CardViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.CardViewModel_Factory;
import ng.com.fairmoney.fairmoney.viewmodels.FormBankViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.FormBankViewModel_Factory;
import ng.com.fairmoney.fairmoney.viewmodels.FormFinancialKycViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.FormFinancialKycViewModel_Factory;
import ng.com.fairmoney.fairmoney.viewmodels.FormLoanPurposeViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.FormLoanPurposeViewModel_Factory;
import ng.com.fairmoney.fairmoney.viewmodels.HomeViewModel;
import ng.com.fairmoney.fairmoney.viewmodels.HomeViewModel_Factory;

public final class DaggerViewModelComponent implements ViewModelComponent {
  public Provider<Application> applicationProvider;
  
  public Provider<BankDetailsViewModel> bankDetailsViewModelProvider;
  
  public Provider<w> bindBankDetailsViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindBvnVerificationViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindCardViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindDataUploadViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindEarlyRepaymentCardViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindFinalLoanOfferViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindForgotPasswordEnterOtpViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindForgotPasswordViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindFormBankViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindFormFinancialKYCViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindFormGuarantorViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindFormLoanPurposeViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindFormViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindFormWorkViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindHomeRepayAmountViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindHomeViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindLoanOfferDetailsFragmentViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindLoanOfferDetailsViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindLoanOffersViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindLoanTransferViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindLoginViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindPaymentHistoryViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindPhoneInputViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindPhoneSignupViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindRejectedViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindRepaymentMethodsViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindSplashViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindTermsOfUseViewModel$app_prodReleaseProvider;
  
  public Provider<w> bindVerifyOtpViewModel$app_prodReleaseProvider;
  
  public Provider<BvnVerificationViewModel> bvnVerificationViewModelProvider;
  
  public Provider<a> countryUseCaseProvider;
  
  public Provider<DataUploadViewModel> dataUploadViewModelProvider;
  
  public Provider<EarlyRepaymentCardViewModel> earlyRepaymentCardViewModelProvider;
  
  public Provider<a> featuresProvider;
  
  public Provider<FinalLoanOfferViewModel> finalLoanOfferViewModelProvider;
  
  public Provider<ForgotPasswordEnterOtpViewModel> forgotPasswordEnterOtpViewModelProvider;
  
  public Provider<ForgotPasswordViewModel> forgotPasswordViewModelProvider;
  
  public Provider<FormBankViewModel> formBankViewModelProvider;
  
  public Provider<FormFinancialKycViewModel> formFinancialKycViewModelProvider;
  
  public Provider<FormGuarantorViewModel> formGuarantorViewModelProvider;
  
  public Provider<FormLoanPurposeViewModel> formLoanPurposeViewModelProvider;
  
  public Provider<FormPersonalViewModel> formPersonalViewModelProvider;
  
  public Provider<a> formRepositoryProvider;
  
  public Provider<FormWorkViewModel> formWorkViewModelProvider;
  
  public Provider<HomeRepayAmountViewModel> homeRepayAmountViewModelProvider;
  
  public Provider<HomeViewModel> homeViewModelProvider;
  
  public Provider<b> inAppMessagingUseCaseProvider;
  
  public Provider<c> kycUseCaseProvider;
  
  public Provider<LoanOfferDetailsFragmentViewModel> loanOfferDetailsFragmentViewModelProvider;
  
  public Provider<LoanOffersViewModel> loanOffersViewModelProvider;
  
  public Provider<LoanTransferViewModel> loanTransferViewModelProvider;
  
  public Provider<e> loanUseCaseProvider;
  
  public Provider<LoginViewModel> loginViewModelProvider;
  
  public Provider<Map<Class<? extends w>, Provider<w>>> mapOfClassOfAndProviderOfViewModelProvider;
  
  public Provider<PaymentHistoryViewModel> paymentHistoryViewModelProvider;
  
  public Provider<f> paymentUseCaseProvider;
  
  public Provider<PhoneInputViewModel> phoneInputViewModelProvider;
  
  public Provider<PhoneNumberFormatter> phoneNumberFormatterProvider;
  
  public Provider<b> phoneNumberValidatorProvider;
  
  public Provider<PhoneSignupViewModel> phoneSignupViewModelProvider;
  
  public Provider<ProfessionalMapper> professionalMapperProvider;
  
  public Provider<RejectedViewModel> rejectedViewModelProvider;
  
  public Provider<RepaymentMethodsViewModel> repaymentMethodsViewModelProvider;
  
  public Provider<c> routerProvider;
  
  public Provider<SplashViewModel> splashViewModelProvider;
  
  public Provider<TermsOfUseViewModel> termsOfUseViewModelProvider;
  
  public Provider<g> userRepositoryProvider;
  
  public Provider<h> userUseCaseProvider;
  
  public Provider<VerifyOtpViewModel> verifyOtpViewModelProvider;
  
  public Provider<ViewModelFactory> viewModelFactoryProvider;
  
  public DaggerViewModelComponent(c paramc, i parami, j paramj, k paramk) {
    initialize(paramc, parami, paramj, paramk);
  }
  
  public static ViewModelComponent.Factory factory() {
    return new Factory();
  }
  
  private void initialize(c paramc, i parami, j paramj, k paramk) {
    this.bindCardViewModel$app_prodReleaseProvider = c.a((Provider)CardViewModel_Factory.create());
    this.userRepositoryProvider = new com_fairmoney_injection_DataComponent_userRepository(parami);
    com_fairmoney_injection_DataComponent_features com_fairmoney_injection_DataComponent_features = new com_fairmoney_injection_DataComponent_features(parami);
    this.featuresProvider = com_fairmoney_injection_DataComponent_features;
    FormLoanPurposeViewModel_Factory formLoanPurposeViewModel_Factory = FormLoanPurposeViewModel_Factory.create(this.userRepositoryProvider, com_fairmoney_injection_DataComponent_features);
    this.formLoanPurposeViewModelProvider = (Provider<FormLoanPurposeViewModel>)formLoanPurposeViewModel_Factory;
    this.bindFormLoanPurposeViewModel$app_prodReleaseProvider = c.a((Provider)formLoanPurposeViewModel_Factory);
    this.formRepositoryProvider = new com_fairmoney_injection_DataComponent_formRepository(parami);
    this.userUseCaseProvider = new com_fairmoney_injection_DomainComponent_userUseCase(paramj);
    this.kycUseCaseProvider = new com_fairmoney_injection_DomainComponent_kycUseCase(paramj);
    com_fairmoney_injection_RoutingComponent_router com_fairmoney_injection_RoutingComponent_router = new com_fairmoney_injection_RoutingComponent_router(paramk);
    this.routerProvider = com_fairmoney_injection_RoutingComponent_router;
    FormPersonalViewModel_Factory formPersonalViewModel_Factory = FormPersonalViewModel_Factory.create(this.formRepositoryProvider, this.userUseCaseProvider, this.kycUseCaseProvider, com_fairmoney_injection_RoutingComponent_router, this.userRepositoryProvider, this.featuresProvider);
    this.formPersonalViewModelProvider = (Provider<FormPersonalViewModel>)formPersonalViewModel_Factory;
    this.bindFormViewModel$app_prodReleaseProvider = c.a((Provider)formPersonalViewModel_Factory);
    FormGuarantorViewModel_Factory formGuarantorViewModel_Factory = FormGuarantorViewModel_Factory.create(this.userUseCaseProvider);
    this.formGuarantorViewModelProvider = (Provider<FormGuarantorViewModel>)formGuarantorViewModel_Factory;
    this.bindFormGuarantorViewModel$app_prodReleaseProvider = c.a((Provider)formGuarantorViewModel_Factory);
    HomeViewModel_Factory homeViewModel_Factory = HomeViewModel_Factory.create(this.featuresProvider);
    this.homeViewModelProvider = (Provider<HomeViewModel>)homeViewModel_Factory;
    this.bindHomeViewModel$app_prodReleaseProvider = c.a((Provider)homeViewModel_Factory);
    FormFinancialKycViewModel_Factory formFinancialKycViewModel_Factory = FormFinancialKycViewModel_Factory.create(this.featuresProvider);
    this.formFinancialKycViewModelProvider = (Provider<FormFinancialKycViewModel>)formFinancialKycViewModel_Factory;
    this.bindFormFinancialKYCViewModel$app_prodReleaseProvider = c.a((Provider)formFinancialKycViewModel_Factory);
    BvnVerificationViewModel_Factory bvnVerificationViewModel_Factory = BvnVerificationViewModel_Factory.create(this.featuresProvider);
    this.bvnVerificationViewModelProvider = (Provider<BvnVerificationViewModel>)bvnVerificationViewModel_Factory;
    this.bindBvnVerificationViewModel$app_prodReleaseProvider = c.a((Provider)bvnVerificationViewModel_Factory);
    FormBankViewModel_Factory formBankViewModel_Factory = FormBankViewModel_Factory.create(this.featuresProvider);
    this.formBankViewModelProvider = (Provider<FormBankViewModel>)formBankViewModel_Factory;
    this.bindFormBankViewModel$app_prodReleaseProvider = c.a((Provider)formBankViewModel_Factory);
    this.loanUseCaseProvider = new com_fairmoney_injection_DomainComponent_loanUseCase(paramj);
    com_fairmoney_injection_ContextComponent_application com_fairmoney_injection_ContextComponent_application = new com_fairmoney_injection_ContextComponent_application(paramc);
    this.applicationProvider = com_fairmoney_injection_ContextComponent_application;
    ProfessionalMapper_Factory professionalMapper_Factory = ProfessionalMapper_Factory.create(com_fairmoney_injection_ContextComponent_application);
    this.professionalMapperProvider = (Provider<ProfessionalMapper>)professionalMapper_Factory;
    FormWorkViewModel_Factory formWorkViewModel_Factory = FormWorkViewModel_Factory.create(this.loanUseCaseProvider, this.userUseCaseProvider, (Provider)professionalMapper_Factory);
    this.formWorkViewModelProvider = (Provider<FormWorkViewModel>)formWorkViewModel_Factory;
    this.bindFormWorkViewModel$app_prodReleaseProvider = c.a((Provider)formWorkViewModel_Factory);
    RepaymentMethodsViewModel_Factory repaymentMethodsViewModel_Factory = RepaymentMethodsViewModel_Factory.create(this.featuresProvider);
    this.repaymentMethodsViewModelProvider = (Provider<RepaymentMethodsViewModel>)repaymentMethodsViewModel_Factory;
    this.bindRepaymentMethodsViewModel$app_prodReleaseProvider = c.a((Provider)repaymentMethodsViewModel_Factory);
    com_fairmoney_injection_DomainComponent_paymentUseCase com_fairmoney_injection_DomainComponent_paymentUseCase = new com_fairmoney_injection_DomainComponent_paymentUseCase(paramj);
    this.paymentUseCaseProvider = com_fairmoney_injection_DomainComponent_paymentUseCase;
    PaymentHistoryViewModel_Factory paymentHistoryViewModel_Factory = PaymentHistoryViewModel_Factory.create(com_fairmoney_injection_DomainComponent_paymentUseCase);
    this.paymentHistoryViewModelProvider = (Provider<PaymentHistoryViewModel>)paymentHistoryViewModel_Factory;
    this.bindPaymentHistoryViewModel$app_prodReleaseProvider = c.a((Provider)paymentHistoryViewModel_Factory);
    this.phoneNumberValidatorProvider = new com_fairmoney_injection_DataComponent_phoneNumberValidator(parami);
    com_fairmoney_injection_DomainComponent_countryUseCase com_fairmoney_injection_DomainComponent_countryUseCase = new com_fairmoney_injection_DomainComponent_countryUseCase(paramj);
    this.countryUseCaseProvider = com_fairmoney_injection_DomainComponent_countryUseCase;
    PhoneInputViewModel_Factory phoneInputViewModel_Factory = PhoneInputViewModel_Factory.create(this.phoneNumberValidatorProvider, com_fairmoney_injection_DomainComponent_countryUseCase, this.userUseCaseProvider, (Provider)d.a());
    this.phoneInputViewModelProvider = (Provider<PhoneInputViewModel>)phoneInputViewModel_Factory;
    this.bindPhoneInputViewModel$app_prodReleaseProvider = c.a((Provider)phoneInputViewModel_Factory);
    com_fairmoney_injection_DomainComponent_inAppMessagingUseCase com_fairmoney_injection_DomainComponent_inAppMessagingUseCase = new com_fairmoney_injection_DomainComponent_inAppMessagingUseCase(paramj);
    this.inAppMessagingUseCaseProvider = com_fairmoney_injection_DomainComponent_inAppMessagingUseCase;
    LoginViewModel_Factory loginViewModel_Factory = LoginViewModel_Factory.create(com_fairmoney_injection_DomainComponent_inAppMessagingUseCase, this.userUseCaseProvider);
    this.loginViewModelProvider = (Provider<LoginViewModel>)loginViewModel_Factory;
    this.bindLoginViewModel$app_prodReleaseProvider = c.a((Provider)loginViewModel_Factory);
    ForgotPasswordViewModel_Factory forgotPasswordViewModel_Factory = ForgotPasswordViewModel_Factory.create(this.userUseCaseProvider);
    this.forgotPasswordViewModelProvider = (Provider<ForgotPasswordViewModel>)forgotPasswordViewModel_Factory;
    this.bindForgotPasswordViewModel$app_prodReleaseProvider = c.a((Provider)forgotPasswordViewModel_Factory);
    ForgotPasswordEnterOtpViewModel_Factory forgotPasswordEnterOtpViewModel_Factory = ForgotPasswordEnterOtpViewModel_Factory.create(this.userUseCaseProvider);
    this.forgotPasswordEnterOtpViewModelProvider = (Provider<ForgotPasswordEnterOtpViewModel>)forgotPasswordEnterOtpViewModel_Factory;
    this.bindForgotPasswordEnterOtpViewModel$app_prodReleaseProvider = c.a((Provider)forgotPasswordEnterOtpViewModel_Factory);
    EarlyRepaymentCardViewModel_Factory earlyRepaymentCardViewModel_Factory = EarlyRepaymentCardViewModel_Factory.create(this.userUseCaseProvider);
    this.earlyRepaymentCardViewModelProvider = (Provider<EarlyRepaymentCardViewModel>)earlyRepaymentCardViewModel_Factory;
    this.bindEarlyRepaymentCardViewModel$app_prodReleaseProvider = c.a((Provider)earlyRepaymentCardViewModel_Factory);
    PhoneSignupViewModel_Factory phoneSignupViewModel_Factory = PhoneSignupViewModel_Factory.create(this.userUseCaseProvider);
    this.phoneSignupViewModelProvider = (Provider<PhoneSignupViewModel>)phoneSignupViewModel_Factory;
    this.bindPhoneSignupViewModel$app_prodReleaseProvider = c.a((Provider)phoneSignupViewModel_Factory);
    SplashViewModel_Factory splashViewModel_Factory = SplashViewModel_Factory.create(this.userUseCaseProvider, this.routerProvider);
    this.splashViewModelProvider = (Provider<SplashViewModel>)splashViewModel_Factory;
    this.bindSplashViewModel$app_prodReleaseProvider = c.a((Provider)splashViewModel_Factory);
    LoanTransferViewModel_Factory loanTransferViewModel_Factory = LoanTransferViewModel_Factory.create(this.userUseCaseProvider);
    this.loanTransferViewModelProvider = (Provider<LoanTransferViewModel>)loanTransferViewModel_Factory;
    this.bindLoanTransferViewModel$app_prodReleaseProvider = c.a((Provider)loanTransferViewModel_Factory);
    TermsOfUseViewModel_Factory termsOfUseViewModel_Factory = TermsOfUseViewModel_Factory.create(this.userUseCaseProvider, this.loanUseCaseProvider);
    this.termsOfUseViewModelProvider = (Provider<TermsOfUseViewModel>)termsOfUseViewModel_Factory;
    this.bindTermsOfUseViewModel$app_prodReleaseProvider = c.a((Provider)termsOfUseViewModel_Factory);
    PhoneNumberFormatter_Factory phoneNumberFormatter_Factory = PhoneNumberFormatter_Factory.create((Provider)d.a(), (Provider)NigerianPhoneNumberFormatter_Factory.create(), (Provider)IndianPhoneNumberFormatter_Factory.create());
    this.phoneNumberFormatterProvider = (Provider<PhoneNumberFormatter>)phoneNumberFormatter_Factory;
    VerifyOtpViewModel_Factory verifyOtpViewModel_Factory = VerifyOtpViewModel_Factory.create((Provider)phoneNumberFormatter_Factory, this.phoneNumberValidatorProvider);
    this.verifyOtpViewModelProvider = (Provider<VerifyOtpViewModel>)verifyOtpViewModel_Factory;
    this.bindVerifyOtpViewModel$app_prodReleaseProvider = c.a((Provider)verifyOtpViewModel_Factory);
    LoanOffersViewModel_Factory loanOffersViewModel_Factory = LoanOffersViewModel_Factory.create(this.loanUseCaseProvider, this.userRepositoryProvider, this.userUseCaseProvider, this.routerProvider);
    this.loanOffersViewModelProvider = (Provider<LoanOffersViewModel>)loanOffersViewModel_Factory;
    this.bindLoanOffersViewModel$app_prodReleaseProvider = c.a((Provider)loanOffersViewModel_Factory);
    BankDetailsViewModel_Factory bankDetailsViewModel_Factory = BankDetailsViewModel_Factory.create(this.loanUseCaseProvider, this.routerProvider);
    this.bankDetailsViewModelProvider = (Provider<BankDetailsViewModel>)bankDetailsViewModel_Factory;
    this.bindBankDetailsViewModel$app_prodReleaseProvider = c.a((Provider)bankDetailsViewModel_Factory);
    RejectedViewModel_Factory rejectedViewModel_Factory = RejectedViewModel_Factory.create(this.userUseCaseProvider);
    this.rejectedViewModelProvider = (Provider<RejectedViewModel>)rejectedViewModel_Factory;
    this.bindRejectedViewModel$app_prodReleaseProvider = c.a((Provider)rejectedViewModel_Factory);
    this.bindLoanOfferDetailsViewModel$app_prodReleaseProvider = c.a((Provider)LoanOfferDetailsViewModel_Factory.create());
    LoanOfferDetailsFragmentViewModel_Factory loanOfferDetailsFragmentViewModel_Factory = LoanOfferDetailsFragmentViewModel_Factory.create(this.userUseCaseProvider);
    this.loanOfferDetailsFragmentViewModelProvider = (Provider<LoanOfferDetailsFragmentViewModel>)loanOfferDetailsFragmentViewModel_Factory;
    this.bindLoanOfferDetailsFragmentViewModel$app_prodReleaseProvider = c.a((Provider)loanOfferDetailsFragmentViewModel_Factory);
    DataUploadViewModel_Factory dataUploadViewModel_Factory = DataUploadViewModel_Factory.create(this.loanUseCaseProvider, this.userRepositoryProvider);
    this.dataUploadViewModelProvider = (Provider<DataUploadViewModel>)dataUploadViewModel_Factory;
    this.bindDataUploadViewModel$app_prodReleaseProvider = c.a((Provider)dataUploadViewModel_Factory);
    FinalLoanOfferViewModel_Factory finalLoanOfferViewModel_Factory = FinalLoanOfferViewModel_Factory.create(this.loanUseCaseProvider, this.userRepositoryProvider);
    this.finalLoanOfferViewModelProvider = (Provider<FinalLoanOfferViewModel>)finalLoanOfferViewModel_Factory;
    this.bindFinalLoanOfferViewModel$app_prodReleaseProvider = c.a((Provider)finalLoanOfferViewModel_Factory);
    HomeRepayAmountViewModel_Factory homeRepayAmountViewModel_Factory = HomeRepayAmountViewModel_Factory.create(this.userUseCaseProvider, this.routerProvider, this.paymentUseCaseProvider);
    this.homeRepayAmountViewModelProvider = (Provider<HomeRepayAmountViewModel>)homeRepayAmountViewModel_Factory;
    this.bindHomeRepayAmountViewModel$app_prodReleaseProvider = c.a((Provider)homeRepayAmountViewModel_Factory);
    f.b b = f.a(29);
    b.a(CardViewModel.class, this.bindCardViewModel$app_prodReleaseProvider);
    b.a(FormLoanPurposeViewModel.class, this.bindFormLoanPurposeViewModel$app_prodReleaseProvider);
    b.a(FormPersonalViewModel.class, this.bindFormViewModel$app_prodReleaseProvider);
    b.a(FormGuarantorViewModel.class, this.bindFormGuarantorViewModel$app_prodReleaseProvider);
    b.a(HomeViewModel.class, this.bindHomeViewModel$app_prodReleaseProvider);
    b.a(FormFinancialKycViewModel.class, this.bindFormFinancialKYCViewModel$app_prodReleaseProvider);
    b.a(BvnVerificationViewModel.class, this.bindBvnVerificationViewModel$app_prodReleaseProvider);
    b.a(FormBankViewModel.class, this.bindFormBankViewModel$app_prodReleaseProvider);
    b.a(FormWorkViewModel.class, this.bindFormWorkViewModel$app_prodReleaseProvider);
    b.a(RepaymentMethodsViewModel.class, this.bindRepaymentMethodsViewModel$app_prodReleaseProvider);
    b.a(PaymentHistoryViewModel.class, this.bindPaymentHistoryViewModel$app_prodReleaseProvider);
    b.a(PhoneInputViewModel.class, this.bindPhoneInputViewModel$app_prodReleaseProvider);
    b.a(LoginViewModel.class, this.bindLoginViewModel$app_prodReleaseProvider);
    b.a(ForgotPasswordViewModel.class, this.bindForgotPasswordViewModel$app_prodReleaseProvider);
    b.a(ForgotPasswordEnterOtpViewModel.class, this.bindForgotPasswordEnterOtpViewModel$app_prodReleaseProvider);
    b.a(EarlyRepaymentCardViewModel.class, this.bindEarlyRepaymentCardViewModel$app_prodReleaseProvider);
    b.a(PhoneSignupViewModel.class, this.bindPhoneSignupViewModel$app_prodReleaseProvider);
    b.a(SplashViewModel.class, this.bindSplashViewModel$app_prodReleaseProvider);
    b.a(LoanTransferViewModel.class, this.bindLoanTransferViewModel$app_prodReleaseProvider);
    b.a(TermsOfUseViewModel.class, this.bindTermsOfUseViewModel$app_prodReleaseProvider);
    b.a(VerifyOtpViewModel.class, this.bindVerifyOtpViewModel$app_prodReleaseProvider);
    b.a(LoanOffersViewModel.class, this.bindLoanOffersViewModel$app_prodReleaseProvider);
    b.a(BankDetailsViewModel.class, this.bindBankDetailsViewModel$app_prodReleaseProvider);
    b.a(RejectedViewModel.class, this.bindRejectedViewModel$app_prodReleaseProvider);
    b.a(LoanOfferDetailsViewModel.class, this.bindLoanOfferDetailsViewModel$app_prodReleaseProvider);
    b.a(LoanOfferDetailsFragmentViewModel.class, this.bindLoanOfferDetailsFragmentViewModel$app_prodReleaseProvider);
    b.a(DataUploadViewModel.class, this.bindDataUploadViewModel$app_prodReleaseProvider);
    b.a(FinalLoanOfferViewModel.class, this.bindFinalLoanOfferViewModel$app_prodReleaseProvider);
    b.a(HomeRepayAmountViewModel.class, this.bindHomeRepayAmountViewModel$app_prodReleaseProvider);
    f f = b.a();
    this.mapOfClassOfAndProviderOfViewModelProvider = (Provider<Map<Class<? extends w>, Provider<w>>>)f;
    this.viewModelFactoryProvider = c.a((Provider)ViewModelFactory_Factory.create((Provider<Map<Class<? extends w>, Provider<w>>>)f));
  }
  
  private BankAndCardsFragment injectBankAndCardsFragment(BankAndCardsFragment paramBankAndCardsFragment) {
    BankAndCardsFragment_MembersInjector.injectViewModelFactory(paramBankAndCardsFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramBankAndCardsFragment;
  }
  
  private BankDetailsActivity injectBankDetailsActivity(BankDetailsActivity paramBankDetailsActivity) {
    BankDetailsActivity_MembersInjector.injectFactory(paramBankDetailsActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramBankDetailsActivity;
  }
  
  private BaseHomeActivity injectBaseHomeActivity(BaseHomeActivity paramBaseHomeActivity) {
    BaseHomeActivity_MembersInjector.injectViewModelFactory(paramBaseHomeActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramBaseHomeActivity;
  }
  
  private BillChoosePaymentMethodFragment injectBillChoosePaymentMethodFragment(BillChoosePaymentMethodFragment paramBillChoosePaymentMethodFragment) {
    BillChoosePaymentMethodFragment_MembersInjector.injectViewModelFactory(paramBillChoosePaymentMethodFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramBillChoosePaymentMethodFragment;
  }
  
  private BvnVerificationFragment injectBvnVerificationFragment(BvnVerificationFragment paramBvnVerificationFragment) {
    VerifyOtpBaseFragment_MembersInjector.injectViewModelFactory((VerifyOtpBaseFragment)paramBvnVerificationFragment, (y.b)this.viewModelFactoryProvider.get());
    BvnVerificationFragment_MembersInjector.injectViewModelFactory(paramBvnVerificationFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramBvnVerificationFragment;
  }
  
  private CardConnectionFragment injectCardConnectionFragment(CardConnectionFragment paramCardConnectionFragment) {
    CardConnectionFragment_MembersInjector.injectViewModelFactory(paramCardConnectionFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramCardConnectionFragment;
  }
  
  private DataUploadActivity injectDataUploadActivity(DataUploadActivity paramDataUploadActivity) {
    DataUploadActivity_MembersInjector.injectFactory(paramDataUploadActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramDataUploadActivity;
  }
  
  private EarlyRepaymentCardView injectEarlyRepaymentCardView(EarlyRepaymentCardView paramEarlyRepaymentCardView) {
    EarlyRepaymentCardView_MembersInjector.injectViewModelFactory(paramEarlyRepaymentCardView, (y.b)this.viewModelFactoryProvider.get());
    return paramEarlyRepaymentCardView;
  }
  
  private FinalLoanOfferActivity injectFinalLoanOfferActivity(FinalLoanOfferActivity paramFinalLoanOfferActivity) {
    FinalLoanOfferActivity_MembersInjector.injectFactory(paramFinalLoanOfferActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramFinalLoanOfferActivity;
  }
  
  private ForgotPasswordActivity injectForgotPasswordActivity(ForgotPasswordActivity paramForgotPasswordActivity) {
    ForgotPasswordActivity_MembersInjector.injectViewModelFactory(paramForgotPasswordActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramForgotPasswordActivity;
  }
  
  private ForgotPasswordConfirmPasswordActivity injectForgotPasswordConfirmPasswordActivity(ForgotPasswordConfirmPasswordActivity paramForgotPasswordConfirmPasswordActivity) {
    LoginActivity_MembersInjector.injectViewModelFactory((LoginActivity)paramForgotPasswordConfirmPasswordActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramForgotPasswordConfirmPasswordActivity;
  }
  
  private ForgotPasswordEnterOtpFragment injectForgotPasswordEnterOtpFragment(ForgotPasswordEnterOtpFragment paramForgotPasswordEnterOtpFragment) {
    VerifyOtpBaseFragment_MembersInjector.injectViewModelFactory((VerifyOtpBaseFragment)paramForgotPasswordEnterOtpFragment, (y.b)this.viewModelFactoryProvider.get());
    ForgotPasswordEnterOtpFragment_MembersInjector.injectViewModelFactory(paramForgotPasswordEnterOtpFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramForgotPasswordEnterOtpFragment;
  }
  
  private FormBankActivity injectFormBankActivity(FormBankActivity paramFormBankActivity) {
    FormBankActivity_MembersInjector.injectViewModelFactory(paramFormBankActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramFormBankActivity;
  }
  
  private FormFinancialKycActivity injectFormFinancialKycActivity(FormFinancialKycActivity paramFormFinancialKycActivity) {
    FormFinancialKycActivity_MembersInjector.injectViewModelFactory(paramFormFinancialKycActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramFormFinancialKycActivity;
  }
  
  private FormGuarantorActivity injectFormGuarantorActivity(FormGuarantorActivity paramFormGuarantorActivity) {
    FormGuarantorActivity_MembersInjector.injectViewModelFactory(paramFormGuarantorActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramFormGuarantorActivity;
  }
  
  private FormLoanPurposeActivity injectFormLoanPurposeActivity(FormLoanPurposeActivity paramFormLoanPurposeActivity) {
    FormLoanPurposeActivity_MembersInjector.injectViewModelFactory(paramFormLoanPurposeActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramFormLoanPurposeActivity;
  }
  
  private FormPersonalActivity injectFormPersonalActivity(FormPersonalActivity paramFormPersonalActivity) {
    FormPersonalActivity_MembersInjector.injectViewModelFactory(paramFormPersonalActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramFormPersonalActivity;
  }
  
  private FormWorkActivity injectFormWorkActivity(FormWorkActivity paramFormWorkActivity) {
    FormWorkActivity_MembersInjector.injectViewModelFactory(paramFormWorkActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramFormWorkActivity;
  }
  
  private HomeCardRepaymentFragment injectHomeCardRepaymentFragment(HomeCardRepaymentFragment paramHomeCardRepaymentFragment) {
    HomeCardRepaymentFragment_MembersInjector.injectViewModelFactory(paramHomeCardRepaymentFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramHomeCardRepaymentFragment;
  }
  
  private HomeRepayAmountFragment injectHomeRepayAmountFragment(HomeRepayAmountFragment paramHomeRepayAmountFragment) {
    HomeRepayAmountFragment_MembersInjector.injectFactory(paramHomeRepayAmountFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramHomeRepayAmountFragment;
  }
  
  private HomeRepaymentMethodFragment injectHomeRepaymentMethodFragment(HomeRepaymentMethodFragment paramHomeRepaymentMethodFragment) {
    HomeRepaymentMethodFragment_MembersInjector.injectViewModelFactory(paramHomeRepaymentMethodFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramHomeRepaymentMethodFragment;
  }
  
  private IndianPhoneNumberTextWatcher injectIndianPhoneNumberTextWatcher(IndianPhoneNumberTextWatcher paramIndianPhoneNumberTextWatcher) {
    IndianPhoneNumberTextWatcher_MembersInjector.injectViewModel(paramIndianPhoneNumberTextWatcher, new IndianPhoneNumberViewModel());
    return paramIndianPhoneNumberTextWatcher;
  }
  
  private LoanOfferDetailsFragment injectLoanOfferDetailsFragment(LoanOfferDetailsFragment paramLoanOfferDetailsFragment) {
    LoanOfferDetailsFragment_MembersInjector.injectFactory(paramLoanOfferDetailsFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramLoanOfferDetailsFragment;
  }
  
  private LoanOfferDetailsView injectLoanOfferDetailsView(LoanOfferDetailsView paramLoanOfferDetailsView) {
    LoanOfferDetailsView_MembersInjector.injectFactory(paramLoanOfferDetailsView, (y.b)this.viewModelFactoryProvider.get());
    return paramLoanOfferDetailsView;
  }
  
  private LoanOffersActivity injectLoanOffersActivity(LoanOffersActivity paramLoanOffersActivity) {
    LoanOffersActivity_MembersInjector.injectFactory(paramLoanOffersActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramLoanOffersActivity;
  }
  
  private LoanTransferFragment injectLoanTransferFragment(LoanTransferFragment paramLoanTransferFragment) {
    LoanTransferFragment_MembersInjector.injectFactory(paramLoanTransferFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramLoanTransferFragment;
  }
  
  private LoginActivity injectLoginActivity(LoginActivity paramLoginActivity) {
    LoginActivity_MembersInjector.injectViewModelFactory(paramLoginActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramLoginActivity;
  }
  
  private NigerianPhoneNumberTextWatcher injectNigerianPhoneNumberTextWatcher(NigerianPhoneNumberTextWatcher paramNigerianPhoneNumberTextWatcher) {
    NigerianPhoneNumberTextWatcher_MembersInjector.injectViewModel(paramNigerianPhoneNumberTextWatcher, new NigerianPhoneNumberViewModel());
    return paramNigerianPhoneNumberTextWatcher;
  }
  
  private PaymentHistoryFragment injectPaymentHistoryFragment(PaymentHistoryFragment paramPaymentHistoryFragment) {
    PaymentHistoryFragment_MembersInjector.injectViewModelFactory(paramPaymentHistoryFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramPaymentHistoryFragment;
  }
  
  private PermissionsActivity injectPermissionsActivity(PermissionsActivity paramPermissionsActivity) {
    PermissionsActivity_MembersInjector.injectFactory(paramPermissionsActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramPermissionsActivity;
  }
  
  private PhoneInputView injectPhoneInputView(PhoneInputView paramPhoneInputView) {
    PhoneInputView_MembersInjector.injectViewModelFactory(paramPhoneInputView, (y.b)this.viewModelFactoryProvider.get());
    return paramPhoneInputView;
  }
  
  private PhoneSignupActivity injectPhoneSignupActivity(PhoneSignupActivity paramPhoneSignupActivity) {
    LoginActivity_MembersInjector.injectViewModelFactory((LoginActivity)paramPhoneSignupActivity, (y.b)this.viewModelFactoryProvider.get());
    PhoneSignupActivity_MembersInjector.injectViewModelFactory(paramPhoneSignupActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramPhoneSignupActivity;
  }
  
  private RejectedActivity injectRejectedActivity(RejectedActivity paramRejectedActivity) {
    RejectedActivity_MembersInjector.injectFactory(paramRejectedActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramRejectedActivity;
  }
  
  private SplashActivity injectSplashActivity(SplashActivity paramSplashActivity) {
    SplashActivity_MembersInjector.injectFactory(paramSplashActivity, (y.b)this.viewModelFactoryProvider.get());
    return paramSplashActivity;
  }
  
  private VerifyOtpBaseFragment injectVerifyOtpBaseFragment(VerifyOtpBaseFragment paramVerifyOtpBaseFragment) {
    VerifyOtpBaseFragment_MembersInjector.injectViewModelFactory(paramVerifyOtpBaseFragment, (y.b)this.viewModelFactoryProvider.get());
    return paramVerifyOtpBaseFragment;
  }
  
  public void inject(EarlyRepaymentCardView paramEarlyRepaymentCardView) {
    injectEarlyRepaymentCardView(paramEarlyRepaymentCardView);
  }
  
  public void inject(BankDetailsActivity paramBankDetailsActivity) {
    injectBankDetailsActivity(paramBankDetailsActivity);
  }
  
  public void inject(LoanOfferDetailsView paramLoanOfferDetailsView) {
    injectLoanOfferDetailsView(paramLoanOfferDetailsView);
  }
  
  public void inject(LoanTransferFragment paramLoanTransferFragment) {
    injectLoanTransferFragment(paramLoanTransferFragment);
  }
  
  public void inject(PaymentHistoryFragment paramPaymentHistoryFragment) {
    injectPaymentHistoryFragment(paramPaymentHistoryFragment);
  }
  
  public void inject(IndianPhoneNumberTextWatcher paramIndianPhoneNumberTextWatcher) {
    injectIndianPhoneNumberTextWatcher(paramIndianPhoneNumberTextWatcher);
  }
  
  public void inject(NigerianPhoneNumberTextWatcher paramNigerianPhoneNumberTextWatcher) {
    injectNigerianPhoneNumberTextWatcher(paramNigerianPhoneNumberTextWatcher);
  }
  
  public void inject(PhoneInputView paramPhoneInputView) {
    injectPhoneInputView(paramPhoneInputView);
  }
  
  public void inject(BaseHomeActivity paramBaseHomeActivity) {
    injectBaseHomeActivity(paramBaseHomeActivity);
  }
  
  public void inject(DataUploadActivity paramDataUploadActivity) {
    injectDataUploadActivity(paramDataUploadActivity);
  }
  
  public void inject(FinalLoanOfferActivity paramFinalLoanOfferActivity) {
    injectFinalLoanOfferActivity(paramFinalLoanOfferActivity);
  }
  
  public void inject(LoanOffersActivity paramLoanOffersActivity) {
    injectLoanOffersActivity(paramLoanOffersActivity);
  }
  
  public void inject(RejectedActivity paramRejectedActivity) {
    injectRejectedActivity(paramRejectedActivity);
  }
  
  public void inject(SplashActivity paramSplashActivity) {
    injectSplashActivity(paramSplashActivity);
  }
  
  public void inject(ForgotPasswordActivity paramForgotPasswordActivity) {
    injectForgotPasswordActivity(paramForgotPasswordActivity);
  }
  
  public void inject(ForgotPasswordConfirmPasswordActivity paramForgotPasswordConfirmPasswordActivity) {
    injectForgotPasswordConfirmPasswordActivity(paramForgotPasswordConfirmPasswordActivity);
  }
  
  public void inject(FormBankActivity paramFormBankActivity) {
    injectFormBankActivity(paramFormBankActivity);
  }
  
  public void inject(FormFinancialKycActivity paramFormFinancialKycActivity) {
    injectFormFinancialKycActivity(paramFormFinancialKycActivity);
  }
  
  public void inject(FormGuarantorActivity paramFormGuarantorActivity) {
    injectFormGuarantorActivity(paramFormGuarantorActivity);
  }
  
  public void inject(FormLoanPurposeActivity paramFormLoanPurposeActivity) {
    injectFormLoanPurposeActivity(paramFormLoanPurposeActivity);
  }
  
  public void inject(FormPersonalActivity paramFormPersonalActivity) {
    injectFormPersonalActivity(paramFormPersonalActivity);
  }
  
  public void inject(FormWorkActivity paramFormWorkActivity) {
    injectFormWorkActivity(paramFormWorkActivity);
  }
  
  public void inject(PermissionsActivity paramPermissionsActivity) {
    injectPermissionsActivity(paramPermissionsActivity);
  }
  
  public void inject(LoginActivity paramLoginActivity) {
    injectLoginActivity(paramLoginActivity);
  }
  
  public void inject(PhoneSignupActivity paramPhoneSignupActivity) {
    injectPhoneSignupActivity(paramPhoneSignupActivity);
  }
  
  public void inject(VerifyOtpBaseFragment paramVerifyOtpBaseFragment) {
    injectVerifyOtpBaseFragment(paramVerifyOtpBaseFragment);
  }
  
  public void inject(ForgotPasswordEnterOtpFragment paramForgotPasswordEnterOtpFragment) {
    injectForgotPasswordEnterOtpFragment(paramForgotPasswordEnterOtpFragment);
  }
  
  public void inject(BvnVerificationFragment paramBvnVerificationFragment) {
    injectBvnVerificationFragment(paramBvnVerificationFragment);
  }
  
  public void inject(BankAndCardsFragment paramBankAndCardsFragment) {
    injectBankAndCardsFragment(paramBankAndCardsFragment);
  }
  
  public void inject(BillChoosePaymentMethodFragment paramBillChoosePaymentMethodFragment) {
    injectBillChoosePaymentMethodFragment(paramBillChoosePaymentMethodFragment);
  }
  
  public void inject(BillOtherCardPaymentFragment paramBillOtherCardPaymentFragment) {}
  
  public void inject(CardConnectionFragment paramCardConnectionFragment) {
    injectCardConnectionFragment(paramCardConnectionFragment);
  }
  
  public void inject(HomeCardRepaymentFragment paramHomeCardRepaymentFragment) {
    injectHomeCardRepaymentFragment(paramHomeCardRepaymentFragment);
  }
  
  public void inject(HomeRepayAmountFragment paramHomeRepayAmountFragment) {
    injectHomeRepayAmountFragment(paramHomeRepayAmountFragment);
  }
  
  public void inject(HomeRepaymentMethodFragment paramHomeRepaymentMethodFragment) {
    injectHomeRepaymentMethodFragment(paramHomeRepaymentMethodFragment);
  }
  
  public void inject(LoanOfferDetailsFragment paramLoanOfferDetailsFragment) {
    injectLoanOfferDetailsFragment(paramLoanOfferDetailsFragment);
  }
  
  public static final class Factory implements ViewModelComponent.Factory {
    public Factory() {}
    
    public ViewModelComponent create(c param1c, i param1i, j param1j, k param1k) {
      g.a(param1c);
      g.a(param1i);
      g.a(param1j);
      g.a(param1k);
      return new DaggerViewModelComponent(param1c, param1i, param1j, param1k);
    }
  }
  
  public static class com_fairmoney_injection_ContextComponent_application implements Provider<Application> {
    public final c contextComponent;
    
    public com_fairmoney_injection_ContextComponent_application(c param1c) {
      this.contextComponent = param1c;
    }
    
    public Application get() {
      Application application = this.contextComponent.a();
      g.a(application, "Cannot return null from a non-@Nullable component method");
      return application;
    }
  }
  
  public static class com_fairmoney_injection_DataComponent_features implements Provider<a> {
    public final i dataComponent;
    
    public com_fairmoney_injection_DataComponent_features(i param1i) {
      this.dataComponent = param1i;
    }
    
    public a get() {
      a a = this.dataComponent.g();
      g.a(a, "Cannot return null from a non-@Nullable component method");
      return a;
    }
  }
  
  public static class com_fairmoney_injection_DataComponent_formRepository implements Provider<a> {
    public final i dataComponent;
    
    public com_fairmoney_injection_DataComponent_formRepository(i param1i) {
      this.dataComponent = param1i;
    }
    
    public a get() {
      a a = this.dataComponent.d();
      g.a(a, "Cannot return null from a non-@Nullable component method");
      return a;
    }
  }
  
  public static class com_fairmoney_injection_DataComponent_phoneNumberValidator implements Provider<b> {
    public final i dataComponent;
    
    public com_fairmoney_injection_DataComponent_phoneNumberValidator(i param1i) {
      this.dataComponent = param1i;
    }
    
    public b get() {
      b b = this.dataComponent.f();
      g.a(b, "Cannot return null from a non-@Nullable component method");
      return b;
    }
  }
  
  public static class com_fairmoney_injection_DataComponent_userRepository implements Provider<g> {
    public final i dataComponent;
    
    public com_fairmoney_injection_DataComponent_userRepository(i param1i) {
      this.dataComponent = param1i;
    }
    
    public g get() {
      g g = this.dataComponent.b();
      g.a(g, "Cannot return null from a non-@Nullable component method");
      return g;
    }
  }
  
  public static class com_fairmoney_injection_DomainComponent_countryUseCase implements Provider<a> {
    public final j domainComponent;
    
    public com_fairmoney_injection_DomainComponent_countryUseCase(j param1j) {
      this.domainComponent = param1j;
    }
    
    public a get() {
      a a = this.domainComponent.e();
      g.a(a, "Cannot return null from a non-@Nullable component method");
      return a;
    }
  }
  
  public static class com_fairmoney_injection_DomainComponent_inAppMessagingUseCase implements Provider<b> {
    public final j domainComponent;
    
    public com_fairmoney_injection_DomainComponent_inAppMessagingUseCase(j param1j) {
      this.domainComponent = param1j;
    }
    
    public b get() {
      b b = this.domainComponent.d();
      g.a(b, "Cannot return null from a non-@Nullable component method");
      return b;
    }
  }
  
  public static class com_fairmoney_injection_DomainComponent_kycUseCase implements Provider<c> {
    public final j domainComponent;
    
    public com_fairmoney_injection_DomainComponent_kycUseCase(j param1j) {
      this.domainComponent = param1j;
    }
    
    public c get() {
      c c = this.domainComponent.a();
      g.a(c, "Cannot return null from a non-@Nullable component method");
      return c;
    }
  }
  
  public static class com_fairmoney_injection_DomainComponent_loanUseCase implements Provider<e> {
    public final j domainComponent;
    
    public com_fairmoney_injection_DomainComponent_loanUseCase(j param1j) {
      this.domainComponent = param1j;
    }
    
    public e get() {
      e e = this.domainComponent.f();
      g.a(e, "Cannot return null from a non-@Nullable component method");
      return e;
    }
  }
  
  public static class com_fairmoney_injection_DomainComponent_paymentUseCase implements Provider<f> {
    public final j domainComponent;
    
    public com_fairmoney_injection_DomainComponent_paymentUseCase(j param1j) {
      this.domainComponent = param1j;
    }
    
    public f get() {
      f f = this.domainComponent.c();
      g.a(f, "Cannot return null from a non-@Nullable component method");
      return f;
    }
  }
  
  public static class com_fairmoney_injection_DomainComponent_userUseCase implements Provider<h> {
    public final j domainComponent;
    
    public com_fairmoney_injection_DomainComponent_userUseCase(j param1j) {
      this.domainComponent = param1j;
    }
    
    public h get() {
      h h = this.domainComponent.b();
      g.a(h, "Cannot return null from a non-@Nullable component method");
      return h;
    }
  }
  
  public static class com_fairmoney_injection_RoutingComponent_router implements Provider<c> {
    public final k routingComponent;
    
    public com_fairmoney_injection_RoutingComponent_router(k param1k) {
      this.routingComponent = param1k;
    }
    
    public c get() {
      c c = this.routingComponent.a();
      g.a(c, "Cannot return null from a non-@Nullable component method");
      return c;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
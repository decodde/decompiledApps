package ng.com.fairmoney.fairmoney.activities;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.i.c;
import f.d.b.i.e;
import f.d.b.k.g;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class FinalLoanOfferViewModel extends w {
  public final e loanUseCase;
  
  public final r<SelectedLoanOfferState> mutableState;
  
  public final LiveData<SelectedLoanOfferState> state;
  
  public final g userRepository;
  
  @Inject
  public FinalLoanOfferViewModel(e parame, g paramg) {
    this.loanUseCase = parame;
    this.userRepository = paramg;
    r<SelectedLoanOfferState> r1 = new r();
    this.mutableState = r1;
    this.state = (LiveData<SelectedLoanOfferState>)r1;
  }
  
  public final LiveData<SelectedLoanOfferState> getState() {
    return this.state;
  }
  
  public final void initialize() {
    c.a(c.a(this.userRepository.getApplicationId(), 0, new FinalLoanOfferViewModel$initialize$1(null), 1, null), x.a(this));
  }
  
  public static abstract class SelectedLoanOfferState {
    public SelectedLoanOfferState() {}
    
    public static final class Failure extends SelectedLoanOfferState {
      public final Throwable throwable;
      
      public Failure(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Success extends SelectedLoanOfferState {
      public final c loanOffer;
      
      public Success(c param2c) {
        super(null);
        this.loanOffer = param2c;
      }
      
      public final c getLoanOffer() {
        return this.loanOffer;
      }
    }
  }
  
  public static final class Failure extends SelectedLoanOfferState {
    public final Throwable throwable;
    
    public Failure(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Success extends SelectedLoanOfferState {
    public final c loanOffer;
    
    public Success(c param1c) {
      super(null);
      this.loanOffer = param1c;
    }
    
    public final c getLoanOffer() {
      return this.loanOffer;
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.FinalLoanOfferViewModel$initialize$1", f = "FinalLoanOfferViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class FinalLoanOfferViewModel$initialize$1 extends k implements p<String, d<? super a<? extends c>>, Object> {
    public int label;
    
    public String p$0;
    
    public FinalLoanOfferViewModel$initialize$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      FinalLoanOfferViewModel$initialize$1 finalLoanOfferViewModel$initialize$1 = new FinalLoanOfferViewModel$initialize$1(param1d);
      finalLoanOfferViewModel$initialize$1.p$0 = (String)param1Object;
      return (d<k>)finalLoanOfferViewModel$initialize$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((FinalLoanOfferViewModel$initialize$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        return c.a(c.a(FinalLoanOfferViewModel.this.loanUseCase.getSelectedLoanOffer((String)param1Object), new q<b<? super c>, Throwable, d<? super k>, Object>(null) {
                public int label;
                
                public b p$;
                
                public Throwable p$0;
                
                public final d<k> create(b<? super c> param1b, Throwable param1Throwable, d<? super k> param1d) {
                  k.b(param1b, "$this$create");
                  k.b(param1Throwable, "it");
                  k.b(param1d, "continuation");
                  q<b<? super c>, Throwable, d<? super k>, Object> q1 = new q<b<? super c>, Throwable, d<? super k>, Object>(FinalLoanOfferViewModel$initialize$1.this, param1d);
                  q1.p$ = param1b;
                  q1.p$0 = param1Throwable;
                  return (d)q1;
                }
                
                public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                  return ((null)create((b<? super c>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
                }
                
                public final Object invokeSuspend(Object param1Object) {
                  c.a();
                  if (this.label == 0) {
                    g.a(param1Object);
                    param1Object = this.p$0;
                    FinalLoanOfferViewModel.this.mutableState.b(new FinalLoanOfferViewModel.SelectedLoanOfferState.Failure((Throwable)param1Object));
                    return k.a;
                  } 
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
              }), new p<c, d<? super k>, Object>(null) {
              public int label;
              
              public c p$0;
              
              public final d<k> create(Object param1Object, d<?> param1d) {
                k.b(param1d, "completion");
                p<c, d<? super k>, Object> p1 = new p<c, d<? super k>, Object>(FinalLoanOfferViewModel$initialize$1.this, param1d);
                p1.p$0 = (c)param1Object;
                return (d)p1;
              }
              
              public final Object invoke(Object param1Object1, Object param1Object2) {
                return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
              }
              
              public final Object invokeSuspend(Object param1Object) {
                c.a();
                if (this.label == 0) {
                  g.a(param1Object);
                  param1Object = this.p$0;
                  FinalLoanOfferViewModel.this.mutableState.b(new FinalLoanOfferViewModel.SelectedLoanOfferState.Success((c)param1Object));
                  return k.a;
                } 
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              }
            });
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.FinalLoanOfferViewModel$initialize$1$1", f = "FinalLoanOfferViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements q<b<? super c>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public null(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super c> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      q<b<? super c>, Throwable, d<? super k>, Object> q1 = new q<b<? super c>, Throwable, d<? super k>, Object>(FinalLoanOfferViewModel$initialize$1.this, param1d);
      q1.p$ = param1b;
      q1.p$0 = param1Throwable;
      return (d)q1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((null)create((b<? super c>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        FinalLoanOfferViewModel.this.mutableState.b(new FinalLoanOfferViewModel.SelectedLoanOfferState.Failure((Throwable)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.fairmoney.activities.FinalLoanOfferViewModel$initialize$1$2", f = "FinalLoanOfferViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements p<c, d<? super k>, Object> {
    public int label;
    
    public c p$0;
    
    public null(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      p<c, d<? super k>, Object> p1 = new p<c, d<? super k>, Object>(FinalLoanOfferViewModel$initialize$1.this, param1d);
      p1.p$0 = (c)param1Object;
      return (d)p1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        FinalLoanOfferViewModel.this.mutableState.b(new FinalLoanOfferViewModel.SelectedLoanOfferState.Success((c)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\FinalLoanOfferViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
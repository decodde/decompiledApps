package ng.com.fairmoney.android.phoneinput;

import f.d.b.k.b;

public interface OnCountrySelectedListener {
  void onCountrySelected(b paramb, String paramString, int paramInt);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\OnCountrySelectedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.login;

import f.d.b.f.e;
import j.q.d.g;

public abstract class InAppMessageState {
  public InAppMessageState() {}
  
  public static final class Empty extends InAppMessageState {
    public static final Empty INSTANCE = new Empty();
    
    public Empty() {
      super(null);
    }
  }
  
  public static final class Error extends InAppMessageState {
    public final Throwable throwable;
    
    public Error(Throwable param2Throwable) {
      super(null);
      this.throwable = param2Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Success extends InAppMessageState {
    public final e inAppMessage;
    
    public Success(e param2e) {
      super(null);
      this.inAppMessage = param2e;
    }
    
    public final e getInAppMessage() {
      return this.inAppMessage;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel$InAppMessageState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.content.SharedPreferences;
import android.widget.CheckBox;
import android.widget.TextView;
import java.util.Map;

public class CheckBoxUtils {
  public static void applyPreviousCheckBoxAnswer(Activity paramActivity, SharedPreferences paramSharedPreferences, Map<String, String> paramMap) {
    boolean bool = paramSharedPreferences.getBoolean(paramMap.get("id"), false);
    CheckBox checkBox = (CheckBox)paramActivity.findViewById(paramActivity.getResources().getIdentifier(paramMap.get("id"), "id", paramActivity.getPackageName()));
    if (checkBox != null)
      checkBox.setChecked(bool); 
  }
  
  public static String getAcceptCheckBoxAnswer(Activity paramActivity, SharedPreferences.Editor paramEditor, Map<String, String> paramMap, int paramInt) {
    String str;
    CheckBox checkBox = (CheckBox)paramActivity.findViewById(paramInt);
    paramEditor.putBoolean(paramMap.get("id"), checkBox.isChecked()).apply();
    if (checkBox.isChecked()) {
      str = "I accept";
    } else {
      str = "I don't accept";
    } 
    return str;
  }
  
  public static boolean isCheckBoxChecked(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    CheckBox checkBox = (CheckBox)paramActivity.findViewById(paramInt);
    TextView textView = (TextView)paramActivity.findViewById(paramActivity.getResources().getIdentifier(paramMap.get("error_view_id"), "id", paramActivity.getPackageName()));
    if (!checkBox.isChecked()) {
      textView.setText(paramActivity.getString(2131821029, new Object[] { paramMap.get("display_name") }));
      textView.setTextColor(-65536);
      textView.setVisibility(0);
    } else {
      textView.setVisibility(8);
    } 
    return checkBox.isChecked();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\CheckBoxUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.payment;

import j.q.d.k;

public final class JsonParam {
  public final String key;
  
  public final String value;
  
  public JsonParam(String paramString1, String paramString2) {
    this.key = paramString1;
    this.value = paramString2;
  }
  
  public final String component1() {
    return this.key;
  }
  
  public final String component2() {
    return this.value;
  }
  
  public final com.fairmoney.data.payment.JsonParam copy(String paramString1, String paramString2) {
    k.b(paramString1, "key");
    k.b(paramString2, "value");
    return new com.fairmoney.data.payment.JsonParam(paramString1, paramString2);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.payment.JsonParam) {
        paramObject = paramObject;
        if (k.a(this.key, ((com.fairmoney.data.payment.JsonParam)paramObject).key) && k.a(this.value, ((com.fairmoney.data.payment.JsonParam)paramObject).value))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getKey() {
    return this.key;
  }
  
  public final String getValue() {
    return this.value;
  }
  
  public int hashCode() {
    byte b;
    String str = this.key;
    int i = 0;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    str = this.value;
    if (str != null)
      i = str.hashCode(); 
    return b * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonParam(key=");
    stringBuilder.append(this.key);
    stringBuilder.append(", value=");
    stringBuilder.append(this.value);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\payment\JsonParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

public class UpdateAppActivity extends BaseActivity {
  private Intent getPlayStoreIntent(String paramString) {
    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(String.format("%s?id=%s", new Object[] { paramString, getPackageName() })));
    int i = Build.VERSION.SDK_INT;
    intent.addFlags(1208483840);
    return intent;
  }
  
  public void goToPlayStorePage() {
    try {
      startActivity(getPlayStoreIntent("market://details"));
    } catch (ActivityNotFoundException activityNotFoundException) {
      startActivity(getPlayStoreIntent("https://play.google.com/store/apps/details"));
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.isAuthMandatory = false;
    findViewById(2131296422).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            UpdateAppActivity.this.goToPlayStorePage();
          }
        });
  }
  
  public int provideContentViewId() {
    return 2131492919;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\UpdateAppActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
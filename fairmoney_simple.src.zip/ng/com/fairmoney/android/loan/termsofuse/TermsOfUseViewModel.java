package ng.com.fairmoney.android.loan.termsofuse;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.i.e;
import f.d.b.k.b;
import f.d.b.k.h;
import j.e;
import j.g;
import j.i;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import java.net.URL;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import kotlin.NoWhenBranchMatchedException;

public final class TermsOfUseViewModel extends w {
  public final e loanUseCase;
  
  public final r<TermsOfUse> mutableTermsOfUse;
  
  public final LiveData<TermsOfUse> termsOfUse;
  
  public final h userUseCase;
  
  @Inject
  public TermsOfUseViewModel(h paramh, e parame) {
    this.userUseCase = paramh;
    this.loanUseCase = parame;
    r<TermsOfUse> r1 = new r();
    this.mutableTermsOfUse = r1;
    this.termsOfUse = (LiveData<TermsOfUse>)r1;
  }
  
  public final LiveData<TermsOfUse> getTermsOfUse() {
    return this.termsOfUse;
  }
  
  public final void initialize() {
    c.a(c.a(c.a(this.userUseCase.getCountry(), 0, new TermsOfUseViewModel$initialize$1(null), 1, null), new TermsOfUseViewModel$initialize$2(null)), x.a(this));
  }
  
  public static abstract class TermsOfUse {
    public final boolean discountVisibility;
    
    public final e<String, String> feesRange;
    
    public final String higherAmounts;
    
    public final boolean isLoanAgreement;
    
    public final boolean lateFeesVisibility;
    
    public final String loanAgreementLink;
    
    public final e<String, String> loanRange;
    
    public final e<String, String> monthlyFeesRange;
    
    public final boolean neutralCurrency;
    
    public final String privacyUrl;
    
    public final String termsOfUseUrl;
    
    public TermsOfUse(String param1String1, boolean param1Boolean1, boolean param1Boolean2, e<String, String> param1e1, e<String, String> param1e2, e<String, String> param1e3, String param1String2, String param1String3, String param1String4, boolean param1Boolean3, boolean param1Boolean4) {
      this.higherAmounts = param1String1;
      this.discountVisibility = param1Boolean1;
      this.lateFeesVisibility = param1Boolean2;
      this.loanRange = param1e1;
      this.feesRange = param1e2;
      this.monthlyFeesRange = param1e3;
      this.termsOfUseUrl = param1String2;
      this.loanAgreementLink = param1String3;
      this.privacyUrl = param1String4;
      this.neutralCurrency = param1Boolean3;
      this.isLoanAgreement = param1Boolean4;
    }
    
    public final boolean getDiscountVisibility() {
      return this.discountVisibility;
    }
    
    public final e<String, String> getFeesRange() {
      return this.feesRange;
    }
    
    public final String getHigherAmounts() {
      return this.higherAmounts;
    }
    
    public final boolean getLateFeesVisibility() {
      return this.lateFeesVisibility;
    }
    
    public final String getLoanAgreementLink() {
      return this.loanAgreementLink;
    }
    
    public final e<String, String> getLoanRange() {
      return this.loanRange;
    }
    
    public final e<String, String> getMonthlyFeesRange() {
      return this.monthlyFeesRange;
    }
    
    public final boolean getNeutralCurrency() {
      return this.neutralCurrency;
    }
    
    public final String getPrivacyUrl() {
      return this.privacyUrl;
    }
    
    public final String getTermsOfUseUrl() {
      return this.termsOfUseUrl;
    }
    
    public final boolean isLoanAgreement() {
      return this.isLoanAgreement;
    }
    
    public static final class Indian extends TermsOfUse {
      public Indian(String param2String1, String param2String2) {
        super("₹50,000 rupees", false, false, i.a(str, stringBuilder2.toString()), i.a("1%", "15%"), i.a("1%", "10%"), "https://www.fairmoney.in/terms-and-conditions", param2String2, "https://www.fairmoney.in/privacy-policy", true, true, null);
      }
    }
    
    public static final class Nigerian extends TermsOfUse {
      public Nigerian(String param2String) {
        super(str1, true, true, i.a(str2, stringBuilder2.toString()), i.a("10%", "40%"), i.a("1%", "30%"), "https://fairmoney.ng/terms-of-use/", " ", "https://fairmoney.ng/privacy-policy/", false, false, null);
      }
    }
  }
  
  public static final class Indian extends TermsOfUse {
    public Indian(String param1String1, String param1String2) {
      super("₹50,000 rupees", false, false, i.a(str, stringBuilder2.toString()), i.a("1%", "15%"), i.a("1%", "10%"), "https://www.fairmoney.in/terms-and-conditions", param1String2, "https://www.fairmoney.in/privacy-policy", true, true, null);
    }
  }
  
  public static final class Nigerian extends TermsOfUse {
    public Nigerian(String param1String) {
      super(str1, true, true, i.a(str2, stringBuilder2.toString()), i.a("10%", "40%"), i.a("1%", "30%"), "https://fairmoney.ng/terms-of-use/", " ", "https://fairmoney.ng/privacy-policy/", false, false, null);
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel$initialize$1", f = "TermsOfUseViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class TermsOfUseViewModel$initialize$1 extends k implements p<b, d<? super a<? extends TermsOfUse>>, Object> {
    public int label;
    
    public b p$0;
    
    public TermsOfUseViewModel$initialize$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      TermsOfUseViewModel$initialize$1 termsOfUseViewModel$initialize$1 = new TermsOfUseViewModel$initialize$1(param1d);
      termsOfUseViewModel$initialize$1.p$0 = (b)param1Object;
      return (d<k>)termsOfUseViewModel$initialize$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((TermsOfUseViewModel$initialize$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        if (k.a(param1Object, b.b.h)) {
          param1Object = c.a(new TermsOfUseViewModel.TermsOfUse.Nigerian(param1Object.b()));
        } else {
          if (k.a(param1Object, b.a.h))
            return new TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1(c.a(TermsOfUseViewModel.this.loanUseCase.a(), new q<b<? super URL>, Throwable, d<? super k>, Object>(null) {
                    public Object L$0;
                    
                    public Object L$1;
                    
                    public int label;
                    
                    public b p$;
                    
                    public Throwable p$0;
                    
                    public final d<k> create(b<? super URL> param1b, Throwable param1Throwable, d<? super k> param1d) {
                      k.b(param1b, "$this$create");
                      k.b(param1Throwable, "it");
                      k.b(param1d, "continuation");
                      q<b<? super URL>, Throwable, d<? super k>, Object> q1 = new q<b<? super URL>, Throwable, d<? super k>, Object>(param1d);
                      q1.p$ = param1b;
                      q1.p$0 = param1Throwable;
                      return (d)q1;
                    }
                    
                    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                      return ((null)create((b<? super URL>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
                    }
                    
                    public final Object invokeSuspend(Object param1Object) {
                      Object object = c.a();
                      int i = this.label;
                      if (i != 0) {
                        if (i == 1) {
                          object = this.L$1;
                          object = this.L$0;
                          g.a(param1Object);
                        } else {
                          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        } 
                      } else {
                        g.a(param1Object);
                        b b1 = this.p$;
                        param1Object = this.p$0;
                        URL uRL = new URL("https://app.fairmoney.com.ng/in/loan_agreement");
                        this.L$0 = b1;
                        this.L$1 = param1Object;
                        this.label = 1;
                        if (b1.emit(uRL, (d)this) == object)
                          return object; 
                      } 
                      return k.a;
                    }
                  }), (b)param1Object); 
          if (k.a(param1Object, b.c.h))
            throw new IllegalArgumentException("Terms of use must have known country"); 
          throw new NoWhenBranchMatchedException();
        } 
        return param1Object;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    public static final class TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 implements a<TermsOfUseViewModel.TermsOfUse.Indian> {
      public TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1(a param1a, b param1b) {}
      
      public Object collect(b param1b, d param1d) {
        Object object = this.$this_unsafeTransform$inlined.collect(new b<URL>(this) {
              public Object emit(Object param1Object, d param1d) {
                b b1 = this.$this_unsafeFlow$inlined;
                URL uRL = (URL)param1Object;
                param1Object = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(", <a href=\"");
                stringBuilder.append(uRL);
                stringBuilder.append("\">loan agreement</a> ");
                param1Object = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)param1Object, stringBuilder.toString()), param1d);
                return (param1Object == c.a()) ? param1Object : k.a;
              }
            }param1d);
        return (object == c.a()) ? object : k.a;
      }
    }
    
    public static final class null implements b<URL> {
      public null(TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 param1TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1) {}
      
      public Object emit(Object param1Object, d param1d) {
        b b1 = this.$this_unsafeFlow$inlined;
        URL uRL = (URL)param1Object;
        param1Object = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(", <a href=\"");
        stringBuilder.append(uRL);
        stringBuilder.append("\">loan agreement</a> ");
        param1Object = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)param1Object, stringBuilder.toString()), param1d);
        return (param1Object == c.a()) ? param1Object : k.a;
      }
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel$initialize$1$1", f = "TermsOfUseViewModel.kt", l = {48}, m = "invokeSuspend")
  public static final class null extends k implements q<b<? super URL>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public null(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super URL> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      q<b<? super URL>, Throwable, d<? super k>, Object> q1 = new q<b<? super URL>, Throwable, d<? super k>, Object>(param1d);
      q1.p$ = param1b;
      q1.p$0 = param1Throwable;
      return (d)q1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((null)create((b<? super URL>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        param1Object = this.p$0;
        URL uRL = new URL("https://app.fairmoney.com.ng/in/loan_agreement");
        this.L$0 = b1;
        this.L$1 = param1Object;
        this.label = 1;
        if (b1.emit(uRL, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  public static final class TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 implements a<TermsOfUse.Indian> {
    public TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1(a param1a, b param1b) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<URL>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              URL uRL = (URL)param1Object;
              param1Object = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(", <a href=\"");
              stringBuilder.append(uRL);
              stringBuilder.append("\">loan agreement</a> ");
              param1Object = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)param1Object, stringBuilder.toString()), param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<URL> {
    public null(TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1 param1TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      URL uRL = (URL)param1Object;
      param1Object = TermsOfUseViewModel$initialize$1$invokeSuspend$$inlined$map$1.this.$country$inlined.b();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(", <a href=\"");
      stringBuilder.append(uRL);
      stringBuilder.append("\">loan agreement</a> ");
      param1Object = b1.emit(new TermsOfUseViewModel.TermsOfUse.Indian((String)param1Object, stringBuilder.toString()), param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel$initialize$2", f = "TermsOfUseViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class TermsOfUseViewModel$initialize$2 extends k implements p<TermsOfUse, d<? super k>, Object> {
    public int label;
    
    public TermsOfUseViewModel.TermsOfUse p$0;
    
    public TermsOfUseViewModel$initialize$2(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      TermsOfUseViewModel$initialize$2 termsOfUseViewModel$initialize$2 = new TermsOfUseViewModel$initialize$2(param1d);
      termsOfUseViewModel$initialize$2.p$0 = (TermsOfUseViewModel.TermsOfUse)param1Object;
      return (d<k>)termsOfUseViewModel$initialize$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((TermsOfUseViewModel$initialize$2)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        TermsOfUseViewModel.this.mutableTermsOfUse.b(param1Object);
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\termsofuse\TermsOfUseViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
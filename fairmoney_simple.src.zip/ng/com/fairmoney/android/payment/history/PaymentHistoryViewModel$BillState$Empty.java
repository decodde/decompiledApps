package ng.com.fairmoney.android.payment.history;

public final class Empty extends PaymentHistoryViewModel.BillState {
  public static final Empty INSTANCE = new Empty();
  
  public Empty() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel$BillState$Empty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
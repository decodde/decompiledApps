package ng.com.fairmoney.fairmoney.activities.signup;

import android.view.View;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    PhoneSignupConfirmPasswordActivity phoneSignupConfirmPasswordActivity = PhoneSignupConfirmPasswordActivity.this;
    PhoneSignupConfirmPasswordActivity.access$100(phoneSignupConfirmPasswordActivity, PhoneSignupConfirmPasswordActivity.access$000(phoneSignupConfirmPasswordActivity));
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupConfirmPasswordActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.offer;

import j.q.d.g;
import j.q.d.k;

public abstract class LoanOfferDetailsDataState {
  public LoanOfferDetailsDataState() {}
  
  public static final class DisbursementFees extends LoanOfferDetailsDataState {
    public final String disbursementAmountValue;
    
    public final String interestTitle;
    
    public final String interestValue;
    
    public final String loanAmountValue;
    
    public final String processingFeesValue;
    
    public final String taxTitle;
    
    public final String taxValue;
    
    public final String totalValueToPay;
    
    public DisbursementFees(String param2String1, String param2String2, String param2String3, String param2String4, String param2String5, String param2String6, String param2String7, String param2String8) {
      super(null);
      this.disbursementAmountValue = param2String1;
      this.processingFeesValue = param2String2;
      this.taxTitle = param2String3;
      this.taxValue = param2String4;
      this.loanAmountValue = param2String5;
      this.interestTitle = param2String6;
      this.interestValue = param2String7;
      this.totalValueToPay = param2String8;
    }
    
    public final String component1() {
      return this.disbursementAmountValue;
    }
    
    public final String component2() {
      return this.processingFeesValue;
    }
    
    public final String component3() {
      return this.taxTitle;
    }
    
    public final String component4() {
      return this.taxValue;
    }
    
    public final String component5() {
      return this.loanAmountValue;
    }
    
    public final String component6() {
      return this.interestTitle;
    }
    
    public final String component7() {
      return this.interestValue;
    }
    
    public final String component8() {
      return this.totalValueToPay;
    }
    
    public final DisbursementFees copy(String param2String1, String param2String2, String param2String3, String param2String4, String param2String5, String param2String6, String param2String7, String param2String8) {
      k.b(param2String1, "disbursementAmountValue");
      k.b(param2String2, "processingFeesValue");
      k.b(param2String3, "taxTitle");
      k.b(param2String4, "taxValue");
      k.b(param2String5, "loanAmountValue");
      k.b(param2String6, "interestTitle");
      k.b(param2String7, "interestValue");
      k.b(param2String8, "totalValueToPay");
      return new DisbursementFees(param2String1, param2String2, param2String3, param2String4, param2String5, param2String6, param2String7, param2String8);
    }
    
    public boolean equals(Object param2Object) {
      if (this != param2Object) {
        if (param2Object instanceof DisbursementFees) {
          param2Object = param2Object;
          if (k.a(this.disbursementAmountValue, ((DisbursementFees)param2Object).disbursementAmountValue) && k.a(this.processingFeesValue, ((DisbursementFees)param2Object).processingFeesValue) && k.a(this.taxTitle, ((DisbursementFees)param2Object).taxTitle) && k.a(this.taxValue, ((DisbursementFees)param2Object).taxValue) && k.a(this.loanAmountValue, ((DisbursementFees)param2Object).loanAmountValue) && k.a(this.interestTitle, ((DisbursementFees)param2Object).interestTitle) && k.a(this.interestValue, ((DisbursementFees)param2Object).interestValue) && k.a(this.totalValueToPay, ((DisbursementFees)param2Object).totalValueToPay))
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final String getDisbursementAmountValue() {
      return this.disbursementAmountValue;
    }
    
    public final String getInterestTitle() {
      return this.interestTitle;
    }
    
    public final String getInterestValue() {
      return this.interestValue;
    }
    
    public final String getLoanAmountValue() {
      return this.loanAmountValue;
    }
    
    public final String getProcessingFeesValue() {
      return this.processingFeesValue;
    }
    
    public final String getTaxTitle() {
      return this.taxTitle;
    }
    
    public final String getTaxValue() {
      return this.taxValue;
    }
    
    public final String getTotalValueToPay() {
      return this.totalValueToPay;
    }
    
    public int hashCode() {
      byte b1;
      byte b2;
      byte b3;
      byte b4;
      byte b5;
      byte b6;
      byte b7;
      String str = this.disbursementAmountValue;
      int i = 0;
      if (str != null) {
        b1 = str.hashCode();
      } else {
        b1 = 0;
      } 
      str = this.processingFeesValue;
      if (str != null) {
        b2 = str.hashCode();
      } else {
        b2 = 0;
      } 
      str = this.taxTitle;
      if (str != null) {
        b3 = str.hashCode();
      } else {
        b3 = 0;
      } 
      str = this.taxValue;
      if (str != null) {
        b4 = str.hashCode();
      } else {
        b4 = 0;
      } 
      str = this.loanAmountValue;
      if (str != null) {
        b5 = str.hashCode();
      } else {
        b5 = 0;
      } 
      str = this.interestTitle;
      if (str != null) {
        b6 = str.hashCode();
      } else {
        b6 = 0;
      } 
      str = this.interestValue;
      if (str != null) {
        b7 = str.hashCode();
      } else {
        b7 = 0;
      } 
      str = this.totalValueToPay;
      if (str != null)
        i = str.hashCode(); 
      return ((((((b1 * 31 + b2) * 31 + b3) * 31 + b4) * 31 + b5) * 31 + b6) * 31 + b7) * 31 + i;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("DisbursementFees(disbursementAmountValue=");
      stringBuilder.append(this.disbursementAmountValue);
      stringBuilder.append(", processingFeesValue=");
      stringBuilder.append(this.processingFeesValue);
      stringBuilder.append(", taxTitle=");
      stringBuilder.append(this.taxTitle);
      stringBuilder.append(", taxValue=");
      stringBuilder.append(this.taxValue);
      stringBuilder.append(", loanAmountValue=");
      stringBuilder.append(this.loanAmountValue);
      stringBuilder.append(", interestTitle=");
      stringBuilder.append(this.interestTitle);
      stringBuilder.append(", interestValue=");
      stringBuilder.append(this.interestValue);
      stringBuilder.append(", totalValueToPay=");
      stringBuilder.append(this.totalValueToPay);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class Empty extends LoanOfferDetailsDataState {
    public static final Empty INSTANCE = new Empty();
    
    public Empty() {
      super(null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsViewModel$LoanOfferDetailsDataState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
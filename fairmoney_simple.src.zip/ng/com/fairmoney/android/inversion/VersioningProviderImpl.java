package ng.com.fairmoney.android.inversion;

import android.content.Context;
import f.d.a.m;
import j.q.d.k;
import javax.inject.Inject;
import ng.com.fairmoney.fairmoney.utils.Utils;

public final class VersioningProviderImpl implements m {
  public final Context context;
  
  @Inject
  public VersioningProviderImpl(Context paramContext) {
    this.context = paramContext;
  }
  
  public String getVersionCode() {
    String str = Utils.getVersionCode(this.context);
    k.a(str, "Utils.getVersionCode(context)");
    return str;
  }
  
  public String getVersionName() {
    String str = Utils.getVersionName(this.context);
    k.a(str, "Utils.getVersionName(context)");
    return str;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\VersioningProviderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.bankdetails;

import f.d.b.c;
import f.d.b.i.e;
import g.b.d;
import javax.inject.Provider;

public final class BankDetailsViewModel_Factory implements d<BankDetailsViewModel> {
  public final Provider<e> loanUseCaseProvider;
  
  public final Provider<c> routerProvider;
  
  public BankDetailsViewModel_Factory(Provider<e> paramProvider, Provider<c> paramProvider1) {
    this.loanUseCaseProvider = paramProvider;
    this.routerProvider = paramProvider1;
  }
  
  public static BankDetailsViewModel_Factory create(Provider<e> paramProvider, Provider<c> paramProvider1) {
    return new BankDetailsViewModel_Factory(paramProvider, paramProvider1);
  }
  
  public static BankDetailsViewModel newInstance(e parame, c paramc) {
    return new BankDetailsViewModel(parame, paramc);
  }
  
  public BankDetailsViewModel get() {
    return newInstance((e)this.loanUseCaseProvider.get(), (c)this.routerProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.signup;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import d.l.a.o;
import f.d.b.k.f;
import java.io.Serializable;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.login.LoginActivity;
import ng.com.fairmoney.fairmoney.fragments.login.PhoneLoginOtpVerificationFragment;
import ng.com.fairmoney.fairmoney.fragments.signup.PhoneSignupEnterOtpPhoneSignupFragment;

public class PhoneSignupEnterOtpActivity extends LoginActivity {
  public static final String EXTRA_TOKEN = "EXTRA_TOKEN";
  
  public boolean canSkipPhoneVerification;
  
  public boolean isPhoneVerification = false;
  
  public String password;
  
  public f phoneNumber;
  
  public String ussdCode;
  
  public int verificationType;
  
  private void displayFragment() {
    int i = this.verificationType;
    if (i == 12 || i == 18) {
      displayFragment((Fragment)new PhoneLoginOtpVerificationFragment());
      return;
    } 
    displayFragment((Fragment)new PhoneSignupEnterOtpPhoneSignupFragment());
  }
  
  private void displayFragment(Fragment paramFragment) {
    paramFragment.setArguments(getArguments());
    o o = getSupportFragmentManager().a();
    o.a(2131296583, paramFragment);
    o.a();
  }
  
  private Bundle getArguments() {
    Bundle bundle = new Bundle();
    bundle.putBoolean("EXTRA_CAN_SKIP_PHONE_VERIFICATION", this.canSkipPhoneVerification);
    bundle.putInt("EXTRA_CASE_CODE", this.verificationType);
    bundle.putString("EXTRA_PASSWORD", this.password);
    bundle.putSerializable("EXTRA_PHONE_NUMBER", (Serializable)this.phoneNumber);
    bundle.putBoolean("EXTRA_PHONE_VERIFICATION", this.isPhoneVerification);
    bundle.putString("EXTRA_USSD_CODE", this.ussdCode);
    return bundle;
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {}
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, WelcomeActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((BaseActivity)this).isAuthMandatory = false;
    Intent intent = getIntent();
    if (intent != null) {
      this.phoneNumber = (f)getIntent().getSerializableExtra("EXTRA_PHONE_NUMBER");
      this.ussdCode = getIntent().getStringExtra("EXTRA_USSD_CODE");
      if (intent.getBooleanExtra("EXTRA_PHONE_VERIFICATION", false)) {
        this.canSkipPhoneVerification = intent.getBooleanExtra("EXTRA_CAN_SKIP_PHONE_VERIFICATION", false);
        this.verificationType = intent.getIntExtra("EXTRA_CASE_CODE", 0);
        this.password = intent.getStringExtra("EXTRA_PASSWORD");
        this.isPhoneVerification = true;
      } 
    } 
    displayFragment();
  }
  
  public int provideContentViewId() {
    return 2131492915;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupEnterOtpActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
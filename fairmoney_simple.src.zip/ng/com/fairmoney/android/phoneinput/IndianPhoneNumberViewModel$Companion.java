package ng.com.fairmoney.android.phoneinput;

import j.q.d.g;

public final class Companion {
  public Companion() {}
  
  public final int getMaxLength() {
    return IndianPhoneNumberViewModel.access$getMaxLength$cp();
  }
  
  public final void setMaxLength(int paramInt) {
    IndianPhoneNumberViewModel.access$setMaxLength$cp(paramInt);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\IndianPhoneNumberViewModel$Companion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
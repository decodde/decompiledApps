package ng.com.fairmoney.android.injection;

import f.d.b.b;
import f.d.c.i;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DataComponent_phoneNumberValidator implements Provider<b> {
  public final i dataComponent;
  
  public com_fairmoney_injection_DataComponent_phoneNumberValidator(i parami) {
    this.dataComponent = parami;
  }
  
  public b get() {
    b b = this.dataComponent.f();
    g.a(b, "Cannot return null from a non-@Nullable component method");
    return b;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DataComponent_phoneNumberValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
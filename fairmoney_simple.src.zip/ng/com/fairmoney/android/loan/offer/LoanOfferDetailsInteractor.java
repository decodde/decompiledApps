package ng.com.fairmoney.android.loan.offer;

import f.d.b.i.c;

public interface LoanOfferDetailsInteractor {
  void initialize(c paramc);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsInteractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
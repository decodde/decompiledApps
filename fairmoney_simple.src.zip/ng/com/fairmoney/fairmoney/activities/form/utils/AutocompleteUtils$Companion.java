package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ListAdapter;
import com.google.android.material.textfield.TextInputLayout;
import j.q.d.g;
import j.q.d.k;
import j.v.m;
import java.util.Map;

public final class Companion {
  public Companion() {}
  
  public final boolean isTextValid(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    k.b(paramActivity, "activity");
    k.b(paramMap, "params");
    AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView)paramActivity.findViewById(paramInt);
    if (paramMap.get("error_view_id") != null) {
      TextInputLayout textInputLayout = (TextInputLayout)paramActivity.findViewById(paramActivity.getResources().getIdentifier(paramMap.get("error_view_id"), "id", paramActivity.getPackageName()));
      k.a(autoCompleteTextView, "autocomplete");
      ListAdapter listAdapter = autoCompleteTextView.getAdapter();
      k.a(listAdapter, "autocomplete.adapter");
      int i = listAdapter.getCount();
      for (paramInt = 0; paramInt < i; paramInt++) {
        if (m.a(autoCompleteTextView.getText().toString(), (String)autoCompleteTextView.getAdapter().getItem(paramInt), true)) {
          FormUtils.hideErrors((EditText)autoCompleteTextView, textInputLayout);
          return true;
        } 
      } 
      FormUtils.setTextError((EditText)autoCompleteTextView, textInputLayout, paramActivity.getString(2131821029, new Object[] { paramMap.get("display_name") }));
    } 
    return false;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\AutocompleteUtils$Companion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
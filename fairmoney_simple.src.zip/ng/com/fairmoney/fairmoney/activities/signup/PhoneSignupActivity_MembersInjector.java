package ng.com.fairmoney.fairmoney.activities.signup;

import d.o.y;
import g.a;
import javax.inject.Provider;
import ng.com.fairmoney.fairmoney.activities.login.LoginActivity_MembersInjector;

public final class PhoneSignupActivity_MembersInjector implements a<PhoneSignupActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public final Provider<y.b> viewModelFactoryProvider2;
  
  public PhoneSignupActivity_MembersInjector(Provider<y.b> paramProvider1, Provider<y.b> paramProvider2) {
    this.viewModelFactoryProvider = paramProvider1;
    this.viewModelFactoryProvider2 = paramProvider2;
  }
  
  public static a<PhoneSignupActivity> create(Provider<y.b> paramProvider1, Provider<y.b> paramProvider2) {
    return new PhoneSignupActivity_MembersInjector(paramProvider1, paramProvider2);
  }
  
  public static void injectViewModelFactory(PhoneSignupActivity paramPhoneSignupActivity, y.b paramb) {
    paramPhoneSignupActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(PhoneSignupActivity paramPhoneSignupActivity) {
    LoginActivity_MembersInjector.injectViewModelFactory(paramPhoneSignupActivity, (y.b)this.viewModelFactoryProvider.get());
    injectViewModelFactory(paramPhoneSignupActivity, (y.b)this.viewModelFactoryProvider2.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
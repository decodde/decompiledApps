package ng.com.fairmoney.android.loan.form.personal;

import f.d.b.c;
import f.d.b.e.a.a;
import f.d.b.g.a;
import f.d.b.h.c;
import f.d.b.k.g;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class FormPersonalViewModel_Factory implements d<FormPersonalViewModel> {
  public final Provider<a> featuresProvider;
  
  public final Provider<a> formPersonalRepositoryProvider;
  
  public final Provider<c> kycUseCaseProvider;
  
  public final Provider<c> routerProvider;
  
  public final Provider<g> userRepositoryProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public FormPersonalViewModel_Factory(Provider<a> paramProvider, Provider<h> paramProvider1, Provider<c> paramProvider2, Provider<c> paramProvider3, Provider<g> paramProvider4, Provider<a> paramProvider5) {
    this.formPersonalRepositoryProvider = paramProvider;
    this.userUseCaseProvider = paramProvider1;
    this.kycUseCaseProvider = paramProvider2;
    this.routerProvider = paramProvider3;
    this.userRepositoryProvider = paramProvider4;
    this.featuresProvider = paramProvider5;
  }
  
  public static FormPersonalViewModel_Factory create(Provider<a> paramProvider, Provider<h> paramProvider1, Provider<c> paramProvider2, Provider<c> paramProvider3, Provider<g> paramProvider4, Provider<a> paramProvider5) {
    return new FormPersonalViewModel_Factory(paramProvider, paramProvider1, paramProvider2, paramProvider3, paramProvider4, paramProvider5);
  }
  
  public static FormPersonalViewModel newInstance(a parama, h paramh, c paramc, c paramc1, g paramg, a parama1) {
    return new FormPersonalViewModel(parama, paramh, paramc, paramc1, paramg, parama1);
  }
  
  public FormPersonalViewModel get() {
    return newInstance((a)this.formPersonalRepositoryProvider.get(), (h)this.userUseCaseProvider.get(), (c)this.kycUseCaseProvider.get(), (c)this.routerProvider.get(), (g)this.userRepositoryProvider.get(), (a)this.featuresProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
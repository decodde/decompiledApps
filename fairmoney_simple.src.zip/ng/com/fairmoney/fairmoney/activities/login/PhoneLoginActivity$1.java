package ng.com.fairmoney.fairmoney.activities.login;

import ng.com.fairmoney.fairmoney.models.PhoneAuthentication;
import ng.com.fairmoney.fairmoney.models.Session;
import ng.com.fairmoney.fairmoney.models.UssdCode;
import ng.com.fairmoney.fairmoney.network.model.GenericApiResponse;

public class null extends GenericApiResponse<Session, UssdCode> {
  public void failure(int paramInt, String paramString, UssdCode paramUssdCode) {
    PhoneLoginActivity.this.logLoginResult("Phone", false);
    if (paramInt == 17) {
      PhoneLoginActivity.access$200(PhoneLoginActivity.this);
    } else if (paramInt == 401) {
      PhoneLoginActivity.access$300(PhoneLoginActivity.this).setText(2131820763);
      PhoneLoginActivity.this.showNewToastMessage(paramString, 1);
    } else {
      PhoneLoginActivity phoneLoginActivity;
      if (paramInt == 12 || paramInt == 18) {
        phoneLoginActivity = PhoneLoginActivity.this;
        phoneLoginActivity.savePhoneNumber(PhoneLoginActivity.access$000(phoneLoginActivity));
        PhoneLoginActivity.access$400(PhoneLoginActivity.this, phoneAuthentication, paramInt, paramUssdCode);
      } else {
        PhoneLoginActivity.this.showNewToastMessage((String)phoneLoginActivity, 1);
      } 
    } 
    PhoneLoginActivity.this.makeButtonEnabled(true);
  }
  
  public void success(Session paramSession) {
    PhoneLoginActivity phoneLoginActivity = PhoneLoginActivity.this;
    phoneLoginActivity.savePhoneNumber(PhoneLoginActivity.access$000(phoneLoginActivity));
    PhoneLoginActivity.access$100(PhoneLoginActivity.this, paramSession);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\PhoneLoginActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
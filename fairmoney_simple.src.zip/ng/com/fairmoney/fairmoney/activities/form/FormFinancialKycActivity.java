package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;
import com.google.android.material.textfield.TextInputLayout;
import d.l.a.d;
import d.o.y;
import d.o.z;
import f.d.c.b;
import javax.inject.Inject;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.models.BankDetails;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import ng.com.fairmoney.fairmoney.utils.Authentication;
import ng.com.fairmoney.fairmoney.viewmodels.FormFinancialKycViewModel;

public class FormFinancialKycActivity extends FormActivity {
  public EditText etBvn;
  
  public FormFinancialKycViewModel formFinancialKycViewModel;
  
  public TextInputLayout tilFormBvn;
  
  @Inject
  public y.b viewModelFactory;
  
  private void goToBvnVerificationActivity(BankDetails paramBankDetails) {
    Intent intent = new Intent(getApplicationContext(), BvnVerificationActivity.class);
    intent.putExtra("EXTRA_BANK_DETAILS", (Parcelable)paramBankDetails);
    startActivity(intent);
    finish();
  }
  
  private void setUserBvn(BankDetails paramBankDetails) {
    RetrofitSession.getInstance((Context)this).getUserManager().setUserBvn(Authentication.getUserId((Context)this), paramBankDetails, new APIResponse<BankDetails>() {
          public void failure(int param1Int, String param1String) {
            FormFinancialKycActivity.this.onFormCallFailure(param1String);
          }
          
          public void success(BankDetails param1BankDetails) {
            if (param1BankDetails.isBvnVerificationMandatory()) {
              FormFinancialKycActivity.this.goToBvnVerificationActivity(param1BankDetails);
            } else {
              FormFinancialKycActivity.this.goToNextActivity();
            } 
          }
        });
  }
  
  public void goToNextActivity() {
    Intent intent;
    if (this.formFinancialKycViewModel.isMbsEnabled()) {
      intent = new Intent(getApplicationContext(), FormFinancialMBSActivity.class);
    } else {
      intent = new Intent(getApplicationContext(), FormWorkActivity.class);
    } 
    intent.putExtra("EXTRA_BVN", this.etBvn.getText().toString());
    startActivity(intent);
    finish();
  }
  
  public void goToPreviousActivity() {
    startActivity(new Intent(getApplicationContext(), FormPersonalActivity.class));
    finish();
  }
  
  public void onClickOnNextButton(View paramView) {
    if (this.etBvn.getText().length() == 0) {
      this.tilFormBvn.setError(getString(2131821029, new Object[] { "BVN" }));
      return;
    } 
    disableNextButton();
    this.tilFormBvn.setError(null);
    BankDetails bankDetails = new BankDetails();
    bankDetails.setBvn(this.etBvn.getText().toString());
    setUserBvn(bankDetails);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    fillFormWithPreviousResponses();
    initBackButton(2131296632);
    this.etBvn = (EditText)findViewById(2131296533);
    this.tilFormBvn = (TextInputLayout)findViewById(2131296997);
    if (getIntent() != null) {
      String str = getIntent().getStringExtra("EXTRA_BVN");
      this.etBvn.setText(str);
    } 
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.formFinancialKycViewModel = (FormFinancialKycViewModel)z.a((d)this, this.viewModelFactory).a(FormFinancialKycViewModel.class);
  }
  
  public int provideContentViewId() {
    return 2131492900;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormFinancialKycActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import d.i.f.a;
import ng.com.fairmoney.fairmoney.activities.form.FormActivity;
import ng.com.fairmoney.fairmoney.activities.form.PermissionsActivity;

public abstract class BasePermissionActivity extends FormActivity {
  public static final int PERMISSION_CALLBACK_CONSTANT = 100;
  
  public static final int REQUEST_PERMISSION_SETTING = 101;
  
  public static final String[] requiredPermissions = new String[] { "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_SMS", "android.permission.READ_CONTACTS", "android.permission.READ_PHONE_STATE" };
  
  private boolean isPermissionGranted(String paramString) {
    boolean bool;
    if (a.a((Context)this, paramString) == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean missingPermission() {
    String[] arrayOfString = requiredPermissions;
    int i = arrayOfString.length;
    for (byte b = 0; b < i; b++) {
      if (!isPermissionGranted(arrayOfString[b]))
        return true; 
    } 
    return false;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (missingPermission() && !(this instanceof PermissionsActivity)) {
      startActivity(new Intent(getApplicationContext(), PermissionsActivity.class));
      finish();
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\BasePermissionActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
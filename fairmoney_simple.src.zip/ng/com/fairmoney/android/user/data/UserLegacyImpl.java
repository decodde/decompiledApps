package ng.com.fairmoney.android.user.data;

import android.content.Context;
import android.content.SharedPreferences;
import f.d.a.t.e;
import j.q.d.k;
import ng.com.fairmoney.fairmoney.utils.Authentication;
import ng.com.fairmoney.fairmoney.utils.PhoneUtils;
import ng.com.fairmoney.fairmoney.utils.Utils;

public final class UserLegacyImpl implements e {
  public final Context context;
  
  public UserLegacyImpl(Context paramContext) {
    this.context = paramContext;
  }
  
  public String getApplicationId() {
    String str = Utils.getLoanApplicationId(this.context);
    k.a(str, "Utils.getLoanApplicationId(context)");
    return str;
  }
  
  public final Context getContext() {
    return this.context;
  }
  
  public String getEmail() {
    return this.context.getSharedPreferences("CurrentUser", 0).getString("et_form_email", null);
  }
  
  public String getFormattedPhoneNumber() {
    SharedPreferences sharedPreferences = this.context.getSharedPreferences("CurrentUser", 0);
    String str2 = null;
    String str1 = sharedPreferences.getString("phone", null);
    if (str1 != null)
      str2 = PhoneUtils.preparePhoneNumber(str1); 
    return str2;
  }
  
  public String getUserId() {
    return Authentication.getUserId(this.context);
  }
  
  public void savePhone(String paramString) {
    this.context.getSharedPreferences("CurrentUser", 0).edit().putString("phone", paramString).putString("et_form_phone", paramString).apply();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\androi\\user\data\UserLegacyImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
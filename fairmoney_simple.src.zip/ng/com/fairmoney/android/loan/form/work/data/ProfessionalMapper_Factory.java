package ng.com.fairmoney.android.loan.form.work.data;

import g.b.d;

public final class ProfessionalMapper_Factory implements d<ProfessionalMapper> {
  public static ProfessionalMapper_Factory create() {
    return InstanceHolder.INSTANCE;
  }
  
  public static ProfessionalMapper newInstance() {
    return new ProfessionalMapper();
  }
  
  public ProfessionalMapper get() {
    return newInstance();
  }
  
  public static final class InstanceHolder {
    public static final ProfessionalMapper_Factory INSTANCE = new ProfessionalMapper_Factory();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\data\ProfessionalMapper_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.form.personal;

import f.d.b.k.a;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.a;
import k.a.h2.b;

public final class FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1 implements a<FormPersonalViewModel.FormPersonalState> {
  public FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1(a parama) {}
  
  public Object collect(b paramb, d paramd) {
    Object object = this.$this_unsafeTransform$inlined.collect(new b<a>(this) {
          public Object emit(Object param1Object, d param1d) {
            b b1 = this.$this_unsafeFlow$inlined;
            if (((a)param1Object).a() == null) {
              param1Object = FormPersonalViewModel.FormPersonalState.Bvn.INSTANCE;
            } else {
              param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
            } 
            param1Object = b1.emit(param1Object, param1d);
            return (param1Object == c.a()) ? param1Object : k.a;
          }
        }paramd);
    return (object == c.a()) ? object : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
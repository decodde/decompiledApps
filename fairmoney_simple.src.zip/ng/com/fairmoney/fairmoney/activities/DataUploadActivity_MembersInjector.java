package ng.com.fairmoney.fairmoney.activities;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class DataUploadActivity_MembersInjector implements a<DataUploadActivity> {
  public final Provider<y.b> factoryProvider;
  
  public DataUploadActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.factoryProvider = paramProvider;
  }
  
  public static a<DataUploadActivity> create(Provider<y.b> paramProvider) {
    return new DataUploadActivity_MembersInjector(paramProvider);
  }
  
  public static void injectFactory(DataUploadActivity paramDataUploadActivity, y.b paramb) {
    paramDataUploadActivity.factory = paramb;
  }
  
  public void injectMembers(DataUploadActivity paramDataUploadActivity) {
    injectFactory(paramDataUploadActivity, (y.b)this.factoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.login;

import android.text.Editable;
import android.text.TextWatcher;
import com.google.android.material.textfield.TextInputLayout;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;

public class PasswordTextWatcher implements TextWatcher {
  public PhoneInputView pivLogin;
  
  public TextInputLayout tilPassword;
  
  public PasswordTextWatcher(TextInputLayout paramTextInputLayout, PhoneInputView paramPhoneInputView) {
    this.tilPassword = paramTextInputLayout;
    this.pivLogin = paramPhoneInputView;
  }
  
  public void afterTextChanged(Editable paramEditable) {
    if (paramEditable.length() == 4) {
      this.tilPassword.setError(null);
      if (this.pivLogin.getPhoneNumber(false) != null)
        PhoneLoginActivity.access$500(PhoneLoginActivity.this).setEnabled(true); 
    } else {
      PhoneLoginActivity.access$500(PhoneLoginActivity.this).setEnabled(false);
    } 
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\PhoneLoginActivity$PasswordTextWatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
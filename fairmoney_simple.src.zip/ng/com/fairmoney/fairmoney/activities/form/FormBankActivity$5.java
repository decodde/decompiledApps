package ng.com.fairmoney.fairmoney.activities.form;

import android.view.View;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    if (!FormBankActivity.this.checkAnswersValidity())
      return; 
    FormBankActivity.this.goToNextActivity();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
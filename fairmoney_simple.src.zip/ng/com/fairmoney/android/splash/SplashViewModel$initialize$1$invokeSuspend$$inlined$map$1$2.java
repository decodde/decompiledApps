package ng.com.fairmoney.android.splash;

import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.b;

public final class null implements b<Boolean> {
  public null(SplashViewModel$initialize$1$invokeSuspend$$inlined$map$1 paramSplashViewModel$initialize$1$invokeSuspend$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    if (((Boolean)paramObject).booleanValue()) {
      paramObject = SplashViewModel.RouteState.Welcome.INSTANCE;
    } else {
      paramObject = SplashViewModel.RouteState.WalkThrough.INSTANCE;
    } 
    paramObject = b1.emit(paramObject, paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\splash\SplashViewModel$initialize$1$invokeSuspend$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
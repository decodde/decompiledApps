package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.firebase.analytics.FirebaseAnalytics;
import f.h.c.f.a;
import ng.com.fairmoney.fairmoney.activities.login.LoginActivity;
import ng.com.fairmoney.fairmoney.activities.login.PhoneLoginActivity;
import ng.com.fairmoney.fairmoney.activities.signup.PhoneSignupActivity;
import ng.com.fairmoney.fairmoney.utils.Authentication;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class WelcomeActivity extends LoginActivity {
  private void init() {
    FirebaseAnalytics.getInstance((Context)this);
    a.a().a(getIntent());
    Authentication.invalidateToken((Context)this);
    Tracking.sendUniqueEvent((Context)this, new Event("application", "loginScreen"));
    initView();
  }
  
  private void initView() {
    ((Button)findViewById(2131296404)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            WelcomeActivity.this.startActivity(new Intent((Context)WelcomeActivity.this, PhoneSignupActivity.class));
            WelcomeActivity.this.finish();
          }
        });
    ((Button)findViewById(2131296403)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            WelcomeActivity.this.startActivity(new Intent((Context)WelcomeActivity.this, PhoneLoginActivity.class));
            WelcomeActivity.this.finish();
          }
        });
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {}
  
  public void onBackPressed() {
    Intent intent = new Intent("android.intent.action.MAIN");
    intent.addCategory("android.intent.category.HOME");
    intent.setFlags(268435456);
    startActivity(intent);
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((BaseActivity)this).isAuthMandatory = false;
    init();
  }
  
  public int provideContentViewId() {
    return 2131492923;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\WelcomeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
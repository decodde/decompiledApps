package ng.com.fairmoney.android.loan.form.work.data;

public final class InstanceHolder {
  public static final ProfessionalMapper_Factory INSTANCE = new ProfessionalMapper_Factory();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\data\ProfessionalMapper_Factory$InstanceHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
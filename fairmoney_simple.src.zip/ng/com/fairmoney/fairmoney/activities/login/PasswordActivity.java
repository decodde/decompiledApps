package ng.com.fairmoney.fairmoney.activities.login;

import android.content.Context;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import ng.com.fairmoney.fairmoney.textwatcher.DeletePressedWatcher;
import ng.com.fairmoney.fairmoney.textwatcher.PasswordTextWatcher;

public abstract class PasswordActivity extends LoginActivity implements PasswordTextWatcher.OnPasswordTextChangedListener {
  public EditText etPassword1;
  
  public EditText etPassword2;
  
  public EditText etPassword3;
  
  public EditText etPassword4;
  
  public void confirmPassword(String paramString) {
    TextView textView = (TextView)findViewById(2131297100);
    String str = getPassword();
    if (str.length() != 4) {
      textView.setText(2131820770);
      textView.setVisibility(0);
      return;
    } 
    if (paramString.contentEquals(str)) {
      textView.setVisibility(8);
      makeButtonEnabled(false);
      makePasswordAction();
    } else {
      textView.setText(2131821032);
      textView.setVisibility(0);
    } 
  }
  
  public String getPassword() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.etPassword1.getText().toString());
    stringBuilder.append(this.etPassword2.getText().toString());
    stringBuilder.append(this.etPassword3.getText().toString());
    stringBuilder.append(this.etPassword4.getText().toString());
    return stringBuilder.toString();
  }
  
  public void initPasswords() {
    this.etPassword1 = (EditText)findViewById(2131296556);
    this.etPassword2 = (EditText)findViewById(2131296557);
    this.etPassword3 = (EditText)findViewById(2131296558);
    this.etPassword4 = (EditText)findViewById(2131296559);
    EditText editText = this.etPassword1;
    editText.addTextChangedListener((TextWatcher)new PasswordTextWatcher((Context)this, editText, this.etPassword2, this));
    editText = this.etPassword2;
    editText.addTextChangedListener((TextWatcher)new PasswordTextWatcher((Context)this, editText, this.etPassword3, this));
    editText = this.etPassword2;
    editText.setOnKeyListener((View.OnKeyListener)new DeletePressedWatcher((Context)this, editText, this.etPassword1));
    editText = this.etPassword3;
    editText.addTextChangedListener((TextWatcher)new PasswordTextWatcher((Context)this, editText, this.etPassword4, this));
    editText = this.etPassword3;
    editText.setOnKeyListener((View.OnKeyListener)new DeletePressedWatcher((Context)this, editText, this.etPassword2));
    editText = this.etPassword4;
    editText.addTextChangedListener((TextWatcher)new PasswordTextWatcher((Context)this, editText, null, this));
    editText = this.etPassword4;
    editText.setOnKeyListener((View.OnKeyListener)new DeletePressedWatcher((Context)this, editText, this.etPassword3));
  }
  
  public abstract void makePasswordAction();
  
  public void onTextChanged() {
    boolean bool;
    if (getPassword().length() == 4) {
      bool = true;
    } else {
      bool = false;
    } 
    makeButtonEnabled(bool);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\PasswordActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
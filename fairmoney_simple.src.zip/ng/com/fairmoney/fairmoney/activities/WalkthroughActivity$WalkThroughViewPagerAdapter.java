package ng.com.fairmoney.fairmoney.activities;

import androidx.fragment.app.Fragment;
import d.l.a.i;
import d.l.a.m;
import ng.com.fairmoney.fairmoney.fragments.walkthrough.WalkthroughStep1Fragment;
import ng.com.fairmoney.fairmoney.fragments.walkthrough.WalkthroughStep2Fragment;
import ng.com.fairmoney.fairmoney.fragments.walkthrough.WalkthroughStep3Fragment;

public class WalkThroughViewPagerAdapter extends m {
  public WalkThroughViewPagerAdapter(i parami) {
    super(parami, 1);
  }
  
  public int getCount() {
    return 3;
  }
  
  public Fragment getItem(int paramInt) {
    return (Fragment)((paramInt != 1) ? ((paramInt != 2) ? WalkthroughStep1Fragment.newInstance() : WalkthroughStep3Fragment.newInstance()) : WalkthroughStep2Fragment.newInstance());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\WalkthroughActivity$WalkThroughViewPagerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
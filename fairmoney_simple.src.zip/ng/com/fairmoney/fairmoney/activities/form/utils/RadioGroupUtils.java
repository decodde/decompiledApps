package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.content.SharedPreferences;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.util.Map;

public class RadioGroupUtils {
  public static final int NO_SELECTION_RADIO_GROUP = -1;
  
  public static final String SELECTED_VIEW_KEY = "selected_view_key";
  
  public static void displayRadioGroupError(TextView paramTextView) {
    paramTextView.setText(2131820793);
    paramTextView.setVisibility(0);
    paramTextView.setTextColor(-65536);
  }
  
  public static void fillRadioButton(Activity paramActivity, SharedPreferences paramSharedPreferences, Map<String, String> paramMap) {
    String str = paramSharedPreferences.getString(paramMap.get("selected_view_key"), "");
    RadioButton radioButton = (RadioButton)paramActivity.findViewById(paramActivity.getResources().getIdentifier(str, "id", paramActivity.getPackageName()));
    if (radioButton != null)
      radioButton.setChecked(true); 
  }
  
  public static String getRadioGroupAnswer(Activity paramActivity, SharedPreferences.Editor paramEditor, Map<String, String> paramMap, int paramInt) {
    RadioButton radioButton = (RadioButton)paramActivity.findViewById(((RadioGroup)paramActivity.findViewById(paramInt)).getCheckedRadioButtonId());
    paramEditor.putString(paramMap.get("selected_view_key"), paramMap.get("selected_view_value"));
    return radioButton.getText().toString();
  }
  
  public static boolean isRadioGroupChecked(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    TextView textView = (TextView)paramActivity.findViewById(paramActivity.getResources().getIdentifier(paramMap.get("error_view_id"), "id", paramActivity.getPackageName()));
    if (((RadioGroup)paramActivity.findViewById(paramInt)).getCheckedRadioButtonId() == -1) {
      displayRadioGroupError(textView);
      return false;
    } 
    textView.setVisibility(8);
    return true;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\RadioGroupUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.login;

public final class Empty extends LoginViewModel.InAppMessageState {
  public static final Empty INSTANCE = new Empty();
  
  public Empty() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel$InAppMessageState$Empty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
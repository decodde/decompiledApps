package fairmoney.data;

import j.q.d.g;
import j.q.d.k;

public final class JsonRequest<T> {
  public final String applicationId;
  
  public final T data;
  
  public final String versionCode;
  
  public JsonRequest(String paramString1, String paramString2, T paramT) {
    this.versionCode = paramString1;
    this.applicationId = paramString2;
    this.data = paramT;
  }
  
  public final String component1() {
    return this.versionCode;
  }
  
  public final String component2() {
    return this.applicationId;
  }
  
  public final T component3() {
    return this.data;
  }
  
  public final com.fairmoney.data.JsonRequest<T> copy(String paramString1, String paramString2, T paramT) {
    k.b(paramString1, "versionCode");
    return new com.fairmoney.data.JsonRequest(paramString1, paramString2, paramT);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.JsonRequest) {
        paramObject = paramObject;
        if (k.a(this.versionCode, ((com.fairmoney.data.JsonRequest)paramObject).versionCode) && k.a(this.applicationId, ((com.fairmoney.data.JsonRequest)paramObject).applicationId) && k.a(this.data, ((com.fairmoney.data.JsonRequest)paramObject).data))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getApplicationId() {
    return this.applicationId;
  }
  
  public final T getData() {
    return this.data;
  }
  
  public final String getVersionCode() {
    return this.versionCode;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    String str = this.versionCode;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    str = this.applicationId;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    T t = this.data;
    if (t != null)
      i = t.hashCode(); 
    return (b1 * 31 + b2) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonRequest(versionCode=");
    stringBuilder.append(this.versionCode);
    stringBuilder.append(", applicationId=");
    stringBuilder.append(this.applicationId);
    stringBuilder.append(", data=");
    stringBuilder.append(this.data);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\JsonRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
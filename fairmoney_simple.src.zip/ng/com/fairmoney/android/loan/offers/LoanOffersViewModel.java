package ng.com.fairmoney.android.loan.offers;

import androidx.lifecycle.LiveData;
import d.o.r;
import d.o.w;
import d.o.x;
import f.d.b.c;
import f.d.b.i.c;
import f.d.b.i.e;
import f.d.b.k.b;
import f.d.b.k.g;
import f.d.b.k.h;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import java.util.List;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class LoanOffersViewModel extends w {
  public final LiveData<k> checkBvn;
  
  public final LiveData<LoanOffersState> loanOffersState;
  
  public final e loanUseCase;
  
  public final r<k> mutableCheckBvn;
  
  public final r<LoanOffersState> mutableLoanOffersState;
  
  public final c router;
  
  public final g userRepository;
  
  public final h userUseCase;
  
  @Inject
  public LoanOffersViewModel(e parame, g paramg, h paramh, c paramc) {
    this.loanUseCase = parame;
    this.userRepository = paramg;
    this.userUseCase = paramh;
    this.router = paramc;
    r<k> r1 = new r();
    this.mutableCheckBvn = r1;
    this.checkBvn = (LiveData<k>)r1;
    r1 = new r();
    this.mutableLoanOffersState = (r)r1;
    this.loanOffersState = (LiveData)r1;
  }
  
  public final LiveData<k> getCheckBvn() {
    return this.checkBvn;
  }
  
  public final String getFormattedMaturity(c paramc) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'loanOffer'
    //   3: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_1
    //   7: invokevirtual d : ()I
    //   10: bipush #30
    //   12: idiv
    //   13: ifne -> 86
    //   16: aload_1
    //   17: invokevirtual d : ()I
    //   20: bipush #7
    //   22: idiv
    //   23: istore_2
    //   24: getstatic j/q/d/s.a : Lj/q/d/s;
    //   27: astore_1
    //   28: iconst_1
    //   29: anewarray java/lang/Object
    //   32: astore_1
    //   33: iload_2
    //   34: iconst_1
    //   35: if_icmpgt -> 59
    //   38: aload_1
    //   39: iconst_0
    //   40: iload_2
    //   41: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   44: aastore
    //   45: ldc '%d week'
    //   47: aload_1
    //   48: iconst_1
    //   49: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
    //   52: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   55: astore_1
    //   56: goto -> 77
    //   59: aload_1
    //   60: iconst_0
    //   61: iload_2
    //   62: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   65: aastore
    //   66: ldc '%d weeks'
    //   68: aload_1
    //   69: iconst_1
    //   70: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
    //   73: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   76: astore_1
    //   77: aload_1
    //   78: ldc 'java.lang.String.format(format, *args)'
    //   80: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   83: goto -> 153
    //   86: aload_1
    //   87: invokevirtual d : ()I
    //   90: bipush #30
    //   92: idiv
    //   93: istore_2
    //   94: getstatic j/q/d/s.a : Lj/q/d/s;
    //   97: astore_1
    //   98: iconst_1
    //   99: anewarray java/lang/Object
    //   102: astore_1
    //   103: iload_2
    //   104: iconst_1
    //   105: if_icmpgt -> 129
    //   108: aload_1
    //   109: iconst_0
    //   110: iload_2
    //   111: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   114: aastore
    //   115: ldc '%d month'
    //   117: aload_1
    //   118: iconst_1
    //   119: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
    //   122: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   125: astore_1
    //   126: goto -> 147
    //   129: aload_1
    //   130: iconst_0
    //   131: iload_2
    //   132: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   135: aastore
    //   136: ldc '%d months'
    //   138: aload_1
    //   139: iconst_1
    //   140: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
    //   143: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   146: astore_1
    //   147: aload_1
    //   148: ldc 'java.lang.String.format(format, *args)'
    //   150: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   153: aload_1
    //   154: areturn
  }
  
  public final void getLoanOffers() {
    c.a(c.a(this.userRepository.getApplicationId(), 0, new LoanOffersViewModel$getLoanOffers$1(null), 1, null), x.a(this));
  }
  
  public final LiveData<LoanOffersState> getLoanOffersState() {
    return this.loanOffersState;
  }
  
  public final void onLoanOfferSelected() {
    c.a(c.a(this.userUseCase.getCountry(), new LoanOffersViewModel$onLoanOfferSelected$1(null)), x.a(this));
  }
  
  public static abstract class LoanOffersState {
    public LoanOffersState() {}
    
    public static final class Failure extends LoanOffersState {
      public final Throwable throwable;
      
      public Failure(Throwable param2Throwable) {
        super(null);
        this.throwable = param2Throwable;
      }
      
      public final Throwable getThrowable() {
        return this.throwable;
      }
    }
    
    public static final class Success extends LoanOffersState {
      public final List<c> loanOffers;
      
      public Success(List<c> param2List) {
        super(null);
        this.loanOffers = param2List;
      }
      
      public final List<c> getLoanOffers() {
        return this.loanOffers;
      }
    }
  }
  
  public static final class Failure extends LoanOffersState {
    public final Throwable throwable;
    
    public Failure(Throwable param1Throwable) {
      super(null);
      this.throwable = param1Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Success extends LoanOffersState {
    public final List<c> loanOffers;
    
    public Success(List<c> param1List) {
      super(null);
      this.loanOffers = param1List;
    }
    
    public final List<c> getLoanOffers() {
      return this.loanOffers;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.offers.LoanOffersViewModel$getLoanOffers$1", f = "LoanOffersViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class LoanOffersViewModel$getLoanOffers$1 extends k implements p<String, d<? super a<? extends List<? extends c>>>, Object> {
    public int label;
    
    public String p$0;
    
    public LoanOffersViewModel$getLoanOffers$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      LoanOffersViewModel$getLoanOffers$1 loanOffersViewModel$getLoanOffers$1 = new LoanOffersViewModel$getLoanOffers$1(param1d);
      loanOffersViewModel$getLoanOffers$1.p$0 = (String)param1Object;
      return (d<k>)loanOffersViewModel$getLoanOffers$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LoanOffersViewModel$getLoanOffers$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        return c.a(c.a(LoanOffersViewModel.this.loanUseCase.a((String)param1Object), new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(null) {
                public int label;
                
                public b p$;
                
                public Throwable p$0;
                
                public final d<k> create(b<? super List<c>> param1b, Throwable param1Throwable, d<? super k> param1d) {
                  k.b(param1b, "$this$create");
                  k.b(param1Throwable, "it");
                  k.b(param1d, "continuation");
                  q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> q1 = new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(LoanOffersViewModel$getLoanOffers$1.this, param1d);
                  q1.p$ = param1b;
                  q1.p$0 = param1Throwable;
                  return (d)q1;
                }
                
                public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
                  return ((null)create((b<? super List<c>>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
                }
                
                public final Object invokeSuspend(Object param1Object) {
                  c.a();
                  if (this.label == 0) {
                    g.a(param1Object);
                    param1Object = this.p$0;
                    LoanOffersViewModel.this.mutableLoanOffersState.b(new LoanOffersViewModel.LoanOffersState.Failure((Throwable)param1Object));
                    return k.a;
                  } 
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
              }), new p<List<? extends c>, d<? super k>, Object>(null) {
              public int label;
              
              public List p$0;
              
              public final d<k> create(Object param1Object, d<?> param1d) {
                k.b(param1d, "completion");
                p<List<? extends c>, d<? super k>, Object> p1 = new p<List<? extends c>, d<? super k>, Object>(LoanOffersViewModel$getLoanOffers$1.this, param1d);
                p1.p$0 = (List)param1Object;
                return (d)p1;
              }
              
              public final Object invoke(Object param1Object1, Object param1Object2) {
                return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
              }
              
              public final Object invokeSuspend(Object param1Object) {
                c.a();
                if (this.label == 0) {
                  g.a(param1Object);
                  param1Object = this.p$0;
                  LoanOffersViewModel.this.mutableLoanOffersState.b(new LoanOffersViewModel.LoanOffersState.Success((List<c>)param1Object));
                  return k.a;
                } 
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
              }
            });
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.offers.LoanOffersViewModel$getLoanOffers$1$1", f = "LoanOffersViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> {
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public null(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super List<c>> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      q<b<? super List<? extends c>>, Throwable, d<? super k>, Object> q1 = new q<b<? super List<? extends c>>, Throwable, d<? super k>, Object>(LoanOffersViewModel$getLoanOffers$1.this, param1d);
      q1.p$ = param1b;
      q1.p$0 = param1Throwable;
      return (d)q1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((null)create((b<? super List<c>>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        LoanOffersViewModel.this.mutableLoanOffersState.b(new LoanOffersViewModel.LoanOffersState.Failure((Throwable)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.offers.LoanOffersViewModel$getLoanOffers$1$2", f = "LoanOffersViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class null extends k implements p<List<? extends c>, d<? super k>, Object> {
    public int label;
    
    public List p$0;
    
    public null(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      p<List<? extends c>, d<? super k>, Object> p1 = new p<List<? extends c>, d<? super k>, Object>(LoanOffersViewModel$getLoanOffers$1.this, param1d);
      p1.p$0 = (List)param1Object;
      return (d)p1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((null)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        LoanOffersViewModel.this.mutableLoanOffersState.b(new LoanOffersViewModel.LoanOffersState.Success((List<c>)param1Object));
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.offers.LoanOffersViewModel$onLoanOfferSelected$1", f = "LoanOffersViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class LoanOffersViewModel$onLoanOfferSelected$1 extends k implements p<b, d<? super k>, Object> {
    public int label;
    
    public b p$0;
    
    public LoanOffersViewModel$onLoanOfferSelected$1(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      LoanOffersViewModel$onLoanOfferSelected$1 loanOffersViewModel$onLoanOfferSelected$1 = new LoanOffersViewModel$onLoanOfferSelected$1(param1d);
      loanOffersViewModel$onLoanOfferSelected$1.p$0 = (b)param1Object;
      return (d<k>)loanOffersViewModel$onLoanOfferSelected$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((LoanOffersViewModel$onLoanOfferSelected$1)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        if (this.p$0 instanceof b.b) {
          LoanOffersViewModel.this.mutableCheckBvn.b(k.a);
        } else {
          LoanOffersViewModel.this.router.toBankDetails();
        } 
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offers\LoanOffersViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
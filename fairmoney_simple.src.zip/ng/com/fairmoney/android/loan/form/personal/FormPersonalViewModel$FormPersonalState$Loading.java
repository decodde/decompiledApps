package ng.com.fairmoney.android.loan.form.personal;

public final class Loading extends FormPersonalViewModel.FormPersonalState {
  public final boolean loading;
  
  public Loading(boolean paramBoolean) {
    super(null);
    this.loading = paramBoolean;
  }
  
  public final boolean getLoading() {
    return this.loading;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$FormPersonalState$Loading.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import android.text.Editable;
import android.text.TextWatcher;
import f.d.b.i.c;

public class null implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    if (paramEditable.length() != 0) {
      LoanOffersActivity loanOffersActivity = LoanOffersActivity.this;
      c c = LoanOffersActivity.access$600(loanOffersActivity, LoanOffersActivity.access$400(loanOffersActivity).getText().toString(), LoanOffersActivity.access$500(LoanOffersActivity.this).getText().toString());
      if (c != null) {
        LoanOffersActivity.access$700(LoanOffersActivity.this, c);
      } else {
        LoanOffersActivity.access$100(LoanOffersActivity.this);
      } 
    } else {
      LoanOffersActivity.access$100(LoanOffersActivity.this);
    } 
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOffersActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
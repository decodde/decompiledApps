package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.MenuItem;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import d.b.k.a;
import d.l.a.i;
import d.l.a.o;
import java.util.List;
import l.a.a.a.a.f;
import ng.com.fairmoney.fairmoney.fragments.home.HomeFragment;
import ng.com.fairmoney.fairmoney.fragments.home.summary.HomeSummaryBaseFragment;
import ng.com.fairmoney.fairmoney.models.LoanAccepted;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class HomeActivity extends BaseHomeActivity implements HomeFragment.OnUserCodeReceivedListener, HomeSummaryBaseFragment.OnFragmentInteractionListener {
  private boolean checkUserConnected() {
    if (this.preferences.getString("AuthToken", "").contentEquals("")) {
      startActivity(new Intent(getApplicationContext(), WelcomeActivity.class));
      finish();
      return false;
    } 
    return true;
  }
  
  private void initActionBar() {
    a a = getSupportActionBar();
    this.actionBar = a;
    a.d(false);
    this.actionBar.e(false);
    setToolbarVisibility(false);
  }
  
  private void initPayFragment(Fragment paramFragment) {
    this.selectedNavigationMenuItem = 2131296789;
    Tracking.sendUniqueEvent((Context)this, new Event("application", "homePage"));
    if (!getSupportFragmentManager().e()) {
      o o = getSupportFragmentManager().a();
      o.a(2131296582, paramFragment);
      o.a();
    } 
  }
  
  private void logRepaidLoanIfNecessary() {
    if (getIntent().getBooleanExtra("ng.com.fairmoney.EXTRA_LOAN_REPAID", false))
      Tracking.sendUniqueEvent((Context)this, new Event("welcomeBack", "welcomeBack")); 
  }
  
  private void manageBottomMenuVisibility() {
    getSupportFragmentManager().a((i.b)new f(this));
  }
  
  public void goToActivity(Class paramClass) {
    Intent intent = new Intent((Context)this, paramClass);
    intent.setFlags(268468224);
    startActivity(intent);
    finish();
  }
  
  public void goToPaymentsFragment() {
    this.bottomNavigationView.setSelectedItemId(2131296792);
  }
  
  public void goToReferralFragment() {
    this.bottomNavigationView.setSelectedItemId(2131296849);
  }
  
  public void initBottomNavigationView() {
    BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(2131296359);
    this.bottomNavigationView = bottomNavigationView;
    bottomNavigationView.getMenu().findItem(2131296792).setVisible(this.homeViewModel.getBillsVisibility());
    this.bottomNavigationView.getMenu().findItem(2131296849).setVisible(this.homeViewModel.getReferralsVisibility());
    this.bottomNavigationView.getMenu().findItem(2131296304).setVisible(this.homeViewModel.getAccountVisibility());
    this.bottomNavigationView.setOnNavigationItemSelectedListener(new NavigationListener());
    this.bottomNavigationView.setSelectedItemId(this.selectedNavigationMenuItem);
    setBottomNavigationViewVisibility(0);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    initActionBar();
    this.preferences = getSharedPreferences("CurrentUser", 0);
    if (!checkUserConnected())
      return; 
    LoanAccepted loanAccepted = (LoanAccepted)getIntent().getParcelableExtra("accessCode");
    logRepaidLoanIfNecessary();
    initBottomNavigationView();
    manageBottomMenuVisibility();
    HomeFragment homeFragment = new HomeFragment();
    if (loanAccepted != null && loanAccepted.getStatus().contentEquals("card_connection")) {
      Bundle bundle = new Bundle();
      bundle.putParcelable("accessCode", (Parcelable)loanAccepted);
      homeFragment.setArguments(bundle);
    } 
    initPayFragment((Fragment)homeFragment);
  }
  
  public boolean onSupportNavigateUp() {
    if (this.isBackArrowVisible)
      if (getSupportFragmentManager().b() == 0) {
        this.isBackArrowVisible = false;
      } else {
        onBackPressed();
      }  
    return true;
  }
  
  public void onUserCodeReceived(String paramString, boolean paramBoolean) {
    this.preferences.edit().putString("userCode", paramString).putBoolean("isReturning", paramBoolean).apply();
  }
  
  public void replaceHistoryFragmentByHomeFragment() {
    if (this.isActivityActive) {
      BottomNavigationView bottomNavigationView = this.bottomNavigationView;
      bottomNavigationView.setSelectedItemId(bottomNavigationView.getMenu().getItem(0).getItemId());
    } 
  }
  
  public void setActionBarTitle(String paramString) {
    if (this.actionBar != null)
      setTitle(paramString); 
  }
  
  public void storeApplicationId(String paramString) {
    SharedPreferences.Editor editor = this.preferences.edit();
    editor.putString("ApplicationId", paramString);
    editor.apply();
  }
  
  public class NavigationListener implements BottomNavigationView.d {
    public boolean onNavigationItemSelected(MenuItem param1MenuItem) {
      switch (param1MenuItem.getItemId()) {
        default:
          return false;
        case 2131296849:
          HomeActivity.this.displayReferralFragment();
          return true;
        case 2131296792:
          HomeActivity.this.displayBillsFragment();
          return true;
        case 2131296789:
          HomeActivity.this.displayPayFragment();
          return true;
        case 2131296304:
          break;
      } 
      HomeActivity.this.displayAccountFragment();
      return true;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\HomeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
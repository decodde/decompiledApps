package ng.com.fairmoney.android.loan.repayment;

import f.d.b.j.b;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.b;

public final class null implements b<b> {
  public null(HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 paramHomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    paramObject = paramObject;
    paramObject = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(this.this$0.this$0.$amountInCent, (b)paramObject), paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
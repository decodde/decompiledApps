package fairmoney.data;

import j.q.d.k;

public final class JsonAndroid {
  public final String versionName;
  
  public JsonAndroid(String paramString) {
    this.versionName = paramString;
  }
  
  public final String component1() {
    return this.versionName;
  }
  
  public final com.fairmoney.data.JsonAndroid copy(String paramString) {
    k.b(paramString, "versionName");
    return new com.fairmoney.data.JsonAndroid(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.JsonAndroid) {
        paramObject = paramObject;
        if (k.a(this.versionName, ((com.fairmoney.data.JsonAndroid)paramObject).versionName))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getVersionName() {
    return this.versionName;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.versionName;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonAndroid(versionName=");
    stringBuilder.append(this.versionName);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\JsonAndroid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
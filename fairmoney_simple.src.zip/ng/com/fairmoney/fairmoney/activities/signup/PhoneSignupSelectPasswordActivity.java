package ng.com.fairmoney.fairmoney.activities.signup;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import l.a.a.a.a.u.h;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.login.PasswordActivity;

public class PhoneSignupSelectPasswordActivity extends PasswordActivity {
  public Button btNext;
  
  public String token;
  
  private void onNextClicked() {
    String str = getPassword();
    Intent intent = new Intent((Context)this, PhoneSignupConfirmPasswordActivity.class);
    intent.putExtra("password", str);
    intent.putExtra("EXTRA_TOKEN", this.token);
    intent.putExtra("EXTRA_PHONE_VERIFICATION", true);
    startActivity(intent);
    finish();
  }
  
  public void makeButtonEnabled(boolean paramBoolean) {
    this.btNext.setEnabled(paramBoolean);
  }
  
  public void makePasswordAction() {}
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, WelcomeActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((BaseActivity)this).isAuthMandatory = false;
    initPasswords();
    Intent intent = getIntent();
    if (intent != null)
      this.token = intent.getStringExtra("EXTRA_TOKEN"); 
    Button button = (Button)findViewById(2131296420);
    this.btNext = button;
    button.setOnClickListener((View.OnClickListener)new h(this));
  }
  
  public int provideContentViewId() {
    return 2131492916;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\signup\PhoneSignupSelectPasswordActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
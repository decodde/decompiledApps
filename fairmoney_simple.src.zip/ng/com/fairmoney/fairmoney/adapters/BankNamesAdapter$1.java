package ng.com.fairmoney.fairmoney.adapters;

import android.widget.Filter;

public class null extends Filter {
  public Filter.FilterResults performFiltering(CharSequence paramCharSequence) {
    return null;
  }
  
  public void publishResults(CharSequence paramCharSequence, Filter.FilterResults paramFilterResults) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BankNamesAdapter$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
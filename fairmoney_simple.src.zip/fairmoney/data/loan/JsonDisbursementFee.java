package fairmoney.data.loan;

import j.q.d.k;

public final class JsonDisbursementFee {
  public final int amount;
  
  public final String currencyCode;
  
  public final String name;
  
  public final int taxAmount;
  
  public final String taxName;
  
  public final double taxRate;
  
  public JsonDisbursementFee(String paramString1, int paramInt1, int paramInt2, double paramDouble, String paramString2, String paramString3) {
    this.name = paramString1;
    this.amount = paramInt1;
    this.taxAmount = paramInt2;
    this.taxRate = paramDouble;
    this.taxName = paramString2;
    this.currencyCode = paramString3;
  }
  
  public final String component1() {
    return this.name;
  }
  
  public final int component2() {
    return this.amount;
  }
  
  public final int component3() {
    return this.taxAmount;
  }
  
  public final double component4() {
    return this.taxRate;
  }
  
  public final String component5() {
    return this.taxName;
  }
  
  public final String component6() {
    return this.currencyCode;
  }
  
  public final com.fairmoney.data.loan.JsonDisbursementFee copy(String paramString1, int paramInt1, int paramInt2, double paramDouble, String paramString2, String paramString3) {
    k.b(paramString1, "name");
    k.b(paramString2, "taxName");
    k.b(paramString3, "currencyCode");
    return new com.fairmoney.data.loan.JsonDisbursementFee(paramString1, paramInt1, paramInt2, paramDouble, paramString2, paramString3);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.loan.JsonDisbursementFee) {
        paramObject = paramObject;
        if (k.a(this.name, ((com.fairmoney.data.loan.JsonDisbursementFee)paramObject).name) && this.amount == ((com.fairmoney.data.loan.JsonDisbursementFee)paramObject).amount && this.taxAmount == ((com.fairmoney.data.loan.JsonDisbursementFee)paramObject).taxAmount && Double.compare(this.taxRate, ((com.fairmoney.data.loan.JsonDisbursementFee)paramObject).taxRate) == 0 && k.a(this.taxName, ((com.fairmoney.data.loan.JsonDisbursementFee)paramObject).taxName) && k.a(this.currencyCode, ((com.fairmoney.data.loan.JsonDisbursementFee)paramObject).currencyCode))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final int getAmount() {
    return this.amount;
  }
  
  public final String getCurrencyCode() {
    return this.currencyCode;
  }
  
  public final String getName() {
    return this.name;
  }
  
  public final int getTaxAmount() {
    return this.taxAmount;
  }
  
  public final String getTaxName() {
    return this.taxName;
  }
  
  public final double getTaxRate() {
    return this.taxRate;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    String str = this.name;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    int j = this.amount;
    int k = this.taxAmount;
    long l = Double.doubleToLongBits(this.taxRate);
    int m = (int)(l ^ l >>> 32L);
    str = this.taxName;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    str = this.currencyCode;
    if (str != null)
      i = str.hashCode(); 
    return ((((b1 * 31 + j) * 31 + k) * 31 + m) * 31 + b2) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonDisbursementFee(name=");
    stringBuilder.append(this.name);
    stringBuilder.append(", amount=");
    stringBuilder.append(this.amount);
    stringBuilder.append(", taxAmount=");
    stringBuilder.append(this.taxAmount);
    stringBuilder.append(", taxRate=");
    stringBuilder.append(this.taxRate);
    stringBuilder.append(", taxName=");
    stringBuilder.append(this.taxName);
    stringBuilder.append(", currencyCode=");
    stringBuilder.append(this.currencyCode);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonDisbursementFee.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
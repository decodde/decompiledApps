package ng.com.fairmoney.android.loan.form.personal;

import j.q.d.g;

public abstract class FormPersonalState {
  public FormPersonalState() {}
  
  public static final class Bvn extends FormPersonalState {
    public static final Bvn INSTANCE = new Bvn();
    
    public Bvn() {
      super(null);
    }
  }
  
  public static final class Error extends FormPersonalState {
    public final Throwable throwable;
    
    public Error(Throwable param2Throwable) {
      super(null);
      this.throwable = param2Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Hyperverge extends FormPersonalState {
    public static final Hyperverge INSTANCE = new Hyperverge();
    
    public Hyperverge() {
      super(null);
    }
  }
  
  public static final class Loading extends FormPersonalState {
    public final boolean loading;
    
    public Loading(boolean param2Boolean) {
      super(null);
      this.loading = param2Boolean;
    }
    
    public final boolean getLoading() {
      return this.loading;
    }
  }
  
  public static final class Mbs extends FormPersonalState {
    public static final Mbs INSTANCE = new Mbs();
    
    public Mbs() {
      super(null);
    }
  }
  
  public static final class Work extends FormPersonalState {
    public static final Work INSTANCE = new Work();
    
    public Work() {
      super(null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$FormPersonalState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
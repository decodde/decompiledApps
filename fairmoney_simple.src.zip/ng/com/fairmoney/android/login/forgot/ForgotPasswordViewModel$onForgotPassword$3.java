package ng.com.fairmoney.android.login.forgot;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel$onForgotPassword$3", f = "ForgotPasswordViewModel.kt", l = {}, m = "invokeSuspend")
public final class ForgotPasswordViewModel$onForgotPassword$3 extends k implements p<b<? super ForgotPasswordViewModel.ForgotPasswordState.Success>, d<? super k>, Object> {
  public int label;
  
  public b p$;
  
  public ForgotPasswordViewModel$onForgotPassword$3(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    ForgotPasswordViewModel$onForgotPassword$3 forgotPasswordViewModel$onForgotPassword$3 = new ForgotPasswordViewModel$onForgotPassword$3(paramd);
    forgotPasswordViewModel$onForgotPassword$3.p$ = (b)paramObject;
    return (d<k>)forgotPasswordViewModel$onForgotPassword$3;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((ForgotPasswordViewModel$onForgotPassword$3)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      ForgotPasswordViewModel.access$getMutableForgotPassword$p(ForgotPasswordViewModel.this).b(new ForgotPasswordViewModel.ForgotPasswordState.Loading(true));
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordViewModel$onForgotPassword$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.content.SharedPreferences;
import android.widget.EditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import d.b.k.d;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import ng.com.fairmoney.android.loan.form.work.data.ProfessionalMapper;

public class FormUtils {
  public static final String AUTOCOMPLETE = "autocomplete";
  
  public static final String CHECKBOX = "checkbox";
  
  public static final String EDITTEXT = "text";
  
  public static final String PHONE_INPUT_VIEW = "phone";
  
  public static final String RELATIVE_RADIO_GROUP = "relative_radio";
  
  public static final String STYLED_SPINNER = "styled_spinner";
  
  public static final Gson gson = new Gson();
  
  public static final ProfessionalMapper professionalMapper = new ProfessionalMapper();
  
  public static boolean checkAnswersValidity(d paramd, List<Map<String, String>> paramList) {
    Iterator<Map<String, String>> iterator = paramList.iterator();
    boolean bool = true;
    while (iterator.hasNext()) {
      Map<String, String> map = iterator.next();
      int i = paramd.getResources().getIdentifier((String)map.get("id"), "id", paramd.getPackageName());
      if (!getAnswerValidity(paramd, (String)map.get("type"), map, i))
        bool = false; 
    } 
    return bool;
  }
  
  public static void fillFormWithPreviousResponses(d paramd, SharedPreferences paramSharedPreferences, List<Map<String, String>> paramList) {
    for (Map<String, String> map : paramList) {
      int i = paramd.getResources().getIdentifier((String)map.get("id"), "id", paramd.getPackageName());
      String str = (String)map.get("type");
      if (str != null) {
        byte b = -1;
        switch (str.hashCode()) {
          case 1581149869:
            if (str.equals("styled_spinner"))
              b = 2; 
            break;
          case 1536891843:
            if (str.equals("checkbox"))
              b = 4; 
            break;
          case 1117268168:
            if (str.equals("relative_radio"))
              b = 3; 
            break;
          case 106642798:
            if (str.equals("phone"))
              b = 5; 
            break;
          case 3556653:
            if (str.equals("text"))
              b = 1; 
            break;
          case -837947416:
            if (str.equals("autocomplete"))
              b = 0; 
            break;
        } 
        if (b != 0 && b != 1) {
          if (b != 2) {
            if (b != 3) {
              if (b != 4) {
                if (b != 5)
                  continue; 
                PhoneInputViewUtils.fillPhoneNumber(paramd, paramSharedPreferences, map, i);
                continue;
              } 
              CheckBoxUtils.applyPreviousCheckBoxAnswer((Activity)paramd, paramSharedPreferences, map);
              continue;
            } 
            RadioGroupUtils.fillRadioButton((Activity)paramd, paramSharedPreferences, map);
            continue;
          } 
          SpinnerUtils.fillStyledSpinner((Activity)paramd, paramSharedPreferences, map, i);
          continue;
        } 
        EditTextUtils.fillEditText((Activity)paramd, map, paramSharedPreferences, i);
        EditTextUtils.addFocusChangedListenerToEditText((Activity)paramd, map, i);
      } 
    } 
  }
  
  public static boolean getAnswerValidity(d paramd, String paramString, Map<String, String> paramMap, int paramInt) {
    if (paramString != null && paramd.findViewById(paramInt).isShown()) {
      byte b = -1;
      switch (paramString.hashCode()) {
        case 1581149869:
          if (paramString.equals("styled_spinner"))
            b = 1; 
          break;
        case 1536891843:
          if (paramString.equals("checkbox"))
            b = 3; 
          break;
        case 1117268168:
          if (paramString.equals("relative_radio"))
            b = 2; 
          break;
        case 106642798:
          if (paramString.equals("phone"))
            b = 4; 
          break;
        case 3556653:
          if (paramString.equals("text"))
            b = 0; 
          break;
        case -837947416:
          if (paramString.equals("autocomplete"))
            b = 5; 
          break;
      } 
      return (b != 0) ? ((b != 1) ? ((b != 2) ? ((b != 3) ? ((b != 4) ? ((b != 5) ? true : AutocompleteUtils.Companion.isTextValid((Activity)paramd, paramMap, paramInt)) : PhoneInputViewUtils.isValidPhoneNumber(paramd, paramInt)) : CheckBoxUtils.isCheckBoxChecked((Activity)paramd, paramMap, paramInt)) : RelativeRadioGroupUtils.isRelativeRadioGroupChecked((Activity)paramd, paramMap, paramInt)) : SpinnerUtils.isStyledSpinnerValid((Activity)paramd, paramMap, paramInt)) : EditTextUtils.isTextValid((Activity)paramd, paramMap, paramInt);
    } 
    return true;
  }
  
  public static void hideErrors(EditText paramEditText, TextInputLayout paramTextInputLayout) {
    if (paramTextInputLayout != null) {
      paramTextInputLayout.setError(null);
    } else {
      paramEditText.setError(null);
    } 
  }
  
  public static boolean isValidEmailAddress(String paramString) {
    boolean bool;
    if (!paramString.contains(".@") && Pattern.compile("[a-zA-Z0-9._%\\-+]{1,256}@[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}(\\.[a-zA-Z0-9\\-]{2,25})+").matcher(paramString).matches()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  @Deprecated
  public static JsonObject serializeAndStoreAnswers(d paramd, SharedPreferences.Editor paramEditor, List<Map<String, String>> paramList) {
    JsonObject jsonObject = new JsonObject();
    Iterator<Map<String, String>> iterator = paramList.iterator();
    while (true) {
      String[] arrayOfString1;
      if (iterator.hasNext()) {
        Map<String, String> map = iterator.next();
        int i = paramd.getResources().getIdentifier((String)map.get("id"), "id", paramd.getPackageName());
        String str2 = (String)map.get("type");
        String str3 = "";
        String str1 = str3;
        if (str2 != null) {
          str1 = str3;
          if (paramd.findViewById(i).isShown()) {
            byte b;
            switch (str2.hashCode()) {
              default:
                b = -1;
                break;
              case 1581149869:
                if (str2.equals("styled_spinner")) {
                  b = 2;
                  break;
                } 
              case 1536891843:
                if (str2.equals("checkbox")) {
                  b = 4;
                  break;
                } 
              case 1117268168:
                if (str2.equals("relative_radio")) {
                  b = 3;
                  break;
                } 
              case 106642798:
                if (str2.equals("phone")) {
                  b = 5;
                  break;
                } 
              case 3556653:
                if (str2.equals("text")) {
                  b = 1;
                  break;
                } 
              case -837947416:
                if (str2.equals("autocomplete")) {
                  b = 0;
                  break;
                } 
            } 
            if (b != 0 && b != 1) {
              if (b != 2) {
                if (b != 3) {
                  if (b != 4) {
                    if (b != 5) {
                      str1 = str3;
                    } else {
                      str1 = PhoneInputViewUtils.getPhoneNumber(paramd, paramEditor, map, i);
                      jsonObject.addProperty(map.get("key"), str1);
                      continue;
                    } 
                  } else {
                    str1 = CheckBoxUtils.getAcceptCheckBoxAnswer((Activity)paramd, paramEditor, map, i);
                    jsonObject.addProperty(map.get("key"), str1);
                    continue;
                  } 
                } else {
                  str1 = RelativeRadioGroupUtils.getRelativeRadioGroupAnswer((Activity)paramd, paramEditor, map, i);
                } 
              } else {
                Object object = SpinnerUtils.getStyledSpinnerAnswer((Activity)paramd, i);
                str1 = str3;
                str3 = str1;
              } 
            } else {
              str3 = EditTextUtils.getEditTextValue((Activity)paramd, map, i);
              str2 = map.get("id");
              str1 = str3;
              if (str2 != null) {
                str1 = str3;
                if (str2.contentEquals("et_form_birthdate")) {
                  arrayOfString1 = str3.split("/");
                  jsonObject.addProperty("birthdateDay", arrayOfString1[0]);
                  jsonObject.addProperty("birthdateMonth", arrayOfString1[1]);
                  jsonObject.addProperty("birthdateYear", arrayOfString1[2]);
                  paramEditor.putString("et_form_birthdate", str3).apply();
                  continue;
                } 
              } 
            } 
          } 
        } 
        str2 = null;
      } else {
        break;
      } 
      String[] arrayOfString2 = arrayOfString1;
    } 
    paramEditor.apply();
    return jsonObject;
  }
  
  public static void setTextError(EditText paramEditText, TextInputLayout paramTextInputLayout, String paramString) {
    if (paramTextInputLayout != null) {
      paramTextInputLayout.setError(paramString);
    } else {
      paramEditText.setError(paramString);
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\FormUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
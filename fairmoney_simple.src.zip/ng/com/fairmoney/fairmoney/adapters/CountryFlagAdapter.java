package ng.com.fairmoney.fairmoney.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import f.b.a.c;
import f.d.b.k.b;
import f.d.b.k.c;
import j.q.d.k;
import java.util.List;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.phoneinput.CountryMapper;
import ng.com.fairmoney.android.phoneinput.OnCountrySelectedListener;

public final class CountryFlagAdapter extends ArrayAdapter<b> {
  public final List<b> countries;
  
  public final CountryMapper countryMapper;
  
  public final c indicatorMapper;
  
  public OnCountrySelectedListener onCountrySelectedListener;
  
  public CountryFlagAdapter(Context paramContext, int paramInt1, int paramInt2, List<? extends b> paramList) {
    super(paramContext, paramInt1, paramInt2, paramList);
    this.countries = (List)paramList;
    this.indicatorMapper = new c();
    this.countryMapper = new CountryMapper();
  }
  
  private final View getCustomView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    Object object = getContext().getSystemService("layout_inflater");
    if (object != null) {
      View view1 = ((LayoutInflater)object).inflate(2131493001, paramViewGroup, false);
      object = this.countries.get(paramInt);
      View view2 = view1.findViewById(2131297105);
      k.a(view2, "layout.findViewById<Text….id.tv_country_indicator)");
      ((TextView)view2).setText(this.indicatorMapper.a((b)object));
      view2 = view1.findViewById(2131297106);
      k.a(view2, "layout.findViewById<Text…ew>(R.id.tv_country_name)");
      ((TextView)view2).setText(object.d());
      c.e(getContext()).a(Integer.valueOf(this.countryMapper.getFlagResource((b)object))).a((ImageView)view1.findViewById(2131296626));
      view1.setOnClickListener(new CountryFlagAdapter$getCustomView$1((b)object));
      k.a(view1, "layout");
      return view1;
    } 
    throw new TypeCastException("null cannot be cast to non-null type android.view.LayoutInflater");
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    if (paramViewGroup != null)
      return getCustomView(paramInt, paramView, paramViewGroup); 
    k.a();
    throw null;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    k.b(paramViewGroup, "parent");
    return getCustomView(paramInt, paramView, paramViewGroup);
  }
  
  public final void selectCountry(b paramb) {
    k.b(paramb, "country");
    if (!(paramb instanceof b.c)) {
      OnCountrySelectedListener onCountrySelectedListener = this.onCountrySelectedListener;
      if (onCountrySelectedListener != null) {
        onCountrySelectedListener.onCountrySelected(paramb, this.indicatorMapper.a(paramb), this.countryMapper.getFlagResource(paramb));
      } else {
        k.d("onCountrySelectedListener");
        throw null;
      } 
    } 
  }
  
  public final void selectCountry(String paramString) {
    selectCountry(this.indicatorMapper.a(paramString));
  }
  
  public final void setOnCountrySelectedListener(OnCountrySelectedListener paramOnCountrySelectedListener) {
    k.b(paramOnCountrySelectedListener, "onCountrySelectedListener");
    this.onCountrySelectedListener = paramOnCountrySelectedListener;
  }
  
  public static final class CountryFlagAdapter$getCustomView$1 implements View.OnClickListener {
    public CountryFlagAdapter$getCustomView$1(b param1b) {}
    
    public final void onClick(View param1View) {
      CountryFlagAdapter.access$getOnCountrySelectedListener$p(CountryFlagAdapter.this).onCountrySelected(this.$country, CountryFlagAdapter.this.indicatorMapper.a(this.$country), CountryFlagAdapter.this.countryMapper.getFlagResource(this.$country));
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CountryFlagAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.otp;

import d.o.w;
import f.d.b.b;
import f.d.b.k.f;
import j.q.d.k;
import javax.inject.Inject;
import ng.com.fairmoney.fairmoney.utils.PhoneNumberFormatter;

public final class VerifyOtpViewModel extends w {
  public final PhoneNumberFormatter phoneNumberFormatter;
  
  public final b phoneNumberValidator;
  
  @Inject
  public VerifyOtpViewModel(PhoneNumberFormatter paramPhoneNumberFormatter, b paramb) {
    this.phoneNumberFormatter = paramPhoneNumberFormatter;
    this.phoneNumberValidator = paramb;
  }
  
  public final String formatPhoneNumber(f paramf) {
    k.b(paramf, "phoneNumber");
    if (this.phoneNumberValidator.a(paramf.a(), paramf.b())) {
      String str = this.phoneNumberFormatter.format(paramf);
    } else {
      paramf = null;
    } 
    return (String)paramf;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\otp\VerifyOtpViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
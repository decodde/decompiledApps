package ng.com.fairmoney.android.home.card;

import f.d.b.k.b;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.b;
import j.q.d.k;
import k.a.h2.a;
import k.a.h2.b;
import kotlin.NoWhenBranchMatchedException;

public final class EarlyRepaymentCardViewModel$initialize$$inlined$map$1 implements a<EarlyRepaymentCardViewModel.EarlyRepaymentSate> {
  public EarlyRepaymentCardViewModel$initialize$$inlined$map$1(a parama) {}
  
  public Object collect(b paramb, d paramd) {
    Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
          public Object emit(Object param1Object, d param1d) {
            b b1 = this.$this_unsafeFlow$inlined;
            param1Object = param1Object;
            if (k.a(param1Object, b.b.h)) {
              param1Object = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₦500,000", 6, b.a(5), "wahala", false);
            } else if (k.a(param1Object, b.a.h)) {
              param1Object = new EarlyRepaymentCardViewModel.EarlyRepaymentSate("₹50,000", 6, null, "hassle", true);
            } else {
              if (k.a(param1Object, b.c.h))
                throw new IllegalArgumentException(); 
              throw new NoWhenBranchMatchedException();
            } 
            param1Object = b1.emit(param1Object, param1d);
            return (param1Object == c.a()) ? param1Object : k.a;
          }
        }paramd);
    return (object == c.a()) ? object : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardViewModel$initialize$$inlined$map$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
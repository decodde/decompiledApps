package fairmoney.data.payment;

import com.fairmoney.data.JsonRequest;
import com.fairmoney.data.payment.JsonBill;
import com.fairmoney.data.payment.JsonInboundPaymentParams;
import com.fairmoney.data.payment.JsonRepaymentAmount;
import java.util.List;
import k.a.h2.a;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface PaymentService {
  @GET("/v2/android/bill/history")
  a<List<JsonBill>> getBillList(@Query("application_id") String paramString);
  
  @POST("/v2/android/repay/get_token/{type}")
  a<JsonInboundPaymentParams> getInboundPaymentParams(@Path("type") String paramString, @Body JsonRequest<JsonRepaymentAmount> paramJsonRequest);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\payment\PaymentService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.login.forgot;

public final class Error extends ForgotPasswordViewModel.ForgotPasswordState {
  public final Throwable throwable;
  
  public Error(Throwable paramThrowable) {
    super(null);
    this.throwable = paramThrowable;
  }
  
  public final Throwable getThrowable() {
    return this.throwable;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordViewModel$ForgotPasswordState$Error.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
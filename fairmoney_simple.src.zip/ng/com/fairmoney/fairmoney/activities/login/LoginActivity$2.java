package ng.com.fairmoney.fairmoney.activities.login;

import android.content.Context;
import f.c.a.a;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class null implements APIResponse<Void> {
  public void failure(int paramInt, String paramString) {
    a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)LoginActivity.this, paramString, String.valueOf(paramInt))));
    paramInt = retryCount;
    if (paramInt > 0)
      LoginActivity.access$000(LoginActivity.this, paramInt - 1); 
  }
  
  public void success(Void paramVoid) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.applicationconfiguration;

import g.b.d;

public final class ApplicationConfigurationImpl_Factory implements d<ApplicationConfigurationImpl> {
  public static ApplicationConfigurationImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }
  
  public static ApplicationConfigurationImpl newInstance() {
    return new ApplicationConfigurationImpl();
  }
  
  public ApplicationConfigurationImpl get() {
    return newInstance();
  }
  
  public static final class InstanceHolder {
    public static final ApplicationConfigurationImpl_Factory INSTANCE = new ApplicationConfigurationImpl_Factory();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\applicationconfiguration\ApplicationConfigurationImpl_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
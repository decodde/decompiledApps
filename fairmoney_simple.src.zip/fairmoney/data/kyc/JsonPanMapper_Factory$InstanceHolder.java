package fairmoney.data.kyc;

import com.fairmoney.data.kyc.JsonPanMapper_Factory;

public final class InstanceHolder {
  public static final JsonPanMapper_Factory INSTANCE = new JsonPanMapper_Factory();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonPanMapper_Factory$InstanceHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
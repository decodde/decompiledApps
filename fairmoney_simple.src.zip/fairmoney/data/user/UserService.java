package fairmoney.data.user;

import com.fairmoney.data.JsonRequest;
import com.fairmoney.data.user.JsonBvn;
import com.fairmoney.data.user.JsonForgotPassword;
import com.fairmoney.data.user.JsonUssdCode;
import k.a.h2.a;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UserService {
  @POST("/v2/android/forgot_password/phone")
  a<JsonUssdCode> forgotPassword(@Body JsonRequest<JsonForgotPassword> paramJsonRequest);
  
  @GET("v2/android/users/{user_id}/bvn")
  a<JsonBvn> getBvn(@Path("user_id") String paramString);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\dat\\user\UserService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
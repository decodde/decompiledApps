package ng.com.fairmoney.fairmoney.activities.forgotpassword;

import android.content.Context;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public class null implements APIResponse<Object> {
  public void failure(int paramInt, String paramString) {
    ForgotPasswordConfirmPasswordActivity.this.showNewToastMessage(paramString, 0);
    ForgotPasswordConfirmPasswordActivity.this.makeButtonEnabled(true);
  }
  
  public void success(Object paramObject) {
    paramObject = new Event("application", "phoneLogin");
    Tracking.sendUniqueEvent((Context)ForgotPasswordConfirmPasswordActivity.this, (Event)paramObject);
    ForgotPasswordConfirmPasswordActivity.this.goToNextScreen(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\forgotpassword\ForgotPasswordConfirmPasswordActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
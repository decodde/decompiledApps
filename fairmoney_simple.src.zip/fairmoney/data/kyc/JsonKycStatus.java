package fairmoney.data.kyc;

public final class JsonKycStatus {
  public final boolean isClaimed;
  
  public JsonKycStatus(boolean paramBoolean) {
    this.isClaimed = paramBoolean;
  }
  
  public final boolean component1() {
    return this.isClaimed;
  }
  
  public final com.fairmoney.data.kyc.JsonKycStatus copy(boolean paramBoolean) {
    return new com.fairmoney.data.kyc.JsonKycStatus(paramBoolean);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.kyc.JsonKycStatus) {
        paramObject = paramObject;
        if (this.isClaimed == ((com.fairmoney.data.kyc.JsonKycStatus)paramObject).isClaimed)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    boolean bool1 = this.isClaimed;
    boolean bool2 = bool1;
    if (bool1)
      bool2 = true; 
    return bool2;
  }
  
  public final boolean isClaimed() {
    return this.isClaimed;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonKycStatus(isClaimed=");
    stringBuilder.append(this.isClaimed);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonKycStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
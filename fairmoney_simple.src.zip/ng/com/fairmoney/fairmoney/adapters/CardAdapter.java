package ng.com.fairmoney.fairmoney.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import d.b.p.i0;
import java.util.List;
import ng.com.fairmoney.fairmoney.models.Card;

public class CardAdapter extends RecyclerView.g<RecyclerView.d0> {
  public static int MODE_EDIT_CARDS = 0;
  
  public static int MODE_PICK_CARD = 1;
  
  public CardActionCallback callback;
  
  public List<Card> cards;
  
  public Context context;
  
  public int mode;
  
  public int selectedPosition = -1;
  
  public CardAdapter(Context paramContext, CardActionCallback paramCardActionCallback, int paramInt) {
    this.context = paramContext;
    this.callback = paramCardActionCallback;
    this.mode = paramInt;
  }
  
  private void displayPopUpMenu(final CardViewHolder vh, View paramView, Card paramCard) {
    i0 i0 = new i0(this.context, paramView);
    i0.b().inflate(2131558401, i0.a());
    if (i0.a() instanceof d.b.o.j.g && (paramCard.isExpired() || getItemCount() == 1))
      i0.a().removeItem(2131296723); 
    i0.a(new i0.d() {
          public boolean onMenuItemClick(MenuItem param1MenuItem) {
            if (vh.getAdapterPosition() == -1)
              return false; 
            if (param1MenuItem.getItemId() == 2131296722) {
              CardAdapter.this.callback.deleteCard(CardAdapter.this.cards.get(vh.getAdapterPosition()));
              return true;
            } 
            if (param1MenuItem.getItemId() == 2131296723) {
              CardAdapter.this.callback.setDefaultCard(CardAdapter.this.cards.get(vh.getAdapterPosition()));
              return true;
            } 
            return false;
          }
        });
    i0.c();
  }
  
  private void initActionsMenu(final Card item, final CardViewHolder vh) {
    boolean bool;
    ImageView imageView = vh.ivCardMenu;
    if ((item.isDefaultCard() && this.cards.size() > 1) || item.isPending() || this.mode != MODE_EDIT_CARDS) {
      bool = true;
    } else {
      bool = false;
    } 
    imageView.setVisibility(bool);
    vh.ivCardMenu.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            CardAdapter.this.displayPopUpMenu(vh, param1View, item);
          }
        });
  }
  
  private void initCheck(CardViewHolder paramCardViewHolder, Card paramCard, int paramInt) {
    boolean bool2;
    boolean bool = paramCard.isExpired();
    boolean bool1 = true;
    if (!bool && !paramCard.isPending()) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    int i = this.mode;
    int j = MODE_PICK_CARD;
    byte b = 8;
    if (i == j) {
      UpdateSelectedItemClick updateSelectedItemClick;
      RadioButton radioButton1 = paramCardViewHolder.rbCardPick;
      if (bool2)
        b = 0; 
      radioButton1.setVisibility(b);
      radioButton1 = paramCardViewHolder.rbCardPick;
      if (this.selectedPosition != paramInt)
        bool1 = false; 
      radioButton1.setChecked(bool1);
      CardView cardView = paramCardViewHolder.cvCard;
      RadioButton radioButton3 = null;
      if (bool2) {
        updateSelectedItemClick = new UpdateSelectedItemClick(paramCardViewHolder);
      } else {
        radioButton1 = null;
      } 
      cardView.setOnClickListener((View.OnClickListener)radioButton1);
      RadioButton radioButton2 = paramCardViewHolder.rbCardPick;
      radioButton1 = radioButton3;
      if (bool2)
        updateSelectedItemClick = new UpdateSelectedItemClick(paramCardViewHolder); 
      radioButton2.setOnClickListener(updateSelectedItemClick);
    } else {
      paramCardViewHolder.rbCardPick.setVisibility(8);
    } 
  }
  
  private void selectDefaultCard() {
    for (byte b = 0; b < this.cards.size(); b++) {
      if (((Card)this.cards.get(b)).isDefaultCard()) {
        this.selectedPosition = b;
        return;
      } 
    } 
  }
  
  public int getItemCount() {
    List<Card> list = this.cards;
    return (list != null) ? list.size() : 0;
  }
  
  public Card getSelectedItem() {
    return (this.selectedPosition == -1 || this.cards.isEmpty()) ? null : this.cards.get(this.selectedPosition);
  }
  
  public void onBindViewHolder(RecyclerView.d0 paramd0, int paramInt) {
    byte b;
    Card card = this.cards.get(paramInt);
    paramd0 = paramd0;
    TextView textView = ((CardViewHolder)paramd0).tvCardLast4;
    Context context = this.context;
    String str = card.getLast4();
    boolean bool = false;
    textView.setText(context.getString(2131820893, new Object[] { str }));
    textView = ((CardViewHolder)paramd0).tvCardMainCard;
    if (card.isDefaultCard()) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    textView = ((CardViewHolder)paramd0).tvCardExpiredCard;
    if (card.isExpired()) {
      b = 0;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    textView = ((CardViewHolder)paramd0).tvCardPending;
    if (card.isPending()) {
      b = bool;
    } else {
      b = 8;
    } 
    textView.setVisibility(b);
    ((CardViewHolder)paramd0).ivCardType.setImageResource(card.getBrandResource());
    initActionsMenu(card, (CardViewHolder)paramd0);
    initCheck((CardViewHolder)paramd0, card, paramInt);
  }
  
  public RecyclerView.d0 onCreateViewHolder(ViewGroup paramViewGroup, int paramInt) {
    return new CardViewHolder(LayoutInflater.from(this.context).inflate(2131493000, paramViewGroup, false));
  }
  
  public void setCards(List<Card> paramList) {
    this.cards = paramList;
    if (this.mode == MODE_PICK_CARD && paramList != null && this.selectedPosition == -1)
      selectDefaultCard(); 
    notifyDataSetChanged();
  }
  
  public static interface CardActionCallback {
    void deleteCard(Card param1Card);
    
    void setDefaultCard(Card param1Card);
  }
  
  public static class CardViewHolder extends RecyclerView.d0 {
    public CardView cvCard;
    
    public ImageView ivCardMenu;
    
    public ImageView ivCardType;
    
    public RadioButton rbCardPick;
    
    public TextView tvCardExpiredCard;
    
    public TextView tvCardLast4;
    
    public TextView tvCardMainCard;
    
    public TextView tvCardPending;
    
    public CardViewHolder(View param1View) {
      super(param1View);
      this.ivCardType = (ImageView)param1View.findViewById(2131296624);
      this.tvCardLast4 = (TextView)param1View.findViewById(2131297093);
      this.tvCardMainCard = (TextView)param1View.findViewById(2131297091);
      this.ivCardMenu = (ImageView)param1View.findViewById(2131296623);
      this.tvCardExpiredCard = (TextView)param1View.findViewById(2131297092);
      this.tvCardPending = (TextView)param1View.findViewById(2131297099);
      this.rbCardPick = (RadioButton)param1View.findViewById(2131296830);
      this.cvCard = (CardView)param1View.findViewById(2131296461);
    }
  }
  
  public class UpdateSelectedItemClick implements View.OnClickListener {
    public CardAdapter.CardViewHolder cardViewHolder;
    
    public UpdateSelectedItemClick(CardAdapter.CardViewHolder param1CardViewHolder) {
      this.cardViewHolder = param1CardViewHolder;
    }
    
    public void onClick(View param1View) {
      CardAdapter.access$702(CardAdapter.this, this.cardViewHolder.getAdapterPosition());
      CardAdapter.this.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CardAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
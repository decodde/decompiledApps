package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonInstalmentMapper;
import g.b.d;

public final class JsonInstalmentMapper_Factory implements d<JsonInstalmentMapper> {
  public static com.fairmoney.data.loan.JsonInstalmentMapper_Factory create() {
    return InstanceHolder.access$000();
  }
  
  public static JsonInstalmentMapper newInstance() {
    return new JsonInstalmentMapper();
  }
  
  public JsonInstalmentMapper get() {
    return newInstance();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonInstalmentMapper_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
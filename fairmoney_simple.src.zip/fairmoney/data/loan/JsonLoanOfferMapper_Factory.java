package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonDisbursementFeeMapper;
import com.fairmoney.data.loan.JsonInstalmentMapper;
import com.fairmoney.data.loan.JsonLoanOfferMapper;
import g.b.d;
import javax.inject.Provider;

public final class JsonLoanOfferMapper_Factory implements d<JsonLoanOfferMapper> {
  public final Provider<JsonDisbursementFeeMapper> jsonDisbursementFeesMapperProvider;
  
  public final Provider<JsonInstalmentMapper> jsonInstalmentMapperProvider;
  
  public JsonLoanOfferMapper_Factory(Provider<JsonInstalmentMapper> paramProvider, Provider<JsonDisbursementFeeMapper> paramProvider1) {
    this.jsonInstalmentMapperProvider = paramProvider;
    this.jsonDisbursementFeesMapperProvider = paramProvider1;
  }
  
  public static com.fairmoney.data.loan.JsonLoanOfferMapper_Factory create(Provider<JsonInstalmentMapper> paramProvider, Provider<JsonDisbursementFeeMapper> paramProvider1) {
    return new com.fairmoney.data.loan.JsonLoanOfferMapper_Factory(paramProvider, paramProvider1);
  }
  
  public static JsonLoanOfferMapper newInstance(JsonInstalmentMapper paramJsonInstalmentMapper, JsonDisbursementFeeMapper paramJsonDisbursementFeeMapper) {
    return new JsonLoanOfferMapper(paramJsonInstalmentMapper, paramJsonDisbursementFeeMapper);
  }
  
  public JsonLoanOfferMapper get() {
    return newInstance((JsonInstalmentMapper)this.jsonInstalmentMapperProvider.get(), (JsonDisbursementFeeMapper)this.jsonDisbursementFeesMapperProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonLoanOfferMapper_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
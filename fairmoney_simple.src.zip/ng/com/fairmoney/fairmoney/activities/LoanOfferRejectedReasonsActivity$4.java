package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.widget.Toast;
import ng.com.fairmoney.fairmoney.network.OnFailureListener;

public class null implements OnFailureListener {
  public void onFailure(int paramInt, String paramString) {
    Toast.makeText((Context)LoanOfferRejectedReasonsActivity.this, paramString, 1).show();
    LoanOfferRejectedReasonsActivity.access$400(LoanOfferRejectedReasonsActivity.this).setVisibility(8);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOfferRejectedReasonsActivity$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
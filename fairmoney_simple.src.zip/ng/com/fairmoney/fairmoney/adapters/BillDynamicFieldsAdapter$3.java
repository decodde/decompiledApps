package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;
import android.widget.AdapterView;
import ng.com.fairmoney.fairmoney.fragments.home.BillMakePaymentFragment;
import ng.com.fairmoney.fairmoney.models.BillChoice;
import ng.com.fairmoney.fairmoney.models.BillWidget;
import ng.com.fairmoney.fairmoney.views.CustomPickerLayout;

public class null implements AdapterView.OnItemClickListener {
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    customPickerLayout.onSelectedPosition(paramInt, ((BillChoice)widget.getChoices().get(paramInt)).getId());
    BillMakePaymentFragment.OnViewFilledListener onViewFilledListener = BillDynamicFieldsAdapter.access$200(BillDynamicFieldsAdapter.this);
    BillDynamicFieldsAdapter billDynamicFieldsAdapter = BillDynamicFieldsAdapter.this;
    onViewFilledListener.onViewFullyFilled(BillDynamicFieldsAdapter.access$100(billDynamicFieldsAdapter, BillDynamicFieldsAdapter.access$000(billDynamicFieldsAdapter)));
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\BillDynamicFieldsAdapter$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
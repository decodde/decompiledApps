package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

public class DeclinedBottomSheetBehavior extends BottomSheetBehavior.e {
  public DeclinedBottomSheetBehavior() {}
  
  public void onSlide(View paramView, float paramFloat) {}
  
  public void onStateChanged(View paramView, int paramInt) {
    if (paramInt == 4) {
      LoanOffersActivity.this.startActivity(new Intent((Context)LoanOffersActivity.this, HomeActivity.class));
      LoanOffersActivity.this.finish();
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOffersActivity$DeclinedBottomSheetBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
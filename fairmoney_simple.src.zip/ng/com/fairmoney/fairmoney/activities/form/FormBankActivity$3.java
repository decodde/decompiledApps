package ng.com.fairmoney.fairmoney.activities.form;

import android.view.View;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    FormBankActivity formBankActivity = FormBankActivity.this;
    formBankActivity.showNewToastMessage(formBankActivity.getString(2131820628), 1);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.login.inappmessaging;

import f.d.b.f.e;
import j.q.d.k;

public final class InAppMessageResult {
  public final e message;
  
  public InAppMessageResult(e parame) {
    this.message = parame;
  }
  
  public final e component1() {
    return this.message;
  }
  
  public final InAppMessageResult copy(e parame) {
    return new InAppMessageResult(parame);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof InAppMessageResult) {
        paramObject = paramObject;
        if (k.a(this.message, ((InAppMessageResult)paramObject).message))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final e getMessage() {
    return this.message;
  }
  
  public int hashCode() {
    boolean bool;
    e e1 = this.message;
    if (e1 != null) {
      bool = e1.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("InAppMessageResult(message=");
    stringBuilder.append(this.message);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\inappmessaging\InAppMessageResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
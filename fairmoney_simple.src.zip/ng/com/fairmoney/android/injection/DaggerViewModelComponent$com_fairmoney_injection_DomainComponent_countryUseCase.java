package ng.com.fairmoney.android.injection;

import f.d.b.d.a;
import f.d.c.j;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DomainComponent_countryUseCase implements Provider<a> {
  public final j domainComponent;
  
  public com_fairmoney_injection_DomainComponent_countryUseCase(j paramj) {
    this.domainComponent = paramj;
  }
  
  public a get() {
    a a = this.domainComponent.e();
    g.a(a, "Cannot return null from a non-@Nullable component method");
    return a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DomainComponent_countryUseCase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
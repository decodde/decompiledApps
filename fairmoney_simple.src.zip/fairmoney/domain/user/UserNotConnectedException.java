package fairmoney.domain.user;

public final class UserNotConnectedException extends Exception {}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\domai\\user\UserNotConnectedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.adapters;

import android.view.MenuItem;
import d.b.p.i0;

public class null implements i0.d {
  public boolean onMenuItemClick(MenuItem paramMenuItem) {
    if (vh.getAdapterPosition() == -1)
      return false; 
    if (paramMenuItem.getItemId() == 2131296722) {
      CardAdapter.access$1100(CardAdapter.this).deleteCard(CardAdapter.access$1000(CardAdapter.this).get(vh.getAdapterPosition()));
      return true;
    } 
    if (paramMenuItem.getItemId() == 2131296723) {
      CardAdapter.access$1100(CardAdapter.this).setDefaultCard(CardAdapter.access$1000(CardAdapter.this).get(vh.getAdapterPosition()));
      return true;
    } 
    return false;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CardAdapter$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
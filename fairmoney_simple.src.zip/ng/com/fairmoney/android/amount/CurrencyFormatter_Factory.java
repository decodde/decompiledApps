package ng.com.fairmoney.android.amount;

import g.b.d;

public final class CurrencyFormatter_Factory implements d<CurrencyFormatter> {
  public static CurrencyFormatter_Factory create() {
    return InstanceHolder.INSTANCE;
  }
  
  public static CurrencyFormatter newInstance() {
    return new CurrencyFormatter();
  }
  
  public CurrencyFormatter get() {
    return newInstance();
  }
  
  public static final class InstanceHolder {
    public static final CurrencyFormatter_Factory INSTANCE = new CurrencyFormatter_Factory();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\amount\CurrencyFormatter_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
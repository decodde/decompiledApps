package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.view.View;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)FormActivity.this, ApplicationFormEvent.FormEventType.BACK_ARROW_CLICK_EVENT, null, null.class.getSimpleName()));
    FormActivity.this.goToPreviousActivity();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
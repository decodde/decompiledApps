package ng.com.fairmoney.android.applicationconfiguration;

public final class InstanceHolder {
  public static final ApplicationConfigurationImpl_Factory INSTANCE = new ApplicationConfigurationImpl_Factory();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\applicationconfiguration\ApplicationConfigurationImpl_Factory$InstanceHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
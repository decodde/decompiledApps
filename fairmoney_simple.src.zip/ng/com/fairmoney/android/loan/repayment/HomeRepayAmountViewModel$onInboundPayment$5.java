package ng.com.fairmoney.android.loan.repayment;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;

@f(c = "ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel$onInboundPayment$5", f = "HomeRepayAmountViewModel.kt", l = {}, m = "invokeSuspend")
public final class HomeRepayAmountViewModel$onInboundPayment$5 extends k implements p<HomeRepayAmountViewModel.HomeRepayAmountState, d<? super k>, Object> {
  public int label;
  
  public HomeRepayAmountViewModel.HomeRepayAmountState p$0;
  
  public HomeRepayAmountViewModel$onInboundPayment$5(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    HomeRepayAmountViewModel$onInboundPayment$5 homeRepayAmountViewModel$onInboundPayment$5 = new HomeRepayAmountViewModel$onInboundPayment$5(paramd);
    homeRepayAmountViewModel$onInboundPayment$5.p$0 = (HomeRepayAmountViewModel.HomeRepayAmountState)paramObject;
    return (d<k>)homeRepayAmountViewModel$onInboundPayment$5;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((HomeRepayAmountViewModel$onInboundPayment$5)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      HomeRepayAmountViewModel.access$getMutableState$p(HomeRepayAmountViewModel.this).b(paramObject);
      if (paramObject instanceof HomeRepayAmountViewModel.HomeRepayAmountState.Inbound)
        HomeRepayAmountViewModel.access$getRouter$p(HomeRepayAmountViewModel.this).toPayment(((HomeRepayAmountViewModel.HomeRepayAmountState.Inbound)paramObject).getInboundPaymentParams()); 
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$onInboundPayment$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
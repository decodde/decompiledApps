package ng.com.fairmoney.android.loan.form.work.data;

import f.d.b.i.h;
import j.q.d.k;
import kotlin.NoWhenBranchMatchedException;

public final class ProfessionalMapper {
  public final String transform(h paramh) {
    k.b(paramh, "professionalStatus");
    switch (ProfessionalMapper$WhenMappings.$EnumSwitchMapping$0[paramh.ordinal()]) {
      default:
        throw new NoWhenBranchMatchedException();
      case 7:
        return "NYSC";
      case 6:
        return "Retired";
      case 5:
        return "Unemployed";
      case 4:
        return "Student";
      case 3:
        return "Civil/Public servant";
      case 2:
        return "Work in the private sector";
      case 1:
        break;
    } 
    return "Self-employed";
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\data\ProfessionalMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.transfer;

public final class LoanTransferDetails {
  public final int iconRes;
  
  public final boolean roundIcon;
  
  public final int textRes;
  
  public LoanTransferDetails(int paramInt1, int paramInt2, boolean paramBoolean) {
    this.iconRes = paramInt1;
    this.textRes = paramInt2;
    this.roundIcon = paramBoolean;
  }
  
  public final int component1() {
    return this.iconRes;
  }
  
  public final int component2() {
    return this.textRes;
  }
  
  public final boolean component3() {
    return this.roundIcon;
  }
  
  public final LoanTransferDetails copy(int paramInt1, int paramInt2, boolean paramBoolean) {
    return new LoanTransferDetails(paramInt1, paramInt2, paramBoolean);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof LoanTransferDetails) {
        paramObject = paramObject;
        if (this.iconRes == ((LoanTransferDetails)paramObject).iconRes && this.textRes == ((LoanTransferDetails)paramObject).textRes && this.roundIcon == ((LoanTransferDetails)paramObject).roundIcon)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final int getIconRes() {
    return this.iconRes;
  }
  
  public final boolean getRoundIcon() {
    return this.roundIcon;
  }
  
  public final int getTextRes() {
    return this.textRes;
  }
  
  public int hashCode() {
    int i = this.iconRes;
    int j = this.textRes;
    boolean bool1 = this.roundIcon;
    boolean bool2 = bool1;
    if (bool1)
      bool2 = true; 
    return (i * 31 + j) * 31 + bool2;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LoanTransferDetails(iconRes=");
    stringBuilder.append(this.iconRes);
    stringBuilder.append(", textRes=");
    stringBuilder.append(this.textRes);
    stringBuilder.append(", roundIcon=");
    stringBuilder.append(this.roundIcon);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\transfer\LoanTransferDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
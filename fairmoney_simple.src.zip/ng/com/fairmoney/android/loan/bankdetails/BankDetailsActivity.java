package ng.com.fairmoney.android.loan.bankdetails;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.textfield.TextInputLayout;
import d.b.k.a;
import d.b.k.d;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.w;
import d.o.y;
import d.o.z;
import f.d.c.b;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.activities.LoanOffersActivity;

public final class BankDetailsActivity extends d {
  public EditText bankAccountEditText;
  
  public TextInputLayout bankAccountTil;
  
  @Inject
  public y.b factory;
  
  public EditText ifscEditText;
  
  public TextInputLayout ifscTil;
  
  public Button nextButton;
  
  public BankDetailsViewModel viewModel;
  
  public BankDetailsActivity() {
    super(2131492892);
  }
  
  private final void observeBankDetails() {
    BankDetailsViewModel bankDetailsViewModel = this.viewModel;
    if (bankDetailsViewModel != null) {
      bankDetailsViewModel.getBankDetail().a((l)this, new BankDetailsActivity$observeBankDetails$1());
      return;
    } 
    k.d("viewModel");
    throw null;
  }
  
  public final y.b getFactory() {
    y.b b1 = this.factory;
    if (b1 != null)
      return b1; 
    k.d("factory");
    throw null;
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, LoanOffersActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    Context context = getApplicationContext();
    if (context != null) {
      ViewModelComponentKt.create((b)context).inject(this);
      y.b b1 = this.factory;
      if (b1 != null) {
        w w = z.a((d)this, b1).a(BankDetailsViewModel.class);
        k.a(w, "ViewModelProviders.of(th…ilsViewModel::class.java)");
        this.viewModel = (BankDetailsViewModel)w;
        observeBankDetails();
        setSupportActionBar((Toolbar)findViewById(2131297036));
        a a = getSupportActionBar();
        if (a != null) {
          a.a(getString(2131820612));
          a.d(true);
          a.b(2131230973);
          View view = findViewById(2131296348);
          k.a(view, "findViewById(R.id.bank_account_number_til)");
          this.bankAccountTil = (TextInputLayout)view;
          view = findViewById(2131296347);
          k.a(view, "findViewById(R.id.bank_account_number_et)");
          this.bankAccountEditText = (EditText)view;
          view = findViewById(2131296605);
          k.a(view, "findViewById(R.id.ifsc_til)");
          this.ifscTil = (TextInputLayout)view;
          view = findViewById(2131296604);
          k.a(view, "findViewById(R.id.ifsc_et)");
          this.ifscEditText = (EditText)view;
          view = findViewById(2131296349);
          k.a(view, "findViewById(R.id.bank_details_next)");
          Button button = (Button)view;
          this.nextButton = button;
          if (button != null) {
            button.setOnClickListener(new BankDetailsActivity$onCreate$2());
            ((Button)findViewById(2131296575)).setOnClickListener(new BankDetailsActivity$onCreate$3());
            return;
          } 
          k.d("nextButton");
          throw null;
        } 
        k.a();
        throw null;
      } 
      k.d("factory");
      throw null;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    boolean bool;
    if (paramMenuItem != null && paramMenuItem.getItemId() == 16908332) {
      onBackPressed();
      bool = true;
    } else {
      bool = super.onOptionsItemSelected(paramMenuItem);
    } 
    return bool;
  }
  
  public final void setFactory(y.b paramb) {
    k.b(paramb, "<set-?>");
    this.factory = paramb;
  }
  
  public static final class BankDetailsActivity$observeBankDetails$1<T> implements s<BankDetailsViewModel.BankDetailsState> {
    public final void onChanged(BankDetailsViewModel.BankDetailsState param1BankDetailsState) {
      if (param1BankDetailsState instanceof BankDetailsViewModel.BankDetailsState.Success) {
        BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setErrorEnabled(false);
      } else if (param1BankDetailsState instanceof BankDetailsViewModel.BankDetailsState.Loading) {
        BankDetailsActivity.access$getNextButton$p(BankDetailsActivity.this).setEnabled(((BankDetailsViewModel.BankDetailsState.Loading)param1BankDetailsState).isLoading() ^ true);
      } else if (param1BankDetailsState instanceof BankDetailsViewModel.BankDetailsState.InputErrors) {
        param1BankDetailsState = param1BankDetailsState;
        if (param1BankDetailsState.getErrors().contains(BankDetailsViewModel.BankDetailsStateError.IfscError.INSTANCE)) {
          BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setError(BankDetailsActivity.this.getString(2131820868));
          BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setErrorEnabled(true);
        } else {
          BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setErrorEnabled(false);
        } 
        if (param1BankDetailsState.getErrors().contains(BankDetailsViewModel.BankDetailsStateError.BankAccountError.INSTANCE)) {
          BankDetailsActivity.access$getBankAccountTil$p(BankDetailsActivity.this).setError(BankDetailsActivity.this.getString(2131820606));
          BankDetailsActivity.access$getBankAccountTil$p(BankDetailsActivity.this).setErrorEnabled(true);
        } else {
          BankDetailsActivity.access$getBankAccountTil$p(BankDetailsActivity.this).setErrorEnabled(false);
        } 
      } else if (param1BankDetailsState instanceof BankDetailsViewModel.BankDetailsState.Exception) {
        BankDetailsActivity bankDetailsActivity = BankDetailsActivity.this;
        String str = ((BankDetailsViewModel.BankDetailsState.Exception)param1BankDetailsState).getMessage();
        if (str == null)
          str = BankDetailsActivity.this.getString(2131820796); 
        Toast.makeText((Context)bankDetailsActivity, str, 0).show();
      } 
    }
  }
  
  public static final class BankDetailsActivity$onCreate$2 implements View.OnClickListener {
    public final void onClick(View param1View) {
      BankDetailsActivity.access$getViewModel$p(BankDetailsActivity.this).onClickNext(BankDetailsActivity.access$getBankAccountEditText$p(BankDetailsActivity.this).getText().toString(), BankDetailsActivity.access$getIfscEditText$p(BankDetailsActivity.this).getText().toString());
    }
  }
  
  public static final class BankDetailsActivity$onCreate$3 implements View.OnClickListener {
    public final void onClick(View param1View) {
      BankDetailsActivity.access$getViewModel$p(BankDetailsActivity.this).onClickFindIfsc();
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
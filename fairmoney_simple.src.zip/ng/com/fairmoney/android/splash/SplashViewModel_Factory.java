package ng.com.fairmoney.android.splash;

import f.d.b.c;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class SplashViewModel_Factory implements d<SplashViewModel> {
  public final Provider<c> routerProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public SplashViewModel_Factory(Provider<h> paramProvider, Provider<c> paramProvider1) {
    this.userUseCaseProvider = paramProvider;
    this.routerProvider = paramProvider1;
  }
  
  public static SplashViewModel_Factory create(Provider<h> paramProvider, Provider<c> paramProvider1) {
    return new SplashViewModel_Factory(paramProvider, paramProvider1);
  }
  
  public static SplashViewModel newInstance(h paramh, c paramc) {
    return new SplashViewModel(paramh, paramc);
  }
  
  public SplashViewModel get() {
    return newInstance((h)this.userUseCaseProvider.get(), (c)this.routerProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\splash\SplashViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
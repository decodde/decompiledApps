package ng.com.fairmoney.fairmoney.activities;

import android.app.ProgressDialog;
import android.content.Context;
import androidx.fragment.app.Fragment;
import com.android.volley.VolleyError;
import d.l.a.o;
import f.a.b.k;
import f.d.b.i.c;
import l.a.a.a.a.g;
import l.a.a.a.a.h;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.fragments.loanoffer.LoanOfferDetailsFragment;
import ng.com.fairmoney.fairmoney.network.BackendApi;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import org.json.JSONObject;

public abstract class LoanOfferActivity extends BaseActivity {
  public c loanOfferToDisplay;
  
  public ProgressDialog progressDialog;
  
  public boolean shouldDisplayLoanDetailsFragment = false;
  
  public void cancelDialog() {
    ProgressDialog progressDialog = this.progressDialog;
    if (progressDialog != null && progressDialog.isShowing())
      this.progressDialog.cancel(); 
  }
  
  public void declineLoanOffer() {
    enableAnswers(false);
    this.progressDialog = ProgressDialog.show((Context)this, getString(2131821087), getString(2131820726));
    Tracking.sendUniqueClickEvent((Context)this, "DECLINE");
    FairMoney.getBackendApi((Context)this).declineLoanOffer((k.b)new h(this), (k.a)new g(this));
  }
  
  public void displayLoanOfferDetails(c paramc) {
    if (!getSupportFragmentManager().e()) {
      o o = getSupportFragmentManager().a();
      o.a(2131296578, (Fragment)LoanOfferDetailsFragment.newInstance(paramc));
      o.a();
      this.shouldDisplayLoanDetailsFragment = false;
    } else {
      this.shouldDisplayLoanDetailsFragment = true;
      this.loanOfferToDisplay = paramc;
    } 
  }
  
  public abstract void enableAnswers(boolean paramBoolean);
  
  public abstract void onOfferDeclinedResponse();
  
  public void onPostResume() {
    super.onPostResume();
    if (this.shouldDisplayLoanDetailsFragment)
      displayLoanOfferDetails(this.loanOfferToDisplay); 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\LoanOfferActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
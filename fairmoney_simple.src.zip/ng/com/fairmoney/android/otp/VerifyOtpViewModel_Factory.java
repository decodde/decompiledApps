package ng.com.fairmoney.android.otp;

import f.d.b.b;
import g.b.d;
import javax.inject.Provider;
import ng.com.fairmoney.fairmoney.utils.PhoneNumberFormatter;

public final class VerifyOtpViewModel_Factory implements d<VerifyOtpViewModel> {
  public final Provider<PhoneNumberFormatter> phoneNumberFormatterProvider;
  
  public final Provider<b> phoneNumberValidatorProvider;
  
  public VerifyOtpViewModel_Factory(Provider<PhoneNumberFormatter> paramProvider, Provider<b> paramProvider1) {
    this.phoneNumberFormatterProvider = paramProvider;
    this.phoneNumberValidatorProvider = paramProvider1;
  }
  
  public static VerifyOtpViewModel_Factory create(Provider<PhoneNumberFormatter> paramProvider, Provider<b> paramProvider1) {
    return new VerifyOtpViewModel_Factory(paramProvider, paramProvider1);
  }
  
  public static VerifyOtpViewModel newInstance(PhoneNumberFormatter paramPhoneNumberFormatter, b paramb) {
    return new VerifyOtpViewModel(paramPhoneNumberFormatter, paramb);
  }
  
  public VerifyOtpViewModel get() {
    return newInstance((PhoneNumberFormatter)this.phoneNumberFormatterProvider.get(), (b)this.phoneNumberValidatorProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\otp\VerifyOtpViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.bankdetails;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;

@f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$6", f = "BankDetailsViewModel.kt", l = {}, m = "invokeSuspend")
public final class BankDetailsViewModel$onClickNext$6 extends k implements p<BankDetailsViewModel.BankDetailsState, d<? super k>, Object> {
  public int label;
  
  public BankDetailsViewModel.BankDetailsState p$0;
  
  public BankDetailsViewModel$onClickNext$6(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    BankDetailsViewModel$onClickNext$6 bankDetailsViewModel$onClickNext$6 = new BankDetailsViewModel$onClickNext$6(paramd);
    bankDetailsViewModel$onClickNext$6.p$0 = (BankDetailsViewModel.BankDetailsState)paramObject;
    return (d<k>)bankDetailsViewModel$onClickNext$6;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((BankDetailsViewModel$onClickNext$6)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      BankDetailsViewModel.access$getMutableBankDetailsState$p(BankDetailsViewModel.this).b(paramObject);
      if (paramObject instanceof BankDetailsViewModel.BankDetailsState.Success)
        BankDetailsViewModel.access$getRouter$p(BankDetailsViewModel.this).toFinalLoanOffer(); 
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$onClickNext$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class FormGuarantorActivity_MembersInjector implements a<FormGuarantorActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public FormGuarantorActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<FormGuarantorActivity> create(Provider<y.b> paramProvider) {
    return new FormGuarantorActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(FormGuarantorActivity paramFormGuarantorActivity, y.b paramb) {
    paramFormGuarantorActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(FormGuarantorActivity paramFormGuarantorActivity) {
    injectViewModelFactory(paramFormGuarantorActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormGuarantorActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
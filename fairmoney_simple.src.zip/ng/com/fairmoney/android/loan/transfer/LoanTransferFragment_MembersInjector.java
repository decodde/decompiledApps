package ng.com.fairmoney.android.loan.transfer;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class LoanTransferFragment_MembersInjector implements a<LoanTransferFragment> {
  public final Provider<y.b> factoryProvider;
  
  public LoanTransferFragment_MembersInjector(Provider<y.b> paramProvider) {
    this.factoryProvider = paramProvider;
  }
  
  public static a<LoanTransferFragment> create(Provider<y.b> paramProvider) {
    return new LoanTransferFragment_MembersInjector(paramProvider);
  }
  
  public static void injectFactory(LoanTransferFragment paramLoanTransferFragment, y.b paramb) {
    paramLoanTransferFragment.factory = paramb;
  }
  
  public void injectMembers(LoanTransferFragment paramLoanTransferFragment) {
    injectFactory(paramLoanTransferFragment, (y.b)this.factoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\transfer\LoanTransferFragment_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
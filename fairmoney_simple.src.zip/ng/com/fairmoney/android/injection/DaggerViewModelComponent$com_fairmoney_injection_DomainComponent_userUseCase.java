package ng.com.fairmoney.android.injection;

import f.d.b.k.h;
import f.d.c.j;
import g.b.g;
import javax.inject.Provider;

public class com_fairmoney_injection_DomainComponent_userUseCase implements Provider<h> {
  public final j domainComponent;
  
  public com_fairmoney_injection_DomainComponent_userUseCase(j paramj) {
    this.domainComponent = paramj;
  }
  
  public h get() {
    h h = this.domainComponent.b();
    g.a(h, "Cannot return null from a non-@Nullable component method");
    return h;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\DaggerViewModelComponent$com_fairmoney_injection_DomainComponent_userUseCase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
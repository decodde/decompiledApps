package ng.com.fairmoney.android.injection;

import d.o.w;
import g.b.d;
import java.util.Map;
import javax.inject.Provider;

public final class ViewModelFactory_Factory implements d<ViewModelFactory> {
  public final Provider<Map<Class<? extends w>, Provider<w>>> viewModelsProvider;
  
  public ViewModelFactory_Factory(Provider<Map<Class<? extends w>, Provider<w>>> paramProvider) {
    this.viewModelsProvider = paramProvider;
  }
  
  public static ViewModelFactory_Factory create(Provider<Map<Class<? extends w>, Provider<w>>> paramProvider) {
    return new ViewModelFactory_Factory(paramProvider);
  }
  
  public static ViewModelFactory newInstance(Map<Class<? extends w>, Provider<w>> paramMap) {
    return new ViewModelFactory(paramMap);
  }
  
  public ViewModelFactory get() {
    return newInstance((Map<Class<? extends w>, Provider<w>>)this.viewModelsProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\ViewModelFactory_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
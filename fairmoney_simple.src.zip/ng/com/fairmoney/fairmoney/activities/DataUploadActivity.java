package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.c.a.a;
import f.d.b.i.c;
import f.d.c.b;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import l.a.a.a.a.a;
import l.a.a.a.a.b;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.activities.form.PermissionsActivity;
import ng.com.fairmoney.fairmoney.application.FairMoney;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.LocationUtils;
import ng.com.fairmoney.fairmoney.utils.Logging;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import retrofit2.Call;

public class DataUploadActivity extends BaseUploadActivity implements LocationUtils.LocationListener {
  public Button btRetry;
  
  @Inject
  public y.b factory;
  
  public boolean isFirstCallToLoanOffers = true;
  
  public ProgressBar progressBar;
  
  public TextView progressText;
  
  public boolean requestedLoanOffers = false;
  
  public TextView tvUploadError;
  
  public DataUploadViewModel viewModel;
  
  private void initRetryButton() {
    Button button = (Button)findViewById(2131296423);
    this.btRetry = button;
    button.setOnClickListener((View.OnClickListener)new b(this));
  }
  
  private void initView() {
    TextView textView = (TextView)findViewById(2131296979);
    String str = getSharedPreferences("CurrentUser", 0).getString("et_form_firstname", "");
    if (!str.contentEquals("")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(" ");
      stringBuilder.append(str);
      str = stringBuilder.toString();
    } 
    textView.setText(getString(2131820717, new Object[] { str }));
    ProgressBar progressBar = (ProgressBar)findViewById(2131296808);
    this.progressBar = progressBar;
    progressBar.setProgressDrawable(getResources().getDrawable(2131231101));
    this.progressText = (TextView)findViewById(2131296809);
    displayProgress(0);
    this.tvUploadError = (TextView)findViewById(2131297212);
    initRetryButton();
  }
  
  private void onGetLoanOffersFailure(final String message) {
    Call call = this.getLoanOffersCall;
    if (call != null && call.isCanceled())
      return; 
    if (this.isFirstCallToLoanOffers) {
      Logging.logLoanOffersResult((Context)this, false, message);
      this.isFirstCallToLoanOffers = false;
    } 
    runOnUiThread(new Runnable() {
          public void run() {
            String str = message;
            DataUploadActivity.this.tvUploadError.setText(str);
            DataUploadActivity.this.tvUploadError.setVisibility(0);
            DataUploadActivity.this.btRetry.setVisibility(0);
            DataUploadActivity.this.btRetry.setEnabled(true);
          }
        });
    a.a(new Exception(Tracking.getFairMoneyExceptionText((Context)this, message)));
  }
  
  private void onGetLoanOffersSuccess(List<c> paramList) {
    Call call = this.getLoanOffersCall;
    if (call != null && call.isCanceled())
      return; 
    if (this.isFirstCallToLoanOffers) {
      Logging.logLoanOffersResult((Context)this, true, null);
      this.isFirstCallToLoanOffers = false;
    } 
    if (!paramList.isEmpty()) {
      Intent intent = new Intent(getApplicationContext(), LoanOffersActivity.class);
      intent.putExtra("newLoanOffers", new ArrayList<c>(paramList));
      startActivity(intent);
      finish();
      FairMoney.decrementIdlingResource();
    } else {
      startActivity(new Intent(getApplicationContext(), RejectedActivity.class));
      finish();
    } 
  }
  
  public void displayProgress(int paramInt) {
    this.progressBar.setProgress(paramInt);
    this.progressText.setText(getString(2131820898, new Object[] { Integer.toString(paramInt) }));
  }
  
  public void displayRetryButtonAndErrorText(String paramString) {
    FairMoney.decrementIdlingResource();
    this.btRetry.setVisibility(0);
    if (paramString.isEmpty()) {
      this.tvUploadError.setVisibility(8);
    } else {
      this.tvUploadError.setVisibility(0);
      this.tvUploadError.setText(paramString);
    } 
  }
  
  public void goToNextActivity() {
    this.requestedLoanOffers = true;
    this.btRetry.setEnabled(false);
    LocationUtils locationUtils = this.locationUtils;
    if (locationUtils != null)
      locationUtils.stopLocationUpdates(); 
    this.viewModel.getState().a((l)this, (s)new a(this));
    this.viewModel.initialize();
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 == 100)
      if (paramInt2 == -1) {
        this.locationUtils.requestLocation();
        sendPhoneCharacteristics();
      } else {
        this.locationUtils.onLocationDisabled();
      }  
  }
  
  public void onBackPressed() {
    startActivity(new Intent(getApplicationContext(), PermissionsActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    LocationUtils locationUtils = new LocationUtils(this);
    this.locationUtils = locationUtils;
    locationUtils.requestLocation();
    initView();
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.viewModel = (DataUploadViewModel)z.a((d)this, this.factory).a(DataUploadViewModel.class);
    Tracking.sendUniqueEvent((Context)this, new Event("form", "uploadingData"));
    getWindow().addFlags(128);
    FairMoney.incrementIdlingResource();
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.FINISH_APPLICATION_EVENT, null, DataUploadActivity.class.getSimpleName()));
  }
  
  public void onLocationActivated() {
    sendPhoneCharacteristics();
  }
  
  public void onLocationReceived(Location paramLocation) {
    sendLocation(paramLocation, 3);
  }
  
  public void onLocationUnavailable() {
    sendPhoneCharacteristics();
  }
  
  public int provideContentViewId() {
    return 2131492904;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.adapters;

import android.view.View;
import ng.com.fairmoney.fairmoney.models.BillChoice;

public class null implements View.OnClickListener {
  public void onClick(View paramView) {
    CustomListAdapter.access$102(CustomListAdapter.this, position);
    CustomListAdapter.this.notifyDataSetChanged();
    CustomListAdapter.access$300(CustomListAdapter.this).onClick(((BillChoice)CustomListAdapter.access$200(CustomListAdapter.this).get(position)).getName(), ((BillChoice)CustomListAdapter.access$200(CustomListAdapter.this).get(position)).getId());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\adapters\CustomListAdapter$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
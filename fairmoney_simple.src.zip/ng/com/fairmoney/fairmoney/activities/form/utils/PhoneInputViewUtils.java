package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.content.SharedPreferences;
import d.b.k.d;
import f.d.b.k.f;
import java.util.Map;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;

public class PhoneInputViewUtils {
  public static void fillPhoneNumber(d paramd, SharedPreferences paramSharedPreferences, Map<String, String> paramMap, int paramInt) {
    ((PhoneInputView)paramd.getSupportFragmentManager().a(paramInt)).setNumbers(paramSharedPreferences.getString(paramMap.get("id"), ""));
  }
  
  public static String getPhoneNumber(d paramd, SharedPreferences.Editor paramEditor, Map<String, String> paramMap, int paramInt) {
    String str1;
    String str2;
    f f = ((PhoneInputView)paramd.getSupportFragmentManager().a(paramInt)).getPhoneNumber(false);
    if (f == null) {
      paramd = null;
    } else {
      str1 = f.toString();
    } 
    String str3 = paramMap.get("id");
    if (f.b() == null) {
      str2 = "";
    } else {
      str2 = f.b();
    } 
    paramEditor.putString(str3, str2).apply();
    return str1;
  }
  
  public static boolean isValidPhoneNumber(d paramd, int paramInt) {
    PhoneInputView phoneInputView = (PhoneInputView)paramd.getSupportFragmentManager().a(paramInt);
    boolean bool = true;
    if (phoneInputView.getPhoneNumber(true) == null)
      bool = false; 
    return bool;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\PhoneInputViewUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
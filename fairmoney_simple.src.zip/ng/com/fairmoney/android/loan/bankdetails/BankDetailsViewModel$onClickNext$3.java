package ng.com.fairmoney.android.loan.bankdetails;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.q;
import j.q.d.k;
import k.a.h2.b;

@f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$3", f = "BankDetailsViewModel.kt", l = {59}, m = "invokeSuspend")
public final class BankDetailsViewModel$onClickNext$3 extends k implements q<b<? super BankDetailsViewModel.BankDetailsState>, Throwable, d<? super k>, Object> {
  public Object L$0;
  
  public Object L$1;
  
  public int label;
  
  public b p$;
  
  public Throwable p$0;
  
  public BankDetailsViewModel$onClickNext$3(d paramd) {
    super(3, paramd);
  }
  
  public final d<k> create(b<? super BankDetailsViewModel.BankDetailsState> paramb, Throwable paramThrowable, d<? super k> paramd) {
    k.b(paramb, "$this$create");
    k.b(paramThrowable, "it");
    k.b(paramd, "continuation");
    BankDetailsViewModel$onClickNext$3 bankDetailsViewModel$onClickNext$3 = new BankDetailsViewModel$onClickNext$3(paramd);
    bankDetailsViewModel$onClickNext$3.p$ = paramb;
    bankDetailsViewModel$onClickNext$3.p$0 = paramThrowable;
    return (d<k>)bankDetailsViewModel$onClickNext$3;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2, Object paramObject3) {
    return ((BankDetailsViewModel$onClickNext$3)create((b<? super BankDetailsViewModel.BankDetailsState>)paramObject1, (Throwable)paramObject2, (d<? super k>)paramObject3)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    Object object = c.a();
    int i = this.label;
    if (i != 0) {
      if (i == 1) {
        object = this.L$1;
        object = this.L$0;
        g.a(paramObject);
      } else {
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
    } else {
      g.a(paramObject);
      b b1 = this.p$;
      Throwable throwable = this.p$0;
      paramObject = new BankDetailsViewModel.BankDetailsState.Exception(throwable.getMessage());
      this.L$0 = b1;
      this.L$1 = throwable;
      this.label = 1;
      if (b1.emit(paramObject, (d)this) == object)
        return object; 
    } 
    return k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel$onClickNext$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
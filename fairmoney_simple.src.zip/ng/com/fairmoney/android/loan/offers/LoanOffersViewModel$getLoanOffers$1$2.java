package ng.com.fairmoney.android.loan.offers;

import f.d.b.i.c;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import java.util.List;

@f(c = "ng.com.fairmoney.android.loan.offers.LoanOffersViewModel$getLoanOffers$1$2", f = "LoanOffersViewModel.kt", l = {}, m = "invokeSuspend")
public final class null extends k implements p<List<? extends c>, d<? super k>, Object> {
  public int label;
  
  public List p$0;
  
  public null(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    Object object = new Object(LoanOffersViewModel$getLoanOffers$1.this, paramd);
    object.p$0 = (List)paramObject;
    return (d<k>)object;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((null)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      LoanOffersViewModel.access$getMutableLoanOffersState$p(this.this$0.this$0).b(new LoanOffersViewModel.LoanOffersState.Success((List<c>)paramObject));
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offers\LoanOffersViewModel$getLoanOffers$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
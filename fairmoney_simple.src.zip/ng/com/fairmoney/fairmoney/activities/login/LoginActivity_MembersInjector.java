package ng.com.fairmoney.fairmoney.activities.login;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class LoginActivity_MembersInjector implements a<LoginActivity> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public LoginActivity_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<LoginActivity> create(Provider<y.b> paramProvider) {
    return new LoginActivity_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(LoginActivity paramLoginActivity, y.b paramb) {
    paramLoginActivity.viewModelFactory = paramb;
  }
  
  public void injectMembers(LoginActivity paramLoginActivity) {
    injectViewModelFactory(paramLoginActivity, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginActivity_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
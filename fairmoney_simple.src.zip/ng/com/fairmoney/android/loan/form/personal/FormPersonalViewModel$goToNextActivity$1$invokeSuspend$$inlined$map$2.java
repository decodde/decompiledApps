package ng.com.fairmoney.android.loan.form.personal;

import f.d.b.h.b;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.a;
import k.a.h2.b;

public final class FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2 implements a<FormPersonalViewModel.FormPersonalState> {
  public FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2(a parama) {}
  
  public Object collect(b paramb, d paramd) {
    Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
          public Object emit(Object param1Object, d param1d) {
            b b1 = this.$this_unsafeFlow$inlined;
            if (((b)param1Object).a()) {
              param1Object = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
            } else {
              param1Object = FormPersonalViewModel.FormPersonalState.Hyperverge.INSTANCE;
            } 
            param1Object = b1.emit(param1Object, param1d);
            return (param1Object == c.a()) ? param1Object : k.a;
          }
        }paramd);
    return (object == c.a()) ? object : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
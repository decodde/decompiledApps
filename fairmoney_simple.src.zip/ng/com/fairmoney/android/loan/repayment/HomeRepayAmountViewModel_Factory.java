package ng.com.fairmoney.android.loan.repayment;

import f.d.b.c;
import f.d.b.j.f;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class HomeRepayAmountViewModel_Factory implements d<HomeRepayAmountViewModel> {
  public final Provider<f> paymentUseCaseProvider;
  
  public final Provider<c> routerProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public HomeRepayAmountViewModel_Factory(Provider<h> paramProvider, Provider<c> paramProvider1, Provider<f> paramProvider2) {
    this.userUseCaseProvider = paramProvider;
    this.routerProvider = paramProvider1;
    this.paymentUseCaseProvider = paramProvider2;
  }
  
  public static HomeRepayAmountViewModel_Factory create(Provider<h> paramProvider, Provider<c> paramProvider1, Provider<f> paramProvider2) {
    return new HomeRepayAmountViewModel_Factory(paramProvider, paramProvider1, paramProvider2);
  }
  
  public static HomeRepayAmountViewModel newInstance(h paramh, c paramc, f paramf) {
    return new HomeRepayAmountViewModel(paramh, paramc, paramf);
  }
  
  public HomeRepayAmountViewModel get() {
    return newInstance((h)this.userUseCaseProvider.get(), (c)this.routerProvider.get(), (f)this.paymentUseCaseProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
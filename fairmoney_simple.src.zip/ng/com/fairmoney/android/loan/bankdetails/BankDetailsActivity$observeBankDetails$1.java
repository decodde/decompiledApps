package ng.com.fairmoney.android.loan.bankdetails;

import android.content.Context;
import android.widget.Toast;
import d.o.s;

public final class BankDetailsActivity$observeBankDetails$1<T> implements s<BankDetailsViewModel.BankDetailsState> {
  public final void onChanged(BankDetailsViewModel.BankDetailsState paramBankDetailsState) {
    if (paramBankDetailsState instanceof BankDetailsViewModel.BankDetailsState.Success) {
      BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setErrorEnabled(false);
    } else if (paramBankDetailsState instanceof BankDetailsViewModel.BankDetailsState.Loading) {
      BankDetailsActivity.access$getNextButton$p(BankDetailsActivity.this).setEnabled(((BankDetailsViewModel.BankDetailsState.Loading)paramBankDetailsState).isLoading() ^ true);
    } else if (paramBankDetailsState instanceof BankDetailsViewModel.BankDetailsState.InputErrors) {
      paramBankDetailsState = paramBankDetailsState;
      if (paramBankDetailsState.getErrors().contains(BankDetailsViewModel.BankDetailsStateError.IfscError.INSTANCE)) {
        BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setError(BankDetailsActivity.this.getString(2131820868));
        BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setErrorEnabled(true);
      } else {
        BankDetailsActivity.access$getIfscTil$p(BankDetailsActivity.this).setErrorEnabled(false);
      } 
      if (paramBankDetailsState.getErrors().contains(BankDetailsViewModel.BankDetailsStateError.BankAccountError.INSTANCE)) {
        BankDetailsActivity.access$getBankAccountTil$p(BankDetailsActivity.this).setError(BankDetailsActivity.this.getString(2131820606));
        BankDetailsActivity.access$getBankAccountTil$p(BankDetailsActivity.this).setErrorEnabled(true);
      } else {
        BankDetailsActivity.access$getBankAccountTil$p(BankDetailsActivity.this).setErrorEnabled(false);
      } 
    } else if (paramBankDetailsState instanceof BankDetailsViewModel.BankDetailsState.Exception) {
      BankDetailsActivity bankDetailsActivity = BankDetailsActivity.this;
      String str = ((BankDetailsViewModel.BankDetailsState.Exception)paramBankDetailsState).getMessage();
      if (str == null)
        str = BankDetailsActivity.this.getString(2131820796); 
      Toast.makeText((Context)bankDetailsActivity, str, 0).show();
    } 
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsActivity$observeBankDetails$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatCheckBox;
import d.i.e.a;
import d.i.f.a;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.d.c.b;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import l.a.a.a.a.s.g;
import l.a.a.a.a.s.h;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.loan.termsofuse.TermsOfUseViewModel;
import ng.com.fairmoney.fairmoney.activities.BasePermissionActivity;
import ng.com.fairmoney.fairmoney.activities.DataUploadActivity;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.utils.Utils;

public class PermissionsActivity extends BasePermissionActivity {
  public AlertDialog alertDialog;
  
  public boolean alreadyClicked = false;
  
  public Button btNext;
  
  public AppCompatCheckBox cbAccept;
  
  public View discountContainer;
  
  @Inject
  public y.b factory;
  
  public View lateFeesContainer;
  
  public TextView linkToPrivacyPolicy;
  
  public ImageView moneyImageView;
  
  public TextView termsOfUseExplanation;
  
  public TermsOfUseViewModel termsOfUseViewModel;
  
  public TextView upToHigherAmount;
  
  private void dismissAlertDialog() {
    AlertDialog alertDialog = this.alertDialog;
    if (alertDialog != null && alertDialog.isShowing())
      this.alertDialog.cancel(); 
  }
  
  private void initView() {
    this.cbAccept = (AppCompatCheckBox)findViewById(2131296433);
    Button button = (Button)findViewById(2131296760);
    this.btNext = button;
    button.setText(2131820688);
    this.btNext.setEnabled(false);
    this.cbAccept.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new g(this));
    this.cbAccept.setMovementMethod(LinkMovementMethod.getInstance());
  }
  
  private void observeTermsOfUse(TermsOfUseViewModel.TermsOfUse paramTermsOfUse) {
    AppCompatCheckBox appCompatCheckBox = this.cbAccept;
    if (paramTermsOfUse.isLoanAgreement()) {
      i = 2131821195;
    } else {
      i = 2131821198;
    } 
    appCompatCheckBox.setText(getString(i));
    this.upToHigherAmount.setText(getString(2131821189, new Object[] { paramTermsOfUse.getHigherAmounts() }));
    View view = this.discountContainer;
    boolean bool = paramTermsOfUse.getDiscountVisibility();
    byte b1 = 8;
    if (bool) {
      i = 0;
    } else {
      i = 8;
    } 
    view.setVisibility(i);
    view = this.lateFeesContainer;
    int i = b1;
    if (paramTermsOfUse.getLateFeesVisibility())
      i = 0; 
    view.setVisibility(i);
    this.termsOfUseExplanation.setText((CharSequence)Html.fromHtml(getString(2131820715, new Object[] { paramTermsOfUse.getLoanRange().c(), paramTermsOfUse.getLoanRange().d(), paramTermsOfUse.getFeesRange().c(), paramTermsOfUse.getFeesRange().d(), paramTermsOfUse.getMonthlyFeesRange().c(), paramTermsOfUse.getMonthlyFeesRange().d() })));
    TextView textView = this.linkToPrivacyPolicy;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("<a href=\"");
    stringBuilder.append(paramTermsOfUse.getTermsOfUseUrl());
    stringBuilder.append("\">terms of use</a>");
    String str1 = stringBuilder.toString();
    String str2 = paramTermsOfUse.getLoanAgreementLink();
    stringBuilder = new StringBuilder();
    stringBuilder.append("<a href=\"");
    stringBuilder.append(paramTermsOfUse.getPrivacyUrl());
    stringBuilder.append("\">privacy policy</a>");
    textView.setText((CharSequence)Html.fromHtml(getString(2131821182, new Object[] { str1, str2, stringBuilder.toString() })));
    this.linkToPrivacyPolicy.setMovementMethod(LinkMovementMethod.getInstance());
    if (paramTermsOfUse.getNeutralCurrency())
      this.moneyImageView.setImageDrawable(a.c((Context)this, 2131231037)); 
  }
  
  public List<Map<String, String>> getFormParameters() {
    return Utils.getActivityConfigValue((Context)this, 2131755014);
  }
  
  public void goToNextActivity() {
    if (this.cbAccept.isChecked()) {
      startActivity(new Intent(getApplicationContext(), DataUploadActivity.class));
      finish();
    } 
  }
  
  public void onBackPressed() {
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)this, ApplicationFormEvent.FormEventType.BACK_BUTTON_CLICK_EVENT, null, PermissionsActivity.class.getSimpleName()));
    startActivity(new Intent(getApplicationContext(), FormLoanPurposeActivity.class));
    finish();
  }
  
  public void onClickOnNextButton(View paramView) {
    if (!this.alreadyClicked) {
      a.a((Activity)this, BasePermissionActivity.requiredPermissions, 100);
      this.alreadyClicked = true;
    } else if (shouldShowRequestPermissionRationale()) {
      showPermissionDialog("requestPermissions");
    } else {
      showPermissionDialog("goToSettings");
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.termsOfUseViewModel = (TermsOfUseViewModel)z.a((d)this, this.factory).a(TermsOfUseViewModel.class);
    this.upToHigherAmount = (TextView)findViewById(2131297227);
    this.lateFeesContainer = findViewById(2131296663);
    this.discountContainer = findViewById(2131296494);
    this.termsOfUseExplanation = (TextView)findViewById(2131297207);
    this.linkToPrivacyPolicy = (TextView)findViewById(2131296674);
    this.moneyImageView = (ImageView)findViewById(2131296649);
    setTitle(getString(2131821085));
    initView();
    Tracking.sendUniqueEvent((Context)this, new Event("form", "permissions and terms"));
    this.termsOfUseViewModel.getTermsOfUse().a((l)this, (s)new h(this));
    this.termsOfUseViewModel.initialize();
  }
  
  public void onDestroy() {
    super.onDestroy();
    dismissAlertDialog();
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
    if (paramInt == 100) {
      int i = paramArrayOfint.length;
      boolean bool = false;
      byte b1 = 0;
      paramInt = 0;
      while (b1 < i) {
        paramInt = bool;
        if (paramArrayOfint[b1] == 0) {
          b1++;
          paramInt = 1;
        } 
      } 
      if (paramInt != 0) {
        reportClickOnNextButton();
        nextPage((View)this.btNext);
      } 
    } 
  }
  
  public int provideContentViewId() {
    return 2131492911;
  }
  
  public boolean shouldShowRequestPermissionRationale() {
    String[] arrayOfString = BasePermissionActivity.requiredPermissions;
    boolean bool = false;
    if (a.a((Activity)this, arrayOfString[0]) || a.a((Activity)this, BasePermissionActivity.requiredPermissions[1]) || a.a((Activity)this, BasePermissionActivity.requiredPermissions[2]) || a.a((Activity)this, BasePermissionActivity.requiredPermissions[3]))
      bool = true; 
    return bool;
  }
  
  public void showPermissionDialog(final String action) {
    AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
    builder.setTitle(getString(2131820996));
    builder.setMessage(getString(2131820807));
    builder.setPositiveButton(getString(2131820847), new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            PermissionsActivity.this.dismissAlertDialog();
            if (action.equals("requestPermissions")) {
              a.a((Activity)PermissionsActivity.this, BasePermissionActivity.requiredPermissions, 100);
            } else if (action.equals("goToSettings")) {
              Toast.makeText(PermissionsActivity.this.getBaseContext(), PermissionsActivity.this.getString(2131820838), 1).show();
              Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
              intent.setData(Uri.fromParts("package", PermissionsActivity.this.getPackageName(), null));
              PermissionsActivity.this.startActivityForResult(intent, 101);
            } 
          }
        });
    builder.setNegativeButton(getString(2131820636), new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            PermissionsActivity.this.dismissAlertDialog();
          }
        });
    this.alertDialog = builder.show();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\PermissionsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
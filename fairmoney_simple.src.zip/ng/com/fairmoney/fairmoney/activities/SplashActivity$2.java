package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import android.widget.Toast;
import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<Object> {
  public void failure(int paramInt, String paramString) {
    Toast.makeText((Context)SplashActivity.this, paramString, 0).show();
  }
  
  public void success(Object paramObject) {
    SplashActivity.access$200(SplashActivity.this).initialize();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\SplashActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
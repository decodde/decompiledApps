package ng.com.fairmoney.android.loan.offer;

public final class Empty extends LoanOfferDetailsViewModel.LoanOfferDetailsDataState {
  public static final Empty INSTANCE = new Empty();
  
  public Empty() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsViewModel$LoanOfferDetailsDataState$Empty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
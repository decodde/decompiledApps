package ng.com.fairmoney.android.payment.history;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public final class PaymentHistoryFragment$onViewCreated$3 implements SwipeRefreshLayout.j {
  public final void onRefresh() {
    PaymentHistoryFragment.access$getViewModel$p(PaymentHistoryFragment.this).fetchBills();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryFragment$onViewCreated$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
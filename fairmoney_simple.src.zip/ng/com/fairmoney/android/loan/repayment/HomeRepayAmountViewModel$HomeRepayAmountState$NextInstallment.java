package ng.com.fairmoney.android.loan.repayment;

public final class NextInstallment extends HomeRepayAmountViewModel.HomeRepayAmountState {
  public NextInstallment(int paramInt) {
    super(paramInt, null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$HomeRepayAmountState$NextInstallment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
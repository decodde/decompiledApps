package ng.com.fairmoney.android.loan.repayment;

import f.d.b.j.b;
import j.q.d.g;

public abstract class HomeRepayAmountState {
  public final int amountInCent;
  
  public HomeRepayAmountState(int paramInt) {
    this.amountInCent = paramInt;
  }
  
  public final int getAmountInCent() {
    return this.amountInCent;
  }
  
  public static final class CustomAmount extends HomeRepayAmountState {
    public CustomAmount(int param2Int) {
      super(param2Int, null);
    }
  }
  
  public static final class Error extends HomeRepayAmountState {
    public final Throwable exception;
    
    public Error(int param2Int, Throwable param2Throwable) {
      super(param2Int, null);
      this.exception = param2Throwable;
    }
    
    public final Throwable getException() {
      return this.exception;
    }
  }
  
  public static final class FullRepayment extends HomeRepayAmountState {
    public FullRepayment(int param2Int) {
      super(param2Int, null);
    }
  }
  
  public static final class Inbound extends HomeRepayAmountState {
    public final b inboundPaymentParams;
    
    public Inbound(int param2Int, b param2b) {
      super(param2Int, null);
      this.inboundPaymentParams = param2b;
    }
    
    public final b getInboundPaymentParams() {
      return this.inboundPaymentParams;
    }
  }
  
  public static final class Loading extends HomeRepayAmountState {
    public final boolean loading;
    
    public Loading(int param2Int, boolean param2Boolean) {
      super(param2Int, null);
      this.loading = param2Boolean;
    }
    
    public final boolean getLoading() {
      return this.loading;
    }
  }
  
  public static final class NextInstallment extends HomeRepayAmountState {
    public NextInstallment(int param2Int) {
      super(param2Int, null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$HomeRepayAmountState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
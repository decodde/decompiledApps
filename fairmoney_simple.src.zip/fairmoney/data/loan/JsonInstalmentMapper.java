package fairmoney.data.loan;

import com.fairmoney.data.loan.JsonInstalment;
import f.d.b.i.b;
import j.c;
import j.d;
import j.q.c.a;
import j.q.d.k;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class JsonInstalmentMapper {
  public final c simpleDateFormat$delegate = d.a((a)simpleDateFormat.null.INSTANCE);
  
  private final SimpleDateFormat getSimpleDateFormat() {
    return (SimpleDateFormat)this.simpleDateFormat$delegate.getValue();
  }
  
  public final b transform(JsonInstalment paramJsonInstalment) {
    k.b(paramJsonInstalment, "jsonInstalment");
    Date date = getSimpleDateFormat().parse(paramJsonInstalment.getDate());
    k.a(date, "simpleDateFormat.parse(jsonInstalment.date)");
    return new b(date, paramJsonInstalment.getAmount(), paramJsonInstalment.getCurrencyCode());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\loan\JsonInstalmentMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
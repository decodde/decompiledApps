package ng.com.fairmoney.android.phoneinput;

import f.d.b.k.f;
import j.q.d.g;

public abstract class PhoneInputState {
  public PhoneInputState() {}
  
  public static final class InitValue extends PhoneInputState {
    public final f phoneNumber;
    
    public InitValue(f param2f) {
      super(null);
      this.phoneNumber = param2f;
    }
    
    public final f getPhoneNumber() {
      return this.phoneNumber;
    }
  }
  
  public static final class Invalid extends PhoneInputState {
    public final ErrorType errorType;
    
    public Invalid(ErrorType param2ErrorType) {
      super(null);
      this.errorType = param2ErrorType;
    }
    
    public final ErrorType getErrorType() {
      return this.errorType;
    }
    
    public enum ErrorType {
      NO_COUNTRY, NO_NUMBERS;
      
      static {
        ErrorType errorType1 = new ErrorType("NO_COUNTRY", 0);
        NO_COUNTRY = errorType1;
        ErrorType errorType2 = new ErrorType("NO_NUMBERS", 1);
        NO_NUMBERS = errorType2;
        $VALUES = new ErrorType[] { errorType1, errorType2 };
      }
    }
  }
  
  public enum ErrorType {
    NO_COUNTRY, NO_NUMBERS;
    
    static {
      ErrorType errorType1 = new ErrorType("NO_COUNTRY", 0);
      NO_COUNTRY = errorType1;
      ErrorType errorType2 = new ErrorType("NO_NUMBERS", 1);
      NO_NUMBERS = errorType2;
      $VALUES = new ErrorType[] { errorType1, errorType2 };
    }
  }
  
  public static final class Valid extends PhoneInputState {
    public static final Valid INSTANCE = new Valid();
    
    public Valid() {
      super(null);
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputViewModel$PhoneInputState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
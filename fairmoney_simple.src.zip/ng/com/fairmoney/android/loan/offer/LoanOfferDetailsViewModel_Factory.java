package ng.com.fairmoney.android.loan.offer;

import g.b.d;

public final class LoanOfferDetailsViewModel_Factory implements d<LoanOfferDetailsViewModel> {
  public static LoanOfferDetailsViewModel_Factory create() {
    return InstanceHolder.INSTANCE;
  }
  
  public static LoanOfferDetailsViewModel newInstance() {
    return new LoanOfferDetailsViewModel();
  }
  
  public LoanOfferDetailsViewModel get() {
    return newInstance();
  }
  
  public static final class InstanceHolder {
    public static final LoanOfferDetailsViewModel_Factory INSTANCE = new LoanOfferDetailsViewModel_Factory();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offer\LoanOfferDetailsViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
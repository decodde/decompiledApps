package ng.com.fairmoney.android.splash;

import f.d.b.k.b;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import kotlin.NoWhenBranchMatchedException;

@f(c = "ng.com.fairmoney.android.splash.SplashViewModel$initialize$1", f = "SplashViewModel.kt", l = {}, m = "invokeSuspend")
public final class SplashViewModel$initialize$1 extends k implements p<b, d<? super a<? extends SplashViewModel.RouteState>>, Object> {
  public int label;
  
  public b p$0;
  
  public SplashViewModel$initialize$1(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    SplashViewModel$initialize$1 splashViewModel$initialize$1 = new SplashViewModel$initialize$1(paramd);
    splashViewModel$initialize$1.p$0 = (b)paramObject;
    return (d<k>)splashViewModel$initialize$1;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((SplashViewModel$initialize$1)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      if (k.a(paramObject, b.b.h)) {
        paramObject = new SplashViewModel$initialize$1$invokeSuspend$$inlined$map$1(SplashViewModel.access$getUserUseCase$p(SplashViewModel.this).a());
      } else if (k.a(paramObject, b.a.h)) {
        paramObject = c.a(SplashViewModel.RouteState.Welcome.INSTANCE);
      } else {
        if (k.a(paramObject, b.c.h))
          return c.a(SplashViewModel.RouteState.Welcome.INSTANCE); 
        throw new NoWhenBranchMatchedException();
      } 
      return paramObject;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
  
  public static final class SplashViewModel$initialize$1$invokeSuspend$$inlined$map$1 implements a<SplashViewModel.RouteState> {
    public SplashViewModel$initialize$1$invokeSuspend$$inlined$map$1(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<Boolean>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              if (((Boolean)param1Object).booleanValue()) {
                param1Object = SplashViewModel.RouteState.Welcome.INSTANCE;
              } else {
                param1Object = SplashViewModel.RouteState.WalkThrough.INSTANCE;
              } 
              param1Object = b1.emit(param1Object, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<Boolean> {
    public null(SplashViewModel$initialize$1$invokeSuspend$$inlined$map$1 param1SplashViewModel$initialize$1$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      if (((Boolean)param1Object).booleanValue()) {
        param1Object = SplashViewModel.RouteState.Welcome.INSTANCE;
      } else {
        param1Object = SplashViewModel.RouteState.WalkThrough.INSTANCE;
      } 
      param1Object = b1.emit(param1Object, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\splash\SplashViewModel$initialize$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
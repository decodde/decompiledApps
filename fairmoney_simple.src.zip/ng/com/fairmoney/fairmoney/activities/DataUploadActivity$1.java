package ng.com.fairmoney.fairmoney.activities;

public class null implements Runnable {
  public void run() {
    String str = message;
    DataUploadActivity.access$000(DataUploadActivity.this).setText(str);
    DataUploadActivity.access$000(DataUploadActivity.this).setVisibility(0);
    DataUploadActivity.access$100(DataUploadActivity.this).setVisibility(0);
    DataUploadActivity.access$100(DataUploadActivity.this).setEnabled(true);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.inversion;

import android.content.Context;
import android.telephony.TelephonyManager;
import f.d.b.k.e;
import javax.inject.Inject;
import kotlin.TypeCastException;

public final class NetworkCountryProviderImpl implements e {
  public final Context context;
  
  @Inject
  public NetworkCountryProviderImpl(Context paramContext) {
    this.context = paramContext;
  }
  
  public String getCountry() {
    Object object = this.context.getSystemService("phone");
    if (object != null)
      return ((TelephonyManager)object).getSimCountryIso(); 
    throw new TypeCastException("null cannot be cast to non-null type android.telephony.TelephonyManager");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\NetworkCountryProviderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.form.personal;

import f.d.b.k.a;
import j.k;
import j.n.d;
import j.n.i.c;
import k.a.h2.b;

public final class null implements b<a> {
  public null(FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1 paramFormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1) {}
  
  public Object emit(Object paramObject, d paramd) {
    b b1 = this.$this_unsafeFlow$inlined;
    if (((a)paramObject).a() == null) {
      paramObject = FormPersonalViewModel.FormPersonalState.Bvn.INSTANCE;
    } else {
      paramObject = FormPersonalViewModel.FormPersonalState.Work.INSTANCE;
    } 
    paramObject = b1.emit(paramObject, paramd);
    return (paramObject == c.a()) ? paramObject : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$goToNextActivity$1$invokeSuspend$$inlined$map$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.user;

import j.q.d.k;

public final class JsonAuthentication {
  public final String phone;
  
  public JsonAuthentication(String paramString) {
    this.phone = paramString;
  }
  
  public final String component1() {
    return this.phone;
  }
  
  public final com.fairmoney.data.user.JsonAuthentication copy(String paramString) {
    k.b(paramString, "phone");
    return new com.fairmoney.data.user.JsonAuthentication(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.user.JsonAuthentication) {
        paramObject = paramObject;
        if (k.a(this.phone, ((com.fairmoney.data.user.JsonAuthentication)paramObject).phone))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getPhone() {
    return this.phone;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.phone;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonAuthentication(phone=");
    stringBuilder.append(this.phone);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\dat\\user\JsonAuthentication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.kyc;

import com.fairmoney.data.JsonRequest;
import com.fairmoney.data.kyc.JsonKycStatus;
import com.fairmoney.data.kyc.JsonPan;
import k.a.h2.a;
import m.b0;
import m.w;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface KycService {
  @GET("/v2/android/users/{user_id}/kyc/in/is_claimed")
  a<JsonKycStatus> isClaimed(@Path("user_id") String paramString);
  
  @Multipart
  @POST("/v2/android/users/{user_id}/kyc/in/aadhaar_xml")
  a<Object> sendAadhaar(@Path("user_id") String paramString, @Part w.b paramb, @Part("file") b0 paramb01, @Part("share_code") b0 paramb02, @Part("version_code") b0 paramb03);
  
  @POST("/v2/android/users/{user_id}/kyc/in/pan")
  a<Object> sendPanNumber(@Path("user_id") String paramString, @Body JsonRequest<JsonPan> paramJsonRequest);
  
  @Multipart
  @POST("/v2/android/users/{user_id}/kyc/in/hyperverge_selfie")
  a<Object> verifySelfieLiveness(@Path("user_id") String paramString, @Part w.b paramb, @Part("file") b0 paramb01, @Part("hyperverge_liveness_check_response") b0 paramb02, @Part("version_code") b0 paramb03);
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\KycService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.data.inappmessaging;

import com.fairmoney.data.inappmessaging.JsonMessage;
import k.a.h2.a;
import retrofit2.http.GET;

public interface InAppMessagingService {
  @GET("/v2/android/messaging/in_app_message")
  a<JsonMessage> getMessage();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\inappmessaging\InAppMessagingService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
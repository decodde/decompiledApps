package ng.com.fairmoney.fairmoney.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;
import com.google.firebase.iid.FirebaseInstanceId;
import d.l.a.d;
import d.o.y;
import d.o.z;
import f.c.a.a;
import f.d.c.b;
import f.h.a.a.m.c;
import f.h.a.a.m.g;
import f.h.c.h.a;
import i.a.b.b;
import i.a.b.e;
import javax.inject.Inject;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.splash.SplashViewModel;
import ng.com.fairmoney.fairmoney.models.FirebaseToken;
import ng.com.fairmoney.fairmoney.network.APIResponse;
import ng.com.fairmoney.fairmoney.network.RetrofitSession;
import org.json.JSONException;
import org.json.JSONObject;

public class SplashActivity extends BaseActivity {
  @Inject
  public y.b factory;
  
  public SharedPreferences sharedPreferences;
  
  public SplashViewModel viewModel;
  
  private void getFcmToken() {
    FirebaseInstanceId.l().b().a(new c<a>() {
          public void onComplete(g<a> param1g) {
            if (!param1g.e()) {
              a.a(new Exception(param1g.a()));
              return;
            } 
            String str = null;
            if (param1g.b() != null)
              str = ((a)param1g.b()).getToken(); 
            if (str != null)
              SplashActivity.this.storeToken(str); 
          }
        });
  }
  
  private void saveReferralCode(String paramString) {
    this.sharedPreferences.edit().putString("et_form_purpose_referral_code", paramString).apply();
  }
  
  private void saveReferralSource(String paramString) {
    this.sharedPreferences.edit().putString("sp_form_purpose_referral_source", paramString).apply();
  }
  
  private void storeToken(String paramString) {
    FirebaseToken.storeToken((Context)this, paramString);
  }
  
  private void verifyDeprecatedVersion() {
    RetrofitSession.getInstance((Context)this).getAppUtilsManager().verifyDeprecatedVersion(new APIResponse<Object>() {
          public void failure(int param1Int, String param1String) {
            Toast.makeText((Context)SplashActivity.this, param1String, 0).show();
          }
          
          public void success(Object param1Object) {
            SplashActivity.this.viewModel.initialize();
          }
        });
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.viewModel = (SplashViewModel)z.a((d)this, this.factory).a(SplashViewModel.class);
    this.isAuthMandatory = false;
    if (!isTaskRoot() && getIntent().hasCategory("android.intent.category.LAUNCHER") && getIntent().getAction() != null && getIntent().getAction().equals("android.intent.action.MAIN")) {
      finish();
      return;
    } 
    this.sharedPreferences = getSharedPreferences("CurrentUser", 0);
    verifyDeprecatedVersion();
    getFcmToken();
  }
  
  public void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    setIntent(paramIntent);
  }
  
  public void onStart() {
    super.onStart();
    b.E().a(new b.f() {
          public void onInitFinished(JSONObject param1JSONObject, e param1e) {
            if (param1e == null)
              try {
                String str2 = param1JSONObject.getString("referral_code");
                if (str2 != null && !str2.isEmpty())
                  SplashActivity.this.saveReferralCode(str2); 
                String str1 = param1JSONObject.getString("referral_source");
                if (str1 != null && !str1.isEmpty())
                  SplashActivity.this.saveReferralSource(str1); 
              } catch (JSONException jSONException) {} 
          }
        },  getIntent().getData(), (Activity)this);
  }
  
  public int provideContentViewId() {
    return 2131492918;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\SplashActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
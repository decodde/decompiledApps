package ng.com.fairmoney.android.home.card;

import j.q.d.k;

public final class EarlyRepaymentSate {
  public final String amount;
  
  public final Integer discount;
  
  public final int duration;
  
  public final String issueWording;
  
  public final boolean neutralCurrency;
  
  public EarlyRepaymentSate(String paramString1, int paramInt, Integer paramInteger, String paramString2, boolean paramBoolean) {
    this.amount = paramString1;
    this.duration = paramInt;
    this.discount = paramInteger;
    this.issueWording = paramString2;
    this.neutralCurrency = paramBoolean;
  }
  
  public final String component1() {
    return this.amount;
  }
  
  public final int component2() {
    return this.duration;
  }
  
  public final Integer component3() {
    return this.discount;
  }
  
  public final String component4() {
    return this.issueWording;
  }
  
  public final boolean component5() {
    return this.neutralCurrency;
  }
  
  public final EarlyRepaymentSate copy(String paramString1, int paramInt, Integer paramInteger, String paramString2, boolean paramBoolean) {
    k.b(paramString1, "amount");
    k.b(paramString2, "issueWording");
    return new EarlyRepaymentSate(paramString1, paramInt, paramInteger, paramString2, paramBoolean);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof EarlyRepaymentSate) {
        paramObject = paramObject;
        if (k.a(this.amount, ((EarlyRepaymentSate)paramObject).amount) && this.duration == ((EarlyRepaymentSate)paramObject).duration && k.a(this.discount, ((EarlyRepaymentSate)paramObject).discount) && k.a(this.issueWording, ((EarlyRepaymentSate)paramObject).issueWording) && this.neutralCurrency == ((EarlyRepaymentSate)paramObject).neutralCurrency)
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getAmount() {
    return this.amount;
  }
  
  public final Integer getDiscount() {
    return this.discount;
  }
  
  public final int getDuration() {
    return this.duration;
  }
  
  public final String getIssueWording() {
    return this.issueWording;
  }
  
  public final boolean getNeutralCurrency() {
    return this.neutralCurrency;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    String str2 = this.amount;
    int i = 0;
    if (str2 != null) {
      b1 = str2.hashCode();
    } else {
      b1 = 0;
    } 
    int j = this.duration;
    Integer integer = this.discount;
    if (integer != null) {
      b2 = integer.hashCode();
    } else {
      b2 = 0;
    } 
    String str1 = this.issueWording;
    if (str1 != null)
      i = str1.hashCode(); 
    boolean bool1 = this.neutralCurrency;
    boolean bool2 = bool1;
    if (bool1)
      bool2 = true; 
    return (((b1 * 31 + j) * 31 + b2) * 31 + i) * 31 + bool2;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("EarlyRepaymentSate(amount=");
    stringBuilder.append(this.amount);
    stringBuilder.append(", duration=");
    stringBuilder.append(this.duration);
    stringBuilder.append(", discount=");
    stringBuilder.append(this.discount);
    stringBuilder.append(", issueWording=");
    stringBuilder.append(this.issueWording);
    stringBuilder.append(", neutralCurrency=");
    stringBuilder.append(this.neutralCurrency);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardViewModel$EarlyRepaymentSate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
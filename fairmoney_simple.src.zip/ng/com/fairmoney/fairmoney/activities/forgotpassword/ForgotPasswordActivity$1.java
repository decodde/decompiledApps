package ng.com.fairmoney.fairmoney.activities.forgotpassword;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;

public class null implements TextWatcher {
  public void afterTextChanged(Editable paramEditable) {
    boolean bool;
    Button button = ForgotPasswordActivity.access$100(ForgotPasswordActivity.this);
    if (ForgotPasswordActivity.access$000(ForgotPasswordActivity.this) && paramEditable.length() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    button.setEnabled(bool);
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\forgotpassword\ForgotPasswordActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
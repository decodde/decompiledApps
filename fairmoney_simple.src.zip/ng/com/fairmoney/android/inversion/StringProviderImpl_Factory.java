package ng.com.fairmoney.android.inversion;

import android.content.Context;
import g.b.d;
import javax.inject.Provider;

public final class StringProviderImpl_Factory implements d<StringProviderImpl> {
  public final Provider<Context> contextProvider;
  
  public StringProviderImpl_Factory(Provider<Context> paramProvider) {
    this.contextProvider = paramProvider;
  }
  
  public static StringProviderImpl_Factory create(Provider<Context> paramProvider) {
    return new StringProviderImpl_Factory(paramProvider);
  }
  
  public static StringProviderImpl newInstance(Context paramContext) {
    return new StringProviderImpl(paramContext);
  }
  
  public StringProviderImpl get() {
    return newInstance((Context)this.contextProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\StringProviderImpl_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.injection;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import javax.inject.Scope;

@Retention(RetentionPolicy.RUNTIME)
@Scope
public @interface ViewModelScope {}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\injection\ViewModelScope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
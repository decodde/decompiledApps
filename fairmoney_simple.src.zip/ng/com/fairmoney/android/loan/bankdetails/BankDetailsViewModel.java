package ng.com.fairmoney.android.loan.bankdetails;

import androidx.lifecycle.LiveData;
import d.o.p;
import d.o.w;
import d.o.x;
import f.d.b.c;
import f.d.b.i.e;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.c.q;
import j.q.d.g;
import j.q.d.k;
import j.v.d;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;

public final class BankDetailsViewModel extends w {
  public final d bankAccountRegex;
  
  public final LiveData<BankDetailsState> bankDetail;
  
  public final d ifscCodeRegex;
  
  public final e loanUseCase;
  
  public final p<BankDetailsState> mutableBankDetailsState;
  
  public final c router;
  
  @Inject
  public BankDetailsViewModel(e parame, c paramc) {
    this.loanUseCase = parame;
    this.router = paramc;
    this.ifscCodeRegex = new d("[A-Za-z]{4}0[A-Z0-9a-z]{6}");
    this.bankAccountRegex = new d("[A-Z0-9a-z]{9,18}");
    p<BankDetailsState> p1 = new p();
    this.mutableBankDetailsState = p1;
    this.bankDetail = (LiveData<BankDetailsState>)p1;
  }
  
  private final a<Boolean> validateBankAccount(String paramString) {
    return c.a(Boolean.valueOf(this.bankAccountRegex.a(paramString)));
  }
  
  private final a<Boolean> validateIfscCode(String paramString) {
    return c.a(Boolean.valueOf(this.ifscCodeRegex.a(paramString)));
  }
  
  public final LiveData<BankDetailsState> getBankDetail() {
    return this.bankDetail;
  }
  
  public final void onClickFindIfsc() {
    this.router.toBrowser(new URL("https://www.policybazaar.com/ifsc/"));
  }
  
  public final void onClickNext(String paramString1, String paramString2) {
    k.b(paramString1, "bankAccount");
    k.b(paramString2, "ifsc");
    c.a(c.a(c.b(c.b(c.a(c.a(c.a(validateIfscCode(paramString2), validateBankAccount(paramString1), new BankDetailsViewModel$onClickNext$1(null)), 0, new BankDetailsViewModel$onClickNext$2(paramString1, paramString2, null), 1, null), new BankDetailsViewModel$onClickNext$3(null)), new BankDetailsViewModel$onClickNext$4(null)), new BankDetailsViewModel$onClickNext$5(null)), new BankDetailsViewModel$onClickNext$6(null)), x.a(this));
  }
  
  public static abstract class BankDetailsState {
    public BankDetailsState() {}
    
    public static final class Exception extends BankDetailsState {
      public final String message;
      
      public Exception(String param2String) {
        super(null);
        this.message = param2String;
      }
      
      public final String component1() {
        return this.message;
      }
      
      public final Exception copy(String param2String) {
        return new Exception(param2String);
      }
      
      public boolean equals(Object param2Object) {
        if (this != param2Object) {
          if (param2Object instanceof Exception) {
            param2Object = param2Object;
            if (k.a(this.message, ((Exception)param2Object).message))
              return true; 
          } 
          return false;
        } 
        return true;
      }
      
      public final String getMessage() {
        return this.message;
      }
      
      public int hashCode() {
        boolean bool;
        String str = this.message;
        if (str != null) {
          bool = str.hashCode();
        } else {
          bool = false;
        } 
        return bool;
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Exception(message=");
        stringBuilder.append(this.message);
        stringBuilder.append(")");
        return stringBuilder.toString();
      }
    }
    
    public static final class InputErrors extends BankDetailsState {
      public final List<BankDetailsViewModel.BankDetailsStateError> errors;
      
      public InputErrors(List<? extends BankDetailsViewModel.BankDetailsStateError> param2List) {
        super(null);
        this.errors = (List)param2List;
      }
      
      public final List<BankDetailsViewModel.BankDetailsStateError> component1() {
        return this.errors;
      }
      
      public final InputErrors copy(List<? extends BankDetailsViewModel.BankDetailsStateError> param2List) {
        k.b(param2List, "errors");
        return new InputErrors(param2List);
      }
      
      public boolean equals(Object param2Object) {
        if (this != param2Object) {
          if (param2Object instanceof InputErrors) {
            param2Object = param2Object;
            if (k.a(this.errors, ((InputErrors)param2Object).errors))
              return true; 
          } 
          return false;
        } 
        return true;
      }
      
      public final List<BankDetailsViewModel.BankDetailsStateError> getErrors() {
        return this.errors;
      }
      
      public int hashCode() {
        boolean bool;
        List<BankDetailsViewModel.BankDetailsStateError> list = this.errors;
        if (list != null) {
          bool = list.hashCode();
        } else {
          bool = false;
        } 
        return bool;
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InputErrors(errors=");
        stringBuilder.append(this.errors);
        stringBuilder.append(")");
        return stringBuilder.toString();
      }
    }
    
    public static final class Loading extends BankDetailsState {
      public final boolean isLoading;
      
      public Loading(boolean param2Boolean) {
        super(null);
        this.isLoading = param2Boolean;
      }
      
      public final boolean component1() {
        return this.isLoading;
      }
      
      public final Loading copy(boolean param2Boolean) {
        return new Loading(param2Boolean);
      }
      
      public boolean equals(Object param2Object) {
        if (this != param2Object) {
          if (param2Object instanceof Loading) {
            param2Object = param2Object;
            if (this.isLoading == ((Loading)param2Object).isLoading)
              return true; 
          } 
          return false;
        } 
        return true;
      }
      
      public int hashCode() {
        boolean bool1 = this.isLoading;
        boolean bool2 = bool1;
        if (bool1)
          bool2 = true; 
        return bool2;
      }
      
      public final boolean isLoading() {
        return this.isLoading;
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Loading(isLoading=");
        stringBuilder.append(this.isLoading);
        stringBuilder.append(")");
        return stringBuilder.toString();
      }
    }
    
    public static final class Success extends BankDetailsState {
      public static final Success INSTANCE = new Success();
      
      public Success() {
        super(null);
      }
    }
  }
  
  public static final class Exception extends BankDetailsState {
    public final String message;
    
    public Exception(String param1String) {
      super(null);
      this.message = param1String;
    }
    
    public final String component1() {
      return this.message;
    }
    
    public final Exception copy(String param1String) {
      return new Exception(param1String);
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object instanceof Exception) {
          param1Object = param1Object;
          if (k.a(this.message, ((Exception)param1Object).message))
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final String getMessage() {
      return this.message;
    }
    
    public int hashCode() {
      boolean bool;
      String str = this.message;
      if (str != null) {
        bool = str.hashCode();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception(message=");
      stringBuilder.append(this.message);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class InputErrors extends BankDetailsState {
    public final List<BankDetailsViewModel.BankDetailsStateError> errors;
    
    public InputErrors(List<? extends BankDetailsViewModel.BankDetailsStateError> param1List) {
      super(null);
      this.errors = (List)param1List;
    }
    
    public final List<BankDetailsViewModel.BankDetailsStateError> component1() {
      return this.errors;
    }
    
    public final InputErrors copy(List<? extends BankDetailsViewModel.BankDetailsStateError> param1List) {
      k.b(param1List, "errors");
      return new InputErrors(param1List);
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object instanceof InputErrors) {
          param1Object = param1Object;
          if (k.a(this.errors, ((InputErrors)param1Object).errors))
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public final List<BankDetailsViewModel.BankDetailsStateError> getErrors() {
      return this.errors;
    }
    
    public int hashCode() {
      boolean bool;
      List<BankDetailsViewModel.BankDetailsStateError> list = this.errors;
      if (list != null) {
        bool = list.hashCode();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("InputErrors(errors=");
      stringBuilder.append(this.errors);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class Loading extends BankDetailsState {
    public final boolean isLoading;
    
    public Loading(boolean param1Boolean) {
      super(null);
      this.isLoading = param1Boolean;
    }
    
    public final boolean component1() {
      return this.isLoading;
    }
    
    public final Loading copy(boolean param1Boolean) {
      return new Loading(param1Boolean);
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object instanceof Loading) {
          param1Object = param1Object;
          if (this.isLoading == ((Loading)param1Object).isLoading)
            return true; 
        } 
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      boolean bool1 = this.isLoading;
      boolean bool2 = bool1;
      if (bool1)
        bool2 = true; 
      return bool2;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading(isLoading=");
      stringBuilder.append(this.isLoading);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public static final class Success extends BankDetailsState {
    public static final Success INSTANCE = new Success();
    
    public Success() {
      super(null);
    }
  }
  
  public static abstract class BankDetailsStateError {
    public BankDetailsStateError() {}
    
    public static final class BankAccountError extends BankDetailsStateError {
      public static final BankAccountError INSTANCE = new BankAccountError();
      
      public BankAccountError() {
        super(null);
      }
    }
    
    public static final class IfscError extends BankDetailsStateError {
      public static final IfscError INSTANCE = new IfscError();
      
      public IfscError() {
        super(null);
      }
    }
  }
  
  public static final class BankAccountError extends BankDetailsStateError {
    public static final BankAccountError INSTANCE = new BankAccountError();
    
    public BankAccountError() {
      super(null);
    }
  }
  
  public static final class IfscError extends BankDetailsStateError {
    public static final IfscError INSTANCE = new IfscError();
    
    public IfscError() {
      super(null);
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$1", f = "BankDetailsViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class BankDetailsViewModel$onClickNext$1 extends k implements q<Boolean, Boolean, d<? super BankDetailsState>, Object> {
    public int label;
    
    public boolean p$0;
    
    public boolean p$1;
    
    public BankDetailsViewModel$onClickNext$1(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(boolean param1Boolean1, boolean param1Boolean2, d<? super BankDetailsViewModel.BankDetailsState> param1d) {
      k.b(param1d, "continuation");
      BankDetailsViewModel$onClickNext$1 bankDetailsViewModel$onClickNext$1 = new BankDetailsViewModel$onClickNext$1(param1d);
      bankDetailsViewModel$onClickNext$1.p$0 = param1Boolean1;
      bankDetailsViewModel$onClickNext$1.p$1 = param1Boolean2;
      return (d<k>)bankDetailsViewModel$onClickNext$1;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((BankDetailsViewModel$onClickNext$1)create(((Boolean)param1Object1).booleanValue(), ((Boolean)param1Object2).booleanValue(), (d<? super BankDetailsViewModel.BankDetailsState>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        boolean bool1 = this.p$0;
        boolean bool2 = this.p$1;
        if (bool1 && bool2) {
          param1Object = BankDetailsViewModel.BankDetailsState.Success.INSTANCE;
        } else {
          param1Object = new ArrayList();
          if (!bool1)
            param1Object.add(BankDetailsViewModel.BankDetailsStateError.IfscError.INSTANCE); 
          if (!bool2)
            param1Object.add(BankDetailsViewModel.BankDetailsStateError.BankAccountError.INSTANCE); 
          param1Object = new BankDetailsViewModel.BankDetailsState.InputErrors((List<? extends BankDetailsViewModel.BankDetailsStateError>)param1Object);
        } 
        return param1Object;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$2", f = "BankDetailsViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class BankDetailsViewModel$onClickNext$2 extends k implements p<BankDetailsState, d<? super a<? extends BankDetailsState>>, Object> {
    public int label;
    
    public BankDetailsViewModel.BankDetailsState p$0;
    
    public BankDetailsViewModel$onClickNext$2(String param1String1, String param1String2, d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      BankDetailsViewModel$onClickNext$2 bankDetailsViewModel$onClickNext$2 = new BankDetailsViewModel$onClickNext$2(this.$bankAccount, this.$ifsc, param1d);
      bankDetailsViewModel$onClickNext$2.p$0 = (BankDetailsViewModel.BankDetailsState)param1Object;
      return (d<k>)bankDetailsViewModel$onClickNext$2;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((BankDetailsViewModel$onClickNext$2)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        if (k.a(param1Object, BankDetailsViewModel.BankDetailsState.Success.INSTANCE)) {
          param1Object = new BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1(BankDetailsViewModel.this.loanUseCase.a(this.$bankAccount, this.$ifsc));
        } else {
          param1Object = c.a(param1Object);
        } 
        return param1Object;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    public static final class BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1 implements a<BankDetailsViewModel.BankDetailsState.Success> {
      public BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1(a param1a) {}
      
      public Object collect(b param1b, d param1d) {
        Object object = this.$this_unsafeTransform$inlined.collect(new b<k>(this) {
              public Object emit(Object param1Object, d param1d) {
                b b1 = this.$this_unsafeFlow$inlined;
                param1Object = param1Object;
                param1Object = b1.emit(BankDetailsViewModel.BankDetailsState.Success.INSTANCE, param1d);
                return (param1Object == c.a()) ? param1Object : k.a;
              }
            }param1d);
        return (object == c.a()) ? object : k.a;
      }
    }
    
    public static final class null implements b<k> {
      public null(BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1 param1BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1) {}
      
      public Object emit(Object param1Object, d param1d) {
        b b1 = this.$this_unsafeFlow$inlined;
        param1Object = param1Object;
        param1Object = b1.emit(BankDetailsViewModel.BankDetailsState.Success.INSTANCE, param1d);
        return (param1Object == c.a()) ? param1Object : k.a;
      }
    }
  }
  
  public static final class BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1 implements a<BankDetailsState.Success> {
    public BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1(a param1a) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<k>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              param1Object = b1.emit(BankDetailsViewModel.BankDetailsState.Success.INSTANCE, param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<k> {
    public null(BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1 param1BankDetailsViewModel$onClickNext$2$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      param1Object = b1.emit(BankDetailsViewModel.BankDetailsState.Success.INSTANCE, param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$3", f = "BankDetailsViewModel.kt", l = {59}, m = "invokeSuspend")
  public static final class BankDetailsViewModel$onClickNext$3 extends k implements q<b<? super BankDetailsState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public BankDetailsViewModel$onClickNext$3(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super BankDetailsViewModel.BankDetailsState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1Throwable, "it");
      k.b(param1d, "continuation");
      BankDetailsViewModel$onClickNext$3 bankDetailsViewModel$onClickNext$3 = new BankDetailsViewModel$onClickNext$3(param1d);
      bankDetailsViewModel$onClickNext$3.p$ = param1b;
      bankDetailsViewModel$onClickNext$3.p$0 = param1Throwable;
      return (d<k>)bankDetailsViewModel$onClickNext$3;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((BankDetailsViewModel$onClickNext$3)create((b<? super BankDetailsViewModel.BankDetailsState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        Throwable throwable = this.p$0;
        param1Object = new BankDetailsViewModel.BankDetailsState.Exception(throwable.getMessage());
        this.L$0 = b1;
        this.L$1 = throwable;
        this.label = 1;
        if (b1.emit(param1Object, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$4", f = "BankDetailsViewModel.kt", l = {60}, m = "invokeSuspend")
  public static final class BankDetailsViewModel$onClickNext$4 extends k implements p<b<? super BankDetailsState>, d<? super k>, Object> {
    public Object L$0;
    
    public int label;
    
    public b p$;
    
    public BankDetailsViewModel$onClickNext$4(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      BankDetailsViewModel$onClickNext$4 bankDetailsViewModel$onClickNext$4 = new BankDetailsViewModel$onClickNext$4(param1d);
      bankDetailsViewModel$onClickNext$4.p$ = (b)param1Object;
      return (d<k>)bankDetailsViewModel$onClickNext$4;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((BankDetailsViewModel$onClickNext$4)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        b b1 = this.p$;
        param1Object = new BankDetailsViewModel.BankDetailsState.Loading(true);
        this.L$0 = b1;
        this.label = 1;
        if (b1.emit(param1Object, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$5", f = "BankDetailsViewModel.kt", l = {61}, m = "invokeSuspend")
  public static final class BankDetailsViewModel$onClickNext$5 extends k implements q<b<? super BankDetailsState>, Throwable, d<? super k>, Object> {
    public Object L$0;
    
    public Object L$1;
    
    public int label;
    
    public b p$;
    
    public Throwable p$0;
    
    public BankDetailsViewModel$onClickNext$5(d param1d) {
      super(3, param1d);
    }
    
    public final d<k> create(b<? super BankDetailsViewModel.BankDetailsState> param1b, Throwable param1Throwable, d<? super k> param1d) {
      k.b(param1b, "$this$create");
      k.b(param1d, "continuation");
      BankDetailsViewModel$onClickNext$5 bankDetailsViewModel$onClickNext$5 = new BankDetailsViewModel$onClickNext$5(param1d);
      bankDetailsViewModel$onClickNext$5.p$ = param1b;
      bankDetailsViewModel$onClickNext$5.p$0 = param1Throwable;
      return (d<k>)bankDetailsViewModel$onClickNext$5;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2, Object param1Object3) {
      return ((BankDetailsViewModel$onClickNext$5)create((b<? super BankDetailsViewModel.BankDetailsState>)param1Object1, (Throwable)param1Object2, (d<? super k>)param1Object3)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.a();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          object = this.L$1;
          object = this.L$0;
          g.a(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        g.a(param1Object);
        param1Object = this.p$;
        Throwable throwable = this.p$0;
        BankDetailsViewModel.BankDetailsState.Loading loading = new BankDetailsViewModel.BankDetailsState.Loading(false);
        this.L$0 = param1Object;
        this.L$1 = throwable;
        this.label = 1;
        if (param1Object.emit(loading, (d)this) == object)
          return object; 
      } 
      return k.a;
    }
  }
  
  @f(c = "ng.com.fairmoney.android.loan.bankdetails.BankDetailsViewModel$onClickNext$6", f = "BankDetailsViewModel.kt", l = {}, m = "invokeSuspend")
  public static final class BankDetailsViewModel$onClickNext$6 extends k implements p<BankDetailsState, d<? super k>, Object> {
    public int label;
    
    public BankDetailsViewModel.BankDetailsState p$0;
    
    public BankDetailsViewModel$onClickNext$6(d param1d) {
      super(2, param1d);
    }
    
    public final d<k> create(Object param1Object, d<?> param1d) {
      k.b(param1d, "completion");
      BankDetailsViewModel$onClickNext$6 bankDetailsViewModel$onClickNext$6 = new BankDetailsViewModel$onClickNext$6(param1d);
      bankDetailsViewModel$onClickNext$6.p$0 = (BankDetailsViewModel.BankDetailsState)param1Object;
      return (d<k>)bankDetailsViewModel$onClickNext$6;
    }
    
    public final Object invoke(Object param1Object1, Object param1Object2) {
      return ((BankDetailsViewModel$onClickNext$6)create(param1Object1, (d)param1Object2)).invokeSuspend(k.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.a();
      if (this.label == 0) {
        g.a(param1Object);
        param1Object = this.p$0;
        BankDetailsViewModel.this.mutableBankDetailsState.b(param1Object);
        if (param1Object instanceof BankDetailsViewModel.BankDetailsState.Success)
          BankDetailsViewModel.this.router.toFinalLoanOffer(); 
        return k.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\bankdetails\BankDetailsViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.repayment.methods;

import d.o.w;
import f.d.b.g.a;
import f.d.b.g.b;
import javax.inject.Inject;

public final class RepaymentMethodsViewModel extends w {
  public final b paymentMethods;
  
  @Inject
  public RepaymentMethodsViewModel(a parama) {
    this.paymentMethods = parama.a();
  }
  
  public final boolean isBankTransferEnabled() {
    return this.paymentMethods.a();
  }
  
  public final boolean isCardEnabled() {
    return this.paymentMethods.b();
  }
  
  public final boolean isUssdEnabled() {
    return this.paymentMethods.c();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\methods\RepaymentMethodsViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.offers;

import f.d.b.c;
import f.d.b.i.e;
import f.d.b.k.g;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class LoanOffersViewModel_Factory implements d<LoanOffersViewModel> {
  public final Provider<e> loanUseCaseProvider;
  
  public final Provider<c> routerProvider;
  
  public final Provider<g> userRepositoryProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public LoanOffersViewModel_Factory(Provider<e> paramProvider, Provider<g> paramProvider1, Provider<h> paramProvider2, Provider<c> paramProvider3) {
    this.loanUseCaseProvider = paramProvider;
    this.userRepositoryProvider = paramProvider1;
    this.userUseCaseProvider = paramProvider2;
    this.routerProvider = paramProvider3;
  }
  
  public static LoanOffersViewModel_Factory create(Provider<e> paramProvider, Provider<g> paramProvider1, Provider<h> paramProvider2, Provider<c> paramProvider3) {
    return new LoanOffersViewModel_Factory(paramProvider, paramProvider1, paramProvider2, paramProvider3);
  }
  
  public static LoanOffersViewModel newInstance(e parame, g paramg, h paramh, c paramc) {
    return new LoanOffersViewModel(parame, paramg, paramh, paramc);
  }
  
  public LoanOffersViewModel get() {
    return newInstance((e)this.loanUseCaseProvider.get(), (g)this.userRepositoryProvider.get(), (h)this.userUseCaseProvider.get(), (c)this.routerProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\offers\LoanOffersViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
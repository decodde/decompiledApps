package ng.com.fairmoney.android.loan.form.personal;

public final class Mbs extends FormPersonalViewModel.FormPersonalState {
  public static final Mbs INSTANCE = new Mbs();
  
  public Mbs() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\personal\FormPersonalViewModel$FormPersonalState$Mbs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.repayment.methods;

import f.d.b.g.a;
import g.b.d;
import javax.inject.Provider;

public final class RepaymentMethodsViewModel_Factory implements d<RepaymentMethodsViewModel> {
  public final Provider<a> featuresProvider;
  
  public RepaymentMethodsViewModel_Factory(Provider<a> paramProvider) {
    this.featuresProvider = paramProvider;
  }
  
  public static RepaymentMethodsViewModel_Factory create(Provider<a> paramProvider) {
    return new RepaymentMethodsViewModel_Factory(paramProvider);
  }
  
  public static RepaymentMethodsViewModel newInstance(a parama) {
    return new RepaymentMethodsViewModel(parama);
  }
  
  public RepaymentMethodsViewModel get() {
    return newInstance((a)this.featuresProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\methods\RepaymentMethodsViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
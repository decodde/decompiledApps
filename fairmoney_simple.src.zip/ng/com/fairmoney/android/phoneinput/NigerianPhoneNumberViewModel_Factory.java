package ng.com.fairmoney.android.phoneinput;

import g.b.d;

public final class NigerianPhoneNumberViewModel_Factory implements d<NigerianPhoneNumberViewModel> {
  public static NigerianPhoneNumberViewModel_Factory create() {
    return InstanceHolder.INSTANCE;
  }
  
  public static NigerianPhoneNumberViewModel newInstance() {
    return new NigerianPhoneNumberViewModel();
  }
  
  public NigerianPhoneNumberViewModel get() {
    return newInstance();
  }
  
  public static final class InstanceHolder {
    public static final NigerianPhoneNumberViewModel_Factory INSTANCE = new NigerianPhoneNumberViewModel_Factory();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\NigerianPhoneNumberViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

public final class Failure extends DataUploadViewModel.LoanOffersState {
  public final Throwable throwable;
  
  public Failure(Throwable paramThrowable) {
    super(null);
    this.throwable = paramThrowable;
  }
  
  public final Throwable getThrowable() {
    return this.throwable;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadViewModel$LoanOffersState$Failure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.payment.history;

import j.q.d.g;

public final class Companion {
  public Companion() {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryFragment$Companion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import f.d.b.i.c;
import j.q.d.g;
import java.util.List;

public abstract class LoanOffersState {
  public LoanOffersState() {}
  
  public static final class Failure extends LoanOffersState {
    public final Throwable throwable;
    
    public Failure(Throwable param2Throwable) {
      super(null);
      this.throwable = param2Throwable;
    }
    
    public final Throwable getThrowable() {
      return this.throwable;
    }
  }
  
  public static final class Loading extends LoanOffersState {
    public final boolean isLoading;
    
    public Loading(boolean param2Boolean) {
      super(null);
      this.isLoading = param2Boolean;
    }
    
    public final boolean isLoading() {
      return this.isLoading;
    }
  }
  
  public static final class Success extends LoanOffersState {
    public final List<c> loanOffers;
    
    public Success(List<c> param2List) {
      super(null);
      this.loanOffers = param2List;
    }
    
    public final List<c> getLoanOffers() {
      return this.loanOffers;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\DataUploadViewModel$LoanOffersState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
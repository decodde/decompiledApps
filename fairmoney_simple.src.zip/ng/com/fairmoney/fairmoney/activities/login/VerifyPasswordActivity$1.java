package ng.com.fairmoney.fairmoney.activities.login;

import ng.com.fairmoney.fairmoney.models.PhoneAuthentication;
import ng.com.fairmoney.fairmoney.models.Session;
import ng.com.fairmoney.fairmoney.models.UssdCode;
import ng.com.fairmoney.fairmoney.network.model.GenericApiResponse;

public class null extends GenericApiResponse<Session, UssdCode> {
  public void failure(int paramInt, String paramString, UssdCode paramUssdCode) {
    VerifyPasswordActivity.this.logLoginResult("Phone", false);
    if (paramInt == 12 || paramInt == 18) {
      VerifyPasswordActivity.access$100(VerifyPasswordActivity.this, phoneAuthentication.getPhone(), paramInt, paramUssdCode);
      return;
    } 
    VerifyPasswordActivity.this.showNewToastMessage(paramString, 0);
    VerifyPasswordActivity.this.makeButtonEnabled(true);
  }
  
  public void success(Session paramSession) {
    VerifyPasswordActivity.access$000(VerifyPasswordActivity.this, paramSession);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\VerifyPasswordActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
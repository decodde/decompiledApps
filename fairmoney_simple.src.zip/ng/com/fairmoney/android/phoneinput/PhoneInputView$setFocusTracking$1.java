package ng.com.fairmoney.android.phoneinput;

import android.content.Context;
import android.view.View;
import ng.com.fairmoney.fairmoney.models.ApplicationFormEvent;
import ng.com.fairmoney.fairmoney.utils.ApplicationFormTracker;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;

public final class PhoneInputView$setFocusTracking$1 implements View.OnFocusChangeListener {
  public PhoneInputView$setFocusTracking$1(String paramString) {}
  
  public final void onFocusChange(View paramView, boolean paramBoolean) {
    ApplicationFormEvent.FormEventType formEventType;
    Event event = new Event(this.$key, "form_input_focus_changed", 0, 4, null);
    if (paramBoolean) {
      formEventType = ApplicationFormEvent.FormEventType.GET_FOCUS;
    } else {
      formEventType = ApplicationFormEvent.FormEventType.RELEASE_FOCUS;
    } 
    ApplicationFormTracker.getInstance().addApplicationFormEvent(new ApplicationFormEvent((Context)PhoneInputView.this.getActivity(), formEventType, null, this.$key));
    Tracking.sendFormInputFocusChanged((Context)PhoneInputView.this.getActivity(), event, paramBoolean);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputView$setFocusTracking$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
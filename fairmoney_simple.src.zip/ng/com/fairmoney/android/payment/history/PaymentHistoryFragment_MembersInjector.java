package ng.com.fairmoney.android.payment.history;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class PaymentHistoryFragment_MembersInjector implements a<PaymentHistoryFragment> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public PaymentHistoryFragment_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<PaymentHistoryFragment> create(Provider<y.b> paramProvider) {
    return new PaymentHistoryFragment_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(PaymentHistoryFragment paramPaymentHistoryFragment, y.b paramb) {
    paramPaymentHistoryFragment.viewModelFactory = paramb;
  }
  
  public void injectMembers(PaymentHistoryFragment paramPaymentHistoryFragment) {
    injectViewModelFactory(paramPaymentHistoryFragment, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryFragment_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
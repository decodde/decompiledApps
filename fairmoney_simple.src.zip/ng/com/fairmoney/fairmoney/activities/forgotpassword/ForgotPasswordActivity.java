package ng.com.fairmoney.fairmoney.activities.forgotpassword;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.lifecycle.LiveData;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.d.b.k.f;
import f.d.c.b;
import java.io.Serializable;
import javax.inject.Inject;
import l.a.a.a.a.r.a;
import l.a.a.a.a.r.b;
import l.a.a.a.a.r.c;
import l.a.a.a.a.r.d;
import l.a.a.a.a.r.h;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;
import ng.com.fairmoney.fairmoney.activities.BaseActivity;
import ng.com.fairmoney.fairmoney.activities.WelcomeActivity;
import ng.com.fairmoney.fairmoney.activities.login.PhoneLoginActivity;

public class ForgotPasswordActivity extends BaseActivity {
  public Button btVerify;
  
  public boolean buttonEnabled = true;
  
  public ForgotPasswordViewModel viewModel;
  
  @Inject
  public y.b viewModelFactory;
  
  private void initPhoneInputView(PhoneInputView paramPhoneInputView) {
    paramPhoneInputView.setImeOptions(6);
    paramPhoneInputView.setOnEditorActionListener((TextView.OnEditorActionListener)new a(this, paramPhoneInputView));
    paramPhoneInputView.addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            boolean bool;
            Button button = ForgotPasswordActivity.this.btVerify;
            if (ForgotPasswordActivity.this.buttonEnabled && param1Editable.length() != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            button.setEnabled(bool);
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
  }
  
  private void initVerifyButton(PhoneInputView paramPhoneInputView) {
    this.btVerify.setOnClickListener((View.OnClickListener)new c(this, paramPhoneInputView));
  }
  
  private void makeButtonEnabled(boolean paramBoolean) {
    int i;
    this.btVerify.setEnabled(paramBoolean);
    Button button = this.btVerify;
    if (paramBoolean) {
      i = 2131821231;
    } else {
      i = 2131820897;
    } 
    button.setText(i);
    this.buttonEnabled = paramBoolean;
  }
  
  private void observeForgotPassword() {
    this.viewModel.getForgotPassword().a((l)this, (s)new d(this));
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    startActivity(new Intent((Context)this, WelcomeActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ViewModelComponentKt.create((b)getApplicationContext()).inject(this);
    this.viewModel = (ForgotPasswordViewModel)z.a((d)this, this.viewModelFactory).a(ForgotPasswordViewModel.class);
    observeForgotPassword();
    this.isAuthMandatory = false;
    PhoneInputView phoneInputView = (PhoneInputView)getSupportFragmentManager().a(2131296799);
    this.btVerify = (Button)findViewById(2131296386);
    initPhoneInputView(phoneInputView);
    initVerifyButton(phoneInputView);
    ((TextView)findViewById(2131297120)).setOnClickListener((View.OnClickListener)new b(this));
    LiveData liveData = this.viewModel.getPhoneNumber();
    phoneInputView.getClass();
    liveData.a((l)this, (s)new h(phoneInputView));
    this.viewModel.initialize();
  }
  
  public int provideContentViewId() {
    return 2131492894;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\forgotpassword\ForgotPasswordActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
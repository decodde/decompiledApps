package ng.com.fairmoney.android.loan.repayment;

import f.d.b.j.b;
import f.d.b.j.c;
import f.d.b.k.b;
import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;
import k.a.h2.a;
import k.a.h2.b;
import k.a.h2.c;
import kotlin.NoWhenBranchMatchedException;

@f(c = "ng.com.fairmoney.android.loan.repayment.HomeRepayAmountViewModel$onInboundPayment$1", f = "HomeRepayAmountViewModel.kt", l = {}, m = "invokeSuspend")
public final class HomeRepayAmountViewModel$onInboundPayment$1 extends k implements p<b, d<? super a<? extends HomeRepayAmountViewModel.HomeRepayAmountState>>, Object> {
  public int label;
  
  public b p$0;
  
  public HomeRepayAmountViewModel$onInboundPayment$1(c paramc, int paramInt, d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    HomeRepayAmountViewModel$onInboundPayment$1 homeRepayAmountViewModel$onInboundPayment$1 = new HomeRepayAmountViewModel$onInboundPayment$1(this.$inboundPaymentType, this.$amountInCent, paramd);
    homeRepayAmountViewModel$onInboundPayment$1.p$0 = (b)paramObject;
    return (d<k>)homeRepayAmountViewModel$onInboundPayment$1;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((HomeRepayAmountViewModel$onInboundPayment$1)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      if (k.a(this.p$0, b.b.h)) {
        paramObject = this.$inboundPaymentType;
        int i = HomeRepayAmountViewModel$WhenMappings.$EnumSwitchMapping$0[paramObject.ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i == 3) {
              paramObject = new HomeRepayAmountViewModel.HomeRepayAmountState.CustomAmount(this.$amountInCent);
            } else {
              throw new NoWhenBranchMatchedException();
            } 
          } else {
            paramObject = new HomeRepayAmountViewModel.HomeRepayAmountState.NextInstallment(this.$amountInCent);
          } 
        } else {
          paramObject = new HomeRepayAmountViewModel.HomeRepayAmountState.FullRepayment(this.$amountInCent);
        } 
        paramObject = c.a(paramObject);
      } else {
        paramObject = new HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1(this);
      } 
      return paramObject;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
  
  public static final class HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 implements a<HomeRepayAmountViewModel.HomeRepayAmountState.Inbound> {
    public HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1(HomeRepayAmountViewModel$onInboundPayment$1 param1HomeRepayAmountViewModel$onInboundPayment$1) {}
    
    public Object collect(b param1b, d param1d) {
      Object object = this.$this_unsafeTransform$inlined.collect(new b<b>(this) {
            public Object emit(Object param1Object, d param1d) {
              b b1 = this.$this_unsafeFlow$inlined;
              param1Object = param1Object;
              param1Object = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(HomeRepayAmountViewModel$onInboundPayment$1.this.$amountInCent, (b)param1Object), param1d);
              return (param1Object == c.a()) ? param1Object : k.a;
            }
          }param1d);
      return (object == c.a()) ? object : k.a;
    }
  }
  
  public static final class null implements b<b> {
    public null(HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1 param1HomeRepayAmountViewModel$onInboundPayment$1$invokeSuspend$$inlined$map$1) {}
    
    public Object emit(Object param1Object, d param1d) {
      b b1 = this.$this_unsafeFlow$inlined;
      param1Object = param1Object;
      param1Object = b1.emit(new HomeRepayAmountViewModel.HomeRepayAmountState.Inbound(HomeRepayAmountViewModel$onInboundPayment$1.this.$amountInCent, (b)param1Object), param1d);
      return (param1Object == c.a()) ? param1Object : k.a;
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\repayment\HomeRepayAmountViewModel$onInboundPayment$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
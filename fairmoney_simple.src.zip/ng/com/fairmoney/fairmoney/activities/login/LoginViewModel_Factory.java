package ng.com.fairmoney.fairmoney.activities.login;

import f.d.b.f.b;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class LoginViewModel_Factory implements d<LoginViewModel> {
  public final Provider<b> inAppMessagingUseCaseProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public LoginViewModel_Factory(Provider<b> paramProvider, Provider<h> paramProvider1) {
    this.inAppMessagingUseCaseProvider = paramProvider;
    this.userUseCaseProvider = paramProvider1;
  }
  
  public static LoginViewModel_Factory create(Provider<b> paramProvider, Provider<h> paramProvider1) {
    return new LoginViewModel_Factory(paramProvider, paramProvider1);
  }
  
  public static LoginViewModel newInstance(b paramb, h paramh) {
    return new LoginViewModel(paramb, paramh);
  }
  
  public LoginViewModel get() {
    return newInstance((b)this.inAppMessagingUseCaseProvider.get(), (h)this.userUseCaseProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\LoginViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
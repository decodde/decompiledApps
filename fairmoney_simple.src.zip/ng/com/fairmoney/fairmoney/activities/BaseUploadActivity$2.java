package ng.com.fairmoney.fairmoney.activities;

import android.location.Location;
import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<Object> {
  public void failure(int paramInt, String paramString) {
    BaseUploadActivity.access$300(BaseUploadActivity.this, location, paramString, retryCount);
  }
  
  public void success(Object paramObject) {
    BaseUploadActivity.access$200(BaseUploadActivity.this);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\BaseUploadActivity$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.phoneinput;

import d.o.y;
import g.a;
import javax.inject.Provider;

public final class PhoneInputView_MembersInjector implements a<PhoneInputView> {
  public final Provider<y.b> viewModelFactoryProvider;
  
  public PhoneInputView_MembersInjector(Provider<y.b> paramProvider) {
    this.viewModelFactoryProvider = paramProvider;
  }
  
  public static a<PhoneInputView> create(Provider<y.b> paramProvider) {
    return new PhoneInputView_MembersInjector(paramProvider);
  }
  
  public static void injectViewModelFactory(PhoneInputView paramPhoneInputView, y.b paramb) {
    paramPhoneInputView.viewModelFactory = paramb;
  }
  
  public void injectMembers(PhoneInputView paramPhoneInputView) {
    injectViewModelFactory(paramPhoneInputView, (y.b)this.viewModelFactoryProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputView_MembersInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
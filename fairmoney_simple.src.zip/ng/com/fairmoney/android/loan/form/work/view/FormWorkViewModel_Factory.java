package ng.com.fairmoney.android.loan.form.work.view;

import f.d.b.i.e;
import f.d.b.k.h;
import g.b.d;
import javax.inject.Provider;

public final class FormWorkViewModel_Factory implements d<FormWorkViewModel> {
  public final Provider<e> loanUseCaseProvider;
  
  public final Provider<ProfessionalMapper> professionalMapperProvider;
  
  public final Provider<h> userUseCaseProvider;
  
  public FormWorkViewModel_Factory(Provider<e> paramProvider, Provider<h> paramProvider1, Provider<ProfessionalMapper> paramProvider2) {
    this.loanUseCaseProvider = paramProvider;
    this.userUseCaseProvider = paramProvider1;
    this.professionalMapperProvider = paramProvider2;
  }
  
  public static FormWorkViewModel_Factory create(Provider<e> paramProvider, Provider<h> paramProvider1, Provider<ProfessionalMapper> paramProvider2) {
    return new FormWorkViewModel_Factory(paramProvider, paramProvider1, paramProvider2);
  }
  
  public static FormWorkViewModel newInstance(e parame, h paramh, ProfessionalMapper paramProfessionalMapper) {
    return new FormWorkViewModel(parame, paramh, paramProfessionalMapper);
  }
  
  public FormWorkViewModel get() {
    return newInstance((e)this.loanUseCaseProvider.get(), (h)this.userUseCaseProvider.get(), (ProfessionalMapper)this.professionalMapperProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\form\work\view\FormWorkViewModel_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
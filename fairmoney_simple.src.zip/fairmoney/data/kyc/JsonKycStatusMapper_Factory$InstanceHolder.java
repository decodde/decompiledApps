package fairmoney.data.kyc;

import com.fairmoney.data.kyc.JsonKycStatusMapper_Factory;

public final class InstanceHolder {
  public static final JsonKycStatusMapper_Factory INSTANCE = new JsonKycStatusMapper_Factory();
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\data\kyc\JsonKycStatusMapper_Factory$InstanceHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.loan.transfer;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import d.o.l;
import d.o.s;
import d.o.w;
import d.o.y;
import d.o.z;
import f.b.a.c;
import f.b.a.h;
import f.d.c.b;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;

public final class LoanTransferFragment extends Fragment {
  @Inject
  public y.b factory;
  
  public ImageView roundLoanTransferImage;
  
  public ImageView squareLoanTransferImage;
  
  public TextView tvLoanTransferText;
  
  public LoanTransferViewModel viewModel;
  
  public LoanTransferFragment() {
    super(2131492984);
  }
  
  private final void observeImageVisibility() {
    LoanTransferViewModel loanTransferViewModel = this.viewModel;
    if (loanTransferViewModel != null) {
      loanTransferViewModel.getLoanTransferDetails().a((l)this, new LoanTransferFragment$observeImageVisibility$1());
      return;
    } 
    k.d("viewModel");
    throw null;
  }
  
  public final y.b getFactory() {
    y.b b1 = this.factory;
    if (b1 != null)
      return b1; 
    k.d("factory");
    throw null;
  }
  
  public void onAttach(Context paramContext) {
    k.b(paramContext, "context");
    super.onAttach(paramContext);
    paramContext = paramContext.getApplicationContext();
    if (paramContext != null) {
      ViewModelComponentKt.create((b)paramContext).inject(this);
      y.b b1 = this.factory;
      if (b1 != null) {
        w w = z.a(this, b1).a(LoanTransferViewModel.class);
        k.a(w, "ViewModelProviders.of(th…ferViewModel::class.java)");
        this.viewModel = (LoanTransferViewModel)w;
        return;
      } 
      k.d("factory");
      throw null;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {
    k.b(paramView, "view");
    super.onViewCreated(paramView, paramBundle);
    View view = paramView.findViewById(2131296646);
    k.a(view, "view.findViewById(R.id.iv_loan_transfer_round)");
    this.roundLoanTransferImage = (ImageView)view;
    view = paramView.findViewById(2131296647);
    k.a(view, "view.findViewById(R.id.iv_loan_transfer_square)");
    this.squareLoanTransferImage = (ImageView)view;
    paramView = paramView.findViewById(2131297175);
    k.a(paramView, "view.findViewById(R.id.t…oan_transfer_description)");
    this.tvLoanTransferText = (TextView)paramView;
    observeImageVisibility();
    LoanTransferViewModel loanTransferViewModel = this.viewModel;
    if (loanTransferViewModel != null) {
      loanTransferViewModel.initialize();
      return;
    } 
    k.d("viewModel");
    throw null;
  }
  
  public final void setFactory(y.b paramb) {
    k.b(paramb, "<set-?>");
    this.factory = paramb;
  }
  
  public static final class LoanTransferFragment$observeImageVisibility$1<T> implements s<LoanTransferDetails> {
    public final void onChanged(LoanTransferDetails param1LoanTransferDetails) {
      if (param1LoanTransferDetails != null) {
        h h = c.a(LoanTransferFragment.this).a(Integer.valueOf(param1LoanTransferDetails.getIconRes()));
        if (param1LoanTransferDetails.getRoundIcon()) {
          imageView = LoanTransferFragment.access$getRoundLoanTransferImage$p(LoanTransferFragment.this);
        } else {
          imageView = LoanTransferFragment.access$getSquareLoanTransferImage$p(LoanTransferFragment.this);
        } 
        h.a(imageView);
        ImageView imageView = LoanTransferFragment.access$getRoundLoanTransferImage$p(LoanTransferFragment.this);
        boolean bool = param1LoanTransferDetails.getRoundIcon();
        boolean bool1 = false;
        if (bool) {
          b = 0;
        } else {
          b = 8;
        } 
        imageView.setVisibility(b);
        imageView = LoanTransferFragment.access$getSquareLoanTransferImage$p(LoanTransferFragment.this);
        byte b = bool1;
        if (param1LoanTransferDetails.getRoundIcon())
          b = 8; 
        imageView.setVisibility(b);
        LoanTransferFragment.access$getTvLoanTransferText$p(LoanTransferFragment.this).setText(LoanTransferFragment.this.getString(param1LoanTransferDetails.getTextRes()));
      } 
    }
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\loan\transfer\LoanTransferFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
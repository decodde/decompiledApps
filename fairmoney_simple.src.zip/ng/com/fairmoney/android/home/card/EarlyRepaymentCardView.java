package ng.com.fairmoney.android.home.card;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import d.i.f.a;
import d.l.a.d;
import d.o.l;
import d.o.s;
import d.o.y;
import d.o.z;
import f.d.c.b;
import j.q.d.g;
import j.q.d.k;
import javax.inject.Inject;
import kotlin.TypeCastException;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;

public final class EarlyRepaymentCardView extends LinearLayout {
  @Inject
  public y.b viewModelFactory;
  
  public EarlyRepaymentCardView(Context paramContext) {
    this(paramContext, null, 0, 6, null);
  }
  
  public EarlyRepaymentCardView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0, 4, null);
  }
  
  public EarlyRepaymentCardView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    LayoutInflater.from(paramContext).inflate(2131492929, (ViewGroup)this, true);
    setOrientation(1);
    setGravity(1);
    setBackground(a.c(paramContext, 2131231114));
    Context context = paramContext.getApplicationContext();
    if (context != null) {
      EarlyRepaymentCardViewModel earlyRepaymentCardViewModel;
      ViewModelComponentKt.create((b)context).inject(this);
      if (paramContext instanceof Fragment) {
        Fragment fragment = (Fragment)paramContext;
        y.b b1 = this.viewModelFactory;
        if (b1 != null) {
          earlyRepaymentCardViewModel = (EarlyRepaymentCardViewModel)z.a(fragment, b1).a(EarlyRepaymentCardViewModel.class);
        } else {
          k.d("viewModelFactory");
          throw null;
        } 
      } else if (paramContext instanceof d) {
        d d = (d)paramContext;
        y.b b1 = this.viewModelFactory;
        if (b1 != null) {
          earlyRepaymentCardViewModel = (EarlyRepaymentCardViewModel)z.a(d, b1).a(EarlyRepaymentCardViewModel.class);
        } else {
          k.d("viewModelFactory");
          throw null;
        } 
      } else {
        throw new IllegalArgumentException("Parent must be Fragment or FragmentACtivity");
      } 
      k.a(earlyRepaymentCardViewModel, "when (context) {\n       …gmentACtivity\")\n        }");
      earlyRepaymentCardViewModel.getState().a((l)paramContext, new s<EarlyRepaymentCardViewModel.EarlyRepaymentSate>(paramContext) {
            public final void onChanged(EarlyRepaymentCardViewModel.EarlyRepaymentSate param1EarlyRepaymentSate) {
              View view = EarlyRepaymentCardView.this.findViewById(2131296333);
              k.a(view, "findViewById<TextView>(R.id.amount_and_duration)");
              ((TextView)view).setText(this.$context.getString(2131820855, new Object[] { param1EarlyRepaymentSate.getAmount(), Integer.valueOf(param1EarlyRepaymentSate.getDuration()) }));
              if (param1EarlyRepaymentSate.getDiscount() != null) {
                view = EarlyRepaymentCardView.this.findViewById(2131296493);
                k.a(view, "findViewById<TextView>(R.id.discount)");
                ((TextView)view).setText(this.$context.getString(2131820742, new Object[] { param1EarlyRepaymentSate.getDiscount() }));
              } else {
                view = EarlyRepaymentCardView.this.findViewById(2131296494);
                k.a(view, "findViewById<View>(R.id.discount_container)");
                view.setVisibility(8);
              } 
              view = EarlyRepaymentCardView.this.findViewById(2131296846);
              k.a(view, "findViewById<TextView>(R.id.reapplication)");
              ((TextView)view).setText(this.$context.getString(2131820880, new Object[] { param1EarlyRepaymentSate.getIssueWording() }));
              if (param1EarlyRepaymentSate.getNeutralCurrency())
                ((ImageView)EarlyRepaymentCardView.this.findViewById(2131296649)).setImageDrawable(a.c(this.$context, 2131231037)); 
            }
          });
      earlyRepaymentCardViewModel.initialize();
      return;
    } 
    throw new TypeCastException("null cannot be cast to non-null type com.fairmoney.injection.ComponentProvider");
  }
  
  public final y.b getViewModelFactory() {
    y.b b1 = this.viewModelFactory;
    if (b1 != null)
      return b1; 
    k.d("viewModelFactory");
    throw null;
  }
  
  public final void setViewModelFactory(y.b paramb) {
    k.b(paramb, "<set-?>");
    this.viewModelFactory = paramb;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\home\card\EarlyRepaymentCardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.inversion;

import android.content.Context;
import g.b.d;
import javax.inject.Provider;

public final class RouterImpl_Factory implements d<RouterImpl> {
  public final Provider<Context> contextProvider;
  
  public final Provider<CurrentActivityProvider> currentActivityProvider;
  
  public RouterImpl_Factory(Provider<Context> paramProvider, Provider<CurrentActivityProvider> paramProvider1) {
    this.contextProvider = paramProvider;
    this.currentActivityProvider = paramProvider1;
  }
  
  public static RouterImpl_Factory create(Provider<Context> paramProvider, Provider<CurrentActivityProvider> paramProvider1) {
    return new RouterImpl_Factory(paramProvider, paramProvider1);
  }
  
  public static RouterImpl newInstance(Context paramContext, CurrentActivityProvider paramCurrentActivityProvider) {
    return new RouterImpl(paramContext, paramCurrentActivityProvider);
  }
  
  public RouterImpl get() {
    return newInstance((Context)this.contextProvider.get(), (CurrentActivityProvider)this.currentActivityProvider.get());
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\inversion\RouterImpl_Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
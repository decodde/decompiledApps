package ng.com.fairmoney.fairmoney.activities.form;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.TextView;
import d.b.k.c;
import d.l.a.d;
import d.o.y;
import d.o.z;
import f.d.c.b;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import l.a.a.a.a.s.b;
import ng.com.fairmoney.android.injection.ViewModelComponentKt;
import ng.com.fairmoney.fairmoney.utils.Event;
import ng.com.fairmoney.fairmoney.utils.Tracking;
import ng.com.fairmoney.fairmoney.utils.Utils;
import ng.com.fairmoney.fairmoney.viewmodels.FormLoanPurposeViewModel;
import ng.com.fairmoney.fairmoney.views.DrawableRightClick;
import ng.com.fairmoney.fairmoney.views.StyledSpinner;

public class FormLoanPurposeActivity extends FormActivity {
  public FormLoanPurposeViewModel formLoanPurposeViewModel;
  
  @Inject
  public y.b viewModelFactory;
  
  private void initLoanPurposeSpinner() {
    ((StyledSpinner)findViewById(2131296933)).setAdapter((ListAdapter)ArrayAdapter.createFromResource((Context)this, getResources().getIdentifier("loanPurpose", "array", getPackageName()), 17367049));
  }
  
  private void initReferralCodeEditText() {
    ((EditText)findViewById(2131296547)).setFilters(new InputFilter[] { (InputFilter)new InputFilter.AllCaps() });
  }
  
  private void initReferralSpinner() {
    ((StyledSpinner)findViewById(2131296934)).setAdapter((ListAdapter)ArrayAdapter.createFromResource((Context)this, getResources().getIdentifier("referral", "array", getPackageName()), 17367049));
  }
  
  public List<Map<String, String>> getFormParameters() {
    return Utils.getActivityConfigValue((Context)this, 2131755012);
  }
  
  public void goToNextActivity() {
    startActivity(new Intent(getApplicationContext(), PermissionsActivity.class));
    finish();
  }
  
  public void goToPreviousActivity() {
    startActivity(new Intent(getApplicationContext(), FormGuarantorActivity.class));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    byte b1;
    super.onCreate(paramBundle);
    initLoanPurposeSpinner();
    initReferralSpinner();
    fillFormWithPreviousResponses();
    initBackButton(2131296634);
    ViewModelComponentKt.create((b)getApplication()).inject(this);
    this.formLoanPurposeViewModel = (FormLoanPurposeViewModel)z.a((d)this, this.viewModelFactory).a(FormLoanPurposeViewModel.class);
    View view = findViewById(2131296934);
    boolean bool = this.formLoanPurposeViewModel.getMarketingSourceVisibility();
    boolean bool1 = false;
    if (bool) {
      b1 = 0;
    } else {
      b1 = 8;
    } 
    view.setVisibility(b1);
    view = findViewById(2131297013);
    if (this.formLoanPurposeViewModel.getReferralCodeVisibility()) {
      b1 = bool1;
    } else {
      b1 = 8;
    } 
    view.setVisibility(b1);
    if (this.formLoanPurposeViewModel.getReferralCodeVisibility())
      initReferralCodeEditText(); 
    Tracking.sendUniqueEvent((Context)this, new Event("form", "loanPurpose"));
    EditText editText = (EditText)findViewById(2131296546);
    editText.setCompoundDrawablesWithIntrinsicBounds(null, null, getResources().getDrawable(2131231015), null);
    editText.setOnTouchListener((View.OnTouchListener)new DrawableRightClick((TextView)editText, (DrawableRightClick.DrawableRightClickListener)new b(this)));
  }
  
  public int provideContentViewId() {
    return 2131492901;
  }
  
  public void showExplanationsDialog() {
    c.a a = new c.a((Context)this);
    a.c(2131820931);
    a.b(2131820930);
    a.c(2131821021, new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            param1DialogInterface.cancel();
          }
        });
    a.c();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormLoanPurposeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
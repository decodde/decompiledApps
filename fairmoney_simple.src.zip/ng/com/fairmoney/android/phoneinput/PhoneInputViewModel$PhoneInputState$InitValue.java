package ng.com.fairmoney.android.phoneinput;

import f.d.b.k.f;

public final class InitValue extends PhoneInputViewModel.PhoneInputState {
  public final f phoneNumber;
  
  public InitValue(f paramf) {
    super(null);
    this.phoneNumber = paramf;
  }
  
  public final f getPhoneNumber() {
    return this.phoneNumber;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\phoneinput\PhoneInputViewModel$PhoneInputState$InitValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
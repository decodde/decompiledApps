package ng.com.fairmoney.fairmoney.activities;

import android.content.Context;
import com.android.volley.VolleyError;
import f.a.b.k;
import ng.com.fairmoney.fairmoney.network.BackendApi;

public class null implements k.a {
  public void onErrorResponse(VolleyError paramVolleyError) {
    BackendApi.checkServerError((Context)this.this$1.this$0, paramVolleyError);
    String str = BackendApi.getErrorMessageAccordingTo((Context)this.this$1.this$0, paramVolleyError);
    this.this$1.this$0.showNewToastMessage(str, 1);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\OfferDeclinedActivity$1$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.login.forgot;

import j.g;
import j.k;
import j.n.d;
import j.n.i.c;
import j.n.j.a.f;
import j.n.j.a.k;
import j.q.c.p;
import j.q.d.k;

@f(c = "ng.com.fairmoney.android.login.forgot.ForgotPasswordViewModel$onForgotPassword$5", f = "ForgotPasswordViewModel.kt", l = {}, m = "invokeSuspend")
public final class ForgotPasswordViewModel$onForgotPassword$5 extends k implements p<ForgotPasswordViewModel.ForgotPasswordState.Success, d<? super k>, Object> {
  public int label;
  
  public ForgotPasswordViewModel.ForgotPasswordState.Success p$0;
  
  public ForgotPasswordViewModel$onForgotPassword$5(d paramd) {
    super(2, paramd);
  }
  
  public final d<k> create(Object paramObject, d<?> paramd) {
    k.b(paramd, "completion");
    ForgotPasswordViewModel$onForgotPassword$5 forgotPasswordViewModel$onForgotPassword$5 = new ForgotPasswordViewModel$onForgotPassword$5(paramd);
    forgotPasswordViewModel$onForgotPassword$5.p$0 = (ForgotPasswordViewModel.ForgotPasswordState.Success)paramObject;
    return (d<k>)forgotPasswordViewModel$onForgotPassword$5;
  }
  
  public final Object invoke(Object paramObject1, Object paramObject2) {
    return ((ForgotPasswordViewModel$onForgotPassword$5)create(paramObject1, (d)paramObject2)).invokeSuspend(k.a);
  }
  
  public final Object invokeSuspend(Object paramObject) {
    c.a();
    if (this.label == 0) {
      g.a(paramObject);
      paramObject = this.p$0;
      ForgotPasswordViewModel.access$getMutableForgotPassword$p(ForgotPasswordViewModel.this).b(paramObject);
      return k.a;
    } 
    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordViewModel$onForgotPassword$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
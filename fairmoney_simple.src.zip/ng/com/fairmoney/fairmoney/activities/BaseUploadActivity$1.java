package ng.com.fairmoney.fairmoney.activities;

import ng.com.fairmoney.fairmoney.network.APIResponse;

public class null implements APIResponse<Object> {
  public void failure(int paramInt, String paramString) {
    BaseUploadActivity.access$100(BaseUploadActivity.this, paramString);
  }
  
  public void success(Object paramObject) {
    BaseUploadActivity.access$000(BaseUploadActivity.this);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\BaseUploadActivity$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities.form;

import android.view.View;

public class null implements View.OnFocusChangeListener {
  public void onFocusChange(View paramView, boolean paramBoolean) {
    byte b;
    paramView = FormBankActivity.this.findViewById(2131297056);
    if (paramBoolean) {
      b = 0;
    } else {
      b = 8;
    } 
    paramView.setVisibility(b);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\form\FormBankActivity$7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
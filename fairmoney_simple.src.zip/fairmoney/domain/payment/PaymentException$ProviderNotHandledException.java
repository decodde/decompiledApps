package fairmoney.domain.payment;

import com.fairmoney.domain.payment.PaymentException;

public final class ProviderNotHandledException extends PaymentException {
  public static final ProviderNotHandledException f = new ProviderNotHandledException();
  
  public ProviderNotHandledException() {
    super(null);
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\domain\payment\PaymentException$ProviderNotHandledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
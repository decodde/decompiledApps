package ng.com.fairmoney.fairmoney.activities.login;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import ng.com.fairmoney.android.phoneinput.PhoneInputView;

public class PhoneTextWatcher implements TextWatcher {
  public EditText etPassword;
  
  public PhoneTextWatcher(EditText paramEditText) {
    this.etPassword = paramEditText;
  }
  
  public void afterTextChanged(Editable paramEditable) {
    if (this.etPassword.length() == 4) {
      Button button = PhoneLoginActivity.access$500(PhoneLoginActivity.this);
      PhoneInputView phoneInputView = PhoneLoginActivity.this.pivLogin;
      boolean bool = false;
      if (phoneInputView.getPhoneNumber(false) != null)
        bool = true; 
      button.setEnabled(bool);
    } 
  }
  
  public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\login\PhoneLoginActivity$PhoneTextWatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package fairmoney.domain.payment;

import j.q.d.g;

public abstract class PaymentException extends Exception {
  public PaymentException() {}
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\domain\payment\PaymentException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
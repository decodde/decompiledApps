package ng.com.fairmoney.fairmoney.activities.form.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.EditText;
import com.google.gson.Gson;
import java.util.Map;
import ng.com.fairmoney.android.loan.form.work.view.ProfessionalStatus;
import ng.com.fairmoney.fairmoney.views.StyledSpinner;

public class SpinnerUtils {
  public static final Gson gson = new Gson();
  
  @Deprecated
  public static void fillStyledSpinner(Activity paramActivity, SharedPreferences paramSharedPreferences, Map<String, String> paramMap, int paramInt) {
    StyledSpinner styledSpinner = (StyledSpinner)paramActivity.findViewById(paramInt);
    if (!paramSharedPreferences.getString(paramMap.get("id"), "").isEmpty())
      try {
        ProfessionalStatus professionalStatus = (ProfessionalStatus)gson.fromJson(paramSharedPreferences.getString(paramMap.get("id"), ""), ProfessionalStatus.class);
        styledSpinner.setText(professionalStatus.getDescription());
        styledSpinner.setPosition(professionalStatus.getPosition());
      } catch (Exception exception) {
        styledSpinner.setText(paramSharedPreferences.getString(paramMap.get("id"), ""));
      }  
  }
  
  public static Object getStyledSpinnerAnswer(Activity paramActivity, int paramInt) {
    StyledSpinner styledSpinner = (StyledSpinner)paramActivity.findViewById(paramInt);
    if (styledSpinner.getPosition() != -1) {
      Object object = styledSpinner.getAdapter().getItem(styledSpinner.getPosition());
      if (object instanceof ProfessionalStatus)
        return object; 
    } 
    return styledSpinner.getText().toString();
  }
  
  public static boolean isBankSpinnerValid(Context paramContext, StyledSpinner paramStyledSpinner, EditText paramEditText) {
    if (isIncorrectlyFilled(paramContext, paramStyledSpinner, paramContext.getString(2131821029, new Object[] { "Bank name" }))) {
      paramStyledSpinner.setTextColor(-65536);
      paramStyledSpinner.setText(paramContext.getString(2131821029, new Object[] { "Bank name" }));
      return false;
    } 
    if (paramStyledSpinner.getText().toString().contains("Wema Bank")) {
      paramStyledSpinner.setTextColor(-65536);
      paramStyledSpinner.setText(2131821245);
      return false;
    } 
    if (paramStyledSpinner.getText().toString().contains("Ecobank") && ((paramEditText.getText().toString().length() > 2 && paramEditText.getText().toString().substring(0, 3).contentEquals("800")) || paramStyledSpinner.getText().toString().equals(paramContext.getString(2131820748)))) {
      paramStyledSpinner.setTextColor(-65536);
      paramStyledSpinner.setText(2131820748);
      return false;
    } 
    return true;
  }
  
  public static boolean isIncorrectlyFilled(Context paramContext, StyledSpinner paramStyledSpinner, String paramString) {
    return (paramStyledSpinner.getText().toString().contentEquals("") || paramStyledSpinner.getText().toString().contentEquals(paramString) || paramStyledSpinner.getText().toString().contentEquals(paramContext.getString(2131821147)));
  }
  
  public static boolean isStyledSpinnerValid(Activity paramActivity, Map<String, String> paramMap, int paramInt) {
    StyledSpinner styledSpinner = (StyledSpinner)paramActivity.findViewById(paramInt);
    if (isIncorrectlyFilled((Context)paramActivity, styledSpinner, paramActivity.getString(2131821029, new Object[] { paramMap.get("display_name") }))) {
      styledSpinner.setTextColor(-65536);
      styledSpinner.setText(paramActivity.getString(2131821029, new Object[] { paramMap.get("display_name") }));
      return false;
    } 
    if (paramInt == 2131296928) {
      if (styledSpinner.getText().toString().contains("Wema Bank")) {
        styledSpinner.setTextColor(-65536);
        styledSpinner.setText(2131821245);
        return false;
      } 
      if (styledSpinner.getText().toString().contains("Ecobank")) {
        EditText editText = (EditText)paramActivity.findViewById(2131296522);
        if ((editText.getText().toString().length() > 2 && editText.getText().toString().substring(0, 3).contentEquals("800")) || styledSpinner.getText().toString().equals(paramActivity.getString(2131820748))) {
          styledSpinner.setTextColor(-65536);
          styledSpinner.setText(2131820748);
          return false;
        } 
      } 
    } 
    return true;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\for\\utils\SpinnerUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.fairmoney.activities;

import f.d.b.i.c;

public final class Success extends FinalLoanOfferViewModel.SelectedLoanOfferState {
  public final c loanOffer;
  
  public Success(c paramc) {
    super(null);
    this.loanOffer = paramc;
  }
  
  public final c getLoanOffer() {
    return this.loanOffer;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\fairmoney\activities\FinalLoanOfferViewModel$SelectedLoanOfferState$Success.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
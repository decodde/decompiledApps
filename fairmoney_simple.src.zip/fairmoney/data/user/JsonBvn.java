package fairmoney.data.user;

import j.q.d.k;

public final class JsonBvn {
  public final String bvn;
  
  public JsonBvn(String paramString) {
    this.bvn = paramString;
  }
  
  public final String component1() {
    return this.bvn;
  }
  
  public final com.fairmoney.data.user.JsonBvn copy(String paramString) {
    return new com.fairmoney.data.user.JsonBvn(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof com.fairmoney.data.user.JsonBvn) {
        paramObject = paramObject;
        if (k.a(this.bvn, ((com.fairmoney.data.user.JsonBvn)paramObject).bvn))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public final String getBvn() {
    return this.bvn;
  }
  
  public int hashCode() {
    boolean bool;
    String str = this.bvn;
    if (str != null) {
      bool = str.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("JsonBvn(bvn=");
    stringBuilder.append(this.bvn);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\fairmoney\dat\\user\JsonBvn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package ng.com.fairmoney.android.login.forgot;

import f.d.b.k.f;

public final class Success extends ForgotPasswordViewModel.ForgotPasswordState {
  public final f phoneNumber;
  
  public final String ussdCode;
  
  public Success(f paramf, String paramString) {
    super(null);
    this.phoneNumber = paramf;
    this.ussdCode = paramString;
  }
  
  public final f getPhoneNumber() {
    return this.phoneNumber;
  }
  
  public final String getUssdCode() {
    return this.ussdCode;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\login\forgot\ForgotPasswordViewModel$ForgotPasswordState$Success.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
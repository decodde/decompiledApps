package ng.com.fairmoney.android.payment.history;

import f.d.b.j.a;
import j.k;
import j.n.d;
import j.n.i.c;
import java.util.List;
import k.a.h2.a;
import k.a.h2.b;

public final class PaymentHistoryViewModel$fetchBills$$inlined$map$1 implements a<PaymentHistoryViewModel.BillState> {
  public PaymentHistoryViewModel$fetchBills$$inlined$map$1(a parama) {}
  
  public Object collect(b paramb, d paramd) {
    Object object = this.$this_unsafeTransform$inlined.collect(new b<List<? extends a>>(this) {
          public Object emit(Object param1Object, d param1d) {
            b b1 = this.$this_unsafeFlow$inlined;
            param1Object = param1Object;
            if (param1Object.isEmpty()) {
              param1Object = PaymentHistoryViewModel.BillState.Empty.INSTANCE;
            } else {
              param1Object = new PaymentHistoryViewModel.BillState.Success((List<a>)param1Object);
            } 
            param1Object = b1.emit(param1Object, param1d);
            return (param1Object == c.a()) ? param1Object : k.a;
          }
        }paramd);
    return (object == c.a()) ? object : k.a;
  }
}


/* Location:              C:\Users\decodde\Documents\aPPS\decompiledApps\fairmoney_simple\!\ng\com\fairmoney\android\payment\history\PaymentHistoryViewModel$fetchBills$$inlined$map$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */